package datadupScripts;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import configuration.PropertyReader;
import interaction.api.ApiConfig;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.BodyFromFile;
import logs.Log;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.annotations.Test;
import testHelp.Utils;

public class adminUsers {

    @Test
    public void createAdminUsers() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
        UsersPage.getPage().navigate();


        for (String team : ReportingInfo.ALLTEAMS) apiCallString(team);

        PageConfiguration.getPage().quit();
    }

    public void apiCallString(String team) {
        String json = "{\"formJson\":\"{\\\"email\\\":\\\""+team+"@rainfocus.com\\\",\\\"firstname\\\":\\\""+team+"\\\",\\\"lastname\\\":\\\"automation\\\",\\\"navColor\\\":\\\"Pink\\\",\\\"dashboard\\\":\\\"birst\\\",\\\"superuserall\\\":true,\\\"canbulkrefund\\\":false}\""+
                ",\"forceUserToChangePassword\":\"false\",\"password\":\"R@infocus123\",\"confirmPassword\":\"R@infocus123\",\"currentPassword\":\"\",\"showingpw\":\"true\","+
        "\"securityRoleMapJson\":\"{\\\"WDhrQi36D8KWFBBhGxp8B8xUsOIlqD3hnLQGkiZO\\\":[\\\"role.system.admin\\\"]}\",\"orgCodes\":\"WDhrQi36D8KWFBBhGxp8B8xUsOIlqD3hnLQGkiZO\",\"selectedEventFamilyIds\":[],\"selectedDataAccessGroups\":[]}";

        String url = PropertyReader.instance().getProperty("adminUrl") + "/processUser.focus";
        final ApiConfig apiConfig = new ApiConfig(url, json);
        apiConfig.setContentType("application/json");
        PageConfiguration.getPage().post(apiConfig);
        Log.info(apiConfig.getResponse().toString(), getClass());
    }
}
