import configuration.PropertyReader;
import interaction.api.ApiConfig;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.ApiBodies.ApiObject;
import interaction.api.apiObjects.ApiBodyFactory;
import interaction.api.apiObjects.BodyFromFile;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.MyJson;
import testHelp.Utils;

public class ApiJsonTests {

    private String json = "  {\n" +
            "  \"subTest\": [\n" +
            "    {\n" +
            "      \"test2\": false,\n" +
            "      \"test3\": \"string\"\n" +
            "    }\n" +
            "  ],\n" +
            "  \"others\": [\n" +
            "    1,\n" +
            "    2.2,\n" +
            "    1234,\n" +
            "    3\n" +
            "  ],\n" +
            "  \"test1\": 10\n" +
            "}";

    @Test
    public void getOriginalValues() {
        final ApiBody apiBody = ApiBodyFactory.parseJson(json);

        Assert.assertEquals(apiBody.get("test2").getOriginalValue(), false);
        Assert.assertEquals(apiBody.get("test3").getOriginalValue(), "string");
        Assert.assertEquals(apiBody.get("subTest", "0", "test2").getOriginalValue(), false);
        Assert.assertEquals(apiBody.get("subTest", "0", "test3").getOriginalValue(), "string");

        Assert.assertEquals(apiBody.get("subTest", "0").getOriginalValue().toString(), MyJson.createJSON("{'test2':false,'test3':'string'}").toString());
        Assert.assertEquals(apiBody.get("others", "0").getOriginalValue(), 1);
        Assert.assertEquals(apiBody.get("others", "1").getOriginalValue(), 2.2);
        Assert.assertEquals(apiBody.get("others", "2").getOriginalValue(), 1234);
        Assert.assertEquals(apiBody.get("others", "3").getOriginalValue(), 3);
        Assert.assertEquals(apiBody.get("others").getOriginalValue().toString(), MyJson.createJSONArray("[1,2.2,1234,3]").toString());
        Assert.assertEquals(apiBody.get("test1").getOriginalValue(), 10);
    }

    @Test
    public void getValues() {
        final ApiBody apiBody = ApiBodyFactory.parseJson(json);

        System.out.println(apiBody.getJsonValue());
        System.out.println(apiBody.getJsonSchema());
        Assert.assertTrue(Utils.schema((JSONArray)apiBody.get("others").getJsonSchema(), (JSONArray) apiBody.get("others").getJsonValue()));
        Assert.assertTrue(Utils.schema((JSONArray)apiBody.get("subTest").getJsonSchema(), (JSONArray) apiBody.get("subTest").getJsonValue()));

        Assert.assertTrue(Utils.schema((JSONObject) apiBody.getJsonSchema(), (JSONObject)apiBody.getJsonValue()));
        Assert.assertTrue(Utils.schema((JSONObject) apiBody.getJsonSchema(), (JSONObject)apiBody.getOriginalValue()));
        Assert.assertTrue(Utils.schema(MyJson.createJSON(json), (JSONObject) apiBody.getOriginalValue()));

        Assert.assertFalse(Utils.schema((JSONObject) apiBody.get("subTest", "0").getJsonSchema(), (JSONObject)apiBody.getOriginalValue()));
        Assert.assertTrue(Utils.schema((JSONArray) apiBody.get("others").getJsonSchema(), (JSONArray) apiBody.get("others").getOriginalValue()));
        Assert.assertFalse(Utils.schema((JSONObject) apiBody.getJsonSchema(), (JSONObject)apiBody.get("subTest", "0").getOriginalValue()));
    }

    @Test
    public void customValues() {
        final ApiBody apiBody = ApiBodyFactory.parseJson(json);

        Assert.assertNotEquals(apiBody.getJsonValue().toString(), apiBody.getJsonValue().toString());
        Assert.assertEquals(apiBody.getJsonSchema().toString(), apiBody.getJsonSchema().toString());

        apiBody.get("test2").putValue(true);
        apiBody.get("test1").putValue(15);

        Assert.assertEquals(apiBody.getJsonSchema().toString(), apiBody.getJsonSchema().toString());
        Assert.assertNotEquals(apiBody.getJsonValue().toString(), apiBody.getJsonValue().toString());

        PropertyReader.instance().setProperty("api_test3", "my test");
        apiBody.get("others", "0").putValue(1);
        apiBody.get("others", "1").putValue(2);
        apiBody.get("others", "2").putValue(3);
        apiBody.get("others", "3").putValue(4);

        Assert.assertEquals(apiBody.getJsonValue().toString(), apiBody.getJsonValue().toString());
    }

    @Test
    public void lockValues() {
        final ApiBody apiBody = ApiBodyFactory.parseJson(json);

        Assert.assertNotEquals(apiBody.getJsonValue().toString(), apiBody.getJsonValue().toString());
        apiBody.lockValues();
        Assert.assertEquals(apiBody.getJsonValue().toString(), apiBody.getJsonValue().toString());
    }

    @Test
    public void addToArray() {
        final ApiBody apiBody = ApiBodyFactory.parseJson(json);

        Assert.assertEquals(((JSONArray)apiBody.get("others").getJsonValue()).length(), 4);
        Assert.assertEquals(((JSONArray)apiBody.get("subTest").getJsonValue()).length(), 1);

        ((ApiBody)apiBody.get("others")).addAttribute(ApiBodyFactory.createNumberField());
        ((ApiBody)apiBody.get("subTest")).addAttribute(ApiBodyFactory.createApiObject());

        Assert.assertEquals(((JSONArray)apiBody.get("others").getJsonValue()).length(), 5);
        Assert.assertEquals(((JSONArray)apiBody.get("subTest").getJsonValue()).length(), 2);
    }

    @Test
    public void loadFile() {
        String fileName = "attendee.json";
        String contents = "{\n" +
                "  \"externalId\": \"string\",\n" +
                "  \"clientId\": \"string\",\n" +
                "  \"firstname\": \"string\",\n" +
                "  \"lastname\": \"string\",\n" +
                "  \"email\": \"string\",\n" +
                "  \"jobtitle\": \"string\",\n" +
                "  \"companyname\": \"string\",\n" +
                "  \"phone\": \"string\",\n" +
                "  \"address1\": \"string\",\n" +
                "  \"address2\": \"string\",\n" +
                "  \"city\": \"string\",\n" +
                "  \"stateId\": \"string\",\n" +
                "  \"foreignstate\": \"string\",\n" +
                "  \"zip\": \"string\",\n" +
                "  \"countryId\": \"string\",\n" +
                "  \"language\": \"string\"\n" +
                "}";

        final ApiConfig apiConfig = new ApiConfig();
        final ApiBody apiBody = ApiBodyFactory.parseJson(contents);
        final ApiBody apiBodyFile = BodyFromFile.getFile(fileName);
        apiConfig.setBodyFromFile(fileName);

        Assert.assertEquals(apiBodyFile.getOriginalValue().toString(), apiBody.getOriginalValue().toString());
        Assert.assertTrue(Utils.schema((JSONObject)apiBody.getJsonSchema(), apiConfig.getBody()));
    }

    @Test
    public void putSchema() {
        final ApiObject apiBody = (ApiObject) ApiBodyFactory.parseJson(json);

        Assert.assertTrue(Utils.schema(apiBody.getJsonSchema(), apiBody.getJsonValue()));
        apiBody.get("test2").putSchema("wrong");
        Assert.assertFalse(Utils.schema(apiBody.getJsonSchema(), apiBody.getJsonValue()));
    }
}
