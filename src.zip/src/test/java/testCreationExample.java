//import apps.admin.adminPageObjects.AdminDashboardPage;
//import apps.admin.adminPageObjects.AdminLoginPage;
//import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
//import apps.admin.adminPageObjects.registration.EditAttendeePage;
//import org.testng.Assert;
//
//public class testCreationExample {
//
//    public void test1() {
//        String attendeeId = "1538420113425001GkyN";
//        String catalogName = "Constellation Session SessionCatalog";
//
//        // I am logging in
//        AdminLoginPage.getPage().login();
//
//        //I am going to the attendee page
//        EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
//        editAttendeePage.navigate(attendeeId);
//
//        //I am spoofing in to the catalog
//        EditAttendeePage.getPage().spoofToWidget(catalogName);
//
//        //I am not sure what to do from here maybe but I want to check a certain session appears
//        //CatalogPage.getPage().filter("sessionName");
//        //Assert.assertTrue(SessionCatalog.sessionExists(sessionName), "Didn't work");
//    }
//}
