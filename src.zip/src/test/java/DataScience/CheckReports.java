package DataScience;

import apps.admin.AdminApp;
import configuration.PropertyReader;
import interaction.api.Api;
import interaction.awsDatabase.DbQueryConfig;
import interaction.awsDatabase.DbQueryRunner;
import org.json.JSONObject;
import org.testng.Assert;

public class CheckReports {

//    @Test
    public void validateExistingReport() {
        AdminApp adminApp = new AdminApp();
        DbQueryRunner dbQuery = new DbQueryRunner();

        JSONObject apiResponst = Api.Get(adminApp.getHost() + "/endpoint").getResponse();
        DbQueryConfig query = DbQueryConfig.createConfig("Attendees", "id = '123'", "firstName", "address");
        DbQueryConfig query2 = DbQueryConfig.createCustomConfig("Select * From Attendees Where event = " + PropertyReader.instance().getProperty("DSevent"));
        //MyJson.convertToObject();

        Assert.assertEquals(query, query2);
    }
}
