package mobile.hyperion;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import mobileApps.MobileConfiguration;
import mobileApps.hyperion.hyperionPageObjects.AppSetupPage;
import mobileApps.hyperion.hyperionPageObjects.HyperionLogin;
import mobileApps.hyperion.hyperionPageObjects.admin.AdminAttendeeForm;
import mobileApps.hyperion.hyperionPageObjects.admin.AdminRegisteredPage;
import mobileApps.hyperion.hyperionPageObjects.admin.AdminStatisticsPage;
import mobileApps.hyperion.hyperionPageObjects.kiosk.CheckedInPage;
import mobileApps.hyperion.hyperionPageObjects.kiosk.KioskAttendeeForm;
import mobileApps.hyperion.hyperionPageObjects.kiosk.KioskMainPage;
import mobileApps.hyperion.hyperionPageObjects.settings.ModePage;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class KioskAttendeeCheckin {

    AdminApp adminApp = new AdminApp();
    DataGenerator generator;
    String attendeeId;
    String email;
    String firstName;
    String lastName;

    @BeforeClass
    public void createAttendee() {
        generator = new DataGenerator();
        AdminLoginPage.getPage().login();
        PropertyReader.instance().setProperty("event", "Onsite Test Event");
        OrgEventData.getPage().setOrgAndEvent();
        PropertyReader.instance().setProperty("event", "Onsite Test Event Thu Apr 30 2020");

        email = generator.generateEmail();
        firstName = generator.generateName();
        lastName = generator.generateName();
        attendeeId = adminApp.createAttendee(email, firstName, lastName);

        AdminAttendeeOrdersTab.getPage().justDoWhateverYouNeedToOrderThePackage(attendeeId, "automation1");

        adminApp.setupiOSHyperion(false, false);
    }

    @AfterClass
    public void quit() {
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
        MobileConfiguration.getPage().quit();
    }

    @Test
    @ReportingInfo(firefoxIssue = "RA-33675", chromeIssue = "RA-33675")
    public void checkin() {
        HyperionLogin.getPage().login();
        AppSetupPage.getPage().defaultKioskCheckinSetup();

        KioskMainPage.getPage().searchByEmail(email);

        final KioskAttendeeForm attendeeForm = KioskAttendeeForm.getPage();
        Assert.assertEquals(attendeeForm.getFirstName(), firstName, "first name did not show up correctly on the form");
        Assert.assertEquals(attendeeForm.getLastName(), lastName, "last name did not show up correctly on the form");

        attendeeForm.setPreferredName(generator.generateName());
        attendeeForm.checkin();

        final CheckedInPage checkedIn = CheckedInPage.getPage();
        Assert.assertTrue(checkedIn.isCheckedIn(firstName), "Failed to checkin user " + email);
        checkedIn.done();

        final ModePage modeSettings = ModePage.getPage();
        KioskMainPage.getPage().openSettings();
        modeSettings.switchToAdmin();
        modeSettings.back();

        final AdminStatisticsPage statsPage = AdminStatisticsPage.getPage();
        statsPage.sync();
        statsPage.goToAttendees();

        final AdminRegisteredPage registeredPage = AdminRegisteredPage.getPage();
        Assert.assertTrue(registeredPage.isAttendeeOnPage(firstName, lastName), "The registered attendee is not on the registered list page in admin mode");
        registeredPage.openAttendee(firstName, lastName);
        Assert.assertTrue(AdminAttendeeForm.getPage().isAttendeeCheckedIn(), "Attendee is not shown as checked in on the mobile app in admin mode");

        final AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
        attendeeSearchPage.navigate();
        attendeeSearchPage.searchFor(email);
        final String status = attendeeSearchPage.getResults().get(0).get("status").toLowerCase();
        Assert.assertEquals(status, "attended", "Attendee not set to attended in the admin webapp");

    }
}
