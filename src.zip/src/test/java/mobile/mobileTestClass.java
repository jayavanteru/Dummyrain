package mobile;

public class mobileTestClass {
}
