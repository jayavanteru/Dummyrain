package load.tests;

import apps.admin.AdminApp;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueReader;
import load.LoadTestBase;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.CryptoUtil;
import testHelp.DataGenerator;
import testHelp.MyJson;

import java.util.ArrayList;

public class LeadScanning extends LoadTestBase {

    final private static int users = 1;

    private ArrayList<String> exhibitorIds;
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;
    private String baseUrl = "https://leads.dev.rainfocus.com/";
    final String apiProfileId = getProperty("loadApiProfileId");
    final String widgetId = getProperty("loadWidgetId");
    final String widgetIdUrl = "rfApiProfileId=" + apiProfileId + "&rfWidgetId=" + widgetId;
    private int exhibitorIdCount;

    @BeforeClass
    public void setup() {
        buildReport.graphReportFileName = "sessionSaveScan.csv";
        userInfo = adminApp.getAttendeeCredentials(getProperty("loadEventId"));
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void leadSaveScan() {
        startDelay();
        String eventId = getProperty("loadEventId");
        JSONObject response;
        DataGenerator generator =  new DataGenerator();

        //Login to Onsite
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


        while (isTestRunning()) {
            try {
                ApiRunner apiRunner = new ApiRunner(perEndpoint, timer);

                String exhibitorid = getNextExhibitorId();
                String leadToken = CryptoUtil.encrypt( getProperty("orgCode")+"|"+exhibitorid+"|" + eventId);
                //Save Lead
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                JSONObject body = new JSONObject();
                JSONObject lead = new JSONObject();

                DateTime now = DateTime.now();
                AdminApp.AttendeeCredentials user = userInfo.get();
                lead.put("attendeeId", user.attendeeId);
                lead.put("badgeId", user.badgeId);
                lead.put("firstname", generator.generateString());
                lead.put("lastname", generator.generateString());
                lead.put("hotLead", false);
                lead.put("leadDate", now.toString("yyyy-MM-dd"));
                lead.put("leadTime", now.toString("hh:mm:ss"));

                lead.put("companyname", generator.generateString());
                lead.put("jobtitle", generator.generateString());
                lead.put("note", generator.generateString());
                lead.put("questions", new JSONArray());
                lead.put("contactMethod", "");
                lead.put("deviceId", "1517342678270001eVcG");
                body.put("leads", MyJson.createJSONArray("["+lead+"]"));
                apiRunner.postAsForm(baseUrl + "api/saveLeads?leadToken=" + leadToken, body,
                        this::jsonResponse,
                        0);

                //[{   "deviceId": "1516403755023001ZKUR",   "badgeId": "89080760",
                // "firstname": "Sean",   "lastname": "Test",   "companyname": null,
                // "jobtitle": null,   "note": "MLSCANNER\n\n",   "leadDate": "2018-02-09",
                // "leadTime": "00:41:00",   "configurationId": "",   "questions": [],
                // "hotLead": false,   "contactMethod": null }]

            } catch (Exception e) { }
        }
    }

    public boolean config(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("config");
    }

    private synchronized String getNextExhibitorId() {
        //get a list of exhibitors
        if (exhibitorIds == null) {
            exhibitorIds = new ArrayList<>();
            String exhibitorUrl = getProperty("baseUrlEvents") + "api/exhibitorData?" + widgetIdUrl + "&since=0";
            ApiConfig config = new Api().get(new ApiConfig(exhibitorUrl));
            final JSONObject response = config.getResponse();
            //get a list of all exhibitorIds
            JSONArray sectionList = MyJson.getJSONArray(response, "sectionList");
            for (int i = 0; i < sectionList.length(); ++i) {
                JSONArray items = MyJson.getJSONArray(MyJson.getJSONObject(sectionList, i), "items");
                for (int j = 0; j < items.length(); ++j) {
                    JSONObject exhibitor = MyJson.getJSONObject(items, j);
                    String id = MyJson.getString(exhibitor, "exhibitorID");
                    exhibitorIds.add(id);
                }
            }
        }
        exhibitorIdCount = ++exhibitorIdCount % exhibitorIds.size();
        return exhibitorIds.get(exhibitorIdCount);
    }
}
