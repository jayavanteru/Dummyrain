package load.tests;

import interaction.loadTesting.ApiRunner;
import load.LoadTestBase;
import org.json.JSONObject;
import testHelp.MyJson;

public class LoadTestBaseCatalog extends LoadTestBase {

    final String apiProfileId = getProperty("loadApiProfileId");
    final String widgetId = getProperty("loadWidgetId");
    final String baseUrl = getProperty("baseUrlEvents");
    final String widgetIdUrl = "rfApiProfileId=" + apiProfileId + "&rfWidgetId=" + widgetId;

    private long oneHour = 3600000;
    private long days = Long.parseLong(getProperty("dataDumpHoursSince"));
    protected long since = 0;//System.currentTimeMillis() - (oneHour * days);

    public String getJwt(ApiRunner api, String username, String password) {
        JSONObject response;
        // login
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        response = api.get(baseUrl + "api/login?" + widgetIdUrl + "&username=" + username + "&password=" + password,
                this::login,
                0);
        String jwt = MyJson.getString(response, "jwt");


        // login part 2
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        response = api.get(baseUrl + "api/attendeeAccess?" + widgetIdUrl + "&rfAuthToken=" +jwt,
                this::jsonResponse,
                0);
        jwt = MyJson.getString(response, "jwt");

        return jwt;
    }

    public boolean login(Object obj) {
        boolean response;
        try {
            JSONObject json = (JSONObject) obj;
            response = json.has("email");
            response = response && json.has("firstName");
            response = response && json.has("lastName");
            response = response && json.has("jwt");
        } catch (Exception e) {
            response = false;
        }
        return response;
    }
}
