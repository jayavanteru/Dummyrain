package load.tests;

import apps.admin.AdminApp;
import apps.admin.forms.Form;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueReader;
import load.LoadTestBase;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

public class CrmOracle extends LoadTestBase {

    final private static int users = 1;
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;
    final DataGenerator generator = new DataGenerator();
    final String baseUrl = getProperty("baseUrlReg");
    final String workflowApiToken = "oracle.oow18.emp";
    final String pageUri = "contactInfo";
    final String loadPageUri = "managers";

    final String managerAttr1 = "1526747445406001yK21";
    final String managerAttr3 = "1526747469710001yVcb";
    final String managerAttr4 = "1526747501981001ycjB";

    @BeforeClass
    public void setup() {
        buildReport.graphReportFileName = "CrmOracle.csv";
        userInfo = adminApp.getOracleAttendee();
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void oracleCrmAutoUpdate() {
        startDelay();
        JSONObject response;

        ApiRunner apiRunner = new ApiRunner(perEndpoint, timer);

        // get login page
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        apiRunner.getOnce(baseUrl + "flow/oracle/oow18/emp/form/login?bd=1", j->true, 0);

        while (isTestRunning()) {
            try {
                AdminApp.AttendeeCredentials attendee = userInfo.get();

                // process login
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl +"flow/processLogin?email=" + attendee.username + "&password=" + attendee.password + "&workflowApiToken=" + workflowApiToken,
                        this::successLogin,
                        0);

                // load form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = apiRunner.post(baseUrl + "flow/loadForm?workflowApiToken=" + workflowApiToken + "&pageUri=" + pageUri,
                        this::jsonResponse,
                        0);

                Form form = new Form(response);
                JSONObject mapJson  = form.getValueMapJson();


                // save form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                JSONObject body = MyJson.createJSON("{'valueMapJson': '" + mapJson + "'}");
                MyJson.put(body, "pageUri", pageUri);

                apiRunner.post(baseUrl + "flow/saveForm", body,
                        this::saved,
                        0);

                // load form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "flow/loadForm?workflowApiToken=" + workflowApiToken + "&pageUri=" + loadPageUri,
                        this::managementFieldsBlank,
                        0);

                Utils.sleep(100);
                // save form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                mapJson.put("formAttendee.email", attendee.username);
                body = MyJson.createJSON("{'valueMapJson': '" + mapJson + "'}");
                MyJson.put(body, "pageUri", pageUri);

                apiRunner.post(baseUrl + "flow/saveForm", body,
                        this::saved,
                        0);

                // loads form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "flow/loadForm?workflowApiToken=" + workflowApiToken + "&pageUri=" + loadPageUri,
                        this::managementFieldsNotBlank,
                        0);


            } catch (Exception e) { }
        }
    }

    public boolean successLogin(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = ((JSONObject) obj).getJSONObject("data");
            return response && json.has("attendee") && json.has("eventName");
        } catch (JSONException e) {
            return false;
        }
    }

    public boolean saved(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = ((JSONObject) obj).getJSONObject("data");
            response = response && json.has("objectAttributeValuesSaved");
            response = response && json.has("passed");
            response = response && json.has("object");
        } catch (JSONException e) {
            return false;
        }
        return response;
    }

    public boolean managementFieldsBlank(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        try {
            JSONObject formValues = json.getJSONObject("data").getJSONObject("valueMap");
            response = response && !formValues.has(managerAttr1);
            response = response && !formValues.has(managerAttr3);
            response = response && !formValues.has(managerAttr4);
        } catch (JSONException e) {
            return false;
        }
        if (!response) System.out.println("blank fields");
        return response;
    }

    public boolean managementFieldsNotBlank(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        try {
            JSONObject formValues = json.getJSONObject("data").getJSONObject("valueMap");
            response = response && formValues.has(managerAttr1);
            response = response && formValues.has(managerAttr3);
            response = response && formValues.has(managerAttr4);
        } catch (JSONException e) {
            return false;
        }

        return response;
    }

    @Override
    public boolean jsonResponse(Object obj) {
        boolean response = true;
        try {
            JSONObject json = ((JSONObject) obj).getJSONObject("data");
            response = response && json.has("responseMessage");
            response = response && MyJson.getString(json, "responseMessage").equals("Success");

        } catch (Exception e) {
            response = false;
        }
        return response;
    }
}
