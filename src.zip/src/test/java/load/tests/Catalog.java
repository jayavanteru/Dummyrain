package load.tests;

import apps.admin.AdminApp;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueReader;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.MyJson;

import java.util.ArrayList;

public class Catalog extends LoadTestBaseCatalog {

    /**
     * make sure that there is an access rule to allow all to schedule sessions
     */

    final private static int users = 1;
    private DataGenerator generator = new DataGenerator();
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;
    private ArrayList<String> exhibitorIds;
    private int exhibitorIdCount = 0;

    @BeforeClass
    public void setup() throws JSONException {
        try {
            buildReport.graphReportFileName = "LoadCatalog.csv";
            userInfo = adminApp.getAttendeeCredentials(getProperty("loadEventId"));
        } catch (Exception e) {
            getReports();
        }
    }

    private synchronized String getNextExhibitorId() {
        //get a list of exhibitors
        if (exhibitorIds == null) {
            exhibitorIds = new ArrayList<>();
            String exhibitorwidgetId = "rfApiProfileId=kgbXYQt3cWjDRRlRqUVCb7zTMqccaacA&rfWidgetId=uSIebgwKA0QZyk64miA7ON2Y9Q0uhR6z";
            String exhibitorUrl = baseUrl + "api/exhibitorData?" + exhibitorwidgetId + "&since=" + since;
            //String exhibitorUrl = baseUrl + "api/exhibitorData?" + widgetId + "&since=" + since;
            ApiConfig config = new Api().get(new ApiConfig(exhibitorUrl));
            final JSONObject response = config.getResponse();
            //get a list of all exhibitorIds
            JSONArray sectionList = MyJson.getJSONArray(response, "sectionList");
            for (int i = 0; i < sectionList.length(); ++i) {
                JSONArray items = MyJson.getJSONArray(MyJson.getJSONObject(sectionList, i), "items");
                for (int j = 0; j < items.length(); ++j) {
                    JSONObject exhibitor = MyJson.getJSONObject(items, j);
                    String id = MyJson.getString(exhibitor, "exhibitorID");
                    exhibitorIds.add(id);
                }
            }
        }
        exhibitorIdCount = ++exhibitorIdCount % exhibitorIds.size();
        return exhibitorIds.get(exhibitorIdCount);
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void loadCatalog() {
        final String apiProfileId = getProperty("loadApiProfileId");
        final String widgetId = getProperty("loadWidgetId");
        final String widgetIdUrl = "rfApiProfileId=" + apiProfileId + "&rfWidgetId=" + widgetId;

        startDelay();
        JSONObject response;
        while (isTestRunning()) {
            try {
                ApiRunner api = new ApiRunner(perEndpoint, timer);
                // load config
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/widgetConfig?" + widgetIdUrl,
                        this::configLoads,
                        0);

                // login
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                AdminApp.AttendeeCredentials userInfo = this.userInfo.get();
                String jwt = getJwt(api, userInfo.username, userInfo.password);
                String widgetUrlWithJwt = widgetIdUrl + "&rfAuthToken=" + jwt;

                // Add Calendar item
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                JSONObject body = new JSONObject();
                DateTime dateTime = generator.generateDateTimeAfterNow();
                MyJson.put(body, "title", generator.generateString(10));
                MyJson.put(body, "description", generator.generateString(60));
                MyJson.put(body, "location", generator.generateString());
                MyJson.put(body, "date", dateTime.toString("yyyy-MM-dd"));
                MyJson.put(body, "time", dateTime.toString("hh:mm"));
                MyJson.put(body, "length", "45");

                response = api.postAsUrl(baseUrl + "api/addCalendarItem?" + widgetUrlWithJwt, body,
                        this::createdCalendarItem,
                        0);

                String calendarItemId = null;
                try {
                    calendarItemId = response.getJSONObject("calendarItem").getString("calendarItemId");
                } catch (JSONException | NullPointerException e) { }

                // my Schedule
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.get(baseUrl + "api/mySchedule?" + widgetUrlWithJwt,
                        this::schedule,
                        0);

                ArrayList<SessionTimeInfo> scheduledSessionTimesInfo = null;
                try {
                    JSONArray scheduledTimes = response.getJSONArray("mySchedule");
                    scheduledSessionTimesInfo = mapScheduledSession(scheduledTimes);
                } catch (JSONException e) { }

                // list sessions
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.get(baseUrl + "api/search?type=session&" + widgetUrlWithJwt,
                        this::sessionList,
                        0);

                SessionTimeInfo sessionTimeId1 = null;
                SessionTimeInfo sessionTimeId2 = null;
                String sessionId =  null;

                try {
                    //get the list of sessions
                    JSONArray sections = response.getJSONArray("sectionList");
                    //go through all sessions and find 2 with conflicting times
                    for (int i = 1; i < sections.length() && sessionTimeId1 == null; ++i) {
                        JSONArray sessions = sections.getJSONObject(i).getJSONArray("items");

                        //get a random session id for toggling things
                        sessionId = sessions.getJSONObject(generator.generateNumber(sessions.length() - 1)).getString("sessionID");

                        SessionTimeInfo[] twoSessionsToSchedule = findTwoSessionsToSchedule(sessions, scheduledSessionTimesInfo);
                        if (twoSessionsToSchedule[0] != null) {
                            sessionTimeId1 = twoSessionsToSchedule[0];
                            sessionTimeId2 = twoSessionsToSchedule[1];
                        }
                    }
                } catch (JSONException e) { }

                // add session
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                if (sessionTimeId1 != null) {
                    api.post(baseUrl + "api/addSession?" + widgetUrlWithJwt + "&sessionTimeId=" + sessionTimeId1.sessionTimeID,
                            this::jsonResponse,
                            0);
                }

                // toggle session interest
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.post(baseUrl + "api/toggleSessionInterest?" + widgetUrlWithJwt + "&sessionId=" + sessionId,
                        this::toggle,
                        0);

                // toggle exhibitor interest
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.post(baseUrl + "api/toggleExhibitorInterest?" + widgetUrlWithJwt + "&exhibitorId=" + getNextExhibitorId(),
                        this::toggle,
                        0);

                // recommend sponsor
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/recommendSponsor?" + widgetUrlWithJwt + "&since=" + since,
                        this::recommend,
                        0);

                // recommend
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/recommend?" + widgetUrlWithJwt + "&since=" + since,
                        this::recommend,
                        0);

                // drop swap session
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                if (sessionTimeId1 != null) {
                    JSONObject dropSession = MyJson.createJSON("{'dropSessionItems':[{'dropSessionId':'"+sessionTimeId1.sessionId+"','dropSessionTimeId':'" + sessionTimeId1.sessionTimeID + "','dropWaitlist':'false'}]}");
                    dropSession.put("sessionTimeId", sessionTimeId2.sessionTimeID);
                    dropSession.put("sessionId", sessionTimeId2.sessionId);

                    api.postAsUrl(baseUrl + "api/dropSwapSession?" + widgetUrlWithJwt, dropSession,
                            this::jsonResponse,
                            0);
                }

                // badge lookup
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.post(baseUrl + "api/badgeLookup?" + widgetIdUrl + "&badgeId=" + userInfo.badgeId,
                        this::badgeLookup,
                        0);

                // add session attendance
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                //get a solid session time
                SessionTimeInfo attendedSession;
                if (sessionTimeId2 != null) {
                    attendedSession = sessionTimeId2;
                } else {
                    attendedSession = scheduledSessionTimesInfo.stream()
                            .filter(sess -> !sess.sessionId.isEmpty() && !sess.sessionTimeID.isEmpty())
                            .findAny().orElse(null);
                }

                if (attendedSession != null) {
                    api.post(baseUrl + "api/addSessionAttendance?" + widgetUrlWithJwt + "&attendeeId=" + userInfo.attendeeId + "&sessionTimeId=" + attendedSession.sessionTimeID,
                            this::jsonResponse,
                            0);
                }

                // my interests
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/myInterests?" + widgetUrlWithJwt,
                        this::interests,
                        0);

                // my Data
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/myData?" + widgetUrlWithJwt,
                        this::myData,
                        0);

                // attendee info
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/attendeeInfo?attendeeId=" + userInfo.attendeeId + "&" + widgetIdUrl,
                        this::attendeeInfo,
                        0);

                // attendee info since
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                api.get(baseUrl + "api/attendeeInfo?" + widgetIdUrl + "&timestamp=" + DateTime.now().minusMinutes(15).getMillis(),
//                        this::attendeesInfo,
//                        0);

                // get survey list
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/surveys?" + widgetUrlWithJwt + "&show=all",
                        this::surveys,
                        0);

                // delete Calendar Item
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.post(baseUrl + "api/deleteCalendarItem?" + widgetUrlWithJwt + "&calendarItemId=" + calendarItemId,
                        this::jsonResponse,
                        0);

                // remove session from schedule
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                if (sessionTimeId2 != null) {
                    api.post(baseUrl + "api/removeSession?" + widgetUrlWithJwt + "&sessionTimeId=" + sessionTimeId2.sessionTimeID,
                            this::jsonResponse,
                            0);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    private boolean configLoads(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = (JSONObject) obj;
            response = response && json.has("config");

        } catch (Exception e) {
            response = false;
        }
        return response;
    }

    public boolean createdCalendarItem(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = (JSONObject) obj;
            response = response && json.has("calendarItem");

            JSONObject calendarItem = json.getJSONObject("calendarItem");
            response = response && calendarItem.has("calendarItemId");
        } catch (JSONException e) {
            response = false;
        }
        return response;
    }

    public boolean sessionList(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = (JSONObject) obj;
            response = response && json.has("sectionList");
            JSONArray sectionList = json.getJSONArray("sectionList");

            boolean hasItems = false;
            for (int i = 0; i < sectionList.length(); ++i) {
                hasItems =  hasItems || sectionList.getJSONObject(i).has("items");
            }
            response = response && hasItems;
        } catch (JSONException e) {
            response = false;
        }
        return response;
    }

    public boolean schedule(Object obj) {
        JSONObject json = (JSONObject) obj;
        return json.has("loggedInUser") && json.has("mySchedule");
    }

    public boolean interests(Object obj) {
        JSONObject json = (JSONObject) obj;
        return json.has("sessionInterests") && json.has("exhibitorInterests");
    }

    public boolean myData(Object obj) {
        return schedule(obj) && interests(obj);
    }

    public boolean surveys(Object obj) {
        JSONObject json = (JSONObject) obj;
        return jsonResponse(obj) && json.has("surveys");
    }

    public boolean attendeeInfo(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        response = response && json.has("attendee");
        return response;
    }

    public boolean attendeesInfo(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        response = response && json.has("attendees");
        return response;
    }

    public boolean badgeLookup(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        response = response && json.has("attendeeID")
                && json.has("firstName")
                && json.has("lastName")
                && json.has("companyName");
        return response;
    }

    public boolean toggle(Object obj) {
        JSONObject json = (JSONObject) obj;
        return json.has("operation");
    }

    public boolean recommend(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("jwtClaims") && json.has("items");
    }

    private SessionTimeInfo[] findTwoSessionsToSchedule(JSONArray sessions, ArrayList<SessionTimeInfo> scheduledSessions) {
        ArrayList<SessionTimeInfo> allSessionTimes = new ArrayList<>();
        SessionTimeInfo[] sessionTimeIds = new SessionTimeInfo[2];
        //find all the sessions
        for (int i = 0; i < sessions.length(); ++i) {
            try {
                JSONObject session = sessions.getJSONObject(i);
                if (!(session.has("purchased") && session.getBoolean("purchased"))) {
                    String sessionId = session.getString("sessionID");
                    JSONArray times = session.getJSONArray("times");
                    //find all the session times for that session
                    for (int j = 0; j < times.length() && sessionTimeIds[0] == null; ++j) {
                        JSONObject time = times.getJSONObject(j);
                        if (time.has("seatsRemaining") && time.getInt("seatsRemaining") > 0) {
                            SessionTimeInfo sessionTime = new SessionTimeInfo( sessionId,
                                    time.getString("sessionTimeID"),
                                    time.getString("date"),
                                    time.getString("time"),
                                    time.getString("endTime"));
                            //save the session time
                            //ignore it if there is already something scheduled for that time
                            if (!scheduledSessions.contains(sessionTime)) {
                                if (allSessionTimes.contains(sessionTime)) {
                                    SessionTimeInfo otherSession = allSessionTimes.get(allSessionTimes.indexOf(sessionTime));
                                    //found duplicate times save dem ids
                                    sessionTimeIds[0] = sessionTime;
                                    sessionTimeIds[1] = otherSession;
                                } else {
                                    allSessionTimes.add(sessionTime);
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e) { }
        }

        return sessionTimeIds;
    }

    private ArrayList<SessionTimeInfo> mapScheduledSession(JSONArray sessionArray) {
        ArrayList<SessionTimeInfo> sessionTimes = new ArrayList<>();

        for (int i = 0; i < sessionArray.length(); ++i) {
            try {
                JSONObject jsonSessionTime = sessionArray.getJSONObject(i);
                //make sure we give the session time info object as much info as we can
                if (jsonSessionTime.has("sessionID") && jsonSessionTime.has("sessionTimeID")) {
                    SessionTimeInfo timeInfo = new SessionTimeInfo(
                            jsonSessionTime.getString("sessionID"),
                            jsonSessionTime.getString("sessionTimeID"),
                            jsonSessionTime.getString("date"),
                            jsonSessionTime.getString("time"),
                            jsonSessionTime.getString("endTime"));
                    sessionTimes.add(timeInfo);
                } else {
                    SessionTimeInfo timeInfo = new SessionTimeInfo(
                            jsonSessionTime.getString("date"),
                            jsonSessionTime.getString("time"),
                            jsonSessionTime.getString("endTime"));
                    sessionTimes.add(timeInfo);
                }
            } catch (JSONException e) { }
        }
        return sessionTimes;
    }


    public class SessionTimeInfo {
        public final String sessionId;
        public final String sessionTimeID;
        public final String date;
        public final String time;
        public final DateTime start;
        public final DateTime end;

        public SessionTimeInfo(String sessionId, String sessionTimeID, String date, String time, String endTime) {
            this.sessionId = sessionId;
            this.sessionTimeID = sessionTimeID;
            this.date = date;
            this.time = time;
            start = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm").parseDateTime(date + " " + time);
            end = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm").parseDateTime(date + " " + endTime);
        }

        public SessionTimeInfo(String date, String time, String endTime) {
            this("","", date, time, endTime);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj instanceof SessionTimeInfo) {
                SessionTimeInfo info = (SessionTimeInfo) obj;
                return (info.start.minusMinutes(1).isBefore(end) &&
                        info.end.plusMinutes(1).isAfter(start));
            } else return false;
        }

    }
}
