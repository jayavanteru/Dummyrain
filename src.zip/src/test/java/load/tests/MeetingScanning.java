package load.tests;

import apps.workflows.WorkflowsApp;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueOperation;
import load.LoadTestBase;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.MyJson;

public class MeetingScanning extends LoadTestBase{

    WorkflowsApp workflowsApp = new WorkflowsApp();

    protected QueueOperation<String> deleteUsers;

    static final int users = 1;

    static boolean run = true;
    static Boolean done = false;

    @BeforeClass
    public void setup() {
        deleteUsers = new QueueOperation<>(adminApp::deleteAttendeeApi);
        buildReport.graphReportFileName = "RegisterWorkflow.csv";
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void toggleMeeting() {
        startDelay();

        final String baseUrl = getProperty("baseUrlReg");
        final String flowApi = getProperty("flowApi");
        final String formCreateUri = getProperty("formCreateUri");
        final String formInfoUri = getProperty("formInfoUri");
        final String orgCode = getProperty("orgCode");
        final String eventCode = getProperty("loadEventCode");
        final String workflow = "meetingscheckin";//getProperty("workflow");

        JSONObject response;

        ApiRunner api = new ApiRunner(perEndpoint, timer);

        // login page
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        api.get(baseUrl + "flow/" + orgCode + "/" + eventCode + "/" + workflow + "/login",
                (json) -> true,
                0);

        api.get(baseUrl + "flow/processLogin?workflowApiToken="+flowApi+"&email=1500019345466001byuj@rainfocus.net&password=Rainfocus123",
                   (json) -> true,
                   0);

        while (isTestRunning()) {
            try {
                //https://reg-stg.rainfocus.com/flow/loadMyMeetingsCardData.do
                JSONObject params = new JSONObject();
                params.put("cardconfig", "{\"id\":\"checkincard\",\"meetingProgramId\":[\"1540499100548001idtz\",\"15415346720230019PkW\",\"1542387669857001Nw3p\",\"1540491631017001vrHn\"],\"type\":\"myMeetings\",\"suggestMinutesBeforeAfterForNonRegistered\":\"600\",\"suggestForNonRegistered\":true,\"currentTime\":\"2019-01-30 08:00:00\",\"headerConfig\":{\"hide\":true,\"text\":\"My sessions\"}}");
                params.put("workflowApiToken", flowApi);
                response = api.post(baseUrl + "flow/loadMyMeetingsCardData.do",
                        params,
                        this::assertResponse,
                        0);

                System.out.println("====================================== LOAD MY MEETINGS ======================================");
                System.out.println(response);

                // scan meeting
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                //meeting id:
                response = api.post(baseUrl + "flow/toggleMeetingAttendance?meetingTimeId=1541626753108001PfIl&workflowApiToken=" + flowApi,
                        this::assertResponse,
                        0);
                System.out.println("====================================== TOGGLE MEETING ======================================");
                System.out.println(response);

            } catch (Exception e) { }
        }
    }

    public boolean assertResponse(Object obj) {
        boolean assertion;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject data = MyJson.getJSONObject(json, "data");
            assertion = MyJson.getString(data, "responseMessage").equalsIgnoreCase("Success");
        } catch (Exception e) {
            assertion = false;
        }

        return assertion;
    }

}
