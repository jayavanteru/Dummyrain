package load.tests;

import apps.admin.AdminApp;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueReader;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.CryptoUtil;
import testHelp.DataGenerator;
import testHelp.MyJson;

import java.util.ArrayList;

public class SessionScanning extends LoadTestBaseCatalog {

    final private static int users = 1;

    private ArrayList<String[]> sessionIds;
    private int sessionIdCount = 0;
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;

    @BeforeClass
    public void setup() {
        buildReport.graphReportFileName = "sessionSaveScan.csv";
        userInfo = adminApp.getAttendeeCredentials(getProperty("loadEventId"));
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void sessionSaveScan() {
        startDelay();
        String eventId = getProperty("loadEventId");
        String eventToken = CryptoUtil.encrypt(eventId + "|"+getProperty("orgCode")+"|0");
        JSONObject response;
        DataGenerator generator =  new DataGenerator();

        ApiRunner apiRunner = new ApiRunner(perEndpoint, timer);
        //Load Session Device
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        apiRunner.get(baseUrl + "api/scan/sessionDeviceConfig.do?eventToken=" + eventToken + "&hardwareId=D10A0352-FC14-41DC-B146-53DFB594F0AB",
                this::config,
                0);

        //Save Session Device Config
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        apiRunner.post(baseUrl + "api/scan/saveSessionDeviceConfig.do?eventToken=" + eventToken,
                this::config,
                0);

        while (isTestRunning()) {
            try {
                //Save Session
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                String[] nextSession = getNextSessionId();
                String sessionId = nextSession[0];
                String sessionTimeId = nextSession[1];
                JSONObject body = new JSONObject();
                JSONObject scan = new JSONObject();

                DateTime now = DateTime.now();
                AdminApp.AttendeeCredentials user = userInfo.get();
                scan.put("attendeeId", user.attendeeId);
                scan.put("badgeId", user.badgeId);
                scan.put("firstname", generator.generateString());
                scan.put("lastname", generator.generateString());
                scan.put("scanStatus", "green");
                scan.put("sessiontimeId", sessionTimeId);
                scan.put("sessionId", sessionId);
                scan.put("scanDate", now.toString("yyyy-MM-dd"));
                scan.put("scanTime", now.toString("hh:mm:ss"));

                //body.put("eventToken", eventToken);
                body.put("eventId", eventId);
                body.put("deviceId", "1517342678270001eVcG");
                JSONArray scanjson = new JSONArray();
                scanjson.put(scan);
                body.put("scans", scanjson);
                apiRunner.postAsForm(baseUrl + "api/scan/saveSessionScans?" + widgetIdUrl + "&eventToken=" + eventToken, body,
                        this::jsonResponse,
                        0);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public boolean config(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("config");
    }

    private synchronized String[] getNextSessionId() {
        //get a list of exhibitors
        if (sessionIds == null || sessionIds.size() <= 0) {
            sessionIds = new ArrayList<>();
            String exhibitorUrl = baseUrl + "api/sessionData?" + widgetIdUrl + "&since=" + since;
            ApiConfig config = new Api().get(new ApiConfig(exhibitorUrl));
            final JSONObject response = config.getResponse();
            //get a list of all exhibitorIds
            JSONArray sectionList = MyJson.getJSONArray(response, "sectionList");
            for (int i = 0; i < sectionList.length(); ++i) {
                JSONArray items = MyJson.getJSONArray(MyJson.getJSONObject(sectionList, i), "items");
                for (int j = 0; j < items.length(); ++j) {
                    JSONObject session = MyJson.getJSONObject(items, j);
                    if (session.has("times")) {
                        JSONArray times = MyJson.getJSONArray(session, "times");
                        for (int k = 0; k < times.length(); ++k) {
                            JSONObject sessionTime = MyJson.getJSONObject(times, k);
                            String id = MyJson.getString(session, "sessionID");
                            String timeId = MyJson.getString(sessionTime, "sessionTimeID");
                            sessionIds.add(new String[]{id, timeId});
                        }
                    }
                }
            }
        }
        sessionIdCount = ++sessionIdCount % sessionIds.size();
        return sessionIds.get(sessionIdCount);
    }
}
