package load.tests;

import interaction.loadTesting.ApiRunner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.Utils;

public class DataDumps extends LoadTestBaseCatalog {

    /**
     * make sure that there is an access rule to allow all to schedule sessions
     */

    final private static int users = 1;

    @BeforeClass
    public void setup() {
        buildReport.graphReportFileName = "DataDump.csv";
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void dataDumpCalls() {
        final String params = widgetIdUrl + "&since=" + since;
        startDelay();

        JSONObject response;
        while (isTestRunning()) {
            try {
                ApiRunner api = new ApiRunner(perEndpoint, timer);

                // data dump Schedule
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/scheduleDataDump?" + params,
                        this::assertSuccess,
                        0);

                Utils.sleep(20000);

                // data dump interests
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/interestDataDump?" + params,
                        this::assertSuccess,
                        0);

                Utils.sleep(20000);

                // data dump exhibitor interests
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/exhibitorInterestDataDump?" + params,
                        this::assertSuccess,
                        0);

                Utils.sleep(20000);

                // data dump speaker
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/speakerData?" + params,
                        this::assertSuccessSpeaker,
                        0);

                Utils.sleep(20000);

                // data dump exhibitor
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/exhibitorData?" + params,
                        this::assertSuccessSpeaker,
                        0);

                Utils.sleep(20000);

                // data dump session
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/sessionData?" + params,
                        this::assertSuccessSpeaker,
                        0);

                Utils.sleep(20000);

                // data dump leads
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl + "api/leadsDataDump?" + params,
                        this::assertSuccess,
                        0);

                Utils.sleep(20000);

            } catch (Exception e) { }
        }
    }

    public boolean assertSuccess(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            pass = json.has("data");
            pass = pass && json.has("responseMessage");
            pass = pass && json.getString("responseMessage").equals("Success");
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public boolean assertSuccessSpeaker(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            pass = json.has("attributes") && json.has("sectionList");
            pass = pass && json.has("responseMessage");
            pass = pass && json.getString("responseMessage").equals("Success");
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public boolean sessionList(Object obj) {
        boolean response = jsonResponse(obj);
        try {
            JSONObject json = (JSONObject) obj;
            response = response && json.has("sectionList");
            JSONArray sectionList = json.getJSONArray("sectionList");

            boolean hasItems = false;
            for (int i = 0; i < sectionList.length(); ++i) {
                hasItems =  hasItems || sectionList.getJSONObject(i).has("items");
            }
            response = response && hasItems;
        } catch (JSONException e) {
            response = false;
        }
        return response;
    }
}
