package load.tests;

import apps.admin.AdminApp;
import apps.admin.forms.Form;
import apps.workflows.WorkflowsApp;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueOperation;
import interaction.loadTesting.QueueReader;
import load.LoadTestBase;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.MyJson;
import testHelp.Utils;

public class Registration extends LoadTestBase{

    WorkflowsApp workflowsApp = new WorkflowsApp();

    protected QueueOperation<String> deleteUsers;
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;

    static final int users = 3;

    static boolean run = true;
    static Boolean done = false;

    public void runOnce() {
        if (run) {
            run = false;

            final String baseUrl = getProperty("baseUrlReg");
            final String flowApi = getProperty("flowApi");
            final String formCreateUri = getProperty("formCreateUri");
            final String formInfoUri = getProperty("formInfoUri");
            final String orgCode = getProperty("orgCode");
            final String eventCode = getProperty("loadEventCode");
            final String workflow = getProperty("workflow");
            JSONObject response;

            // login page
//            //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
////            api.get(baseUrl + "flow/" + orgCode + "/" + eventCode + "/"+workflow+"/form/login",
////                    (json) -> true,
////                    0);
////
////            api.get(baseUrl + "flow/processLogin?workflowApiToken="+flowApi+"&email=a9e6703fautomation@rainfocus.com&password=Rainfocus123",
////                   (json) -> true,
////                   0);
            synchronized (done) {
                done = true;
            }
        } else {
            Utils.waitForTrue(()->{boolean result; synchronized(done){result = done;} return result;});
        }
    }

    @BeforeClass
    public void setup() {
        deleteUsers = new QueueOperation<>(adminApp::deleteAttendeeApi);
        buildReport.graphReportFileName = "RegisterWorkflow.csv";
        userInfo = adminApp.getAttendeeCredentialsWorkflow(getProperty("loadEventId"));
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void registerWorkflow() {
        startDelay();

        final String baseUrl = getProperty("baseUrlReg");
        final String flowApi = getProperty("flowApi");
        final String formCreateUri = getProperty("formCreateUri");
        final String formInfoUri = getProperty("formInfoUri");
        final String orgCode = getProperty("orgCode");
        final String eventCode = getProperty("loadEventCode");
        final String workflow = getProperty("workflow");

        JSONObject response;
        Form form;
        JSONObject mapJson;
        JSONObject body;
        while (isTestRunning()) {
            try {
                //QueueReader<AdminApp.AttendeeCredentials> userinfo = adminApp.getAttendeeCredentialsWorkflow(getProperty("loadEventId"));
                ApiRunner api = new ApiRunner(perEndpoint, timer);
                // login page
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                api.get(baseUrl + "flow/" + orgCode + "/" + eventCode + "/"+workflow+"/form/login?bd=1",
                api.get(baseUrl + "flow/" + orgCode + "/" + eventCode + "/"+workflow+"/login?bd=1",
                    (json) -> true,
                    0);

                // process login
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                AdminApp.AttendeeCredentials user = this.userInfo.get();
                api.get(baseUrl + "flow/processLogin?workflowApiToken="+flowApi+"&email="+user.username+"&password="+user.password,
                   (json) -> true,
                   0);

                // get create account form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.get(baseUrl + "flow/loadCreateAccount?worflowApiToken=" + flowApi + "&pageUri=" + formCreateUri,
                        this::assertFormJson,
                        0);

                form = new Form(response);
                mapJson = form.getValueMapJson();
                body = MyJson.createJSON("{'valueMapJson': '" + mapJson + "'}");
                MyJson.put(body, "pageUri", formCreateUri);

                // submit create account form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.post(baseUrl + "flow/processCreateAccount?workflowApiToken=" + flowApi + "&pageUri=" + formCreateUri,
                        body,
                        this::assertAttendeeCreation,
                        0);

                //get the attendee id so we can cleanup later
                String attendeeId = null;
                try {
                    attendeeId = response.getJSONObject("data").getJSONObject("attendee").getString("attendeeId");
                } catch (JSONException e) {
                }

                // load a form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.get(baseUrl + "flow/loadForm?workflowApiToken=" + flowApi + "&pageUri=" + formInfoUri,
                        this::assertFormJson,
                        0);

                form = new Form(response);
                mapJson = form.getValueMapJson();


                // submit form
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                body = MyJson.createJSON("{'valueMapJson': '" + mapJson + "'}");
                MyJson.put(body, "pageUri", formInfoUri);
                response = api.post(baseUrl + "flow/saveForm",
                        body,
                        this::assertFormSaved,
                        0);


                // load orders
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = api.post(baseUrl + "flow/loadOrderForm?workflowApiToken=" + flowApi,
                        this::assertOrdersLoad,
                        0);

                //find first package with a price
                String packageId = null;
                JSONObject data = MyJson.getJSONObject(response, "data");
                JSONArray items = MyJson.getJSONArray(data, "items");
                //searching through all the packages
                for (int i = 0; i < items.length() && packageId == null; ++i) {
                    try {
                        JSONObject group = MyJson.getJSONObject(items, i);
                        packageId = workflowsApp.findNonZeroPackageId(MyJson.getJSONArray(group, "items"));
                    } catch (Exception e) {
                    }
                }

                // place an order
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                JSONObject order = MyJson.createJSON(buildOrderForm(packageId));
                body = new JSONObject();
                try {
                    body.put("order", order);
                    body.put("workflowApiToken", flowApi);
                    //body.put("storeCCInVault", false);
                    body.put("compliances", new JSONArray());
                    body.put("paymentNonce", "undefinded");
                    //body.put("vatNumber", "");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                api.postAsUrl(baseUrl + "flow/processOrder",
                        body,
                        this::assertSuccess,
                        0);

                // load the account page
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                 api.get(baseUrl + "flow/myAccount?workflowApiToken=" + flowApi,
                        this::assertSuccess,
                        0);

                // load the html account page
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                api.get(baseUrl +  "flow/" + orgCode + "/" + eventCode + "/"+workflow+"/account?workflowApiToken=" + flowApi,
                        (a)->true,
                        0);

                //make the mmx call
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//                api.get(baseUrl +  "flow/getBookingUrl?workflowApiToken=" + flowApi,
//                        (a)->true,
//                        0);
//
//
//                api.get(baseUrl +  "flow/getReservationInfo?workflowApiToken=" + flowApi,
//                        (a)->true,
//                        0);

                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                //cleanup the created attendee
//                if (attendeeId != null) deleteUsers.add(attendeeId);
            } catch (Exception e) { }
        }
    }

    public boolean assertFormJson(Object obj) {
        boolean assertion;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject form = MyJson.getJSONObject(MyJson.getJSONObject(json, "data"), "form");
            assertion = form.has("formId");
            assertion = form.has("formAttributes") && assertion;
        } catch (Exception e) {
            assertion = false;
        }

        return assertion;
    }

    public boolean assertAttendeeCreation(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject data = MyJson.getJSONObject(json, "data");
            pass = data.has("attendee");
            pass = MyJson.getJSONObject(data, "attendee").has( "attendeeId") && pass;
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public boolean assertFormSaved(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject data = MyJson.getJSONObject(json, "data");
            pass = data.has("objectAttributeValuesSaved");
            pass = MyJson.getJSONArray(data, "objectAttributeValuesSaved").length() > 0 && pass;
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public boolean assertOrdersLoad(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject data = MyJson.getJSONObject(json, "data");
            pass = data.has("paymentMethods");
            pass = pass && data.has("items");
            pass = pass && MyJson.getJSONArray(data, "items").length() > 0;
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public boolean assertSuccess(Object obj) {
        boolean pass;
        try {
            JSONObject json = (JSONObject) obj;
            JSONObject data = MyJson.getJSONObject(json, "data");
            pass = data.has("responseMessage");
            pass = pass && data.getString("responseMessage").equals("Success");
        } catch (Exception e) {
            pass = false;
        }
        return pass;
    }

    public String buildOrderForm(String packageId) {
        String body = "{" +
                  "'combos':[]," +
                  "'items':[" +
                    "{" +
                      "'id':'" + packageId + "'," +
                      "'quantity':1" +
                    "}" +
                  "]," +
                  "'payments': [{"+
                  "'itemIds': ['" + packageId + "'],"+
                  "'paymentTypeId':'Wire Transfer'," +
                  "'address':{" +
                    "'contactName':'Automation Test'," +
                    "'nameOnCard':''," +
                    "'address1':'test'," +
                    "'address2':''," +
                    "'city':'test'," +
                    "'countryId':'US'," +
                    "'zip':'85043'," +
                    "'stateId':'UT'," +
                    "'foreignstate':null," +
                    "'referenceId':'test1'," +
                    "'poNumber':'test'" +
                  "}," +
                "'storeCCInVault' : false,"+
                "'vatNumber': ''"+
        "}]"+
                "}";
        return body;
    }
}
