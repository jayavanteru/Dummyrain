package load.tests;

import apps.admin.AdminApp;
import interaction.loadTesting.ApiRunner;
import interaction.loadTesting.QueueReader;
import load.LoadTestBase;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.BeforeClass;
import testHelp.MyJson;

public class Saturn extends LoadTestBase{

    final private static int users = 1;
    private QueueReader<AdminApp.AttendeeCredentials> userInfo;

    @BeforeClass
    public void setup() {
        buildReport.graphReportFileName = "Saturn.csv";
        userInfo = adminApp.getAttendeeCredentials(getProperty("loadEventId"));
    }

//    @Test(threadPoolSize = users, invocationCount = users)
    public void saturnCheckin() {
        startDelay();
        String baseUrl = getProperty("baseUrlSaturn");

        ApiRunner apiRunner = new ApiRunner(perEndpoint, timer);
        JSONObject response;

        //log into the saturn
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        apiRunner.getOnce(baseUrl + "api/onsite/adminLogin?username=saturn&password=7rings",
                this::jsonResponse,
                0);

        //save printer location
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        apiRunner.postOnce(baseUrl + "api/onsite/savePrintLocation?locationId=" + getProperty("printerLocationId"),
                this::savePrinter,
                0);

        //config gift
        //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        JSONObject giftId = MyJson.createJSON("{'spiffsJson':['" + getProperty("giftId") + "']}");
        apiRunner.postAsUrlOnce(baseUrl + "api/onsite/saveSpiffConfig", giftId,
                this::savegifts,
                0);

        while (isTestRunning()) {
            try {
                AdminApp.AttendeeCredentials attendeeInfo = userInfo.get();

                //Attendee uncheckin
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "api/onsite/markUnCheckedin?attendeeId=" + attendeeInfo.attendeeId,
                        this::unCheckin,
                        0);

                //Attendee search
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "api/onsite/search?email=" + attendeeInfo.username,
                        this::attendeeSearch,
                        0);

                //checkin form load
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                response = apiRunner.post(baseUrl + "api/onsite/checkinForm?attendeeId=" + attendeeInfo.attendeeId,
                        this::checkForm,
                        0);

                JSONObject valueMapJson = null;
                try {
                    valueMapJson = response.getJSONObject("valueMap");
                } catch (JSONException e) { e.printStackTrace(); }

                //checkin form save
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                JSONObject body = new JSONObject();
                body.put("valueMapJson", valueMapJson);
                apiRunner.postAsUrl(baseUrl + "api/onsite/saveCheckinForm?attendeeId=" + attendeeInfo.attendeeId, body,
                        this::jsonResponse,
                        0);

                //complete checkin
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "api/onsite/checkinComplete?attendeeId=" + attendeeInfo.attendeeId,
                        this::checkin,
                        0);

                //redeem gift
                //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                apiRunner.post(baseUrl + "api/onsite/claimSpiffs?attendeeId=" + attendeeInfo.attendeeId,
                        this::unCheckin,
                        0);

            } catch (Exception e) { }
        }
    }

    public boolean savePrinter(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("location");
    }

    public boolean savegifts(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("configuredSpiffs");
    }

    public boolean unCheckin(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("attendee");
    }

    public boolean checkin(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("checkin");
    }

    public boolean attendeeSearch(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("attendees") && json.has("rows");
    }

    public boolean checkForm(Object obj) {
        boolean response = jsonResponse(obj);
        JSONObject json = (JSONObject) obj;
        return response && json.has("form") && json.has("valueMap");
    }

}
