package load;

import apps.admin.AdminApp;
import configuration.PropertyReader;
import interaction.loadTesting.ApiTimerCollection;
import interaction.loadTesting.BuildReport;
import interaction.loadTesting.LoadQueue;
import interaction.loadTesting.Timer;
import logs.Log;
import org.joda.time.DateTime;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.MyJson;
import testHelp.Utils;

import java.util.HashMap;

public class LoadTestBase {

    protected static HashMap<String, ApiTimerCollection> perEndpoint = new HashMap<>();
    protected BuildReport buildReport;
    protected AdminApp adminApp;

    private static Integer threadCount = 0;
    public Timer timer;

    private boolean running = true;
    protected final static Integer delayMillisecondsBetweenStarts = Integer.parseInt(PropertyReader.instance().getProperty("delayMillisecondsBetweenStarts"));
    private int howManySecondsToRunTest = Integer.parseInt(getProperty("howManySecondsToRunTest"));
    private DateTime endTime;

    @BeforeClass
    public void startApi () {
        timer = new Timer();
        timer.start();
        adminApp = new AdminApp();
        Log.allLogging = false;
        perEndpoint = new HashMap<>();
        adminApp.loginApi();
        adminApp.setOrgAndEventApi(getProperty("loadOrgId"), getProperty("loadEventId"));
        endTime = DateTime.now().plusSeconds(howManySecondsToRunTest);
        buildReport = new BuildReport(perEndpoint, timer);
        buildReport.setThreadCountCall(LoadTestBase::getThreadCount);
        new Thread(this::printReports).start();
    }

    @AfterClass
    public void getReports() {
        Utils.sleep(2000);
        LoadQueue.finish();
        LoadQueue.join();
        running = false;
        buildReport.printFullReport();
    }

    public void printReports() {
        while (running) {
            buildReport.erase();
            buildReport.printGraphs();
            Utils.sleep(500);
        }
    }

    public boolean isTestRunning() {
        return endTime.isAfter(DateTime.now());
    }

    private int delay = 0;
    protected void startDelay() {
        synchronized (delayMillisecondsBetweenStarts) {
            delay += delayMillisecondsBetweenStarts;
        }
        Utils.sleep(delay);
        addThread();
    }

    protected String getProperty(String key) {
        return PropertyReader.instance().getProperty(key);
    }

    protected static void addThread() {
        synchronized (threadCount) {
            ++threadCount;
        }
    }

    public static int getThreadCount() {
        return threadCount;
    }

    public boolean jsonResponse(Object obj) {
        boolean response = true;
        try {
            JSONObject json = (JSONObject) obj;
            response = response && json.has("responseMessage");
            response = response && MyJson.getString(json, "responseMessage").equals("Success");

        } catch (Exception e) {
            response = false;
        }
        return response;
    }
}
