package emails;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.leads.LeadsApp;
import apps.workflows.WorkflowsApp;
import configuration.PropertyReader;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.Utils;

public class Email {

    protected AdminApp adminApp;
    protected LeadsApp leadsApp;
    protected WorkflowsApp workflowsApp;
    protected String attendeeId;
    protected String emailAddress;
    protected String password;
    protected EmailApi checkEmail;
    protected PropertyReader properties;
    protected String eventcode = PropertyReader.instance().getProperty("eventCode");
    protected String eventname = PropertyReader.instance().getProperty("event");
    protected String eventorg = PropertyReader.instance().getProperty("org");
    protected String confirmEmail = "Constellations Experiential Marketing Event Registration Invoice";
    protected String cancelEmail = "Registration Cancellation - Constellations Experiential Marketing Event";
    protected String sessionId;
    protected String exhibitorId;

    @BeforeClass
    public void setup() {
        emailAddress = new DataGenerator().generateValidEmail();
        password = new DataGenerator().generatePassword();
        adminApp = new AdminApp();
        workflowsApp = new WorkflowsApp();
        checkEmail = EmailApi.emailClient();
        properties = PropertyReader.instance();
        properties.setProperty("adminEmail2", properties.getProperty("adminEmail"));
    }

    @AfterClass
    public void cleanup() {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void resetEmail() {
        properties.setProperty("adminEmail", properties.getProperty("adminEmail2"));

        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (sessionId != null) {
            adminApp.deleteSession(sessionId);
            sessionId = null;
        } if (exhibitorId != null) {
            adminApp.deleteExhibitor(exhibitorId);
            exhibitorId = null;
        }

        PageConfiguration.getPage().deleteAllCookies();
        Utils.sleep(500);
        PageConfiguration.getPage().refreshPage();
    }

    protected void findTheEmail(String emailSubject, boolean isAttachment, String... content) {
        checkEmail.waitForEmail(emailSubject);
        EmailMessage message = checkEmail.getEmail(emailSubject);
        Assert.assertEquals(message.hasAttachment(), isAttachment, "the email '"+emailSubject+"' did not have the right attachment");

        //check the content of the attachment
        if (isAttachment) {
            String document = message.getAttachments().get(0);
            Log.debug("attached document: " + document, getClass());
            for (String c : content) {
                Assert.assertTrue(document.contains(c), "the attached document did not contain '" + c + "'");
            }
        }
        message.deleteEmail();
    }

    protected void loginAndCreateAttendee() {
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();

        attendeeId = adminApp.createAttendee(emailAddress, password);
        Utils.sleep(1000);
    }
}
