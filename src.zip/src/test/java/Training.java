import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorRolesSearchPage;
import apps.admin.adminPageObjects.exhibits.NewExhibitorRolePage;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.api.CommonApiActions;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import interaction.webUI.NetworkRequest;
import logs.Log;
import org.testng.Assert;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

public class Training {

    /*
        setting up project - clone repo, install maven(brew install maven),

        cp hooks/pre-push .git/hooks/pre-push

        Page Object Model and how we utilize it. webpage, Page Configuration
        selenium api calls
        app common operations and extra functionality
        email testing
        Utils(sleep, wait for true), Logging, data generator, property reader
        api testing - apiconfig, schema validation
        network sniffing
     */

//    @BeforeClass
    public void login() {
//        PropertyReader.instance().setProperty("enableNetworkLogging", true);
        AdminLoginPage.getPage().login();
    }

//    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

//    @Test
    public void myTest() {
        String name = "automation" + new DataGenerator().generateString(5);

        NewExhibitorRolePage.getPage().navigate();
        NewExhibitorRolePage.getPage().createRole(name);
        String roleId = ExhibitorRolesSearchPage.getPage().getIdByName(name);
        Utils.sleep(1000);
        Assert.assertNotNull(roleId);
        ExhibitorRolesSearchPage.getPage().deleteRole(roleId);

        Utils.waitForTrue(()->ExhibitorRolesSearchPage.getPage().getIdByName(name) == null);
        roleId = ExhibitorRolesSearchPage.getPage().getIdByName(name);
        Assert.assertNull(roleId);
    }

//    @Test
    public void myApiTest() {
        String name = "automation" + new DataGenerator().generateString(5);

        NewExhibitorRolePage.getPage().navigate();
        NewExhibitorRolePage.getPage().createRole(name);
        String roleId = ExhibitorRolesSearchPage.getPage().getIdByName(name);
        Utils.sleep(1000);
        Assert.assertNotNull(roleId);
        PageConfiguration.getPage().quit();

        CommonApiActions.getAdminApp().loginApi();
        ApiConfig config = Api.Post( "{{adminUrl}}/exhibitorParticipantRoleDelete.focus?id=" + roleId);

        Log.info(config.getResponse().toString(), getClass());
        config.schemaValidate(MyJson.createJSON("{\"data\":{\"responseMessage\":\".*\",\"errors\":[{\"code\":\"\",\"message\":\"Unable to delete\"}]"));
//        ExhibitorRolesSearchPage.getPage().deleteRole(roleId);

//        Utils.waitForTrue(()->ExhibitorRolesSearchPage.getPage().getIdByName(name) == null);
//        roleId = ExhibitorRolesSearchPage.getPage().getIdByName(name);
//        Assert.assertNull(roleId);
    }

//    @Test
    public void myNetworkTest() {
        String roleName = "automation" + new DataGenerator().generateString(5);

        NewExhibitorRolePage.getPage().navigate();

        PageConfiguration.getPage().startNetworkMonitoring();
        NewExhibitorRolePage.getPage().createRole(roleName);
        Utils.sleep(1000, "let the create finish so we can delete easily");
        NetworkRequest request = PageConfiguration.getPage().getRequestByEndpoint("exhibitorParticipantRoleProcess.do");
        PageConfiguration.getPage().stopNetworkMonitoring();

        Assert.assertTrue(request.getRequestBody().contains(roleName));
        Assert.assertEquals(request.getResponseContent(), "{\"data\":{\"responseMessage\":\"success\"}}");


        String roleId = ExhibitorRolesSearchPage.getPage().getIdByName(roleName);
        Assert.assertNotNull(roleId, "role id should not be null");
        ExhibitorRolesSearchPage.getPage().deleteRole(roleId);

        Utils.waitForTrue(()-> ExhibitorRolesSearchPage.getPage().getIdByName(roleName) == null);
        roleId = ExhibitorRolesSearchPage.getPage().getIdByName(roleName);
        Assert.assertNull(roleId, "role id should be null after deleting");
    }

//    @Test
    public void emailTest() {
        EmailApi.emailClient().sendEmail("MY TEST EMAIL",
                "rainfocustestautomationuser@gmail.com",
                "This is my test email");

        EmailApi.emailClient().waitForEmail("MY TEST EMAIL");
        EmailMessage emessage = EmailApi.emailClient().getEmail("MY TEST EMAIL");
        Assert.assertEquals(emessage.getBody(), "This is my test email");

//        emessage.deleteEmail();
    }
}


//
//import apps.PageConfiguration;
//import apps.admin.adminPageObjects.AdminLoginPage;
//import apps.admin.adminPageObjects.exhibits.ExhibitorRolesSearchPage;
//import apps.admin.adminPageObjects.exhibits.NewExhibitorRolePage;
//import configuration.PropertyReader;
//import interaction.api.Api;
//import interaction.api.ApiConfig;
//import interaction.api.CommonApiActions;
//import interaction.gmail.EmailApi;
//import interaction.gmail.EmailMessage;
//import interaction.webUI.NetworkRequest;
//import org.json.JSONObject;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
//import testHelp.DataGenerator;
//import testHelp.MyJson;
//import testHelp.Utils;
//
//public class Training {
//
//    /*
//        setting up project - clone repo, install maven(brew install maven), cp hooks/pre-push .git/hooks/pre-push
//        Page Object Model and how we utilize it. webpage, Page Configuration
//        selenium api calls
//        app common operations and extra functionality
//        email testing
//        Utils(sleep, wait for true), Logging, data generator, property reader
//        api testing - apiconfig, schema validation
//        network sniffing
//     */
//
//    @BeforeClass
//    public void login() {
//        PropertyReader.instance().setProperty("enableNetworkLogging", true);
//        AdminLoginPage.getPage().login();
//    }
//
//    @AfterClass
//    public void close() {
//        PageConfiguration.getPage().quit();
//    }
//
//    @Test
//    public void myTest() {
//        String roleName = "automation" + new DataGenerator().generateString(5);
//
//        NewExhibitorRolePage.getPage().navigate();
//        NewExhibitorRolePage.getPage().createRole(roleName);
//        Utils.sleep(1000, "let the create finish so we can delete easily");
//        String roleId = ExhibitorRolesSearchPage.getPage().getRoleId(roleName);
//        Assert.assertNotNull(roleId, "role id should not be null");
//        ExhibitorRolesSearchPage.getPage().deleteRole(roleId);
//
//        Utils.waitForTrue(()-> ExhibitorRolesSearchPage.getPage().getRoleId(roleName) == null);
//        roleId = ExhibitorRolesSearchPage.getPage().getRoleId(roleName);
//        Assert.assertNull(roleId, "role id should be null after deleting");
//    }
//
//    @Test
//    public void myApiTest() {
//        String roleName = "automation" + new DataGenerator().generateString(5);
//
//        NewExhibitorRolePage.getPage().navigate();
//        NewExhibitorRolePage.getPage().createRole(roleName);
//        Utils.sleep(1000, "let the create finish so we can delete easily");
//        String roleId = ExhibitorRolesSearchPage.getPage().getRoleId(roleName);
//        Assert.assertNotNull(roleId, "role id should not be null");
//        PageConfiguration.getPage().quit();
//
//        CommonApiActions.getAdminApp().loginApi();
////        ApiConfig response = Api.Post(PropertyReader.instance().getProperty("adminUrl") + "/exhibitorParticipantRoleDelete.focus?id=" + roleId);
//        ApiConfig response = Api.Post("{{adminUrl}}/exhibitorParticipantRoleDelete.focus?id=" + roleId);
//
//        JSONObject schema = MyJson.createJSON("{\"data\":{\"status\":\"success\"}}");
//        Assert.assertTrue(response.schemaValidate(schema));
//    }
//
//    @Test
//    public void myNetworkTest() {
//        String roleName = "automation" + new DataGenerator().generateString(5);
//
//        NewExhibitorRolePage.getPage().navigate();
//
//        PageConfiguration.getPage().startNetworkMonitoring();
//        NewExhibitorRolePage.getPage().createRole(roleName);
//        Utils.sleep(1000, "let the create finish so we can delete easily");
//        NetworkRequest request = PageConfiguration.getPage().getRequestByEndpoint("exhibitorParticipantRoleProcess.do");
//        PageConfiguration.getPage().stopNetworkMonitoring();
//
//        Assert.assertTrue(request.getRequestBody().contains(roleName));
//        Assert.assertEquals(request.getResponseContent(), "{\"data\":{\"responseMessage\":\"success\"}}");
//
//
//        String roleId = ExhibitorRolesSearchPage.getPage().getRoleId(roleName);
//        Assert.assertNotNull(roleId, "role id should not be null");
//        ExhibitorRolesSearchPage.getPage().deleteRole(roleId);
//
//        Utils.waitForTrue(()-> ExhibitorRolesSearchPage.getPage().getRoleId(roleName) == null);
//        roleId = ExhibitorRolesSearchPage.getPage().getRoleId(roleName);
//        Assert.assertNull(roleId, "role id should be null after deleting");
//    }
//
//    @Test
//    public void emailTest() {
//        EmailApi.emailClient().sendEmail("MY TEST EMAIL",
//                "rainfocustestautomationuser@gmail.com",
//                "This is my test email");
//
//        EmailApi.emailClient().waitForEmail("MY TEST EMAIL");
//        EmailMessage emessage = EmailApi.emailClient().getEmail("MY TEST EMAIL");
//        Assert.assertEquals(emessage.getBody(), "This is my test email");
//
//        emessage.deleteEmail();
//    }
//}
