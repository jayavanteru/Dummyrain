import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.forms.Form;
import apps.admin.forms.formAttributes.FormAttribute;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.webUI.NetworkRequest;
import logs.Log;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.io.*;
import java.util.HashMap;
import java.util.List;

public class practiceTest {


 //   @Test
    public void startApps() {
//        final MobileDriver<MobileElement> driver = new MobileUI().getDriver();
//
//        final By button = By.className("android.view.View");
//        final TapOptions tapOptions = new TapOptions();
//
//        final MobileElement element = driver.findElement(button);
//        element.click();
 /*       LeadsConfigurationPage.getPage().enterAssetTag("4732904710923175897");
        LeadsConfigurationPage.getPage().clickTheButton();*/

        Assert.assertTrue(WorkflowPage.getPage().spoofCheck());




//        tapOptions.withElement(new ElementOption().withElement(element));
//        new TouchAction(driver).tap(tapOptions).perform();
//        final TouchActions touchActions = new TouchActions(driver);
//                touchActions.singleTap(driver.findElement(button)).perform();
    }

    @Test
    public void testAuth() {
//        PageConfiguration.getPage().navigateTo("http://espn.com");
//        StartJenkinsTest.startTest("dev", "chrome", "Test", "master");
//        PageConfiguration.getPage().quit();
    }

    @Test
    public void auth() {
        String jump = "https://console.jumpcloud.com/login?context=sso&redirectTo=saml2%2Fjenkins-qa";
        String jenkins = "https://jenkins-qa.corp.rainfocus.com/job/Test_Starter/buildWithParameters?token=Ra1yN4wlqZPH5MelpLhWN6q2OGwLYdtF&TESTPATH=admin.nothing.nothing";

        PageConfiguration.getPage().navigateTo(jump);
        while (PageConfiguration.getPage().getCurrentUrl().contains("console.jumpcloud.com")) {
            Utils.sleep(800);
        }
        final AdminApp adminApp = new AdminApp();
        Utils.sleep(1000);
        adminApp.syncCookieFromBrowserToApi();
        PageConfiguration.getPage().quit();
        Api api = adminApp.getApi();
        final ApiConfig apiConfig = api.post(new ApiConfig(jenkins));
        Log.info(apiConfig.getResponse().toString(), getClass());
    }

//    @Test
    public void myFailingTest() {
        AdminLoginPage.getPage().login();
        Utils.sleep(1000);
        PageConfiguration.getPage().quit();
    }

    HashMap<String, Integer> pageCoverage = new HashMap<>();
    @Test
    public void fullPageCoveredReport() throws IOException {
        File dir = new File("runner");

        for (File file : dir.listFiles()) {
            if (file.getName().endsWith("_pages.csv")) {
                Log.info("reading file " + file.getName(), getClass());
                final FileReader reader = new FileReader(file);
                final BufferedReader buffer = new BufferedReader(reader);
                buffer.lines().forEach(l->addLineToMap(l.trim()));
            }
        }

        final FileWriter writer = new FileWriter("coverage.csv", true);

        for (String key : pageCoverage.keySet()) {
            writer.append(key)
                    .append(",")
                    .append(key.substring(key.lastIndexOf(".")+1))
                    .append(",")
                    .append(pageCoverage.get(key).toString())
                    .append("\n");
        }
        writer.close();
    }

    public void addLineToMap(String line) {
        if (line.isEmpty() || !line.contains(",")) return;
        String[] row = line.split(",");
        int number = Integer.parseInt(row[2]);

        if (!pageCoverage.containsKey(row[0])) {
            pageCoverage.put(row[0], 0);
        }
        pageCoverage.put(row[0], pageCoverage.get(row[0]) + number);
    }

//    @Test
    public void navigationTest() {

        AdminLoginPage.getPage().login();
        PageConfiguration.getPage().startNetworkMonitoring();

        NavigationBar.getPage().gotoPage(NavigationBar.getPage().ATTENDEES);
        AttendeeSearchPage.getPage().searchFor("automation");
        AttendeeSearchPage.getPage().searchFor("Bryce");

        NetworkRequest request1 = PageConfiguration.getPage().getRequestByEndpoint("attendeesSearchFAKE.do");
        NetworkRequest request = PageConfiguration.getPage().getRequestByEndpoint("attendeesSearch.do");
        PageConfiguration.getPage().stopNetworkMonitoring();

        Assert.assertNull(request1);
        Assert.assertNotNull(request);
        Assert.assertTrue(request.getResponseContent().contains("\"firstname\":\"Bryce\""));
        System.out.println(request.toString());

        PageConfiguration.getPage().quit();
    }


    private AdminApp adminApp = new AdminApp();
    private DataGenerator generator = new DataGenerator();
    private String fileTypeId = "6654021218154482449";
    private String attendeeId;
    private String fileId;

//    @Test
    public void form() {
        String formid = "a146268e-3a89-11e7-b859-06fe95280409";

        adminApp.loginApi();

        Form form = adminApp.getFormApi(formid);
        List<FormAttribute> attributes = form.getFormAttributes();

        for (FormAttribute attr : attributes) {
            attr.getAttributeId();
            attr.getAttributeValidInput();
            attr.getAttributeInvalidInput();
        }

        JSONObject schema = form.getSchemaValidation();
    }


}
