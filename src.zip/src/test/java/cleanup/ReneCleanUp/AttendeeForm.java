package cleanup.ReneCleanUp;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class AttendeeForm {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "", firefoxIssue = "")
    public void removeAllAttributesFromAttendeeForm() {
        String[] EVENTS = {"Blue Event A", "Blue Event B" ,"Blue Event C" ,"Blue Event D", "Blue Event E", "Blue Event F"};
        for (int i = 0; i < EVENTS.length; i++) {
            OrgEventData.getPage().setOrgAndEvent("RF Automation", EVENTS[i]);

            //get to attendee page
            AttendeeSearchPage.getPage().navigate();
            AttendeeSearchPage.getPage().search();
            if(AttendeeSearchPage.getPage().isAnySearchResults()){
                AttendeeSearchPage.getPage().editItem();
            } else {
                attendeeId = adminApp.createAttendee();
            }

            //remove attributes from form
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().removeAllAttributes();
            EditFormPage.getPage().submitForm();


            //delete attendee
            if(!(attendeeId == null)){
                adminApp.deleteAttendee(attendeeId);
                attendeeId = null;
            }
        }
    }
}
