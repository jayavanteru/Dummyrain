package cleanup;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.AdminOrgPage;
import apps.admin.adminPageObjects.MasterDelete;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadOrdersTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorNewContactPage;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorOrdersTab;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.housing.HotelsSearchPage;
import apps.admin.adminPageObjects.housing.SubBlockSearchPage;
import apps.admin.adminPageObjects.libraries.AdminOrgAttributesPage;
import apps.admin.adminPageObjects.libraries.ImportTemplatesSearchPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import apps.admin.adminPageObjects.libraries.WidgetBuilderSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingDaysSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingProgramsSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingRoomsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.PackageSearchPage;
import apps.admin.adminPageObjects.registration.PaymentTypesSearchPage;
import configuration.PropertyReader;
import interaction.awsDatabase.DbQueryConfig;
import interaction.awsDatabase.DbQueryRunner;
import interaction.pageObjects.rfBy;
import logs.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.xbill.DNS.Master;
import testHelp.Utils;

import java.util.*;

public class CleanupTest {

    private AdminApp app;

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @BeforeClass
    public void login() {
        app = new AdminApp();
        AdminLoginPage.getPage().login();
    }

//    @Test
    public void cleanupPaymentTypes() {
        OrgEventData.getPage().setOrgAndEvent();
        //get the ids of the payment types
        PaymentTypesSearchPage searchPage = PaymentTypesSearchPage.getPage();
        searchPage.navigate();
        List<String> ids = searchPage.getIds("automation......");
        for (String id : ids ) {
            String paymentTypePrices = "DELETE FROM paymenttypeprices WHERE paymenttype_id = '" + id + "'";
            String orderLineItems = "DELETE FROM ORDERLINEITEMS WHERE currency_id = '" + id + "'";

            DbQueryConfig configPaymentType = DbQueryConfig.createCustomConfig(paymentTypePrices);
            DbQueryConfig configLineItems = DbQueryConfig.createCustomConfig(orderLineItems);
            DbQueryRunner dbRunner = new DbQueryRunner();
            dbRunner.runAction(configPaymentType);
            dbRunner.runAction(configLineItems);

            app.deletePaymentType(id);
        }
    }

    @Test
    public void deleteRegCodeAllocation() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#regCode/exhibitor/allocators.do";
        By searchField = By.id("regcodeallocatorparam");
        By searchButton = By.cssSelector("[data-qa-id=\"search-button\"]");
        String onclick = "event.cancelBubble=true; document.location.hash='regCode/exhibitor/allocatorItem.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/regCode/exhibitor/allocatorItemDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteFileTypes() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#fileTypes.do";
        By searchField = By.id("filetypeparam");
        By searchButton = By.cssSelector("[data-qa-id=\"search-button\"]");
        String onclick = "document.location.hash='fileType.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/fileTypeDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteAttributesNew() {
        PropertyReader.instance().setProperty("event", "GLOBAL");
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#attributes.do";
        By searchField = By.id("attributeparam");
        By searchButton = By.id("rf-search-button");
        String onclick = "event.cancelBubble=true; document.location.hash='loadAttributeEdit.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/processAttributeDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteForms() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#forms.do";
        By searchField = By.id("formparam");
        By searchButton = By.id("rf-search-button");
        String onclick = "event.cancelBubble=true; document.location.hash='form.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/formDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteDeviceAllocation() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#lead/allocation/exhibitorSearch.do";
        By searchField = By.id("filter_param");
        By searchButton = By.className("mdBtnR-primary");
        MasterDelete.getPage().setAttributeUsedToFindId("data-test");
        String onclick = "adv-table-row-actions-";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/lead/deleteAllocationItem.do?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deletePackages() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#inventoryItems.do";
        By searchField = By.id("inventoryitemparam");
        By searchButton = By.id("rf-search-button");
        String onclick = "event.cancelBubble=true; document.location.hash='inventoryItem.do?itemId=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/eventInventoryItemDelete.focus?type=exhibitor&itemId=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteTaskQualifier() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#entityTaskQualifiers.do";
        By searchField = By.id("entitytaskqualifierparam");
        By searchButton = By.className("search-output-submit");
        String onclick = "event.cancelBubble=true; document.location.hash='entityTaskQualifier.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/entityTaskQualifierDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteRules() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#rulesPage.do";
        By searchField = By.id("filter_param");
        By searchButton = By.cssSelector(".search-actions .mdBtnR-primary");
        String onclick = "action-";
        MasterDelete.getPage().setAttributeUsedToFindId("id");
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/ruleDelete.do?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteAccounts() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#accounts.do";
        By searchField = By.id("filter_param");
        By searchButton = By.className("mdBtnR-primary");
        String onclick = "adv-table-row-actions-";
        MasterDelete.getPage().setAttributeUsedToFindId("data-test");
        By pages = By.cssSelector("[data-test=\"pagination-undefined\"] li");
        String deleteApi = "/accountDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteBooths() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#booths.do";
        By searchField = By.id("filter_param");
        By searchButton = By.className("mdBtnR-primary");
        String onclick = "adv-table-row-actions-";
        MasterDelete.getPage().setAttributeUsedToFindId("data-test");
        By pages = By.cssSelector("[data-test=\"pagination-undefined\"] li");
        String deleteApi = "/booth/delete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteMeetingLengths() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#meetingLengths.do";
        By searchField = By.id("lengthparam");
        By searchButton = By.className("mdBtnR-primary");
        String onclick = "event.cancelBubble=true; document.location.hash='meetingLength.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/meetingLengthDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteMeetingDays() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#meetingDays.do";
        By searchField = By.id("dayparam");
        By searchButton = By.id("rf-search-button");
        String onclick = "event.cancelBubble=true; document.location.hash='meetingDay.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/meetingDayDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteSessionDays() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#days.do";
        By searchField = By.id("dayparam");
        By searchButton = By.id("rf-search-button");
        String onclick = "event.cancelBubble=true; document.location.hash='day.do?id=";
        By pages = MasterDelete.getPage().defaultPages();
        String deleteApi = "/dayDelete.focus?id=";
        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

    @Test
    public void deleteImportTemplates() {
        OrgEventData.getPage().setOrgAndEvent();

        ImportTemplatesSearchPage.getPage().navigate();
        int count = 0;

        ArrayList<String> test_automation = ImportTemplatesSearchPage.getPage().getIdsMatching("Test Automation");
        while (test_automation.size() > 0) {
            for (String id : test_automation) {
                ImportTemplatesSearchPage.getPage().deleteImportTemplateById(id);
                Log.info("deleted: " +(++count), getClass());
            }
            ImportTemplatesSearchPage.getPage().searchFor("");
            test_automation = ImportTemplatesSearchPage.getPage().getIdsMatching("Test Automation");

        }

    }

    @Test
    public void deleteMeetingPrograms() {
        final MeetingProgramsSearchPage meetingPrograms = MeetingProgramsSearchPage.getPage();
        PageConfiguration.getPage().justWait();
        OrgEventData.getPage().setOrgAndEvent();
        meetingPrograms.navigate();
        meetingPrograms.search("automation");
        final WebDriver selbrowser = PageConfiguration.getPage().getBrowser();

        By pages = By.cssSelector("li[class=' ']");
        int size = selbrowser.findElements(pages).size();
        selbrowser.findElements(pages).get(--size).click();
        for (int i = size; i > 0; --i) {
            PageConfiguration.getPage().justWait();
            List<String> programIDs = meetingPrograms.getAutomationMeetingProgramIDs();
            selbrowser.findElements(pages).get(i).click();
            programIDs.forEach(app::deleteMeetingProgram);
        }

    }

//    @Test
    public void deleteAttributes() {
        String event = PropertyReader.instance().getProperty("event");
        PropertyReader.instance().setProperty("event", "GLOBAL");
        OrgEventData.getPage().setOrgAndEvent();
        PropertyReader.instance().setProperty("event", event);

        //find the attributes
        AdminOrgAttributesPage attributesPage = AdminOrgAttributesPage.getPage();
        attributesPage.navigateToPage();
        attributesPage.waitForPageToLoad();
        attributesPage.searchFor("automation");
        attributesPage.goToPage(10);
        String[] automationIds = attributesPage.findAutomationAttributes();
        String[] oldIds = {};
        //go for multiple pages too
        while (!Arrays.equals(automationIds, oldIds)) {

            for (String id : automationIds) {
                app.deleteAttribute(id);
            }
            oldIds = automationIds;
            attributesPage.searchFor("automation");
            attributesPage.goToPage(11);
            automationIds = attributesPage.findAutomationAttributes();
        }
    }

//    @Test
    public void deletePackages_old() {
        PackageSearchPage pkgSearch = PackageSearchPage.getPage();
        OrgEventData.getPage().setOrgAndEvent();

        pkgSearch.navigate();
        final List<String> packageNames = pkgSearch.getSearchResults("automation");

        for (int i = 0; i < packageNames.size(); ++i) {
            final String name = packageNames.get(i);
            //automation names don't have spaces
            if (!name.contains(" ") && pkgSearch.isDeletable(i)) {
                pkgSearch.deletePackage(i);
                Utils.sleep(500, "let the delete process complete");
            }
        }
    }

    @Test
    public void deleteExhibitors() {
        By lastpage = By.cssSelector("[data-test=\"pagination-last\"]");
        By previous = By.cssSelector("[data-test=\"pagination-prev\"]");
        Set<String> previousIds = new HashSet<>();
        Set<String> allIds;
        OrgEventData.getPage().setOrgAndEvent();

        ExhibitorSearchPage exhibitorSearchPage = ExhibitorSearchPage.getPage();

        int i = 0;
        int size = 0;
        //delete for multiple pages
        do {
            exhibitorSearchPage.navigate();
            exhibitorSearchPage.searchFor("automation");
            size = Integer.parseInt(PageConfiguration.getPage().getBrowser().findElement(lastpage).getText());
            PageConfiguration.getPage().getBrowser().findElement(lastpage).click();
            for (int j = 0; j < i; ++j) {
                PageConfiguration.getPage().getBrowser().findElement(previous).click();
            } ++i;
            allIds = exhibitorSearchPage.getAllIds("......automation");

            //remove ids that we have already tried
            allIds.removeAll(previousIds);

            for (String id : allIds) {
                //delete any orders
                AdminExhibitorOrdersTab.getPage().navigate(id);
                Utils.sleep(1000);
                if (AdminExhibitorOrdersTab.getPage().isAnyOrders()) {
                    AdminExhibitorOrdersTab.getPage().selectFirstOrder();
                    AdminExhibitorOrdersTab.getPage().deleteOrders();
                    AdminExhibitorOrdersTab.getPage().toggleCancellationEmail();
                    AdminExhibitorOrdersTab.getPage().cancelOrder();
                }
                //delete any lead orders
                AdminExhibitorLeadOrdersTab.getPage().navigate(id);
                Utils.sleep(1000);
                if (AdminExhibitorLeadOrdersTab.getPage().isAnyOrders()) {
                    AdminExhibitorLeadOrdersTab.getPage().selectAllOrders();
                    AdminExhibitorLeadOrdersTab.getPage().deleteOrders();
                    AdminExhibitorLeadOrdersTab.getPage().toggleCancellationEmail();
                    AdminExhibitorLeadOrdersTab.getPage().cancelOrder();
                    AdminExhibitorLeadOrdersTab.getPage().clearError();
                }
                app.deleteExhibitor(id);
            }
            Utils.sleep(2000);
            previousIds.addAll(allIds);
        } while (allIds.size() > 0);
    }

    @Test
    public void deleteAttendees() {
        OrgEventData.getPage().setOrgAndEvent();

        AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
        attendeeSearchPage.navigate();

        //delete for multiple pages
        deleteFromSearch("%rainfocustestautomationuser");
        deleteFromSearch("%automation@rainfocus.com");
    }

    @Test
    public void deleteEntityTaskQualifiers() {
        PageConfiguration.getPage().justWait();
        TaskQualifierSearchPage.getPage().navigate();
        final List<String> ids = TaskQualifierSearchPage.getPage().getAllIds("automation");
        ids.forEach(id ->
                PageConfiguration.getPage().post(PropertyReader.instance().getProperty("adminUrl") + "/entityTaskQualifierDelete.focus?id=" + id));

    }

    private void deleteFromSearch(String searchFor) {
        Set<String> previousIds = new HashSet<>();
        Set<String> allIds;
        AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
        do {
            attendeeSearchPage.searchFor(searchFor);

            allIds = attendeeSearchPage.getAllIds();

            //remove ids that we have already tried
            allIds.removeAll(previousIds);

            for (String id : allIds) {
                app.deleteAttendee(id);
            }
            Utils.sleep(2000);
            previousIds.addAll(allIds);
        } while (allIds.size() > 0);
    }

    @Test
    public void deleteSessions() {
        OrgEventData.getPage().setOrgAndEvent();

        String url = "/rain.focus#sessions.do";
        By searchField = By.id("filter_param");
        By searchButton = By.cssSelector(".search-actions .mdBtnR-primary");
        String onclick = "adv-table-row-";
        MasterDelete.getPage().setAttributeUsedToFindId("data-test");
        By pages = By.cssSelector("[data-test=\"pagination-undefined\"] li");
        String deleteApi = "/sessionDelete.focus?id=";

        MasterDelete.getPage().deleteThings(url, searchField, searchButton, onclick, pages, deleteApi);
    }

//    @Test
//    public void deleteSessions() {
//        Set<String> previousIds = new HashSet<>();
//        Set<String> allIds;
//        OrgEventData.getPage().setOrgAndEvent();
//
//        SessionSearchPage sessionSearchPage = SessionSearchPage.getPage();
//        sessionSearchPage.navigate();
//
//        //delete for multiple pages
//        do {
//            sessionSearchPage.searchFor("automation");
//
//            allIds = sessionSearchPage.getAllIds(".....automation");
//            allIds.addAll(sessionSearchPage.getAllIds("......automation"));
//            allIds.addAll(sessionSearchPage.getAllIds("automation....."));
//
//            //remove ids that we have already tried
//            allIds.removeAll(previousIds);
//
//            allIds.forEach(app::deleteSession);
//
//            Utils.sleep(2000);
//            previousIds.addAll(allIds);
//        } while (allIds.size() > 0);
//    }

    @Test
    public void deleteRoomsAndDays() {
        //delete Session rooms
        RoomsSearchPage.getPage().navigate();
        Set<String> previousIds = new HashSet<>();
        Set<String> roomIds;

        do {
            RoomsSearchPage.getPage().searchFor("automation");
            roomIds = RoomsSearchPage.getPage().getIdsMatching("automation.....");

            roomIds.removeAll(previousIds);

            roomIds.forEach(app::deleteSessionRoom);

            Utils.sleep(2000);
            previousIds.addAll(roomIds);
        } while (roomIds.size() > 0);
        previousIds = new HashSet<>();

        //delete meeting rooms
        MeetingRoomsSearchPage.getPage().navigate();
        do {
            MeetingRoomsSearchPage.getPage().searchFor("automation");
            roomIds = MeetingRoomsSearchPage.getPage().getIdsMatching("automation.....");

            roomIds.removeAll(previousIds);

            roomIds.forEach(MeetingRoomsSearchPage.getPage()::deleteMeetingRoomById);

            Utils.sleep(2000);
            previousIds.addAll(roomIds);
        } while (roomIds.size() > 0);
        previousIds = new HashSet<>();

        //delete session days
        SessionDaysSearchPage.getPage().navigate();
        do {
            SessionDaysSearchPage.getPage().searchFor("automation");
            roomIds = SessionDaysSearchPage.getPage().getIdsMatching("automation.....");

            roomIds.removeAll(previousIds);

            roomIds.forEach(SessionDaysSearchPage.getPage()::deleteSessionDayById);

            Utils.sleep(2000);
            previousIds.addAll(roomIds);
        } while (roomIds.size() > 0);
        previousIds = new HashSet<>();

        //delete meeting days
        MeetingDaysSearchPage.getPage().navigate();
        do {
            MeetingDaysSearchPage.getPage().searchFor("automation");
            roomIds = MeetingDaysSearchPage.getPage().getIdsMatching("automation.....");

            roomIds.removeAll(previousIds);

            roomIds.forEach(MeetingDaysSearchPage.getPage()::deleteMeetingDayById);

            Utils.sleep(2000);
            previousIds.addAll(roomIds);
        } while (roomIds.size() > 0);
    }

    @Test
    public void cleanupRegressionHotels() {
        HotelsSearchPage search = HotelsSearchPage.getPage();
            String regressionHotel = "Regression Hotel";
            search.navigate();
            List<String> hotelIds = new ArrayList<>();
            List<String> currentHotelIds;
            do {
                search.searchFor(regressionHotel);
                currentHotelIds = new ArrayList<>();
                int count = search.rowCount();
                for(int i = 0; i < count; i++) {
                    String hotelId = search.getHotelId(i);
                    String hotelName = search.getHotelName(hotelId);
                    if (hotelName.startsWith(regressionHotel)) {
                        currentHotelIds.add(hotelId);
                    }
                }
                currentHotelIds.removeAll(hotelIds);
                currentHotelIds.forEach(app::deleteHotel);
                hotelIds.addAll(currentHotelIds);
            } while(currentHotelIds.size() > 0);
    }

    @Test
    public void cleanupAutomatedSignage() {
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        WidgetBuilderSearchPage widget = WidgetBuilderSearchPage.getPage();
            String automatedSignage = "Automated Signage";
            widget.navigate();
            List<String> widgetIds = new ArrayList<>();
            List<String> currentWidgetIds;
            do {
                widget.searchFor(automatedSignage);
                currentWidgetIds = new ArrayList<>();
                int count = widget.rowCount();
                for(int i = 0; i < count; i++) {
                    String widgetId = widget.getWidgetId(i);
                    String widgetName = widget.getWidgetName(widgetId);
                    if(widgetName.startsWith(automatedSignage)) {
                        currentWidgetIds.add(widgetId);
                    }
                }
                currentWidgetIds.removeAll(widgetIds);
                currentWidgetIds.forEach(app::deleteWidget);
                widgetIds.addAll(currentWidgetIds);
            } while(currentWidgetIds.size() > 0);
    }

    @Test
    public void cleanupRegressionSubBlocks() {
        SubBlockSearchPage search = SubBlockSearchPage.getPage();
            String regressionSubBlock = "Regression Sub-Block";
            search.navigate();
            List<String> subBlockIds = new ArrayList<>();
            List<String> currentSubBlockIds;
            do {
                search.searchSubBlock(regressionSubBlock);
                currentSubBlockIds = new ArrayList<>();
                int count = search.rowCount();
                for(int i = 0; i < count; i++) {
                    String subBlockId = search.getSubBlockId(i);
                    String subBlockName = search.getSubBlockName(subBlockId);
                    if (subBlockName.toLowerCase().startsWith(regressionSubBlock.toLowerCase())) {
                        currentSubBlockIds.add(subBlockId);
                    }
                }
                currentSubBlockIds.removeAll(subBlockIds);
                currentSubBlockIds.forEach(app::deleteSubBlock);
                subBlockIds.addAll(currentSubBlockIds);
            } while(currentSubBlockIds.size() > 0);
    }

    @Test
    public void cleanUpTargetedAgendaGroups() {
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        TargetedAgendaGroupsPage agendaGroups = TargetedAgendaGroupsPage.getPage();
        agendaGroups.navigate();
        String[] names = agendaGroups.getGroupNames();
        TargetedAgendasPage agendasPage = TargetedAgendasPage.getPage();
        for(int i = 0; i <= names.length - 1; i++) {
            if(names[i].contains("automation")) {
                agendaGroups.selectGroup(names[i]);
                agendasPage.openSettingsSlideOut();
                agendasPage.switchToSettingsTab("Advanced");
                agendasPage.deleteCurrentGroup();
            }
        }
    }
}
