package Leads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.LeadsAppPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ChatsDoNotAppear {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorId, exhibitorName, attendeeId, attendeeEmail;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Chat Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        AttendeeSearchPage.getPage().navigate();
        adminApp.deleteExhibitor(exhibitorId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-43813", firefoxIssue = "RA-43814")
    public void chatsDoNotAppear() {
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail(), attendeeEmail, attendeeEmail);
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");

        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendeeEmail,"Primary Owner");

        adminApp.spoofIntoLeads(attendeeEmail, 1);
        Assert.assertFalse(LeadsAppPage.getPage().chatNavigationItemRendered(), "CHAT NAV ITEM RENDERED AND SHOULD NOT HAVE");
    }
}
