package Leads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import apps.admin.adminPageObjects.onsite.LeadsDeviceConfigurationPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.LeadsEquipRentalAgreement;
import apps.leads.leadsPageObjects.LeadsManageDevice;
import apps.leads.leadsPageObjects.LeadsPortalNoAccess;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class LeadsPortalPermissions {

    String role1;
    String role2;
    String role3;
    String role1Id;
    String role2Id;
    String role3Id;
    String exhibitor;
    String exhibitorId;
    String AttendeeFN1;
    String AttendeeFN2;
    String AttendeeFN3;
    String AttendeeLN1;
    String AttendeeLN2;
    String AttendeeLN3;
    String AttendeeEmail1;
    String AttendeeEmail2;
    String AttendeeEmail3;
    String attendeeId1;
    String attendeeId2;
    String attendeeId3;

    NewExhibitorRolePage ExhibitorRole = NewExhibitorRolePage.getPage();
    ExhibitorRolesSearchPage ExhibitorRoleSearch = ExhibitorRolesSearchPage.getPage();
    LeadsDeviceConfigurationPage LeadsConfig = LeadsDeviceConfigurationPage.getPage();
    AdminExhibitorContactsTab contacts = AdminExhibitorContactsTab.getPage();
    AdminExhibitorLeadOrdersTab leadOrdersPage = AdminExhibitorLeadOrdersTab.getPage();
    LeadsEquipRentalAgreement eraPage = LeadsEquipRentalAgreement.getPage();
    LeadsManageDevice leads = LeadsManageDevice.getPage();

    final DataGenerator data = new DataGenerator();
    AdminApp AdminApp = new AdminApp();
    LeadsApp leadsApp = new LeadsApp();

    @BeforeClass
    public void setup() {
        role1 = data.generateName();
        role2 = data.generateName();
        role3 = data.generateName();
        exhibitor = data.generateName();
        AttendeeFN1 = data.generateName();
        AttendeeFN2 = data.generateName();
        AttendeeFN3 = data.generateName();
        AttendeeLN1 = data.generateName();
        AttendeeLN2 = data.generateName();
        AttendeeLN3 = data.generateName();
        AttendeeEmail1 = data.generateEmail();
        AttendeeEmail2 = data.generateEmail();
        AttendeeEmail3 = data.generateEmail();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        PropertyReader.instance().setProperty("org", "RF Automation" );
        PropertyReader.instance().setProperty("event", "Onsite Automation" );
        PropertyReader.instance().setProperty("eventId", "1603141373onsiteauto" );

    }

    @AfterClass
    public void close() {
        LeadsConfig.navigate();
        AdminApp.deleteAttendee(attendeeId1);
        AdminApp.deleteAttendee(attendeeId2);
        AdminApp.deleteAttendee(attendeeId3);
        AdminApp.deleteExhibitorRole(role1Id);
        AdminApp.deleteExhibitorRole(role2Id);
        AdminApp.deleteExhibitorRole(role3Id);
        AdminApp.deleteExhibitor(exhibitorId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18812", firefoxIssue = "RA-21284")
    public void leadsPortalPermissionsTest() {
        role1Id = AdminApp.createExhibitorRoleWithRoleAndPermissions(role1, "Other", new String[]{});
        role2Id = AdminApp.createExhibitorRoleWithRoleAndPermissions(role2, "Primary Owner", new String[]{"portalAccess"});
        role3Id = AdminApp.createExhibitorRoleWithRoleAndPermissions(role3, "Primary Owner", new String[]{"portalAccess", "leadsAccess"});
        attendeeId1 = AdminApp.createAttendee(AttendeeEmail1,AttendeeFN1,AttendeeLN1);
        attendeeId2 = AdminApp.createAttendee(AttendeeEmail2,AttendeeFN2,AttendeeLN2);
        attendeeId3 = AdminApp.createAttendee(AttendeeEmail3,AttendeeFN3,AttendeeLN3);
        exhibitorId = AdminApp.createExhibitor(exhibitor);
        leadOrdersPage.navigate(exhibitorId);
        leadOrdersPage.addOrder();
        leadOrdersPage.selectPackage("Leads Device");
        leadOrdersPage.clickNextOnAddOrderModal();
        leadOrdersPage.fillOutOrder();
        leadOrdersPage.markAsPaid();
        leadOrdersPage.toggleSendInvoice();
        leadOrdersPage.submitOrder();
        contacts.navigate(exhibitorId);
        contacts.setStatusToApproved();
        contacts.addExistingParticipant(AttendeeFN1, role1);
        contacts.addExistingParticipant(AttendeeFN2, role2);
        contacts.addExistingParticipant(AttendeeFN3, role3);
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor);
        String leadToken = LeadsConfig.getLeadToken(exhibitorId);
        Utils.sleep(200);
        LeadsConfig.spoof(AttendeeFN1+" "+AttendeeLN1);
        Assert.assertTrue(LeadsPortalNoAccess.getPage().noRoleAccessMessageDisplayed(), "did not get the error page when this role should not have access to leads portal");
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor);
        LeadsConfig.spoof(AttendeeFN2+" "+AttendeeLN2);
        eraPage.fillOutForm();
        leadsApp.addLead(attendeeId2, leadToken);
        Utils.sleep(200);
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(500);
        Assert.assertFalse(leads.isViewLeadsOnPage(), "View leads link should not appear on the page");
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor);
        LeadsConfig.spoof(AttendeeFN3+" "+AttendeeLN3);
        Assert.assertTrue(leads.isViewLeadsOnPage(), "View leads link should appear on the page");
    }
}
