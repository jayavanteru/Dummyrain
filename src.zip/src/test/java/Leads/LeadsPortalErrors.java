package Leads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadOrdersTab;
import apps.admin.adminPageObjects.exhibits.ExhibitorRolesSearchPage;
import apps.admin.adminPageObjects.exhibits.NewExhibitorRolePage;
import apps.admin.adminPageObjects.onsite.LeadsDeviceConfigurationPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.leads.leadsPageObjects.LeadsPortalNoAccess;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class LeadsPortalErrors {

    AdminApp adminApp= new AdminApp();
    String role1
    , role2
    , roleId1
    , roleId2
    , exhibitor
    , exhibitorId
    , AttendeeFN1
    , AttendeeFN2
    , AttendeeLN1
    , AttendeeLN2
    , AttendeeEmail1
    , AttendeeEmail2
    , attendeeId1
    , attendeeId2;

    NewExhibitorRolePage ExhibitorRole = NewExhibitorRolePage.getPage();
    ExhibitorRolesSearchPage ExhibitorRoleSearch = ExhibitorRolesSearchPage.getPage();
    LeadsDeviceConfigurationPage LeadsConfig = LeadsDeviceConfigurationPage.getPage();
    AdminExhibitorContactsTab contacts = AdminExhibitorContactsTab.getPage();
    AdminExhibitorLeadOrdersTab leadOrdersPage = AdminExhibitorLeadOrdersTab.getPage();
    EditAttendeePage EditAttendee = EditAttendeePage.getPage();

    final DataGenerator data = new DataGenerator();
    apps.admin.AdminApp AdminApp = new AdminApp();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        PropertyReader.instance().setProperty("org", "RF Automation" );
        PropertyReader.instance().setProperty("event", "Onsite Automation" );
        PropertyReader.instance().setProperty("eventId", "1603141373onsiteauto" );
    }

    @AfterClass
    public void close() {
        LeadsConfig.navigate();
        AdminApp.deleteAttendee(attendeeId1);
        AdminApp.deleteAttendee(attendeeId2);
        AdminApp.deleteExhibitorRole(roleId1);
        AdminApp.deleteExhibitorRole(roleId2);
        AdminApp.deleteExhibitor(exhibitorId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-29397", firefoxIssue = "RA-29400")
    public void leadsPortalErrorsTest() {
        role1 = data.generateName();
        role2 = data.generateName();
        exhibitor = data.generateName();
        AttendeeFN1 = data.generateName();
        AttendeeFN2 = data.generateName();
        AttendeeLN1 = data.generateName();
        AttendeeLN2 = data.generateName();
        AttendeeEmail1 = data.generateEmail();
        AttendeeEmail2 = data.generateEmail();
        roleId1 = adminApp.createExhibitorRoleWithRoleAndPermissions(role1, "Other", new String[]{});
        roleId2 = adminApp.createExhibitorRoleWithRoleAndPermissions(role2, "Primary Owner", new String[]{"portalAccess"});

        attendeeId1 = AdminApp.createAttendee(AttendeeEmail1,AttendeeFN1,AttendeeLN1);
        attendeeId2 = AdminApp.createAttendee(AttendeeEmail2,AttendeeFN2,AttendeeLN2);
        exhibitorId = AdminApp.createExhibitor(exhibitor);
        leadOrdersPage.navigate(exhibitorId);
        leadOrdersPage.addOrder();
        leadOrdersPage.selectPackage("Leads Device");
        leadOrdersPage.clickNextOnAddOrderModal();
        leadOrdersPage.fillOutOrder();
        leadOrdersPage.markAsPaid();
        leadOrdersPage.toggleSendInvoice();
        leadOrdersPage.submitOrder();
        contacts.navigate(exhibitorId);
        contacts.setStatusToApproved();
        contacts.addExistingParticipant(AttendeeFN1, role1);
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor);
        LeadsConfig.spoof(AttendeeFN1+" "+AttendeeLN1);
        Utils.waitForTrue(LeadsPortalNoAccess.getPage()::noRoleAccessMessageDisplayed);
        Assert.assertTrue(LeadsPortalNoAccess.getPage().noRoleAccessMessageDisplayed(), "user should not have lead portal access and should see an error");
        contacts.navigate(exhibitorId);
        contacts.setStatusToNew();
        Utils.sleep(200);
        contacts.removeParticipant(AttendeeFN1);
        contacts.addExistingParticipant(AttendeeFN1, role2);
        EditAttendee.navigate(attendeeId1);
        EditAttendee.spoofToLeads(2);
        Utils.waitForTrue(LeadsPortalNoAccess.getPage()::notApprovedMessageDisplayed);
        Assert.assertTrue(LeadsPortalNoAccess.getPage().notApprovedMessageDisplayed(), "exhibitor should not be approved and the user should not have leads portal access");
        EditAttendee.navigate(attendeeId2);
        EditAttendee.spoofToLeads(2);
        Utils.waitForTrue(LeadsPortalNoAccess.getPage()::noExhibitorMessageDisplayed);
        Assert.assertTrue(LeadsPortalNoAccess.getPage().noExhibitorMessageDisplayed(), "user is not associated with an exhibitor and should not have lead portal access");


    }
}
