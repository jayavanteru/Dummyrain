package Leads.LeadsDevice;

import apps.admin.adminPageObjects.onsite.LeadsDevicePage;
import apps.leads.leadsPageObjects.LeadsEquipRentalAgreement;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LeadDevicePurchase extends LeadDeviceTest{

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-39912", firefoxIssue = "RA-39913")
    public void leadsDevicePurchaseExists() {
        setUp();
        LeadsEquipRentalAgreement.getPage().fillOutForm();
        Assert.assertTrue(LeadsDevicePage.getPage().deviceExists(deviceName));
    }
}
