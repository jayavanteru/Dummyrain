package Leads.LeadsDevice;

import apps.admin.adminPageObjects.onsite.LeadsDevicePage;
import apps.leads.leadsPageObjects.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LeadsQuestion extends LeadDeviceTest{

  @Test(groups = {ReportingInfo.BLUE})
  @ReportingInfo(chromeIssue = "RA-47217", firefoxIssue = "RA-47218")
  public void setLeadsQuestion() {
    setUp();
    LeadsEquipRentalAgreement.getPage().fillOutForm();
    Assert.assertTrue(LeadsDevicePage.getPage().deviceExists(deviceName), "Could not find Device Name: \"" + deviceName + "\"");

    String questionSet = "question set" + dataGenerator.generateString(5);
    LeadsManageDevice Device = LeadsManageDevice.getPage();
    Device.justWait();
    Device.editDevice(0);
    LeadsDeviceModal Modal = LeadsDeviceModal.getPage();
    Modal.justWait();
    Modal.addQuestionSet();
    LeadsQuestionSetup Question = LeadsQuestionSetup.getPage();
    Question.justWait();
    Question.questionSetName(questionSet);
    Device.editDevice(0);
    Modal.justWait();
    Assert.assertTrue(Modal.isQset(questionSet), "Could not find Question Set text: \"" + questionSet + "\"");

    //Edit Leads Question
    Modal.editQuestionSet();
    Question.justWait();
    questionSet = "Edit question set" + dataGenerator.generateString(5);
    Question.questionSetName(questionSet);
    Device.editDevice(0);
    Modal.justWait();
    Assert.assertTrue(Modal.isQset(questionSet), "Could not find Question Set text: \"" + questionSet + "\"");
  }

}
