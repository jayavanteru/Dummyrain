package Leads.LeadsDevice;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.EditDemoPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorDeviceManagementTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import configuration.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;

public class LeadDeviceTest {

  DataGenerator dataGenerator = new DataGenerator();
  AdminApp adminApp = new AdminApp();
  String exhibitorId, exhibitorName, deviceName, AttendeeFN1, AttendeeLN1, AttendeeEmail1, attendeeId1;

  @BeforeClass
  public void beforeClass() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
    NavigationBar.getPage().collapse();
    PropertyReader.instance().setProperty("org", "RF Automation" );
    PropertyReader.instance().setProperty("event", "Onsite Automation" );
    PropertyReader.instance().setProperty("eventId", "1603141373onsiteauto" );
  }

  @AfterClass
  public void afterClass() {
    AttendeeSearchPage.getPage().navigate();
    adminApp.deleteAttendee(attendeeId1);
    adminApp.deleteExhibitor(exhibitorId);
    PageConfiguration.getPage().quit();
  }

  protected void setUp() {
    attendeeId1 = adminApp.createAttendee(AttendeeEmail1 = dataGenerator.generateEmail(),AttendeeFN1 = dataGenerator.generateName(),AttendeeLN1 = dataGenerator.generateName());
    exhibitorId = adminApp.createExhibitor(exhibitorName = dataGenerator.generateName());
    adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");
    adminApp.safeSetCheckBoxValue("Exhibitor Published?", "Yes");
    EditExhibitorPage.getPage().clickContactsTab();
    AdminExhibitorContactsTab.getPage().addExistingParticipant(AttendeeFN1, "Primary Owner");

    EditExhibitorPage.getPage().clickLeadOrdersTab();
    AdminAttendeeOrdersTab.getPage().addOrder();
    AdminAttendeeOrdersTab.getPage().orderPackageForFree("Leads Device");

    EditDemoPage.getPage().deviceManagement();
    ExhibitorDeviceManagementTab.getPage().editDeviceName("Device 1", deviceName = dataGenerator.generateName());

    AttendeeSearchPage.getPage().navigate();
    AttendeeSearchPage.getPage().searchFor(AttendeeFN1);
    AttendeeSearchPage.getPage().clickResult(0);
    EditAttendeePage.getPage().spoofToLeads(1);
  }
}
