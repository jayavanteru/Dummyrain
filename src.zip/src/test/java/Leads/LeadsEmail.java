package Leads;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorNewContactPage;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.LeadsLogin;
import apps.leads.leadsPageObjects.LeadsManageDevice;
import apps.leads.leadsPageObjects.LeadsOrderPage;
import emails.Email;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

public class LeadsEmail extends Email {

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-27712", chromeIssue = "RA-27711")
    public void leadsPurchaseEmail() {
        leadsApp = new LeadsApp();
        String emailSubject = "Leads device confirmation";

        loginAndCreateAttendee();

        exhibitorId = adminApp.createExhibitor();

        //assign attendee to exhibitor
        AdminExhibitorContactsTab contactsPage = AdminExhibitorContactsTab.getPage();
        AdminExhibitorNewContactPage newContactPage = AdminExhibitorNewContactPage.getPage();

        contactsPage.navigate(exhibitorId);
        Utils.sleep(1000);
        //set exhibitor as approved
        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");

        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(emailAddress, "Primary Owner");
        PageConfiguration.getPage().justWait();
        Assert.assertTrue(contactsPage.isContactOnExhibitor(emailAddress), "the exhibitor did not get updated with the new participant");

        LeadsLogin Login = LeadsLogin.getPage();
        Login.navigate(eventcode);
        Login.login(emailAddress, password);
        LeadsManageDevice Device = LeadsManageDevice.getPage();
        Device.addFirstDevice();
        LeadsOrderPage Order = LeadsOrderPage.getPage();
        Order.purchase("Leads Device");
        Order.filloutform();

        findTheEmail(emailSubject, true);
    }

}
