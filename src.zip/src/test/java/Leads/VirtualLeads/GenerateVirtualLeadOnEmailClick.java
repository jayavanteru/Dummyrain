package Leads.VirtualLeads;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.ExhibitorCatalogExhibitorPage;
import apps.leads.leadsPageObjects.LeadsAppPage;
import apps.leads.leadsPageObjects.LeadsViewLeadsPage;
import interaction.pageObjects.rfBy;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GenerateVirtualLeadOnEmailClick extends GenerateVirtualLeadsTestSuperClass{
    String exhibitorEmail;

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-42101", firefoxIssue = "RA-42102")
    public void generateVirtualLeadOnEmailClick() {
        ExhibitorCatalogExhibitorPage.getPage().clickElementByText(exhibitorEmail);
        PageConfiguration.getPage().switchToTab(1);
        ExhibitorCatalogExhibitorPage.getPage().fillOutPrivacyPolicy("Yes");

        adminApp.spoofIntoLeads(primaryOwnerEmail, 2);

        LeadsAppPage.getPage().viewLeads();
        for (int i = 0; i < 3; i++) {
            if(LeadsViewLeadsPage.getPage().leadExistsByEmail(attendeeEmail)){
                Assert.assertTrue(LeadsViewLeadsPage.getPage().leadExistsByEmail(attendeeEmail), "LEAD WAS NOT CREATED");
                break;
            } else {
                PageConfiguration.getPage().refreshPage();
                PageConfiguration.getPage().justWait();
            }
        }
    }

    @Override
    void setOrgAndEvent() {
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Matrix Virtual Leads");
    }

    @Override
    void setWidgetJson() {
        widgetJson = "{\"componentConfigs\":[{\"element\":\"rf-exhibitorcatalog\",\"sponsoredSessions\":{\"initialSize\":\"2\",\"sessionDetailsOption\":\"expandSession\",\"sessionTitleConfig\":\"%title% - %code%\",\"sessionConfig.collapsedViewComponents\":[\"abstract\"],\"sessionConfig.expandedViewComponents\":[\"abstract\",\"speakers\",\"times\",\"sessionFiles\",\"attributes\"],\"showScheduleButton\":true,\"allowSchedulingInRecommendation\":true,\"showSessionFilesOnPublicCatalog\":false},\"sessionSpeakers\":{\"initialSize\":\"2\",\"speakersViewComponents\":[\"attprofile\",\"fullName\",\"jobTitle\",\"companyName\",\"bio\"],\"pullSpeakerDataFromGlobal\":false},\"type\":\"exhibitorcatalog\",\"layout\":\"layout-4\",\"jwtCookieName\":\"rfjwt\",\"exhibitorDemoRadio\":\"exhibitors\",\"exhibitorDetailsOption\":\"exhibitorDetailPage\",\"showAttendeeChatIntroModal\":true,\"sideNavAttributes\":[\"liveChat\",\"socialMedia\",\"customSideNavComponent\",\"leadContactMe\",\"email\"],\"detailsAttributes\":[\"action_column\",\"name\",\"exhibitortype\",\"booth-list\",\"url\",\"description\",\"videos\",\"files\",\"sponsoredSessions\",\"speakers\",\"customComponent1\"],\"showOnlyPublished\":false,\"size\":\"9999\",\"sortAttributeId\":\"\",\"topButtonList\":[{\"buttonText\":\"\",\"link\":\"\"}],\"filterConfig\":{\"myFavorites\":true},\"filterConfig.hiddenFilters\":[{\"filterID\":\"\",\"attendeeType\":\"\"}],\"filterConfig.hiddenFilterValues\":[\"\"],\"filterConfig.filterOrder\":[\"\"],\"filterConfig.defaults\":{\"\":{\"name\":\"\",\"value\":\"\"}},\"tableColumnStructure\":[{\"elementProp\":\"logo\",\"headerColumn\":\"Logo\",\"type\":\"img\"},{\"elementProp\":\"name\",\"headerColumn\":\"Name\"},{\"elementProp\":\"booth-list\",\"headerColumn\":\"Booth\"},{\"elementProp\":\"exhibitortype\",\"headerColumn\":\"Exhibitor Type\"},{\"elementProp\":\"action_column\",\"headerColumn\":\"Mark Favorites\"}],\"tileView.showBanner\":true,\"tileView.showName\":true,\"tileView.showDescription\":true,\"tileView.showButton\":true,\"tileView.showFavorite\":true,\"tileView.showSponsorBadge\":true,\"templateId\":\"1583175527Q752905135\",\"exhibitorMeetingWorkflowURI\":\"exhibitormeetingrequest\",\"showDataCollectionOptInModal\":true,\"optInMode\":\"onLeadTrigger\",\"id\":\"1612540806048001wnw1\"}]}";
    }

    @Override
    void exhibitorAttributes() {
        adminApp.safeSetTextBox("Email", exhibitorEmail = dataGenerator.generateEmail());
    }

    @Override
    void doStuffToAttendeeRecord() {

    }
}
