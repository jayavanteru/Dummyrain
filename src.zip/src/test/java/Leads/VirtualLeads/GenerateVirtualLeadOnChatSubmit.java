package Leads.VirtualLeads;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.libraries.ExhibitorCatalogExhibitorPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.leads.leadsPageObjects.LeadsAppPage;
import apps.leads.leadsPageObjects.LeadsViewLeadsPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class GenerateVirtualLeadOnChatSubmit extends GenerateVirtualLeadsTestSuperClass {

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-42122", firefoxIssue = "RA-42123")
    public void generateVirtualLeadOnChatSubmit() {
        ExhibitorCatalogExhibitorPage.getPage().liveChat();
        ExhibitorCatalogExhibitorPage.getPage().fillOutPrivacyPolicy("Yes");
        ExhibitorCatalogExhibitorPage.getPage().fillOutChatModal(dataGenerator.generateString());

        adminApp.spoofIntoLeads(primaryOwnerEmail, 2);
        LeadsAppPage.getPage().viewLeads();
        //some times it takes a while before a chat generates a lead - this is just a form of waiting :shrug:
        for (int i = 0; i < 3; i++) {
            if(LeadsViewLeadsPage.getPage().leadExistsByEmail(attendeeEmail)){
                break;
            } else {
                PageConfiguration.getPage().refreshPage();
            }
        }
        Assert.assertTrue(LeadsViewLeadsPage.getPage().leadExistsByEmail(attendeeEmail), "LEAD WAS NOT CREATED");
    }

    @Override
    void setOrgAndEvent() {
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Matrix Virtual Leads");
    }

    @Override
    void setWidgetJson() {
        widgetJson = "{\"componentConfigs\":[{\"showChat\":true,\"element\":\"rf-exhibitorcatalog\",\"sponsoredSessions\":{\"initialSize\":\"2\",\"sessionDetailsOption\":\"expandSession\",\"sessionTitleConfig\":\"%title% - %code%\",\"sessionConfig.collapsedViewComponents\":[\"abstract\"],\"sessionConfig.expandedViewComponents\":[\"abstract\",\"speakers\",\"times\",\"sessionFiles\",\"attributes\"],\"showScheduleButton\":true,\"allowSchedulingInRecommendation\":true,\"showSessionFilesOnPublicCatalog\":false},\"sessionSpeakers\":{\"initialSize\":\"2\",\"speakersViewComponents\":[\"attprofile\",\"fullName\",\"jobTitle\",\"companyName\",\"bio\"],\"pullSpeakerDataFromGlobal\":false},\"type\":\"exhibitorcatalog\",\"layout\":\"layout-4\",\"jwtCookieName\":\"rfjwt\",\"exhibitorDemoRadio\":\"exhibitors\",\"exhibitorDetailsOption\":\"exhibitorDetailPage\",\"showAttendeeChatIntroModal\":true,\"sideNavAttributes\":[\"liveChat\",\"socialMedia\",\"customSideNavComponent\",\"leadContactMe\",\"email\",\"liveChat\"],\"detailsAttributes\":[\"action_column\",\"name\",\"exhibitortype\",\"booth-list\",\"url\",\"description\",\"videos\",\"files\",\"sponsoredSessions\",\"speakers\",\"customComponent1\"],\"showOnlyPublished\":false,\"size\":\"9999\",\"sortAttributeId\":\"\",\"topButtonList\":[{\"buttonText\":\"\",\"link\":\"\"}],\"filterConfig\":{\"myFavorites\":true},\"filterConfig.hiddenFilters\":[{\"filterID\":\"\",\"attendeeType\":\"\"}],\"filterConfig.hiddenFilterValues\":[\"\"],\"filterConfig.filterOrder\":[\"\"],\"filterConfig.defaults\":{\"\":{\"name\":\"\",\"value\":\"\"}},\"tableColumnStructure\":[{\"elementProp\":\"logo\",\"headerColumn\":\"Logo\",\"type\":\"img\"},{\"elementProp\":\"name\",\"headerColumn\":\"Name\"},{\"elementProp\":\"booth-list\",\"headerColumn\":\"Booth\"},{\"elementProp\":\"exhibitortype\",\"headerColumn\":\"Exhibitor Type\"},{\"elementProp\":\"action_column\",\"headerColumn\":\"Mark Favorites\"}],\"tileView.showBanner\":true,\"tileView.showName\":true,\"tileView.showDescription\":true,\"tileView.showButton\":true,\"tileView.showFavorite\":true,\"tileView.showSponsorBadge\":true,\"templateId\":\"1583175527Q752905135\",\"exhibitorMeetingWorkflowURI\":\"exhibitormeetingrequest\",\"showDataCollectionOptInModal\":true,\"optInMode\":\"onLeadTrigger\",\"id\":\"1612540806048001wnw1\"}]}";
    }

    @Override
    void exhibitorAttributes() {
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(primaryOwnerEmail, "Exhibitor Chat Host");
    }

    @Override
    void doStuffToAttendeeRecord() {
        EditAttendeePage.getPage().goToOrdersTab();
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().orderPackageForFree("Package - A");
    }
}
