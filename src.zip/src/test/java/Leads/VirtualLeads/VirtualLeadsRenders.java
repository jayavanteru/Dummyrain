package Leads.VirtualLeads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.leads.leadsPageObjects.LeadsAppPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class VirtualLeadsRenders {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName, exhibitorId,
            attendeeId, attendeeEmail;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Matrix Virtual Leads");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        AttendeeSearchPage.getPage().navigate();

        //delete stuff
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteAttendee(attendeeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-42078", firefoxIssue = "RA-42079")
    public void virtualLeadsRenders() {
        setUp();
        adminApp.spoofIntoLeads(attendeeEmail, 1);

        LeadsAppPage.getPage().viewDashboard();
        //Leads are generated elsewhere and verified just confirming the dashboard link and url for now.
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("manageDevices"));
    }

    public void setUp(){
        attendeeId =  adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());

        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");

        //add attendee to exhibitor as primary owner
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendeeEmail, "Primary Owner");
    }
}
