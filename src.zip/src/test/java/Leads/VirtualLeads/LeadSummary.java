package Leads.VirtualLeads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.libraries.ExhibitorCatalogExhibitorPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.LeadsAppPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import static apps.admin.adminPageObjects.OrgEventData.getPage;

public class LeadSummary extends GenerateVirtualLeadsTestSuperClass{
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-45508", firefoxIssue = "RA-45509")
    public void leadSummary() {
        ExhibitorCatalogExhibitorPage.getPage().favoriteExhibitor();
        ExhibitorCatalogExhibitorPage.getPage().fillOutPrivacyPolicy("Yes");
        PageConfiguration.getPage().justWait();

        adminApp.spoofIntoLeads(primaryOwnerEmail, 2);
        PageConfiguration.getPage().justWait();
        Assert.assertTrue(LeadsAppPage.getPage().leadsActivityRendered(), "LEADS ACTIVITY SUMMARY DID NOT RENDER");
    }

    @Override
    void setOrgAndEvent() {
        getPage().setOrgAndEvent("RF Automation", "Matrix Virtual Leads");
    }

    @Override
    void setWidgetJson() {
        widgetJson = "{\"componentConfigs\":[{\"showChat\":true,\"element\":\"rf-exhibitorcatalog\",\"sponsoredSessions\":{\"initialSize\":\"2\",\"sessionDetailsOption\":\"expandSession\",\"sessionTitleConfig\":\"%title% - %code%\",\"sessionConfig.collapsedViewComponents\":[\"abstract\"],\"sessionConfig.expandedViewComponents\":[\"abstract\",\"speakers\",\"times\",\"sessionFiles\",\"attributes\"],\"showScheduleButton\":true,\"allowSchedulingInRecommendation\":true,\"showSessionFilesOnPublicCatalog\":false},\"sessionSpeakers\":{\"initialSize\":\"2\",\"speakersViewComponents\":[\"attprofile\",\"fullName\",\"jobTitle\",\"companyName\",\"bio\"],\"pullSpeakerDataFromGlobal\":false},\"type\":\"exhibitorcatalog\",\"layout\":\"layout-4\",\"jwtCookieName\":\"rfjwt\",\"exhibitorDemoRadio\":\"exhibitors\",\"exhibitorDetailsOption\":\"exhibitorDetailPage\",\"showAttendeeChatIntroModal\":true,\"sideNavAttributes\":[\"liveChat\",\"socialMedia\",\"leadContactMe\",\"requestMeeting\",\"customSideNavComponent\",\"customSideNavComponent2\",\"customSideNavComponent3\"],\"detailsAttributes\":[\"action_column\",\"name\",\"exhibitortype\",\"booth-list\",\"url\",\"description\",\"videos\",\"files\",\"sponsoredSessions\",\"speakers\",\"customComponent1\",\"customComponent2\",\"customComponent3\"],\"showOnlyPublished\":true,\"size\":\"9999\",\"sortAttributeId\":\"\",\"topButtonList\":[{\"buttonText\":\"\",\"link\":\"\"}],\"filterConfig\":{\"myFavorites\":true},\"filterConfig.hiddenFilters\":[{\"filterID\":\"\",\"attendeeType\":\"\"}],\"filterConfig.hiddenFilterValues\":[\"\"],\"filterConfig.filterOrder\":[\"\"],\"filterConfig.defaults\":{\"\":{\"name\":\"\",\"value\":\"\"}},\"tableColumnStructure\":[{\"elementProp\":\"logo\",\"headerColumn\":\"Logo\",\"type\":\"img\"},{\"elementProp\":\"name\",\"headerColumn\":\"Name\"},{\"elementProp\":\"booth-list\",\"headerColumn\":\"Booth\"},{\"elementProp\":\"exhibitortype\",\"headerColumn\":\"Exhibitor Type\"},{\"elementProp\":\"action_column\",\"headerColumn\":\"Mark Favorites\"}],\"tileView.showBanner\":true,\"tileView.showName\":true,\"tileView.showDescription\":true,\"tileView.showButton\":true,\"tileView.showFavorite\":true,\"tileView.showSponsorBadge\":true,\"templateId\":\"1583175527Q752905135\",\"exhibitorMeetingWorkflowURI\":\"exhibitormeetingrequest\",\"showDataCollectionOptInModal\":true,\"optInMode\":\"onLeadTrigger\",\"allowStickyNav\":true,\"id\":\"1618248357070001MxVZ\",\"enableAnchorText\":false}]}";
    }

    @Override
    void exhibitorAttributes() {

    }

    @Override
    void doStuffToAttendeeRecord() {

    }
}
