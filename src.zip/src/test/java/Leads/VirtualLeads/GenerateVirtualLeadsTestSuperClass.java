package Leads.VirtualLeads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;

public abstract class GenerateVirtualLeadsTestSuperClass {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendeeEmail, attendeeId,
            exhibitorId, exhibitorName,
            primaryOwnerId, primaryOwnerEmail,
            widgetName, widgetId,
            widgetJson, apiToken;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        setOrgAndEvent();
        NavigationBar.getPage().collapse();

        setUp();

        adminApp.spoofIntoCatalog(attendeeEmail, widgetName, 1);

        ExhibitorCatalogPage.getPage().clickExhibitor(exhibitorName);
    }

    @AfterClass
    public void afterClass() {
        AttendeeSearchPage.getPage().navigate();

        adminApp.deleteWidget(widgetId);
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteAttendee(primaryOwnerId);

        PageConfiguration.getPage().quit();
    }

    public void setUp(){
        //create widget & set widget json
        widgetId = adminApp.createExhibitorCatalog(widgetName = dataGenerator.generateName(), widgetName);

        WidgetSearchPage.getPage().navigate();
        WidgetSearchPage.getPage().searchWidgets(widgetName);
        WidgetSearchPage.getPage().editItem();
        setWidgetJson();
        EditWidgetPage.getPage().setWidgetJson(widgetJson);
        apiToken = EditWidgetPage.getPage().getApiToken();
        EditWidgetPage.getPage().saveWidgetConfig();

        //create stuff
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());
        doStuffToAttendeeRecord();
        primaryOwnerId = adminApp.createAttendee(primaryOwnerEmail = dataGenerator.generateEmail());
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());

        //prepare exhibitor
        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");
        adminApp.safeSetCheckBoxValue("Exhibitor Published?", "Yes");

        exhibitorAttributes();

        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(primaryOwnerEmail, "Primary Owner");


    }

    abstract void setOrgAndEvent();

    abstract void setWidgetJson();

    abstract void exhibitorAttributes();

    abstract void doStuffToAttendeeRecord();
}
