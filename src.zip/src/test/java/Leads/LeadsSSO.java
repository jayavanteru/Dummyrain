package Leads;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.OracleSignOnPage;
import configuration.PropertyReader;
import events.OrgCatalogs.SsoBase;
import logs.Log;
import org.openqa.selenium.Cookie;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

import java.util.ArrayList;
import java.util.Set;

public class LeadsSSO extends SsoBase {

//    @Test(dataProvider = "leads")
    public void setsSsoCookie(String org, String event) {
        String url = generateUrl(org, event);
        PageConfiguration.getPage().navigateTo(url);

        Assert.assertTrue(OracleSignOnPage.getPage().isPageLoaded());

        PageConfiguration.getPage().navigateTo(eventsApp.getHealthCheckUrl());

        Set<Cookie> cookies = PageConfiguration.getPage().getCookies();
        ArrayList<String> cookieNames = new ArrayList<>();
        for (Cookie cookie : cookies) {
            Log.info(cookie.toString(), getClass());
            cookieNames.add(cookie.getName());
        }
        Assert.assertTrue(cookieNames.contains("ssoEncToken"), "there was no ssoEncToken cookie set for the sso to use");
    }

    private String generateUrl(String org, String event) {
        String baseUrl = PropertyReader.instance().getProperty("eventsUrl");
        return baseUrl + "/ev:"+org+"/"+event+"/samlRequest?app=leads";
    }

    @DataProvider(name = "leads")
    public Object[][] leadData() {
        return new Object[][]{
                {"oracle", "modfinance18"},
                {"oracle", "cwsydney18"},
                {"oracle", "sw18"},
                {"oracle", "mbx18amsterdam"},
                {"oracle", "oic18"},
                {"oracle", "mcx18"},
                {"oracle", "cwmex17"},
        };
    }
}
