package Leads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorNewContactPage;
import apps.admin.adminPageObjects.onsite.LeadsDeviceConfigurationPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.*;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

/**
 * Created by brianpulham on 10/3/17.
 */
public class LeadsPortal {
    AdminApp adminApp;
    LeadsApp leadsApp;
    String email;
    String password;
    String attendeeId;
    String exhibitorId;
    String eventcode = PropertyReader.instance().getProperty("onsiteEventCode");



    @BeforeMethod
    public void Setup(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        PropertyReader.instance().setProperty("org", "RF Automation" );
        PropertyReader.instance().setProperty("event", "Onsite Automation" );
        PropertyReader.instance().setProperty("eventId", "1603141373onsiteauto" );
    }

    @AfterMethod
    public void tearDown() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteExhibitor(exhibitorId);

        PageConfiguration.getPage().quit();
    }


    @Test (groups = {ReportingInfo.ONSITE})
    @ReportingInfo(firefoxIssue = "RA-27718", chromeIssue = "RA-27717")
    public void AddPurposeAndQuestions(){
        DataGenerator generator = new DataGenerator();

        adminApp = new AdminApp();
        leadsApp = new LeadsApp();

        email = generator.generateValidEmail();
        password = generator.generatePassword();
        attendeeId = adminApp.createAttendee(email,password);
        exhibitorId = adminApp.createExhibitor();

        //assign attendee to exhibitor
        AdminExhibitorContactsTab contactsPage = AdminExhibitorContactsTab.getPage();
        AdminExhibitorNewContactPage newContactPage = AdminExhibitorNewContactPage.getPage();

        contactsPage.navigate(exhibitorId);
        Utils.sleep(1000);
        //set exhibitor as approved
        contactsPage.setStatusToApproved();
        contactsPage.clickAddParticipantButton();
        newContactPage.fillOutForm(email, "Primary Owner"); // Fails here
        PageConfiguration.getPage().refreshPage();
        Utils.waitForTrue(()->contactsPage.isContactOnExhibitor(email));
        Assert.assertTrue(contactsPage.isContactOnExhibitor(email), "the exhibitor did not get updated with the new participant");

        String name = "Device: ";
        String purposetext = "You pass butter: ";
        String qset = "Question set: ";
        String date;

        DataGenerator gen = new DataGenerator();
        name+=gen.generateString(5);
        qset+=gen.generateString(5);
        purposetext+=gen.generateString(5);

        LeadsLogin Login = LeadsLogin.getPage();
        Login.navigate(eventcode);
        Login.login(email, password);
        LeadsManageDevice Device = LeadsManageDevice.getPage();
        Device.addFirstDevice();
        LeadsOrderPage Order =LeadsOrderPage.getPage();
        Order.purchase("Leads Device");
        Order.filloutform();

        Utils.waitForTrue(() -> PageConfiguration.getPage().getCurrentUrl().contains("orderinvoice"), 10);
        String confirmUrl = PageConfiguration.getPage().getCurrentUrl();
        Assert.assertTrue(confirmUrl.contains("orderinvoice"), "The URL does not contain 'orderinvoice'");

        //View Order History
        LeadsOrderHistory History = LeadsOrderHistory.getPage();
        History.navigate(eventcode);
        date = History.getDate(0);
        Assert.assertEquals(date, DateTime.now().toString("MM/dd/YYYY"), "The current date could not be found." );

        Device.navigate(eventcode);
        Device.editDevice(0);
        LeadsDeviceModal Modal = LeadsDeviceModal.getPage();
        Modal.nameDevice(name);
        Modal.addPurpose(purposetext);
        Utils.sleep(200);
        Modal.addQuestionSet();
        LeadsQuestionSetup Question = LeadsQuestionSetup.getPage();
        Utils.sleep(500);
        Question.questionSetName(qset);
        Device.editDevice(0);
        Utils.sleep(200);
        String deviceName = Modal.getDeviceName();
        Assert.assertEquals(deviceName, name, "The device name did not match");
        Assert.assertTrue(Modal.isPurposeText(purposetext), "Could not find purpose text: \"" + purposetext +"\"");
        Assert.assertTrue(Modal.isQset(qset), "Could not find Question Set text: \"" + qset + "\"");

        //get that leadsToken
        LeadsDeviceConfigurationPage leadConfigPage = LeadsDeviceConfigurationPage.getPage();
        leadConfigPage.navigate();
        Utils.sleep(500);
        String leadToken = leadConfigPage.getLeadToken(exhibitorId);

        Device.navigate(eventcode);
        Utils.sleep(200);
        leadsApp.addLead(attendeeId, leadToken);
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(500);
        Assert.assertTrue(Device.isLeadsTotalOnPage(1), "the leads total on the page was not 1");
        Assert.assertEquals(Device.getDeviceLeadsCount(deviceName), 1, "the leads count on the page was not 1");
        Device.viewLeads();
        LeadsView ScanLead=LeadsView.getPage();
        Assert.assertTrue(ScanLead.isLeadsDataOnPage(),"No leads available");
    }

}
