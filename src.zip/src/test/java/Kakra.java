import apps.admin.AdminApp;
import apps.admin.forms.Form;
import configuration.PropertyReader;
import interaction.api.CommonApiActions;
import logs.Log;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import testHelp.DataGenerator;

import java.util.ArrayList;

public class Kakra {

    ArrayList<String> attendeeIds = new ArrayList<>();
    int users = Integer.parseInt(PropertyReader.instance().getProperty("kakrausers"));
    AdminApp adminApp;

    @BeforeClass
    public void setup() {
        Log.info("\n========================== CREATING ATTENDEES ==========================", getClass());
        DataGenerator generator = new DataGenerator();
        adminApp = CommonApiActions.getAdminApp();

        for (int i = 0; i < users; ++i) {
            String id = CommonApiActions.createAttendee_Constellations(generator.generateEmail(), generator.generateString());
            attendeeIds.add(id);
        }

        Log.info("\n========================== DONE CREATING ATTENDEES, STARTING TEST ==========================", getClass());
    }

    @AfterClass
    public void delete() {
        Log.info("\n========================== TEST FINISHED, DELETING ATTENDEES ==========================", getClass());

        for (String id : attendeeIds) {
            CommonApiActions.deleteAttendee(id);
        }
    }

//    @Test(dataProvider = "getids")
    public void testForKakra(String id) {
        String formid = "961c4e2b-1fbf-11e7-822e-06fe95280409"; //tab 3
        Form formApi = adminApp.getFormApi(formid);
        JSONObject response = adminApp.saveFormApi(formid, id, formApi);
    }

    @DataProvider(name = "getids", parallel = true)
    public Object[][] idsList() {
        Object[][] params = new Object[attendeeIds.size()][1];
        for (int i = 0; i < params.length; i++) {
            params[i][0] = attendeeIds.get(i);
        }
        return params;
    }
}
