package scheduled;

import apps.admin.AdminApp;
import interaction.api.CommonApiActions;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.MyJson;

import java.util.Iterator;

public class ProdReportApi {

    @Test
    public void reportRegressionTest() {
        AdminApp adminApp = CommonApiActions.getAdminApp();

        JSONObject post = adminApp.post("/runReports.do");
        JSONObject postData = MyJson.getJSONObject(post, "data");

        Log.info("response: \n" + postData, getClass());

        if (postData.has("errors")) {
            JSONArray errors = MyJson.getJSONArray(postData, "errors");
            Assert.assertEquals(errors.length(), 0, "found errors: \n" + formatJsonString(errors.toString()) + "\n");
        }

        JSONObject problems = MyJson.getJSONObject(postData, "problemReports");

        Iterator problemKeys = problems.keys();
        while (problemKeys.hasNext()) {
            String key = (String) problemKeys.next();
            JSONArray problemIds = MyJson.getJSONArray(problems, key);

            Assert.assertEquals(problemIds.length(), 0, key + "\n" + formatJsonString(problemIds.toString()) + "\n");
        }
    }

    private String formatJsonString(String json) {
        return json.replace("\",\"", "\",\n\"");
    }
}
