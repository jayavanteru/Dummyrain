package events.OrgCatalogs;

import apps.PageConfiguration;
import apps.events.EventsApp;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class SsoBase {

    protected EventsApp eventsApp;

    @BeforeClass
    public void setup() {
        eventsApp = new EventsApp();
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void deleteCookies() {
        PageConfiguration.getPage().deleteAllCookies();
    }
}
