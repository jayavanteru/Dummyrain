package events.OrgCatalogs;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.ApiProfilePage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeSummaryTab;
import apps.events.EventsApp;
import configuration.PropertyReader;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;
import testHelp.MyJson;
import testHelp.Utils;

import java.util.Arrays;

public class EventEndpoints {

    private AdminApp adminApp;
    private EventsApp eventsApp;
    private String apiToken;
    private PropertyReader property;
    private String orgName;
    private String eventname;
    private String eventsUrl;
    private SoftAssert softAsssert;
    private String attendeeId;


    @BeforeMethod
    public void authenticate() {
        property = PropertyReader.instance();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        eventsApp = new EventsApp();
        eventsUrl = PropertyReader.instance().getProperty("eventsUrl");
        softAsssert = new SoftAssert();
    }

    @AfterMethod
    public void tearDown() {
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

//    @Test(dataProvider = "event")//)
    public void testEndpoints(String widgetId, String apiProfileId) {
        Integer[] endpointsToSkipIndex = {0 /*badge lookup*/, 11 /*login*/, 67 /*attendeeSessionHistory*/, 64/*exhibitor create*/, 51 /*raw saturn data*/, 1 /*attendee store*/, 59 /*create lead*/};
        this.orgName = PropertyReader.instance().getProperty("org");
        this.eventname = PropertyReader.instance().getProperty("event");
        OrgEventData.getPage().setOrgAndEvent();
        Utils.sleep(2000);
        attendeeId = adminApp.createAttendee(property.getProperty("EventParam-email"), property.getProperty("EventParam-password"));
        Utils.sleep(500);

        //make the attendee authenticated by adding the full package and checking Schedule Access Test on tab 1
        authenticateAttendee(attendeeId);
        AdminAttendeeSummaryTab.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeSummaryTab.getPage().waitForAccessRulesToLoad("All", 1) > 0, "did not ever get the access rule applied to it");

        PropertyReader.instance().setProperty("EventParam-userKey", attendeeId);
        ApiProfilePage apiProfilePage = ApiProfilePage.getPage();
        apiProfilePage.navigate(apiProfileId);
        apiToken = apiProfilePage.getApiToken();

        //authenticate
        Utils.sleep(500); //make sure the user is all created
        JSONObject response = eventsApp.makeApiCall("login", apiToken, widgetId);
        property.setProperty("EventParam-rfAuthToken",MyJson.getString(response, "jwt"));
        //get attendee access jwt
        response = eventsApp.makeApiCall("attendeeAccess", apiToken, widgetId);
        property.setProperty("EventParam-rfAuthToken",MyJson.getString(response, "jwt"));

        //iterate through all the endpoints and test them
        int count = apiProfilePage.howManyEndpoints();
        for (int i = 0; i < count; ++i) {
            if (!Arrays.asList(endpointsToSkipIndex).contains(i)) {
                boolean endpointOn = apiProfilePage.isEndpointOn(i);
                String endpointName = apiProfilePage.getEndpointName(i);
                Log.info("running endpoint " + i + " - " + endpointName, getClass().getName());
                JSONObject apiResponse;

                apiResponse = eventsApp.makeApiCall(endpointName, apiToken, widgetId);

                String fullUrl = eventsApp.getUrlForApiCall(endpointName, apiToken, widgetId);
                AssertApiResponse(endpointName, apiResponse, endpointOn, fullUrl);
            }
        }
        softAsssert.assertAll();
    }

    private void AssertApiResponse(String endpoint, JSONObject response, boolean enabled, String fullUrl) {
        String responseCode = MyJson.getString(response, "responseCode");
        String responseMessage = MyJson.getString(response, "responseMessage");
        String type = null;
        if (enabled) {
            switch (endpoint) {
                case "login":
                    softAsssert.assertEquals(MyJson.getString(response, "email"), property.getProperty("EventParam-email"), response.toString());
                    break;
                case "attendeeAccess":
                    String userKey =  MyJson.getString(MyJson.getJSONObject(response, "claims"), "userKey");
                    Assert.assertTrue(response.has("jwt"),"not getting a jwt \n"+ fullUrl + "\n" + response.toString());
                    Assert.assertEquals(userKey, property.getProperty("EventParam-userKey"), "the user key is not matching attendeeId\n" + fullUrl + "\n" + response.toString());
                    Assert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    Assert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "rooms":
                    JSONArray jsonArray = MyJson.getJSONArray(MyJson.getJSONObject(response, "config"), "rooms");
                    softAsssert.assertNotNull(jsonArray, "did not have a list of rooms\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "jwt":
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("jwt"), "did not get back a jwt\n" + fullUrl + "\n" + response.toString());
                    break;
                case "removeSession":
                    type = "Removed";
                case "addSession":
                    softAsssert.assertTrue(MyJson.getString(response, "sessionTimeId") != null &&
                            MyJson.getString(response, "sessionTimeId").length() > 0, "did not get the session Time id\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getInt(response, "seatsRemaining") >= 0, "did not get a valid value for seats remaining\n" + fullUrl + "\n" + response.toString());
//                    softAsssert.assertTrue(MyJson.getInt(response, "registered") >= 0, "did not get a valid value for registered\n" + fullUrl + "\n" + response.toString());
                case "dropSwapSession":  //authentication required
                    type = type == null ? "Enrolled" : type;
                    softAsssert.assertEquals(MyJson.getString(response, "type"), type, "did not get the right type\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "myData":
                    softAsssert.assertTrue(response.has("sessionInterests"), "did not get the session interests field\n" + fullUrl + "\n" + response.toString());
                case "mySchedule":
                    softAsssert.assertTrue(response.has("mySchedule"), "did not get the my Schedule field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("loggedInUser"), "did not get the logged In User field\n" + fullUrl + "\n" + response.toString());
                    JSONObject loggedInUserSchedule = MyJson.getJSONObject(response, "loggedInUser");
                    softAsssert.assertTrue(loggedInUserSchedule.has("firstName"), "did not get the logged in user info\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(loggedInUserSchedule.has("lastName"), "did not get the logged in user info\n" + fullUrl + "\n" + response.toString());
                    break;
                case "myInterests":
                    softAsssert.assertTrue(response.has("sessionInterests"), "did not get the session interests field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("loggedInUser"), "did not get the logged In User field\n" + fullUrl + "\n" + response.toString());
                    JSONObject loggedInUser = MyJson.getJSONObject(response, "loggedInUser");
                    softAsssert.assertTrue(loggedInUser.has("firstName"), "did not get the logged in user info\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(loggedInUser.has("lastName"), "did not get the logged in user info\n" + fullUrl + "\n" + response.toString());
                    break;
                case "myScheduleExport":
                    softAsssert.assertTrue(MyJson.getString(response,"data").length() > 0, "did not get the export string\n" + fullUrl + "\n" + response.toString());
                    break;
                case "toggleSessionInterest":
                    softAsssert.assertTrue(MyJson.getString(response, "sessionID").length() > 0, "did not get the session id\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("times"), "did not give the list of times\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(MyJson.getString(response, "operation"), "added", "the operation should be \"added\"\n" + fullUrl + "\n" + response.toString());
                    break;
                case "toggleExhibitorInterest":
                    softAsssert.assertEquals(MyJson.getString(response, "operation"), "added", "the operation should be \"added\"\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getString(response, "exhibitorID").length() > 0, "did not get the exhibitor id\n" + fullUrl + "\n" + response.toString());
                    break;
                case "recommendSponsor":
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("jwtClaims"), "not getting the jwt claims\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("items"), "not getting the items list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getInt(response, "total") >= 0, "didn't get a valid total\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getInt(response, "size") >= 0, "didn't get a valid size\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getInt(response, "from") >= 0, "didn't get a valid from\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(MyJson.getInt(response, "numItems") >= 0, "didn't get a valid numItems\n" + fullUrl + "\n" + response.toString());
                    break;
                case "similar":
                    for (String fieldName : new String[]{"total", "size", "from", "millis", "numItems"}) {
                        softAsssert.assertTrue(response.has(fieldName), "does not contain " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(MyJson.getInt(response, fieldName) >= 0, "did not get a valid " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                    }
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "recommendCache":
                    for (String fieldName : new String[]{"sessionIdTopics", "sessionIdTopics-removed", "similar-sessions-removed", "similar-sessions"}) {
                        softAsssert.assertTrue(response.has(fieldName), "does not contain " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(MyJson.getInt(response, fieldName) >= 0, "did not get a valid " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                    }
                case "recommendSponsorCache":
                    for (String fieldName : new String[]{"num-seconds", "recommendations", "recommendations-removed"}) {
                        softAsssert.assertTrue(response.has(fieldName), "does not contain " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(MyJson.getInt(response, fieldName) >= 0, "did not get a valid " + fieldName + "\n" + fullUrl + "\n" + response.toString());
                    }
//                    softAsssert.assertTrue(MyJson.getString(response, "eventCode").length() > 0, "did not get an event code\n" + fullUrl + "\n" + response.toString());
//                    softAsssert.assertEquals(MyJson.getString(response, "org").toLowerCase(), orgName.toLowerCase(), "did not get the right org\n" + fullUrl + "\n" + response.toString());
//                    softAsssert.assertEquals(MyJson.getString(response, "eventName").toLowerCase(), eventname.toLowerCase(), "did not get the right event name\n" + fullUrl + "\n" + response.toString());
                    break;
                case "elasticSessionLoad":
                case "elasticExhibitorLoad":
                case "elasticSpeakerLoad":
                    String jsonString = MyJson.getString(response, "data");
                    JSONArray data = MyJson.createJSONArray(jsonString);
                    softAsssert.assertEquals(data.length(), 3, response.toString());
                    for (int i = 0; i < data.length(); ++i) {
                        JSONObject json = MyJson.getJSONObject(data, i);
                        softAsssert.assertTrue(json.has("name"), "json response does not have a name\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(json.has("numObjects"), "json response does not have a numObjects\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(json.has("numChanges"), "json response does not have a numChagnes\n" + fullUrl + "\n" + response.toString());
                        softAsssert.assertTrue(json.has("message"), "json response does not have a message\n" + fullUrl + "\n" + response.toString());

                        softAsssert.assertEquals(MyJson.getString(json, "message"), "Success", "did not get a success from elastic search\n" + fullUrl + "\n" + response.toString());
                        //dynamically find the name based off the endpoint
                        String name = endpoint.replace("elastic", "").replace("Load", "");
                        softAsssert.assertTrue(MyJson.getString(json, "name").contains(name), response.toString());
                    }
                    break;
                case "widgetConfig":
                    JSONObject config = MyJson.getJSONObject(response, "config");
                    softAsssert.assertTrue(config.has("endDate"), "does not have end Date field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("onLoadMessage"), "does not have on load message field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("type"), "does not have type field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("text"), "does not have text field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("showOnlyPublished"), "does not have show only published field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("startDate"), "does not have start Date field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("waitlist"), "does not have wait list field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("banner"), "does not have banner field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(config.has("includeCSS"), "does not have include CSS field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "sessionTimesByRoom":
                    JSONObject timesConfig = MyJson.getJSONObject(response, "config");
                    softAsssert.assertTrue(timesConfig.has("sessiontimes"), "does not have the list of times\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "session":
                    JSONObject sessionItems = MyJson.getJSONObject(MyJson.getJSONArray(response, "items"), 0);
                    softAsssert.assertEquals(MyJson.getString(sessionItems, "sessionID"), property.getProperty("EventParam-sessionId"), "doesn't have the right session id");
                    softAsssert.assertTrue(sessionItems.has("participants"), "does not have participants\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sessionItems.has("title"), "does not have a title field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sessionItems.has("abstract"), "does not contain the abstract\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sessionItems.has("status"), "does not have a set status\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sessionItems.has("times"), "does not have the list of times\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sessionItems.has("attributevalues"), "does not have the attribute values\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "exhibitor":
                    JSONObject exhibitorItems = MyJson.getJSONObject(MyJson.getJSONArray(response, "items"), 0);
                    softAsssert.assertEquals(MyJson.getString(exhibitorItems, "exhibitorID"), property.getProperty("EventParam-exhibitorId"), "doesn't have the right exhibitor id\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(exhibitorItems.has("status"), "does not have a set status\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(exhibitorItems.has("description"), "does not have a description field\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(exhibitorItems.has("attributevalues"), "does not have the attribute values\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "speaker":
                    JSONObject speakerItems = MyJson.getJSONObject(MyJson.getJSONArray(response, "items"), 0);
                    softAsssert.assertEquals(MyJson.getString(speakerItems, "userRef"), property.getProperty("EventParam-speaker-id").split("_")[0], "did not find the right speaker\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(speakerItems.has("session"), "does not contain the assigned session\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(speakerItems.has("published"), "does not show if it has been published\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(speakerItems.has("fullName"), "does not contain the full name\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "search":
                case "sessions":
                case "sessionData":
                case "speakerData":
                case "exhibitorData":
                case "exhibitors":
                    JSONObject sectionList = MyJson.getJSONObject(MyJson.getJSONArray(response, "sectionList"), 0);
                    softAsssert.assertTrue(sectionList.has("items"), "does not have items in section list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sectionList.has("total"), "does not have total in section list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sectionList.has("sectionId"), "does not have sectionId in section list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(sectionList.has("size"), "does not have size in section list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "suggest":
                    softAsssert.assertTrue(response.has("items"), "did not provide items list\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    break;
                case "walkinMeetings":
                    softAsssert.assertEquals(responseMessage,"Success", "did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertEquals(responseCode,"0","did not get back a success\n" + fullUrl + "\n" + response.toString());
                    softAsssert.assertTrue(response.has("config"), "did not provide the config field\n" + fullUrl + "\n" + response.toString());
                    JSONObject walkinConfig = MyJson.getJSONObject(response, "config");
                    softAsssert.assertTrue(walkinConfig.has("walkinMeetings"), "did not provide the config walkin meetings field\n" + fullUrl + "\n" + response.toString());
                    break;
                //locked
                case "attendeeStore":
                case "attendeeInfo":
                case "feed":
                case "surveyResponses":

                case "ciscoHistory":
                    //{"responseCode":"107","responseMessage":"Authentication is required for this action."}
                case "focusOnDoc":
                    //{"responseCode":"103","responseMessage":"Required parameter missing: focusId"}
                case "sendNomLoginEmail":
                    //{"data":{"status":"error","message":"Email Address is required"}}
                case "report":
                    //{"responseCode":"103","responseMessage":"Required parameter missing: reportId"}
                    System.out.println(response);
                    break;
                case "sessionAttendance":
                    String timeId = MyJson.getString(MyJson.getJSONObject(response, "attendanceData"), "sessiontime_id");
                    softAsssert.assertNotNull(timeId, "did not send back the session time id, for sessionAttendance");
                    softAsssert.assertEquals(MyJson.getString(response, "responseMessage"), "Success", "did not get back a success for sessionAttendance");
                    break;
                //broken things, this section needs to be deleted when fixed
                case "forgotPassword":   // not implemented yet
                case "changePassword":  // not implemented yet
                case "saveEditLogin":  //not implemented yet
                case "surveys":  // not implemented yet
                case "samlRequestSSOEncUrl":  // not implemented yet
                case "connectSSOUrl":  //lanyon only
                case "loadForm": // Internal - outside consumers won't know what to do with it - RA-6920
                case "saveForm": // Internal - outside consumers won't know what to do with it - RA-6920
                case "loadCreateAccount":  // Internal - outside consumers won't know what to do with it - RA-6920
                case "saveCreateAccount": // Internal - outside consumers won't know what to do with it - RA-6920
                case "preference":  //ignore this, used when we integrated with lanyon - RA-6920
                case "accept":  // this is for invitations, let's not worry about this yet - RA-6920
                case "decline": // this is for invitations, let's not worry about this yet - RA-6920
                case "recommend":
                    Log.error("skipping all asserts for " + endpoint, getClass().getName());
                    break;
                //end of deleted section
                default:
                    Log.error("there was no section for checking " + endpoint, getClass().getName());
            }
        } else {
            switch (endpoint) {

                //broken things, this section needs to be deleted
                case "accept":  // this is for invitations, let's not worry about this yet - RA-6920
                case "decline": // this is for invitations, let's not worry about this yet - RA-6920
                case "collection": //not sure where this came form
                case "deleteCalendarItem":
                case "boothChoices":
                case "boothTokenVerification":
                    break;
                //end of deleted section
                case "samlRequestSSOEncUrl":
                    System.out.println(response);
                    break;

                 default:
                     softAsssert.assertEquals(responseMessage, "Access to API endpoint "+endpoint+" denied.", "this endpoint is turned off\n" + fullUrl + "\n" + response.toString());
                     softAsssert.assertEquals(responseCode, "124", "this endpoint is turned off\n" + fullUrl + "\n" + response.toString());
            }
        }
    }

    private void authenticateAttendee(String attendeeId) {
        AdminAttendeeOrdersTab orderTab = AdminAttendeeOrdersTab.getPage();

        orderTab.navigate(attendeeId);
        Utils.sleep(500);
        orderTab.addOrder();
        orderTab.selectPackage("Approval Package");
        orderTab.clickNextOnAddOrderModal();
        orderTab.placeOrder();
    }

    @DataProvider(name = "event")
    public Object[][] workflowIds() {
        //for stg
        return new Object[][] {
                {"XeiJjYtcUyZ6dcQS7e08fK8etAPD5P3H", "15150824149240016P0Z"}
        };
    }
}
