package events.OrgCatalogs;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.CiscoLoginPage;
import apps.events.eventsPageObjects.OracleSignOnPage;
import configuration.PropertyReader;
import logs.Log;
import org.openqa.selenium.Cookie;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import testHelp.CryptoUtil;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.Set;

public class EventSSO extends SsoBase{

//    @Test(dataProvider = "events", groups = "prodTest")
    public void setsSsoCookie(String org, String event, String catalogUrl) {
        String url = generateUrl(org, event, catalogUrl);
        PageConfiguration.getPage().navigateTo(url);

        Assert.assertTrue(OracleSignOnPage.getPage().isPageLoaded());

        PageConfiguration.getPage().navigateTo(eventsApp.getHealthCheckUrl());

        Set<Cookie> cookies = PageConfiguration.getPage().getCookies();
        ArrayList<String> cookieNames = new ArrayList<>();
        for (Cookie cookie : cookies) {
            Log.info(cookie.toString(), getClass());
            cookieNames.add(cookie.getName());
        }
        Assert.assertTrue(cookieNames.contains("ssoEncUrl"), "there was no ssoEncUrl cookie set for the sso to use");
    }

//    @Test(groups = "prodTest")
    public void ciscoSso() {
        String env = PropertyReader.instance().getProperty("env");
        String event = "CL_GLOBAL-" + env;
        String catalogUrl = PropertyReader.instance().getProperty(event + "Url");

        PageConfiguration.getPage().navigateTo(catalogUrl);

        CiscoLoginPage.getPage().login();

        PageConfiguration.getPage().navigateTo(catalogUrl);

        System.out.println(CiscoLoginPage.getPage().loggedInAs());
        Utils.sleep(5000);
    }

    private String generateUrl(String org, String eventCode, String catalogUrl) {
        String eventsUrl = PropertyReader.instance().getProperty("eventsUrl");
        String encrypted = null;
        try {
            encrypted = CryptoUtil.encrypt(eventCode + "|"+catalogUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return eventsUrl + "/ev:"+org+"/"+eventCode + "/samlRequest?ssoEncUrl=" + encrypted;
    }

    @DataProvider(name = "events")
    public Object[][] eventData() {
        return new Object[][]{
                {"oracle", "modfinance18", "/catalog/oracle/modfinance18/mfe18catalog"},
                {"oracle", "cwsydney18", "/catalog/oracle/cwsydney18/cwsydney18catalog"},
                {"oracle", "sw18", "/catalog/oracle/sw18/catalogsw2018"},
                {"oracle", "mbx18amsterdam", "/catalog/oracle/mbx18amsterdam/mbxamster18catalog"},
                {"oracle", "oic18", "/catalog/oracle/oic18/oic18catalog"},
//                {"oracle", "cwny18", "/catalog/oracle/cwny18/cwny18catalog"},
                {"oracle", "mcx18", "/catalog/oracle/mcx18/catalogmcx18"},
                {"oracle", "cwmex17", "/catalog/oracle/cwmex17/cwmexico18catalog"},
        };
    }
}
