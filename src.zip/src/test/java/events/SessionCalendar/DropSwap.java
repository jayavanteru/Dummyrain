package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class DropSwap {

    private String attendeeId;
    private AdminApp adminApp = new AdminApp();
    private final String SESSION1 = "Drop Swap Session 1";
    private final String SESSION2 = "Drop Swap Session 2";
    private final String ORDER = "Trogdor Full Conference Pass";
    private String attendeeEmail = new DataGenerator().generateEmail();

    private AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void testSetup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
        attendeeId = adminApp.createAttendee(attendeeEmail);

        orders.navigate(attendeeId);
        orders.verifyPackageOrdered(ORDER);
        orders.addOrder();
        orders.selectPackage(ORDER);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void testCleanup() {
        orders.navigate(attendeeId);
        orders.selectAllOrders();
        orders.deleteOrders();
        orders.cancelOrder();
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-26071", firefoxIssue = "RA-26072")
    public void dropSwapSession() {
        EditAttendeePage attendee = EditAttendeePage.getPage();
            attendee.spoofToWidget("Trogdor Catalog");
        PageConfiguration.getPage().switchToTab(1);

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog("Drop Swap");

            String sessionId1 = catalog.getSessionId(SESSION1);
            String sessionId2 = catalog.getSessionId(SESSION2);
            catalog.toggleFavorite(sessionId1);
            catalog.toggleFavorite(sessionId2);

        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

            attendee.spoofToWidget("Trogdor Calendar");
        PageConfiguration.getPage().switchToTab(1);

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.toggleShowFavoritesCheckbox();

            calendar.clickFavoriteSession(SESSION1);
            catalog.scheduleSessionById(sessionId1, true);

        Assert.assertTrue(calendar.sessionWithTitleIsScheduled(SESSION1), "First session wasn't able to be scheduled successfully");
            calendar.closeSessionScheduleModal();

            calendar.clickFavoriteSession(SESSION2);
            catalog.scheduleSessionById(sessionId2, true);

            calendar.selectProposedInScheduleConflictModal();
            calendar.confirmScheduleConflictModal();
        Assert.assertTrue(calendar.sessionWithTitleIsScheduled(SESSION2), "Second session wasn't able to be scheduled successfully");
    }
}