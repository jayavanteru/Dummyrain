package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeDemographicsTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CalendarRecommendations {

    private AdminApp adminApp;
    private String attendeeId;
    private String eventsUrl = PageConfiguration.getPage().getData("eventsUrl");
    private String widgetId = "B7n96tTn3ahjQ6IjlIQd0gzKmyh0S8gj";
    private String profileId = "yOMvyuE8og2sjtmIWKYcTSw21ptBi5Rj";
    private final String KING = "Data is King";
    private final String STORY = "Let Data Tell the Story";
    private final String ORDER = "Trogdor Full Conference Pass";
    private final String CATALOG = "Trogdor Catalog";
    private final String CALENDAR = "Trogdor Calendar";

    private AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        attendeeId = adminApp.createAttendee();
    }

    @AfterClass
    public void tearDown() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        orders.navigate(attendeeId);
        orders.deleteOrder(ORDER);
        //temporarily here to -actually- cancel the order
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-34161", chromeIssue = "RA-24999")
    public void calendarRecommendations() {
            orders.navigate(attendeeId);
            orders.addOrder();
            orders.selectPackage(ORDER);
            orders.clickNextOnAddOrderModal();
            orders.setComment("Test");
            orders.submitOrder();

        AdminAttendeeDemographicsTab demographics = AdminAttendeeDemographicsTab.getPage();
            demographics.navigate(attendeeId);
            demographics.chooseFromDropdown("Primary Topic", "Customer Experience");
            demographics.attendeesubmit();

        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);

        PageConfiguration.getPage().navigateTo(eventsUrl+ "/api/recommendCache?rfWidgetId=" + widgetId + "&rfApiProfileId=" + profileId);
        PageConfiguration.getPage().switchToTab(0);

        PageConfiguration.getPage().refreshPage();
        PageConfiguration.getPage().justWait();
        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog("data");

        Assert.assertTrue(catalog.isSessionOnCatalog(KING), KING + " is not on the session catalog");
        Assert.assertTrue(catalog.isSessionOnCatalog(STORY), STORY + " is not on the session catalog");

            String kingId = catalog.getSessionId(KING);
            String storyId = catalog.getSessionId(STORY);

            catalog.toggleFavorite(kingId);
            catalog.toggleFavorite(storyId);

        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        EditAttendeePage.getPage().spoofToWidget(CALENDAR);
        PageConfiguration.getPage().switchToTab(1);

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.toggleShowFavoritesCheckbox();

            calendar.clickFavoriteSession(KING);
        Assert.assertTrue(calendar.rateRecommendation(kingId, true));
            calendar.closeSessionScheduleModal();

            calendar.clickFavoriteSession(STORY);
        Assert.assertFalse(calendar.rateRecommendation(storyId, false));

            PageConfiguration.getPage().refreshPage();

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(KING);
        Assert.assertTrue(catalog.hasRecommendation(kingId), "Session was not recommended and should be");
            calendar.closeSessionScheduleModal();

            calendar.clickFavoriteSession(STORY);
        Assert.assertFalse(catalog.hasRecommendation(storyId), "Session was recommended and should not be");
    }
}
