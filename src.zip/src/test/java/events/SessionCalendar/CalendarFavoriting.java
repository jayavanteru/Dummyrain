package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import configuration.PropertyReader;
import interaction.webUI.NetworkRequest;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.MyJson;

public class CalendarFavoriting {

    private AdminApp adminApp;
    private String attendeeId;
    private int status;
    private JSONObject response;
    private String operation;
    private NetworkRequest apiCall;
    private final String WIDGET = "Trogdor Calendar";
    private final String ORDER = "Trogdor Full Conference Pass";

    private CalendarWidgetPage calendar = new CalendarWidgetPage();
    private AdminAttendeeOrdersTab orders = new AdminAttendeeOrdersTab();

    @BeforeClass
    public void testSetup() {
        PropertyReader.instance().setProperty("enableNetworkLogging", true);
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
        attendeeId = adminApp.createAttendee();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage(ORDER);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void testCleanup() {
        orders.navigate(attendeeId);
        orders.selectAllOrders();
        orders.deleteOrders();
        orders.cancelOrder();

        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-26069", firefoxIssue = "RA-26070")
    public void calendarToggleFavoritingSession() {
        EditAttendeePage.getPage().spoofToWidget(WIDGET);

        PageConfiguration.getPage().startNetworkMonitoring();
            calendar.clickFirstAvailableTimeSlot();
            calendar.favoriteFirstAvailableSession();

            apiCall = PageConfiguration.getPage().getRequestByEndpoint("toggleSessionInterest");
            status = apiCall.getResponseStatusCode();
            response = MyJson.createJSON(apiCall.getResponseContent());
            operation = MyJson.getString(response, "operation");

        Assert.assertEquals(operation, "added", operation + " is wrong. Expected added");
        Assert.assertEquals(status, 200, status + " was the wrong response");
        PageConfiguration.getPage().stopNetworkMonitoring();

        PageConfiguration.getPage().refreshPage();
            calendar.clickFirstAvailableTimeSlot();
        Assert.assertTrue(calendar.firstSessionIsFavorited(), "Session not favorited successfully");
            calendar.closeSessionScheduleModal();
            calendar.toggleShowFavoritesCheckbox();

        Assert.assertTrue(calendar.verifyFavoritedSession(), "Session wasn't favorited correctly");
            calendar.clickFavoritedSession();

        PageConfiguration.getPage().startNetworkMonitoring();
            calendar.unfavoriteFirstFavoritedSession();

            apiCall = PageConfiguration.getPage().getRequestByEndpoint("toggleSessionInterest");
            status = apiCall.getResponseStatusCode();
            response = MyJson.createJSON(apiCall.getResponseContent());
            operation = MyJson.getString(response, "operation");

        Assert.assertEquals(operation, "removed", operation + " is wrong. Expected removed");
        Assert.assertEquals(status, 200, status + " was the wrong response");
        PageConfiguration.getPage().stopNetworkMonitoring();

        Assert.assertFalse(calendar.verifyFavoritedSession(), "Session favorite was not removed");
        PageConfiguration.getPage().refreshPage();
            calendar.toggleShowFavoritesCheckbox();
        Assert.assertFalse(calendar.verifyFavoritedSession(), "Session unfavorite was not saved after refresh");
    }
}
