package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class CalendarDownloads {

  private AdminApp adminApp;
  private String attendeeEmail = "calendar.downloads@rainfocus.com";
  private final String WIDGET = "Trogdor Selenium Details Calendar";
  private final String eventCode = "trogdorauto";

  private CalendarWidgetPage calendar = new CalendarWidgetPage();

  @BeforeClass
  public void testSetup() {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    NavigationBar.getPage().collapse();
  }

  @AfterClass
  public void testCleanup() {
    PageConfiguration.getPage().quit();
  }

  @Test (groups = { ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-20021", firefoxIssue = "RA-51985")
  public void calendarDownloads() throws IOException {
    adminApp.spoofIntoCatalog(attendeeEmail, WIDGET, 1);

    // Favorites not shown
    // ensure interests are hidden in print when show favorites is off
    calendar.clickPrintMenuItem();
    Assert.assertFalse(calendar.favoritesAreShownInPrintModal(), "The print modal is showing favorites when it shouldn't.");
    calendar.closePrintModal();

    // ensure that ical and vcal download
    calendar.clickDownloadMenuItem("ICal");
    Assert.assertFalse(scheduleCalendarFileHasFavorites("ics"), "The ICal calendar file contains favorites when it shouldn't.");
    calendar.clickDownloadMenuItem("VCal");
    Assert.assertFalse(scheduleCalendarFileHasFavorites("vcs"), "The VCal calendar file contains favorites when it shouldn't.");

    // ensure that csv downloads, without favorites
    calendar.clickDownloadMenuItem("CSV");
    Assert.assertFalse(scheduleCSVHasFavorites(), "The CSV file contains favorites when it shouldn't.");

    // Favorites are shown
    // ensure interests are shown in print when show favorites is on
    calendar.toggleShowFavoritesCheckbox();
    calendar.clickPrintMenuItem();
    Assert.assertTrue(calendar.favoritesAreShownInPrintModal(), "The print modal is not showing favorites when it should.");
    calendar.closePrintModal();

    // ensure that ical and vcal download
    calendar.clickDownloadMenuItem("ICal");
    Assert.assertTrue(scheduleCalendarFileHasFavorites("ics"), "The ICal calendar file does not contain favorites when it should.");
    calendar.clickDownloadMenuItem("VCal");
    Assert.assertTrue(scheduleCalendarFileHasFavorites("vcs"), "The VCal calendar file does not contain favorites when it should.");

    // ensure that csv downloads, with favorites
    calendar.clickDownloadMenuItem("CSV");
    Assert.assertTrue(scheduleCSVHasFavorites(), "The CSV file does not contain favorites when it should.");

  }
  public boolean scheduleCSVHasFavorites() {
    OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("myschedule.+csv\\z");
    List<Map<String, String>> CSVList = file.getCsvMap();

    return CSVList.stream().anyMatch(row -> row.get("Status").equals("Favorited"));
  }
  public boolean scheduleCalendarFileHasFavorites(String fileType) throws IOException {
    final File icsfile = OpenFile.OpenRecentDownloadedFileMatchingPattern("myschedule.+" + fileType + "\\z").getFile();
    final Map<String, Map<String, String>> icsmap = Utils.icalToMap(icsfile);

    return icsmap.keySet().stream().anyMatch(mapKey -> mapKey.contains("status") && icsmap.get(mapKey).get("value").trim().equals("Favorited"));
  }
}
