package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarPersonalTimePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PersonalTime {

    private AdminApp adminApp;
    private String attendeeId;
    private String[] dates;
    private final String CALENDAR = "Trogdor Calendar";
    private final String TITLE1 = "I Need Personal Time";
    private final String TITLE2 = "Much Needed Personal Time";

    EditAttendeePage editAttendeePage = new EditAttendeePage();
    AdminAttendeeOrdersTab orders = new AdminAttendeeOrdersTab();

    @BeforeClass
    public void testSetup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        attendeeId = adminApp.createAttendee();
        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage("Trogdor Full Conference Pass");
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void testCleanup() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-20023", firefoxIssue = "RA-33735")
    public void personalTime() {
            editAttendeePage.spoofToWidget(CALENDAR);

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.addPersonalTimeModal();

        CalendarPersonalTimePage PT = CalendarPersonalTimePage.getPage();
            dates = PT.getEligibleDaysInPersonalTime();
            String day1 = dates[0];
            String day2 = dates[1];
            PT.addPersonalTimeMethods(TITLE1, day1,"8:00", true, "1 h", "Lehi", "I don't want to be bothered");
            PT.addPersonalTime();

        Assert.assertTrue(PT.isPersonalTimeOnCalendar(TITLE1), "Personal Time was not added");
            PT.editPersonalTime(TITLE1);

            String title = PT.getPersonalTimeTitle();
            String date = PT.getPersonalTimeDate();
            String startTime = PT.getPersonalStartTime();
            String length = PT.getPersonalTimeLength();
            String location = PT.getPersonalTimeLocation();
            String notes = PT.getPersonalTimeNotes();

            PT.addPersonalTimeMethods(TITLE2, day2,"1:00", false, "2 h 15 mins", "SLC", "Relaxation time");
            PT.personalTimeSaveChanges();

        Assert.assertFalse(PT.isPersonalTimeOnCalendar(TITLE1), TITLE1 + " should no longer exist after the edit");
        Assert.assertTrue(PT.isPersonalTimeOnCalendar(TITLE2), TITLE2 + " does not exist on the page. Edit failed");
            PT.editPersonalTime(TITLE2);

        Assert.assertNotEquals(PT.getPersonalTimeTitle(), title, "Title edit did not save");
        Assert.assertNotEquals(PT.getPersonalTimeDate(), date, "Date edit did not save");
        Assert.assertNotEquals(PT.getPersonalStartTime(), startTime, "Start Time edit did not save");
        Assert.assertNotEquals(PT.getPersonalTimeLength(), length, "Length edit did not save");
        Assert.assertNotEquals(PT.getPersonalTimeLocation(), location, "Location edit did not save");
        Assert.assertNotEquals(PT.getPersonalTimeNotes(), notes, "Notes edit did not save");

            PT.personalTimeSaveChanges();

        Assert.assertFalse(PT.deletePersonalTime(TITLE2),TITLE2 + " was not deleted");
    }
}
