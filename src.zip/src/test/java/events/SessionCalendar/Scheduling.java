package events.SessionCalendar;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Scheduling {

  private AdminApp adminApp = new AdminApp();
  private DataGenerator dataGenerator = new DataGenerator();
  private String attendeeId = "";
  private String attendeeEmail = dataGenerator.generateEmail();
  private final String ORDER = "Trogdor Full Conference Pass";

  EditAttendeePage editAttendeePage = new EditAttendeePage();
  CalendarWidgetPage calendarWidgetPage = new CalendarWidgetPage();
  AdminAttendeeOrdersTab orders = new AdminAttendeeOrdersTab();

  @BeforeClass
  public void testSetup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
    NavigationBar.getPage().collapse();
    attendeeId = adminApp.createAttendee(attendeeEmail);

    orders.navigate(attendeeId);
    orders.verifyPackageOrdered(ORDER);
    orders.addOrder();
    orders.selectPackage(ORDER);
    orders.clickNextOnAddOrderModal();
    orders.setComment("Test");
    orders.submitOrder();
  }

  @AfterClass
  public void testCleanup() {
    orders.navigate(attendeeId);
    orders.selectAllOrders();
    orders.deleteOrders();
    orders.cancelOrder();
    adminApp.deleteAttendee(attendeeId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-26067", firefoxIssue = "RA-26068")
  public void toggleSchedulingSession() {
    // Spoof into widget
    editAttendeePage.spoofToWidget("Trogdor Calendar");

    // Schedule first session
    calendarWidgetPage.clickFirstAvailableTimeSlot();
    calendarWidgetPage.scheduleFirstAvailableSession();

    Assert.assertTrue(calendarWidgetPage.firstSessionIsScheduled(), "Session wasn't able to be scheduled successfully");

    // Unschedule first session
    calendarWidgetPage.unscheduleFirstScheduledSession();

    Assert.assertTrue(calendarWidgetPage.firstSessionIsUnscheduled(), "Session wasn't able to be unscheduled successfully");
  }
}

