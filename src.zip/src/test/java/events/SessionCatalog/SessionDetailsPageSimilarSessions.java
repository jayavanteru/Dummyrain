package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.EventsApp;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.events.eventsPageObjects.WidgetSessionDetailsPage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.aspectj.lang.annotation.After;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionDetailsPageSimilarSessions {
    AdminApp adminApp = new AdminApp();
    DataGenerator dataGen = new DataGenerator();
    EventsApp eventsApp = new EventsApp();
    AdminAttendeeOrdersTab ordersTab;
    WidgetSessionDetailsPage sessionDetailsPage;
    TrogdorSessionCatalog sessionCatalog;

    public String order = "Trogdor Full Conference Pass";
    public String attendeeID;
    public String catalogName = "sessiondetailscatalog"; //id: 1596758067307001P4Bt
    public String email = dataGen.generateEmail();
    public final String password = dataGen.generatePassword();
    public final String SIMILAR_SESSION_2_ID = "160166706810200179Ug";
    public final String SIMILAR_SESSION_4_ID = "16016671519820014Nnh";
    public final String TITLE_SIMILAR_SESSION_MR_1 = "Similar Session MR 1";
    public final String TITLE_SIMILAR_SESSION_MR_2 = "Similar Session MR 2";
    public final String TITLE_SIMILAR_SESSION_MR_3 = "Similar Session MR 3";
    public final String TITLE_SIMILAR_SESSION_MR_4 = "Similar Session MR 4";

    private boolean finished = false;

    @BeforeClass
    public void setup() {
        ordersTab = AdminAttendeeOrdersTab.getPage();
        sessionCatalog = TrogdorSessionCatalog.getPage();
        sessionDetailsPage = WidgetSessionDetailsPage.getPage();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");

        //create attendee and order package
        attendeeID = adminApp.createAttendee(email, password);
        ordersTab.navigate(attendeeID);
        ordersTab.addOrder();
        ordersTab.orderPackageForFree(order);

        //navigate to catalog and sign in
        sessionCatalog.navigateTrogdorEvent(catalogName);
        sessionCatalog.signIn(email, password);
    }

    @AfterClass
    public void teardown() {
        if (!finished)
            sessionDetailsPage.unscheduleSimilarSession(TITLE_SIMILAR_SESSION_MR_2);
        else
            sessionDetailsPage.unscheduleSimilarSession(TITLE_SIMILAR_SESSION_MR_3);
        ordersTab.navigate(attendeeID);
        ordersTab.deleteOrder(order);
        adminApp.deleteAttendee(attendeeID);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-38357", firefoxIssue = "RA-51232")
    public void SessionDetailsPageSimilarSessions() {
        sessionCatalog.filterCatalog(TITLE_SIMILAR_SESSION_MR_1);
        sessionCatalog.scheduleSessionById(SIMILAR_SESSION_2_ID, true); //session 2
        sessionCatalog.toggleFavorite(SIMILAR_SESSION_4_ID); //session 4
        sessionCatalog.clickFirstSession();

        //run elastics if similar sessions aren't on page
        elasticRefresh();

        //similar sessions are on the page
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_2), "Similar Session 2 was not on the page");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_3), "Similar Session 3 was not on the page");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_4), "Similar Session 4 was not on the page");

        //Check the status of similar sessions
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionScheduled(TITLE_SIMILAR_SESSION_MR_2), "The session is not scheduled");
        Assert.assertTrue(sessionDetailsPage.doesSimilarSessionHaveLearnMoreButton(TITLE_SIMILAR_SESSION_MR_4), "The session does have a learn more button");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionFavorited(TITLE_SIMILAR_SESSION_MR_4), "The session is not a favorite");
        Assert.assertTrue(sessionDetailsPage.doesSimilarSessionHaveConflict(TITLE_SIMILAR_SESSION_MR_3), "The is no schedule conflict");

        //unschedule similar session 2 and reschedule it
        PageConfiguration.getPage().justWait();
        sessionDetailsPage.unscheduleSimilarSession(TITLE_SIMILAR_SESSION_MR_2);
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionNotScheduled(TITLE_SIMILAR_SESSION_MR_2), "The session is scheduled");
        sessionDetailsPage.scheduleSimilarSession(TITLE_SIMILAR_SESSION_MR_2);
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionScheduled(TITLE_SIMILAR_SESSION_MR_2), "The session is not scheduled");

        //Schedule conflict
        PageConfiguration.getPage().justWait();
        sessionDetailsPage.scheduleSimilarSession(TITLE_SIMILAR_SESSION_MR_3);
        sessionDetailsPage.scheduleConflictModalSwitchSessionsAndSubmit();
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionNotScheduled(TITLE_SIMILAR_SESSION_MR_2), "The session is scheduled");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionScheduled(TITLE_SIMILAR_SESSION_MR_3), "The session is not scheduled");

        //click learn more button and verify other similar sessions are on page
        sessionDetailsPage.clickSimilarSessionLearnMore(TITLE_SIMILAR_SESSION_MR_4);
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_2), "Similar Session 2 not on the page");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_3), "Similar Session 3 was not on the page");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionOnPage(TITLE_SIMILAR_SESSION_MR_1), "Similar Session 1 was not on the page");

        //Make sure favorites still apply after page refresh
        sessionDetailsPage.toggleSimilarSessionFavorite(TITLE_SIMILAR_SESSION_MR_1);
        sessionDetailsPage.toggleSimilarSessionFavorite(TITLE_SIMILAR_SESSION_MR_3);
        PageConfiguration.getPage().refreshPage();
        elasticRefresh();
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionFavorited(TITLE_SIMILAR_SESSION_MR_1), "The session is not a favorite");
        Assert.assertTrue(sessionDetailsPage.isSimilarSessionFavorited(TITLE_SIMILAR_SESSION_MR_3), "The session is not a favorite");
        Assert.assertFalse(sessionDetailsPage.isSimilarSessionFavorited(TITLE_SIMILAR_SESSION_MR_2), "The session is a favorite");
        finished = true;
    }

    //refreshes elastics and navigates back to the similar session page
    public void elasticRefresh() {
        if (!sessionDetailsPage.isSimilarSessionContainerOnPage()) {
            eventsApp.post("/api/elasticSessionLoad?rfWidgetId=88aQHYLj53m2MKkeJisjdYh9xWJVoJUD&rfApiProfileId=k6ZRBRWmNMxVb20z8rEYgXJOrteRK5uI&forceReindex=true");
            eventsApp.post("/api/recommendCache?rfWidgetId=88aQHYLj53m2MKkeJisjdYh9xWJVoJUD&rfApiProfileId=k6ZRBRWmNMxVb20z8rEYgXJOrteRK5uI&forceReindex=true");
            sessionCatalog.navigateTrogdorEvent(catalogName);
            sessionCatalog.filterCatalog(TITLE_SIMILAR_SESSION_MR_1);
            PageConfiguration.getPage().justWait();
            sessionCatalog.clickFirstSession();
        }
    }
}
