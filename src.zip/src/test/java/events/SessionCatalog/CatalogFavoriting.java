package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import configuration.PropertyReader;
import interaction.webUI.NetworkRequest;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.MyJson;

public class CatalogFavoriting {

    private int status;
    private AdminApp adminApp;
    private String attendeeId;
    private String operation;
    private String sessionId;
    private JSONObject response;
    private NetworkRequest apiCall;
    private final String SESSION = "\"Almost Full Session MR\"";
    private final String WIDGET = "Trogdor Catalog";
    private final String ORDER = "Trogdor Full Conference Pass";

    private TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
    private AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void testSetup() {
        PropertyReader.instance().setProperty("enableNetworkLogging", true);
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
        attendeeId = adminApp.createAttendee();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage(ORDER);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void testCleanup() {
        orders.navigate(attendeeId);
        orders.selectAllOrders();
        orders.deleteOrders();
        orders.cancelOrder();

        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-39373", firefoxIssue = "RA-39374")
    public void catalogToggleFavoritingSession() {
        EditAttendeePage.getPage().spoofToWidget(WIDGET);
        PageConfiguration.getPage().justWait();
            catalog.filterCatalog(SESSION);
            sessionId = catalog.getSessionId(SESSION.replaceAll("\"", ""));

        PageConfiguration.getPage().startNetworkMonitoring();
            catalog.toggleFavorite(sessionId);

            apiCall = PageConfiguration.getPage().getRequestByEndpoint("toggleSessionInterest");
            status = apiCall.getResponseStatusCode();
            response = MyJson.createJSON(apiCall.getResponseContent());
            operation = MyJson.getString(response, "operation");

        Assert.assertEquals(operation, "added", operation + " is wrong. Expected added");
        Assert.assertEquals(status, 200, status + " was the wrong response");
        PageConfiguration.getPage().stopNetworkMonitoring();

        Assert.assertTrue(catalog.isSessionFavorite(sessionId), "Session was not marked as a favorite");

        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(catalog.isSessionFavorite(sessionId), "Session favorite state did not save after refresh");

        PageConfiguration.getPage().startNetworkMonitoring();
            catalog.toggleFavorite(sessionId);

            apiCall = PageConfiguration.getPage().getRequestByEndpoint("toggleSessionInterest");
            status = apiCall.getResponseStatusCode();
            response = MyJson.createJSON(apiCall.getResponseContent());
            operation = MyJson.getString(response, "operation");

        Assert.assertEquals(operation, "removed", operation + " is wrong. Expected removed");
        Assert.assertEquals(status, 200, status + " was the wrong response");
        PageConfiguration.getPage().stopNetworkMonitoring();

        Assert.assertFalse(catalog.isSessionFavorite(sessionId), "Session favorite was not removed");
        PageConfiguration.getPage().refreshPage();
        Assert.assertFalse(catalog.isSessionFavorite(sessionId), "Session unfavorite was not saved after refresh");
    }
}
