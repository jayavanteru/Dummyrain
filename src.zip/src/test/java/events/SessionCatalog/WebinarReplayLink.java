package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WebinarReplayLink {

    private String oldJson;
    private String sessionId;
    private String widgetUrl;
    private String sessionUrl;
    private String attendeeId;
    private AdminApp adminApp;
    private String sessionTitle;
    private boolean jsonCleanup = false;
    private final String WEBINAR = "Webinar";
    private boolean activeReplayCleanup = false;
    private final String PAST_WEBINAR = "pastwebinar";
    private final String TROGDOR_CATALOG = "Past Trogdor Catalog";
    private final String SMALL_JSON = "\"replayAvailableMinutesAfter\": 10.0";
    private final String LARGE_JSON = "\"replayAvailableMinutesAfter\": 9999999.0";
    private final String REGEX_JSON = "\"replayAvailableMinutesAfter\":.*?[0-9]+?\\.[0-9]+?";

    private final EditWidgetPage config = EditWidgetPage.getPage();
    private final EditSessionPage sessionEdit = EditSessionPage.getPage();
    private final SessionSearchPage sessions = SessionSearchPage.getPage();
    private final AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();
    private final WidgetSearchPage search = WidgetSearchPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Past Event Trogdor Tests");
        attendeeId = adminApp.createAttendee();

        sessions.navigate();
        sessions.search(PAST_WEBINAR);
        sessions.clickResult(PAST_WEBINAR);

        sessionEdit.scheduleTab();
        sessionUrl = PageConfiguration.getPage().getCurrentUrl();
        sessionEdit.setReplayValue(true);

        search.navigate();
        search.searchWidgets(TROGDOR_CATALOG);
        search.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Catalog"));
        widgetUrl = PageConfiguration.getPage().getCurrentUrl();
        oldJson = config.getWidgetJson();
        config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, SMALL_JSON));
        config.saveWidgetConfig();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage("Full Conference Trogdor Past Event");
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void quit() {
        if (activeReplayCleanup) {
            PageConfiguration.getPage().navigateTo(sessionUrl);
            sessionEdit.setReplayValue(true);
        }
        if (jsonCleanup) {
            PageConfiguration.getPage().navigateTo(widgetUrl);
            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, SMALL_JSON));
            config.saveWidgetConfig();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    //Combined both tests into one
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-36363", chromeIssue = "RA-36362")
    public void catalogAndCalendarReplayLink() {
        EditAttendeePage.getPage().spoofToWidget("Past Trogdor Catalog");
        PageConfiguration.getPage().switchToTab(1);
        String catalogUrl = PageConfiguration.getPage().getCurrentUrl();

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog(WEBINAR);
            sessionId = catalog.getSessionId(WEBINAR);
        Assert.assertTrue(catalog.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
        Assert.assertTrue(catalog.webinarLinkIsActive(sessionId), "Webinar link cannot be clicked");

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorpast/pastTrogdorCalendar");

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
        String calendarUrl = PageConfiguration.getPage().getCurrentUrl();
            calendar.clickFirstAvailableTimeSlot();
            sessionTitle = calendar.getFirstSessionTitle();
            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
            if(!sessionTitle.contains(WEBINAR)) {
                PageConfiguration.getPage().refreshPage();
                calendar.clickFirstAvailableTimeSlot();
            }
        Assert.assertTrue(calendar.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
        Assert.assertTrue(calendar.webinarLinkIsActive(sessionId), "Webinar link cannot be clicked");

        PageConfiguration.getPage().switchToTab(0);

            search.navigate();
            search.searchWidgets(TROGDOR_CATALOG);
            search.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Catalog"));
            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, LARGE_JSON));
            config.saveWidgetConfig();
            jsonCleanup = true;

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().navigateTo(catalogUrl);
            catalog.filterCatalog(WEBINAR);

        String minutes = LARGE_JSON.split(" ")[1].replace(".0", "");
        Assert.assertTrue(catalog.webinarReplayAvailableMessage(sessionId, minutes), "The text with set number of minutes do not match");

        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.clickFirstAvailableTimeSlot();
            sessionTitle = calendar.getFirstSessionTitle();
            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
            if(!sessionTitle.contains(WEBINAR)) {
                PageConfiguration.getPage().refreshPage();
                calendar.clickFirstAvailableTimeSlot();
            }
        Assert.assertTrue(calendar.webinarReplayAvailableMessage(sessionId, minutes), "The text with set number of minutes do not match");

        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().navigateTo(sessionUrl);

            sessionEdit.setReplayValue(false);
            activeReplayCleanup = true;
        Assert.assertFalse(sessionEdit.isReplayAvailable(), "Replay checkbox is not checked and should be");

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().navigateTo(catalogUrl);
            catalog.filterCatalog(WEBINAR);

        Assert.assertTrue(catalog.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
        Assert.assertFalse(catalog.webinarLinkIsActive(sessionId), "Webinar link should be disabled");

        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.clickFirstAvailableTimeSlot();
            sessionTitle = calendar.getFirstSessionTitle();
            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
            if(!sessionTitle.contains(WEBINAR)) {
                PageConfiguration.getPage().refreshPage();
                calendar.clickFirstAvailableTimeSlot();
            }
        Assert.assertTrue(calendar.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
        Assert.assertFalse(calendar.webinarLinkIsActive(sessionId), "Webinar link should be disabled");
    }

    //Combined following two tests into test above to reduce overlap failures
//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-34060", chromeIssue = "RA-33862")
//    public void catalogWebinarReplayLink() {
//        EditAttendeePage.getPage().spoofToWidget("Past Trogdor Catalog");
//        PageConfiguration.getPage().switchToTab(1);
//
//        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
//            catalog.filterCatalog(WEBINAR);
//            sessionId = catalog.getSessionId(WEBINAR);
//        Assert.assertTrue(catalog.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
//        Assert.assertTrue(catalog.webinarLinkIsActive(sessionId), "Webinar link cannot be clicked");
//
//        PageConfiguration.getPage().switchToTab(0);
//
//            search.navigate();
//            search.searchWidgets(TROGDOR_CATALOG);
//            search.editItem();
//
//            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, LARGE_JSON));
//            config.saveWidgetConfig();
//            jsonCleanup = true;
//
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().refreshPage();
//
//            String minutes = LARGE_JSON.split(" ")[1].replace(".0", "");
//        Assert.assertTrue(catalog.webinarReplayAvailableMessage(sessionId, minutes), "The text with set number of minutes do not match");
//
//        PageConfiguration.getPage().switchToTab(0);
//        PageConfiguration.getPage().navigateTo(sessionUrl);
//
//            sessionEdit.setReplayValue(false);
//            activeReplayCleanup = true;
//        Assert.assertFalse(sessionEdit.isReplayAvailable(), "Replay checkbox is not checked and should be");
//
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().refreshPage();
//
//        Assert.assertTrue(catalog.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
//        Assert.assertFalse(catalog.webinarLinkIsActive(sessionId), "Webinar link should be disabled");
//    }
//
//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-34062", chromeIssue = "RA-34063")
//    public void calendarWebinarReplayLink() {
//        EditAttendeePage.getPage().spoofToWidget("Past Trogdor Calendar");
//        PageConfiguration.getPage().switchToTab(1);
//
//        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
//            calendar.clickFirstAvailableTimeSlot();
//            sessionTitle = calendar.getFirstSessionTitle();
//            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
//            if(!sessionTitle.contains(WEBINAR)) {
//                PageConfiguration.getPage().refreshPage();
//                calendar.clickFirstAvailableTimeSlot();
//            }
//            sessionId = calendar.getSessionId(WEBINAR);
//        Assert.assertTrue(calendar.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
//        Assert.assertTrue(calendar.webinarLinkIsActive(sessionId), "Webinar link cannot be clicked");
//
//        PageConfiguration.getPage().switchToTab(0);
//
//            search.navigate();
//            search.searchWidgets(TROGDOR_CATALOG);
//            search.editItem();
//
//            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, LARGE_JSON));
//            config.saveWidgetConfig();
//            jsonCleanup = true;
//
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().refreshPage();
//
//            calendar.clickFirstAvailableTimeSlot();
//            sessionTitle = calendar.getFirstSessionTitle();
//            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
//            if(!sessionTitle.contains(WEBINAR)) {
//                PageConfiguration.getPage().refreshPage();
//                calendar.clickFirstAvailableTimeSlot();
//            }
//            String minutes = LARGE_JSON.split(" ")[1].replace(".0", "");
//        Assert.assertTrue(calendar.webinarReplayAvailableMessage(sessionId, minutes), "The text with set number of minutes do not match");
//
//        PageConfiguration.getPage().switchToTab(0);
//        PageConfiguration.getPage().navigateTo(sessionUrl);
//
//            sessionEdit.setReplayValue(false);
//            activeReplayCleanup = true;
//        Assert.assertFalse(sessionEdit.isReplayAvailable(), "Replay checkbox is not checked and should be");
//
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().refreshPage();
//
//            calendar.clickFirstAvailableTimeSlot();
//            sessionTitle = calendar.getFirstSessionTitle();
//            Log.info("The session title is -------> " + sessionTitle, getClass().getName());
//            if(!sessionTitle.contains(WEBINAR)) {
//                PageConfiguration.getPage().refreshPage();
//                calendar.clickFirstAvailableTimeSlot();
//            }
//        Assert.assertTrue(calendar.sessionHasWebinarLink(sessionId), "Session does not have a webinar link");
//        Assert.assertFalse(calendar.webinarLinkIsActive(sessionId), "Webinar link should be disabled");
//    }
}
