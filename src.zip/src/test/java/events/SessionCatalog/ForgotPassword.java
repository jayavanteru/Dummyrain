package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ForgotPassword {

    private AdminApp adminApp;
    private String attendeeId;
    private String attendeeName;
    private final String BAD_PW = "badpw";
    private final String GOOD_PW = "reallyG00dPassword!";
    private final String URI = "TrogdorSeleniumSessionCatalog";
    private final String EMAIL_SUBJECT = "RainFocus Password Reset";
    private final String EMAIL = new DataGenerator().generateValidEmail();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        attendeeId = adminApp.createAttendee(EMAIL);
        attendeeName = EditAttendeePage.getPage().getFirstName() + " " + EditAttendeePage.getPage().getLastName();
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-44629", chromeIssue = "RA-22436")
    public void forgotPasswordFlow() {
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.navigateTrogdorAutomation(URI);
            catalog.clickCookieConsent();
            catalog.signOut();
        EmailApi checkEmail = EmailApi.emailClient();
            catalog.sendForgotPasswordEmail(EMAIL);

        Assert.assertTrue(checkEmail.waitForEmail(EMAIL_SUBJECT, EMAIL), "waiting for email");
        EmailMessage message = checkEmail.getEmail(EMAIL_SUBJECT);
        String emailText = message.getBody();
        Assert.assertTrue(emailText.contains("Click this link to reset your password"), "Email does not contain attendee name");
        String url = getLinkFromEmail(emailText).get(0);

        PageConfiguration.getPage().navigateTo(url);
        Utils.waitForTrue(catalog::isResetPasswordModalOnPage);
            catalog.setInitialError();
        Assert.assertEquals(catalog.getPasswordErrorMessage(),"Required parameter missing: password","Wrong error message displayed");
            catalog.resetPassword(BAD_PW, BAD_PW);
        Assert.assertEquals(catalog.getPasswordErrorMessage(), "Invalid Password", "Wrong error message for weak password");
            catalog.resetPassword(BAD_PW, GOOD_PW);
        Assert.assertEquals(catalog.getPasswordErrorMessage(), "Passwords do not match.", "Wrong error message for mismatched passwords");
            catalog.resetPassword(GOOD_PW, GOOD_PW);
        Assert.assertEquals(catalog.getAuthenticatedUsername(), attendeeName,"Wrong user authenticated from login");

            catalog.signOut();
            catalog.signIn(EMAIL, GOOD_PW);
        Assert.assertEquals(catalog.getAuthenticatedUsername(), attendeeName, "Password change did not take affect");

            catalog.signOut();
        PageConfiguration.getPage().navigateTo(url);
        Assert.assertFalse(catalog.isResetPasswordModalOnPage(),"Link from email should not have allowed a password reset after already being used");
        Assert.assertEquals(catalog.getAuthenticatedUsername(), "Sign In", "Link should not have authenticated user");
    }

    public ArrayList<String> getLinkFromEmail(String emailBody) {
        ArrayList<String> links = new ArrayList<>();
        final String LINK_REGEX = "((http:\\/\\/|https:\\/\\/)?(www.)?(([a-zA-Z0-9-]){2,2083}\\.){1,4}([a-zA-Z]){2,6}(\\/(([a-zA-Z-_\\/\\.0-9#:?=&;,]){0,2083})?){0,2083}?[^ \\n]*)";
        Pattern p = Pattern.compile(LINK_REGEX, Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(emailBody);
        while(m.find()) {
            links.add(m.group());
        }
        return links;
    }
}
