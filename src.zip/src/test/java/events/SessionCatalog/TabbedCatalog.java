package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import interaction.pageObjects.WebPage;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;

public class TabbedCatalog{
    private final EditWidgetPage widgetPage = new EditWidgetPage();
    private final String EVENTNAME = "Trogdor Automation";
    private final String ONDEMAND = "\"attributeValueDisplayName\": \"On-demand\",";
    private final String LIVE = "\"attributeValueDisplayName\": \"Live\",";
    private final String ATTENDEE_ID = "1504651702935001LsRI";
    private final String SPOOF_LOCATION = "Trogdor Tabbed Catalog";
    private final String WIDGET_ID = "1640381870049003FAAy";
    private String originalJSON;
    private TrogdorSessionCatalog sessionCatalog = TrogdorSessionCatalog.getPage();

    @BeforeClass
    public void setup(){
        TrogdorSessionCatalog sessionCatalog;
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", EVENTNAME);
        widgetPage.goToWidget(WIDGET_ID);
    }

    @AfterClass
    public void quit(){
        PageConfiguration.getPage().switchToTab(0);
        widgetPage.goToWidget(WIDGET_ID);
        widgetPage.setWidgetJson(originalJSON);
        widgetPage.saveWidgetConfig();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-52082", chromeIssue = "RA-38807")
    public void tabbedCatalog(){
        //getting json before any changes are made
        originalJSON = widgetPage.getWidgetJson();

        //checking json to make sure it's configured correctly
        Assert.assertTrue(originalJSON.contains(LIVE), "Widget does not have 'SessionDeliveryLive'");
        Assert.assertTrue(originalJSON.contains(ONDEMAND), "Widget does not have 'sessionDeliveryOn-demand'");

        //spoofing into an attendee
        EditAttendeePage.getPage().navigate(ATTENDEE_ID);
        EditAttendeePage.getPage().spoofToWidget(SPOOF_LOCATION);

        //making sure there are tabs that are displayed
        Assert.assertTrue(sessionCatalog.hasTabs(), "Tab container not found");
        Assert.assertTrue(sessionCatalog.tabsAreActive(), "Tabs displaying could not be verified");

        //modifying json to add the 'bof' tab
        PageConfiguration.getPage().switchToTab(0);
        widgetPage.goToWidget(WIDGET_ID);
        int attributeLocation = originalJSON.indexOf("attributeTabs");
        String newJSON = originalJSON.substring(0,attributeLocation+17) +"\n" +"{\n\"attribute\":\"sessiontype\",\n" +
                "\"value\":\"bof\"\n},\n" + originalJSON.substring(attributeLocation+17);
        widgetPage.setWidgetJson(newJSON);
        widgetPage.saveWidgetConfig();

        //verifying 'bof' tab is there with content in it
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(sessionCatalog.clickTab("Birds of a feather"), "Birds of a feather tab is not showing");
        Assert.assertTrue(sessionCatalog.hasResults());

        //making sure the on-demand tab has its results in alphabetical order
        Assert.assertTrue(sessionCatalog.clickTab("On-demand"), "On-demand tab not found");
        Assert.assertTrue(sessionCatalog.verifyResultsAlphabetical(), "The results are not in alphabetical order");

        //Switching json to sort the 'live' tab by 'DayTime'
        PageConfiguration.getPage().switchToTab(0);
        widgetPage.goToWidget(WIDGET_ID);
        int insertLocation = originalJSON.indexOf("\"attributeValueDisplayName\": \"Live\",");
        String dayTimeJSON = originalJSON.substring(0,insertLocation+36)+"\n\"sortAttributeId\":\"DayTime\""+
                originalJSON.substring(insertLocation+68);
        widgetPage.setWidgetJson(dayTimeJSON);
        widgetPage.saveWidgetConfig();

        //making sure the live tab is selected
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(sessionCatalog.clickTab("Live"), "Live tab was not successfully selected");

        //making sure the live tab is sorting by 'DayTime'
        String[][] sessionTimes = sessionCatalog.getResultsDayTime();
        DateTime prevDateTime = null;
        for(int i = 0; i <= sessionTimes.length-1; i++){
            DateTime curDateTime = dateCreator(sessionTimes[i][0], sessionTimes[i][1]);
            if(prevDateTime != null){
                Assert.assertTrue(prevDateTime.isBefore(curDateTime)|| prevDateTime.isEqual(curDateTime),
                            "Session "+prevDateTime + "shows up before "+curDateTime);
            }
        }

    }

    //This method creates a datetime out of two strings
    //time format: 'HH:MM AM/PM - HH:MM AM/PM Zone'
    //date format: 'Weekday, MMM Day'
    private DateTime dateCreator(String time, String date){
        Date today = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(today);
        int year = calendar.get(Calendar.YEAR);
        int day = Integer.parseInt(date.replaceAll("\\D",""));
        String dayFormatted = day < 10? "0"+day: String.valueOf(day);
        String formattedDate = year+"-"+monthToNum(date)+"-"+dayFormatted+"T"+hourFormat(time)+":00";
        return new DateTime(formattedDate);
    }

    //This method takes in a date string and returns the months numerical value
    //eg: 'Thursday, Dec 16' will return 12
    private static String monthToNum(String date){
        if(date.contains("Jan"))
            return "01";
        else if (date.contains("Feb"))
            return "02";
        else if(date.contains("Mar"))
            return "03";
        else if(date.contains("Apr"))
            return "04";
        else if(date.contains("May"))
            return "05";
        else if(date.contains("Jun"))
            return "06";
        else if(date.contains("Jul"))
            return "07";
        else if(date.contains("Aug"))
            return "08";
        else if(date.contains("Sep"))
            return "09";
        else if(date.contains("Oct"))
            return "10";
        else if(date.contains("Nov"))
            return "11";
        else if(date.contains("Dec"))
            return "12";
        else
            return "0";
    }

    //This method takes in a time string and returns a formatted version
    //eg '2:00 PM - 3:00 PM MST' will return '14:00'
    private String hourFormat(String time) {
        String[] stringArray = time.split(" ");
        String formattedTime = stringArray[0];
        if(stringArray[1].equals("PM")) {
            int hourLocation = stringArray[0].indexOf(":");
            int hour = Integer.parseInt(stringArray[0].substring(0, hourLocation));
            hour += 12;
            formattedTime = hour + stringArray[0].substring(hourLocation,hourLocation+3);
        }
        return formattedTime;
    }

}
