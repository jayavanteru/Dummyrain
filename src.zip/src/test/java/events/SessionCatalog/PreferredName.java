package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeDemographicsTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.DigitalSignageWidgetPage;
import apps.events.eventsPageObjects.SpeakerListWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;

public class PreferredName {

    private AdminApp adminApp;
    private String sessionId;
    private String attendeeId = "";
    private boolean cleanUp = false;
    private final String DATA = "Data is King";
    private final String CATALOG = "Trogdor Catalog";
    private final String CALENDAR = "Trogdor Calendar";
    private final String PREFERRED_NAME = "Bob";
    private final String EXPECTED_NAME = "Bob Smith";
    private final String ROBERT_ID = "15634866391970018qKn";
    private final String ORDER = "Trogdor Full Conference Pass";
    private final String PREFERRED_NAME_BADGE = "Preferred First Name for Badge";

    private final AdminAttendeeDemographicsTab demographics = AdminAttendeeDemographicsTab.getPage();
    private final AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void fullSetup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
    }

    @BeforeMethod
    public void setup() {
        if(attendeeId.equals("")) {
            attendeeId = adminApp.createAttendee();
        }
        orders.navigate(attendeeId);
        if(!orders.verifyPackageOrdered(ORDER)) {
            orders.addOrder();
            orders.selectPackage(ORDER);
            orders.clickNextOnAddOrderModal();
            orders.setComment("Test");
            orders.submitOrder();
        }
        demographics.navigate(ROBERT_ID);
        if(!demographics.getTextInputFieldValue(PREFERRED_NAME_BADGE).equals(PREFERRED_NAME)) {
            demographics.textInputFields(PREFERRED_NAME_BADGE, PREFERRED_NAME);
            demographics.attendeesubmit();
        }
        cleanUp = true;
    }

    @AfterClass
    public void quit() {
        if(cleanUp) {
            demographics.navigate(ROBERT_ID);
            demographics.textInputFields(PREFERRED_NAME_BADGE, "");
            demographics.attendeesubmit();
        }
        if(!attendeeId.equals("")) {
            adminApp.deleteAttendee(attendeeId);
        }
        PageConfiguration.getPage().quit();
    }
    //This test combines all 3 tests into 1. They fail if ran at the same time
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-36159", chromeIssue =  "RA-36158")
    public void allPreferredNames() {
            orders.navigate(attendeeId);

        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog(DATA);
            sessionId = catalog.getSessionId(DATA);
            if(!catalog.isSessionFavorite(sessionId)) {
                catalog.toggleFavorite(sessionId);
            }
            catalog.expandSessionDetails(sessionId, true);
        Assert.assertEquals(EXPECTED_NAME, catalog.getSessionSpeakerName(sessionId, 0), PREFERRED_NAME + " was not saved on the session");

            catalog.openSpeakerModal(sessionId);
        Assert.assertEquals(EXPECTED_NAME, catalog.getSpeakerNameFromSpeakerModal(EXPECTED_NAME), PREFERRED_NAME + " was not saved on the speaker modal");
        Assert.assertEquals(EXPECTED_NAME, catalog.seeAllSessionWithThisSpeaker(), PREFERRED_NAME + " was not set in the catalog filter");

        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        EditAttendeePage.getPage().spoofToWidget(CALENDAR);
        PageConfiguration.getPage().switchToTab(1);
        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(DATA);
        Assert.assertEquals(EXPECTED_NAME, catalog.getSessionSpeakerName(sessionId, 0), PREFERRED_NAME + " was not saved on the session");

        SpeakerListWidgetPage speaker = SpeakerListWidgetPage.getPage();
            speaker.navigate();
            speaker.searchSpeakerList(EXPECTED_NAME);
        Assert.assertTrue(speaker.isSpeakerOnList(EXPECTED_NAME), PREFERRED_NAME + " was not applied to Robert on the speaker list page");

            String room = "Delfino";
            String year = "2022";
            String month = "12";
            String day = "07";
            String hour = "12";
            String minute = "00";

        DigitalSignageWidgetPage signage = DigitalSignageWidgetPage.getPage();
            signage.navigate();
            signage.searchRoom(room, year, month, day, hour, minute);

        Assert.assertEquals(DATA, signage.getSessionTitle(), DATA + " session was not displayed after the search");
        Assert.assertEquals(EXPECTED_NAME, signage.getSpeakerName(), EXPECTED_NAME + " was not applied to the digital signage page");
    }

    //These tests have been merged into the one above it
//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-35202", chromeIssue = "RA-35208")
//    public void catalogPreferredName() {
//            orders.navigate(attendeeId);
//
//        EditAttendeePage.getPage().spoofToWidget(CATALOG);
//        PageConfiguration.getPage().switchToTab(1);
//
//        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
//            catalog.filterCatalog(DATA);
//            sessionId = catalog.getSessionId(DATA);
//            if(!catalog.isSessionFavorite(sessionId)) {
//                catalog.toggleFavorite(sessionId);
//            }
//            catalog.expandSessionDetails(sessionId);
//        Assert.assertEquals(EXPECTED_NAME, catalog.getSessionSpeakerName(sessionId, 0), PREFERRED_NAME + " was not saved on the session");
//
//            catalog.openSpeakerModal(ROBERT_ID);
//        Assert.assertEquals(EXPECTED_NAME, catalog.getSpeakerNameFromSpeakerModal(EXPECTED_NAME), PREFERRED_NAME + " was not saved on the speaker modal");
//        Assert.assertEquals(EXPECTED_NAME, catalog.seeAllSessionWithThisSpeaker(), PREFERRED_NAME + " was not set in the catalog filter");
//
//        PageConfiguration.getPage().close();
//        PageConfiguration.getPage().switchToTab(0);
//    }
//
//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-35205", chromeIssue = "RA-35203")
//    public void calendarPreferredName() {
//            orders.navigate(attendeeId);
//
//        EditAttendeePage.getPage().spoofToWidget(CATALOG);
//        PageConfiguration.getPage().switchToTab(1);
//
//        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
//            catalog.filterCatalog(DATA);
//            sessionId = catalog.getSessionId(DATA);
//            if(!catalog.isSessionFavorite(sessionId)) {
//                catalog.toggleFavorite(sessionId);
//            }
//
//            catalog.headerNavbar("Calendar");
//        PageConfiguration.getPage().switchToTab(2);
//
//        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
//            calendar.toggleShowFavoritesCheckbox();
//            calendar.clickFavoriteSession(DATA);
//        Assert.assertEquals(EXPECTED_NAME, catalog.getSessionSpeakerName(sessionId, 0), PREFERRED_NAME + " was not saved on the session");
//
//        PageConfiguration.getPage().close();
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().close();
//        PageConfiguration.getPage().switchToTab(0);
//    }
//
//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-35207", chromeIssue = "RA-35206")
//    public void speakerPreferredName() {
//        SpeakerListWidgetPage speaker = SpeakerListWidgetPage.getPage();
//            speaker.navigate();
//            speaker.seachSpeakerList(EXPECTED_NAME);
//        Assert.assertTrue(speaker.isSpeakerOnList(EXPECTED_NAME), PREFERRED_NAME + " was not applied to Robert on the speaker list page");
//    }

//    ----> As of right now this test will not work unless we have automation clear a retis cache <----
//
//    @Test(groups = {ReportingInfo.TROGDOR})
//    //Chrome issue number is original x-ray test <----
//    @ReportingInfo(firefoxIssue = "RA-35209", chromeIssue = "RA-23020")
//    public void digitalSignagePreferredName() {
//            String room = "Delfino";
//            String year = "2022";
//            String month = "12";
//            String day = "07";
//            String hour = "12";
//            String minute = "00";
//
//        DigitalSignageWidgetPage signage = DigitalSignageWidgetPage.getPage();
//            signage.navigate();
//            signage.searchRoom(room, year, month, day, hour, minute);
//
//        Assert.assertEquals(DATA, signage.getSessionTitle(), DATA + " session was not displayed after the search");
//        Assert.assertEquals(EXPECTED_NAME, signage.getSpeakerName(), EXPECTED_NAME + " was not applied to the digital signage page");
//    }
}
