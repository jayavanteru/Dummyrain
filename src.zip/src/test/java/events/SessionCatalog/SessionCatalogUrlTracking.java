package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewWebPagePage;
import apps.admin.adminPageObjects.registration.*;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.events.eventsPageObjects.WidgetSessionDetailsPage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class SessionCatalogUrlTracking {
    AdminApp adminApp = new AdminApp();
    DataGenerator dataGenerator = new DataGenerator();
    NewRegCodeCategoryPage regCodeCategoryCreation;
    RegCodeSearchPage regCodeSearchPage;
    RegCodeCategoriesSearchPage categoriesSearchPage;
    AdminAttendeeOrdersTab ordersTab;
    OrgEventData eventData;
    LegacyEventSettings eventSettings;
    AdminAttendeeDemographicsTab demoTab;
    NewRegCodePage regCodePage;
    TrogdorSessionCatalog sessionCatalog;

    public String attendeeId;
    public String email = dataGenerator.generateEmail();
    public String password = dataGenerator.generatePassword();
    public String regCodeCategory = "AutomatedURLTracking" + dataGenerator.generateString(5);
    private String regCodeCategoryId;
    private String regCodeId;

    private final String regCodeCode = "TMR" + dataGenerator.generateString(7);
    private final String initialRegCodeQuantity = "1";
    private final String nextRegCodeQuantity = "0";
    private final String platform = "hello";
    private final String soda = "world";
    private final String urlAssert = "regcode="+regCodeCode+"&soda="+soda+"&platform="+platform;
    private final String updatedFromUrlString = "updatedfromurl";
    private final String updateUrlAssert = "platform="+updatedFromUrlString;
    private final String allTrackingUrl = "trogdorseleniumsessiondetailscatalog?regcode="+regCodeCode+"&platform="+platform+"&soda="+soda;
    private final String updatedFromURL = "trogdorseleniumsessiondetailscatalog?platform="+updatedFromUrlString;

    private boolean finished = false;

    @BeforeClass
    public void setup() {
        regCodeCategoryCreation = NewRegCodeCategoryPage.getPage();
        regCodeSearchPage = RegCodeSearchPage.getPage();
        categoriesSearchPage = RegCodeCategoriesSearchPage.getPage();
        ordersTab = AdminAttendeeOrdersTab.getPage();
        eventData = OrgEventData.getPage();
        eventSettings = LegacyEventSettings.getPage();
        demoTab = AdminAttendeeDemographicsTab.getPage();
        regCodePage = NewRegCodePage.getPage();
        sessionCatalog = TrogdorSessionCatalog.getPage();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        attendeeId = adminApp.createAttendee(email, password);
        demoTab.navigate(attendeeId);
        demoTab.checkTrackingURL();
    }

    @AfterClass
    public void teardown() {
        adminApp.deleteAttendee(attendeeId);
        if (!finished)
            regCodeSearchPage.deleteRegCodeApi(regCodeId);
        categoriesSearchPage.deleteRegCodeCategoryApi(regCodeCategoryId);

        //reset event tracking params
        eventData.waitForOrgVisible();
        eventData.clickEventSelect();
        eventSettings.clickOnCog();
        eventSettings.setTrackingUrlParams("");
        eventSettings.clickSubmit();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-21834", firefoxIssue = "RA-51256")
    public void SessionCatalogUrlTracking() {
        //create Reg Code Category and get id
        regCodeCategoryCreation.navigate();
        regCodeCategoryCreation.createRegCodeCategory(regCodeCategory, initialRegCodeQuantity, regCodeCode);
        categoriesSearchPage.editRegCodeCategory(regCodeCategory);
        regCodeCategoryId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        //set event tracking params
        Utils.sleep(3000);
        eventData.waitForOrgVisible();
        eventData.clickEventSelect();
        eventSettings.clickOnCog();
        eventSettings.setTrackingUrlParams("platform, cid, soda[att], regcode[rc]");
        eventSettings.clickSubmit();

        //create reg code and get id
        regCodePage.navigate();
        regCodePage.createStandardRegCode(regCodeCode, regCodeCategory, initialRegCodeQuantity);
        regCodeSearchPage.editRegCode(regCodeCode);
        regCodeId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        NewWebPagePage.getPage().openUrlInNewTab(PageConfiguration.getPage().getCurrentUrl());
        sessionCatalog.navigateTrogdorAutomation(allTrackingUrl);
        PageConfiguration.getPage().justWait();
        signInAssertDemographicsAndOrderTabsDeleteReg(true);

        //update tracking url
        signOutAndNavigate(updatedFromURL);
        sessionCatalog.signIn(email, password);
        PageConfiguration.getPage().switchToTab(0);
        demoTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage(); //Refresh for firefox
        Assert.assertTrue(demoTab.assertTrackUrl(updateUrlAssert),"The platform was not applied");

        //Ensure when reg code is 0, it is not applied to the orders tab
        regCodePage.navigate();
        regCodePage.createStandardRegCode(regCodeCode, regCodeCategory, nextRegCodeQuantity);
        regCodeSearchPage.editRegCode(regCodeCode);
        regCodeId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        signOutAndNavigate(allTrackingUrl);
        signInAssertDemographicsAndOrderTabsDeleteReg(false);
        finished = true;
    }

    public void signOutAndNavigate(String url) {
        PageConfiguration.getPage().switchToTab(1);
        sessionCatalog.signOut();
        sessionCatalog.navigateTrogdorAutomation(url);
        PageConfiguration.getPage().justWait();
    }

    public void signInAssertDemographicsAndOrderTabsDeleteReg(boolean ordersTabAssert) {
        sessionCatalog.clearAllFilters();
        sessionCatalog.signIn(email, password);
        PageConfiguration.getPage().switchToTab(0);
        demoTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage(); //Refresh for firefox
        Assert.assertTrue(demoTab.assertTrackUrl(urlAssert), "The tracking url was not applied");

        ordersTab.navigate(attendeeId);
        if (ordersTabAssert) { //Reg Code should be applied
            Assert.assertTrue(ordersTab.verifyRegCode(regCodeCode), "The reg code was not applied");
            ordersTab.removeRegCode(regCodeCode);
            Assert.assertFalse(ordersTab.verifyRegCode(regCodeCode), "The reg code was not deleted");
        }
        else //Reg Code should not be applied
            Assert.assertFalse(ordersTab.verifyRegCode(regCodeCode), "The reg code was applied");

        //Delete reg code
        regCodeSearchPage.deleteRegCodeApi(regCodeId);
    }
}
