package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class FullSessionRecommendations {

    private String catalogJson;
    private String calendarJson;
    private String catalogWidgetUrl;
    private String calendarWidgetUrl;
    private boolean cleanUpCatalog = false;
    private boolean cleanUpCalendar = false;
    private String calendarUrl = PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorevent/settingsTestCalendar";
    private final String SESSION = "Recommended Session";
    private final String FULL_SESSION = "Full Recommended Session";
    private final String WAITLIST_SESSION = "Waitlisted Recommended Session";
    private final String ATTENDEE_ID = "1466442636522001ngrw";
    private final String CATALOG = "Settings Test Catalog";
    private final String CALENDAR = "Settings Test Calendar";
    private final String JSON_FALSE = "\"showFullSessionsInRecommendation\":false,";
    private final String JSON_TRUE = "\"showFullSessionsInRecommendation\":true,";
    private final String REGEX_JSON = "\"showFullSessionsInRecommendation\":(.*?),";

    private EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
    private CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
    private TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
    private EditWidgetPage config = EditWidgetPage.getPage();
    private WidgetSearchPage widgetSearch = WidgetSearchPage.getPage();

    @BeforeClass
    public void testSetup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");

        widgetSearch.navigate();
        widgetSearch.searchWidgets(CATALOG);
        widgetSearch.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Catalog"));
        catalogWidgetUrl = PageConfiguration.getPage().getCurrentUrl();
        catalogJson = config.getWidgetJson();
        config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_TRUE));
        config.saveWidgetConfig();

        widgetSearch.searchWidgets(CALENDAR);
        widgetSearch.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Calendar"));
        calendarWidgetUrl = PageConfiguration.getPage().getCurrentUrl();
        calendarJson = config.getWidgetJson();
        config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_TRUE));
        config.saveWidgetConfig();

        editAttendeePage.navigate(ATTENDEE_ID);
        editAttendeePage.spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);
    }

    @AfterClass
    public void testCleanup() {
        if(cleanUpCatalog) {
            widgetSearch.navigate();
            widgetSearch.searchWidgets(CATALOG);
            widgetSearch.editItem();
            Assert.assertEquals(catalogWidgetUrl, PageConfiguration.getPage().getCurrentUrl(), "Not on the correct widget page");
            config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_TRUE));
            config.saveWidgetConfig();
        }
        if(cleanUpCalendar) {
            widgetSearch.navigate();
            widgetSearch.searchWidgets(CALENDAR);
            widgetSearch.editItem();
            Assert.assertEquals(calendarWidgetUrl, PageConfiguration.getPage().getCurrentUrl(), "Not on the correct widget page");
            config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_TRUE));
            config.saveWidgetConfig();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-28215", firefoxIssue = "RA-37391")
    public void fullRecommendation() {
            catalog.filterCatalog(SESSION);
            String sessionId1 = catalog.getSessionId(FULL_SESSION);
            String sessionId2 = catalog.getSessionId(WAITLIST_SESSION);
            if(!catalog.isSessionFavorite(sessionId1)) {
                catalog.toggleFavorite(sessionId1);
            }
            if(!catalog.isSessionFavorite(sessionId2)) {
                catalog.toggleFavorite(sessionId2);
            }
        Assert.assertTrue(catalog.hasRecommendation(sessionId1), "Session is not recommended and should be");
        Assert.assertTrue(catalog.hasRecommendation(sessionId2), "Session is not recommended and should be");

        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(FULL_SESSION);
        Assert.assertTrue(catalog.hasRecommendation(sessionId1), "Session is not recommended and should be");
            calendar.closeSessionScheduleModal();

            calendar.clickFavoriteSession(WAITLIST_SESSION);
        Assert.assertTrue(catalog.hasRecommendation(sessionId2), "Session is not recommended and should be");

        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().navigateTo(catalogWidgetUrl);

            catalogJson = config.getWidgetJson();
            config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_FALSE));
            config.saveWidgetConfig();
            cleanUpCatalog = true;

            widgetSearch.searchWidgets(CALENDAR);
            widgetSearch.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Calendar"));
            calendarJson = config.getWidgetJson();
            config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_FALSE));
            config.saveWidgetConfig();
            cleanUpCalendar = true;

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();

        Assert.assertFalse(catalog.hasRecommendation(sessionId1), "Session is recommended and should not be");
        Assert.assertFalse(catalog.hasRecommendation(sessionId2), "Session is recommended and should not be");

        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(FULL_SESSION);
        Assert.assertFalse(catalog.hasRecommendation(sessionId1), "Session is recommended and should not be");
            calendar.closeSessionScheduleModal();

            calendar.clickFavoriteSession(WAITLIST_SESSION);
        Assert.assertFalse(catalog.hasRecommendation(sessionId2), "Session is recommended and should not be");
    }
}
