package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Unremovable {

    private String attendeeId;
    private AdminApp adminApp;
    private boolean cleanUp = false;
    private final String CATALOG = "Trogdor Catalog";
    private final String UNREMOVABLE = "unremovable";
    private final String SESSION1 = "Trogdor Unremovable MR";
    private final String SESSION2 = "Trogdor Unremovable Conflict MR";
    private final String ORDER = "Trogdor Full Conference Pass";
    private final String EVENTID = "155784956264steph902";
    private final String AGENDA_ID = "1570564148013001u6By";

    private final LegacyEventSettings event = LegacyEventSettings.getPage();
    private final AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
        event.navigate(EVENTID);
        event.setUnremovable(UNREMOVABLE);
        event.clickSubmit();
        attendeeId = adminApp.createAttendee();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage(ORDER);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void quit() {
        if(cleanUp) {
            event.navigate(EVENTID);
            event.setUnremovable(UNREMOVABLE);
            event.clickSubmit();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        orders.navigate(attendeeId);
        orders.deleteOrder(ORDER);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-36675", chromeIssue = "RA-22205")
    public void unremovableSession() {
        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);
        String catalogUrl = PageConfiguration.getPage().getCurrentUrl();

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog(UNREMOVABLE);
            String sessionId1 = catalog.getSessionId(SESSION1);
            String sessionId2 = catalog.getSessionId(SESSION2);

            catalog.toggleFavorite(sessionId1);
            catalog.toggleFavorite(sessionId2);

            catalog.scheduleSessionById(sessionId1, true);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was not scheduled");

            catalog.unscheduleUnremovable(sessionId1);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was unscheduled and should not have been");

            catalog.scheduleSessionById(sessionId2, true);
        Assert.assertTrue(catalog.schedulingNotAllowed(), SESSION2 + " should be displaying a schedule conflict error");
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " should not be scheduled");

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorevent/trogdorCalendar");
        String calendarUrl = PageConfiguration.getPage().getCurrentUrl();

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION1);

            catalog.unscheduleUnremovable(sessionId1);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was unscheduled and should not have been");

            calendar.closeSessionScheduleModal();
            calendar.clickFavoriteSession(SESSION2);

            catalog.scheduleSessionById(sessionId2, true);
        Assert.assertTrue(catalog.schedulingNotAllowed(), SESSION2 + " should be displaying a schedule conflict error");
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " should not be scheduled");
            calendar.closeSessionScheduleModal();

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorevent/" + AGENDA_ID);
        String agendaUrl = PageConfiguration.getPage().getCurrentUrl();

            catalog.unscheduleUnremovable(sessionId1);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was unscheduled and should not have been");

            catalog.scheduleSessionById(sessionId2, true);
        Assert.assertTrue(catalog.schedulingNotAllowed(), SESSION2 + " should be displaying a schedule conflict error");
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " should not be scheduled");

        PageConfiguration.getPage().switchToTab(0);
            event.navigate(EVENTID);
            event.setUnremovable(UNREMOVABLE + "1");
            event.clickSubmit();
            cleanUp = true;

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().navigateTo(catalogUrl);
            catalog.filterCatalog(UNREMOVABLE);

            catalog.scheduleSessionById(sessionId1, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId1), SESSION1 + " is still scheduled and should not be");

        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION1);

            catalog.scheduleSessionById(sessionId1, true);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was not scheduled");
            catalog.scheduleSessionById(sessionId1, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId1), SESSION1 + " is still scheduled and should not be");

        PageConfiguration.getPage().navigateTo(agendaUrl);

            catalog.scheduleSessionById(sessionId1, true);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " was not scheduled");
            catalog.scheduleSessionById(sessionId1, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId1), SESSION1 + " is still scheduled and should not be");
    }
}
