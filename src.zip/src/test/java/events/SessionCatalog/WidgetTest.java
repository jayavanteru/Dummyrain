package events.SessionCatalog;

import apps.PageConfiguration;
import apps.events.EventsApp;
import apps.events.eventsPageObjects.WidgetPage;
import configuration.PropertyReader;
import interaction.DriverManager;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import testHelp.Utils;

public class WidgetTest {

    static EventsApp eventsApp;
    String env = PropertyReader.instance().getProperty("env");

    @BeforeClass
    public void setup() {
        eventsApp = new EventsApp();
    }

    @AfterClass
    public void stopTest() {
        PageConfiguration.getPage().quit();
    }

    @BeforeMethod
    public void clearCookies() {
        eventsApp.clearCookies();
    }

    protected WidgetPage getPage(String eventName) {
        eventsApp.setEventName(eventName);
        return eventsApp.getWidgetPage();
    }

    protected void switchToMobile(WidgetPage page) {
        DriverManager.getWebDriver(Thread.currentThread().getName()).toMobileSize();
        Utils.sleep(100);
        page.expandForMobile();
    }

    //-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~ Parameters ~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-~-
    @DataProvider(name = "catalogs")
    public Object[][] filterData() {
        return new Object[][]{
                //{"Oracle_SW"}, {"Oracle_MBX"},
                //{"Blue_Yonder_Icon21"},
                //{"Oracle_MCX"}, {"Oracle_OOW"}, {"Oracle_CodeOne"},
                //{"SuseCon"}, {"Adobe_Max"},
                {"CL_GLOBAL"},
                // commenting this out until beginning of May 2021 because of vanity url for adobe event testing
                //{"Adobe_Summit21"},
                {"Splunk_Global"}, //{"Emerson_Exchange"},
             //   {"Informatica_World21"},
                //{"Emerson_EMEA21"}, {"NetApp_Insight"},
                //{"Nvidia_GTC"}, {"Doterra_LR20"}, {"Fiserv_Forum20"}
                {"CL_EMEAR22"}
//                {"Oracle_SW20"}, {"Oracle_MBX20"}, {"SuseCon20"},{"Adobe_Max20"},{"CL_Online20"},{"Splunk_SKO20"}, {"Splunk_OnDemand20"},{"Emerson_Global20"},
//                {"VMware_Empower_AMS"},{"VMware_Empower_APJ"},{"VMware_Empower_EMEA"}, {"CL_US"}, {"RSA_APJ"}, {"PaloAlto_Europe"},
        };
    }

    @DataProvider(name = "catalogDetails")
    public Object[][] catalogDetails() {
        return new Object[][]{{"CL_GLOBAL"}};
    }

    @DataProvider(name = "api")
    public Object[][] apiData() {
        if (env.equals("dev") || env.isEmpty()) {
            return new Object[][]{

            };
        } else {
            return new Object[0][0];
        }
    }

    @DataProvider(name = "prodCatalog")
    public Object[][] prodUrls() {
        if (PropertyReader.instance().getProperty("env").isEmpty()) {
            return new Object[][]{
                    {"https://www.ciscolive.com/anz/dcid1_agenda/"},
                    {"https://www.ciscolive.com/anz/dcid2_agenda/"},
                    {"https://www.ciscolive.com/anz/learn/programs/it-management-program/agenda/"},
                    {"https://www.ciscolive.com/anz/exec_symposium_agenda/"},
                    {"https://www.ciscolive.com/anz/cid-agenda/"},
                    {"https://www.ciscolive.com/anz/enid-agenda/"},
                    {"https://www.ciscolive.com/anz/wtts-agenda/"}
            };
        } else {
            return new Object[0][0];
        }
    }
}
