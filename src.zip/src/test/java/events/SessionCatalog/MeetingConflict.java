package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MeetingConflict {

    private final String NEW_TIME = "09:00 AM";
    private final String NAME = "Trogdor Meeting";
    private final String EMAIL = "trogdormeeting@rainfocus.com";
    private final String CATALOG = "2019catalog";
    private final String MEETING_CONFLICT = "BR1072";
    private final String SESSION = "BR1026";

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-37444", chromeIssue = "RA-23849")
    public void meetingConflict() {
        SessionSearchPage search = SessionSearchPage.getPage();
            search.navigate();
            search.searchFor(SESSION);
            search.editItem();

        EditSessionPage sessionEdit = EditSessionPage.getPage();
            sessionEdit.scheduleTab();
            sessionEdit.openSessionEdit();
            sessionEdit.editScheduleTime(NEW_TIME);
            sessionEdit.saveScheduleEdit();
            sessionEdit.clickOneAttendees(NAME, EMAIL);
            sessionEdit.closeFinalizeModal();

        AttendeeSearchPage attendeeSearch = AttendeeSearchPage.getPage();
            attendeeSearch.navigate();
            attendeeSearch.searchFor(EMAIL);
            attendeeSearch.clickResult(0);

        EditAttendeePage edit = EditAttendeePage.getPage();
            edit.spoofToWidget(CATALOG);

        PageConfiguration.getPage().switchToTab(1);
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog(MEETING_CONFLICT);
        Assert.assertTrue(catalog.scheduleMeetingConflict(), "There was not a meeting conflict and there should be");
    }
}
