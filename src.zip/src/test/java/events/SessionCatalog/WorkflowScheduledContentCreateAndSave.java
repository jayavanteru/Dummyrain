package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.workflows.NewPagesSearchPage;
import apps.workflows.workflowsPageObjects.PageBuilder;
import logs.ReportingInfo;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class WorkflowScheduledContentCreateAndSave {
    private String pageId = "1643824767870001CX5Z";


    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");


}

    @AfterTest
    public void cleanUp() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.PBJ})
    @ReportingInfo(chromeIssue = "RA-52865", firefoxIssue = "RA-53388")
    public void scheduledContentCreateAndSave() {

// goes to workflow > pages
        NewPagesSearchPage.getPage().navigateById(pageId);
        PageBuilder pageBuilder = PageBuilder.getPage();

        //adds headline to page and schedules content
        pageBuilder.addContent();
        pageBuilder.headline();
        pageBuilder.header2();
        pageBuilder.headlineContent();
        pageBuilder.justWait();
        pageBuilder.floatingSection();
        pageBuilder.justWait();
        pageBuilder.scheduledContent();
        pageBuilder.addContentButton();
        pageBuilder.contentName();
        pageBuilder.setPublishDate();
        pageBuilder.setPublishTime();
        pageBuilder.addContentIcon();
        pageBuilder.sessionList();
        pageBuilder.saveContent();
        pageBuilder.done();

        //deletes content
        pageBuilder.floatingSection();
        pageBuilder.justWait();
        pageBuilder.deleteContent();



    }
}


