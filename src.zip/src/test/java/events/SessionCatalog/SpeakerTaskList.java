package events.SessionCatalog;

import admin.Registration.UploadFile;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.libraries.EditTaskPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import apps.admin.adminPageObjects.registration.*;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.DashboardFilter;
import apps.workflows.workflowsPageObjects.TaskPage;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.NewSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;

public class SpeakerTaskList {
    private AdminApp adminApp;
    private String attendeeId;
    private String attendeeId2;
    private DataGenerator dataGenerator = new DataGenerator();
    private String sessionId;
    private String attendeeEmail;
    private String secondAttendeeEmail;
    public ArrayList<String> ExpectedFilters = new ArrayList<>();
    private String Option = "1 DON'T DELETE - Session File Upload Task";
    private String Option2 = "2 Copy Edit";

    @BeforeClass
    public void login() {
        adminApp = new AdminApp();
        attendeeEmail = dataGenerator.generateEmail();
        secondAttendeeEmail = dataGenerator.generateEmail();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        attendeeId = adminApp.createAttendee(attendeeEmail);
        attendeeId2 = adminApp.createAttendee(secondAttendeeEmail);
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().orderPackageForFree("Full Conference Pass Automation");
        sessionId = adminApp.createSession();
        EditSessionPage.getPage().setSessionStatus("On Hold");
        ExpectedFilters.add("Incomplete");
    }

    @AfterClass
    public void quit() throws Exception {
        adminApp.deleteSession(sessionId);
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteAttendee(attendeeId2);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-35845", firefoxIssue = "RA-53169")
    public void speakerTaskList() {
        TasksSearchPage tasksSearchPage = TasksSearchPage.getPage();
        tasksSearchPage.navigate();
        tasksSearchPage.search("Don't Delete");
        tasksSearchPage.select("Session File Upload Task");
        EditTaskPage editTaskPage = EditTaskPage.getPage();
        editTaskPage.setDueDate(DateTime.now());
        editTaskPage.submit();

        //goes to create a session
        AdminSessionParticipantsTab adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
        adminSessionParticipantsTab.navigate(sessionId);
        adminSessionParticipantsTab.clickAddParticipantButton();
        adminSessionParticipantsTab.searchExistingParticipant(attendeeEmail);
        adminSessionParticipantsTab.setParticipantRole("Speaker");
        adminSessionParticipantsTab.setCompany(dataGenerator.generateString());
        adminSessionParticipantsTab.submitAddParticipant();
        adminSessionParticipantsTab.clickAddParticipantButton();
        adminSessionParticipantsTab.searchExistingParticipant(secondAttendeeEmail);
        adminSessionParticipantsTab.setCompany(dataGenerator.generateString());
        adminSessionParticipantsTab.setParticipantRole("Copy Editor");
        adminSessionParticipantsTab.submitAddParticipant();
        //goes to demographics tab
        AdminDemographicsTab adminDemographicsTab = AdminDemographicsTab.getPage();
        adminDemographicsTab.navigate(sessionId);
        adminDemographicsTab.selectCheckbox("File Review Qualifier");
        adminDemographicsTab.submit();

        //spoofs to speaker portal and click anywhere on Speaker Tasks card
        EditAttendeePage editAttendeePage = new EditAttendeePage();
        editAttendeePage.navigate(attendeeId);
        editAttendeePage.waitForPageLoad();
        editAttendeePage.spoofTo("speakerPortal");
        Dashboard.getPage().clickIncompleteTasks();

        //Adds incomplete filter from drop down and clears filter
        String status = "Incomplete";
        TaskPage taskPage = TaskPage.getPage();
        taskPage.waitForPageLoad();
        taskPage.filterBy(status);
        Assert.assertTrue(taskPage.incompleteTasks() > 0);
        taskPage.clearFilter(status);
        ArrayList<String> actualFilters = new ArrayList<>();
        actualFilters = taskPage.GetsFilters();
        Assert.assertEquals(actualFilters, ExpectedFilters, "Filters do not match");

        //Clicks on view as single list and then clears filter
        taskPage.setVIEW_AS_SINGLE_LIST_CHECK_BOX();
        taskPage.setUNCHECK_VIEW_AS_SINGLE_LIST_CHECK_BOX();

//        //clicks Show only unread comments
//        taskPage.filterBy(status);
//        Assert.assertTrue(Boolean.parseBoolean("taskPage.showOnlyUnreadComments"));
//        taskPage.clearFilter(status);

        //Clicks on "DON'T DELETE- session file upload task", upload file and leaves comment
//        Assert.assertTrue(Boolean.parseBoolean("NoticeIncompleteBadge"));
        String option = "1 DON'T DELETE - Session File Upload Task";
        taskPage.setSESSION_TASK();
        taskPage.waitForPageLoad();
        taskPage.uploadFileSpeakerPortal();
        taskPage.clickSubmit();
        PageConfiguration.getPage().justWait();
        taskPage.clickAddComment();
        taskPage.addComment();
        taskPage.clickReturnTaskList();

        //filters list by in review
//        taskPage.inReview();

        //Goes to Attendee set as copy editor, spoofs into speaker portal
        AdminAttendeeFilesPage.getPage().navigate(attendeeId2);
        editAttendeePage.waitForPageLoad();
        editAttendeePage.spoofTo("speakerPortal");

//        Assert.assertTrue(Boolean.parseBoolean("Notice In Review Badge"));
//        Assert.assertTrue(Boolean.parseBoolean("Notice Unread Comments"));

        //Selects task that needs review
        Dashboard.getPage().clickIncompleteTasks();
        taskPage.waitForPageLoad();
        String Option2 = "2 Copy Edit";
        taskPage.copyEditFile();
        taskPage.clickAddComment();
        taskPage.addComment();

//        goes back to task list and selects need review
        String status2 = "Needs Review";
        taskPage.clickReturnTaskList();
        taskPage.filterBy(status2);
        taskPage.NeedsReview();


        //in filter dropdown select Revision Requested
//        taskPage.filterBy(status);
//        taskPage.setInReview();
//        Assert.assertTrue(Boolean.parseBoolean("Revision Requested"));

        //Return to Attendee set as Speaker and spoof to speaker portal
        AdminAttendeeFilesPage.getPage().navigate(attendeeId);
        editAttendeePage.waitForPageLoad();
        editAttendeePage.spoofTo("speakerPortal");

        //Click on task and upload another file
        Dashboard.getPage().clickIncompleteTasks();

        taskPage.setSESSION_TASK();
        taskPage.waitForPageLoad();
        taskPage.uploadFileSpeakerPortal();
        taskPage.clickSubmit();

//spoof back into attendee set as copy editor
        AdminAttendeeFilesPage.getPage().navigate(attendeeId2);
        editAttendeePage.waitForPageLoad();
        editAttendeePage.spoofTo("speakerPortal");
        Dashboard.getPage().clickIncompleteTasks();
        taskPage.filterBy(status2);
        taskPage.NeedsReview();
        taskPage.copyEditFile();
        taskPage.clickApprove();




        //on task list page select Complete and uncheck show completed checkbox
        String status3 = "Complete";
        taskPage.clickReturnTaskList();
        taskPage.filterBy(status3);
//        Assert.assertTrue(Boolean.parseBoolean("Complete"));
        taskPage.clearFilter("Complete");
        taskPage.showCompletedBox();

        //returns to session edit page and removes participants
        AdminSessionParticipantsTab.getPage();
        adminSessionParticipantsTab.navigate(sessionId);
        adminSessionParticipantsTab.deleteParticipantById(attendeeId);
        adminSessionParticipantsTab.deleteParticipantById(attendeeId2);

    }
}
