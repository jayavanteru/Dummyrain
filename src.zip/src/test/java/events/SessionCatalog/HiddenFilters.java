package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeDemographicsTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HiddenFilters {

    private AdminApp adminApp;
    private String attendeeId;
    private boolean cleanUp = false;
    protected final String EMAIL = "multipleattendeetype@rainfocus.com";
    protected final String PASSWORD = "Rainfocus123@";
    protected final String FILTER = "Session Technology";

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
    }

    @AfterClass
    public void tearDown() {
        if(cleanUp) {
            PageConfiguration.getPage().navigateTo(adminApp.getHost());
            adminApp.deleteAttendee(attendeeId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25599", chromeIssue = "RA-33350")
    public void HiddenFilters() {
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.navigateTrogdorEvent("settingsTestCatalog");
        Assert.assertFalse(catalog.isFilterOnPage(FILTER), "The " + FILTER + " filter is on the catalog and should not be");
            catalog.signIn(EMAIL, PASSWORD);
        Assert.assertTrue(catalog.isFilterOnPage(FILTER), "The " + FILTER + " filter is not on the catalog");
            catalog.signOut();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        attendeeId = adminApp.createAttendee();
        cleanUp = true;

        AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();
            orders.navigate(attendeeId);
            orders.addOrder();
            orders.selectPackage("Trogdor Full Conference Pass");
            orders.clickNextOnAddOrderModal();
            orders.setComment("Test");
            orders.submitOrder();

        EditAttendeePage.getPage().spoofToWidget("Settings Test Catalog");
        Assert.assertFalse(catalog.isFilterOnPage(FILTER), "The " + FILTER + " filter is on the catalog and should not be");

        PageConfiguration.getPage().switchToTab(0);

        AdminAttendeeDemographicsTab demographics = AdminAttendeeDemographicsTab.getPage();
            demographics.navigate(attendeeId);
            demographics.selectCheckbox("Employee");
            demographics.attendeesubmit();

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();

        Assert.assertTrue(catalog.isFilterOnPage(FILTER), "The " + FILTER + " filter is not on the catalog");
    }
}
