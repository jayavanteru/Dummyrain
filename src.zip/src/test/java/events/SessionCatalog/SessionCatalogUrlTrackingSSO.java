package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewWebPagePage;
import apps.admin.adminPageObjects.registration.*;
import apps.events.eventsPageObjects.CiscoLoginPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import configuration.PropertyReader;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class SessionCatalogUrlTrackingSSO {
    DataGenerator dataGenerator = new DataGenerator();
    RegCodeSearchPage regCodeSearchPage;
    RegCodeCategoriesSearchPage categoriesSearchPage;
    AdminAttendeeOrdersTab ordersTab;
    OrgEventData eventData;
    LegacyEventSettings eventSettings;
    AdminAttendeeDemographicsTab demoTab;
    NewRegCodePage regCodePage;
    TrogdorSessionCatalog sessionCatalog;

    private String regCodeId;

    public final String regCodeCategory = "Event Staff";
    public final String attendeeId = "15120859266120019tDU";
    public final String email = "wayne.woodfield@rainfocus.com";
    public final String password = "zD3710e5gm";
    private final String regCodeCode = "TMR" + dataGenerator.generateString(7);
    private final String initialRegCodeQuantity = "1";
    private final String src = "hello";
    private final String intsrc = "world";
    private final String urlAssert = "intsrc="+intsrc+"&src="+src+"&regcode="+regCodeCode;
    private final String updatedFromUrlString = "updatedfromurl";
    private final String updateUrlAssert = "src="+updatedFromUrlString;
    private final String allTrackingUrl = PropertyReader.instance().getProperty("eventsUrl")+"/widget/cisco/clus19/clus19catalog?regcode="+regCodeCode+"&src="+src+"&intsrc="+intsrc;
    private final String updatedFromURL = PropertyReader.instance().getProperty("eventsUrl")+"/widget/cisco/clus19/clus19catalog?src="+updatedFromUrlString;


    private boolean finished = false;

    @BeforeClass
    public void setup() {
        regCodeSearchPage = RegCodeSearchPage.getPage();
        categoriesSearchPage = RegCodeCategoriesSearchPage.getPage();
        ordersTab = AdminAttendeeOrdersTab.getPage();
        eventData = OrgEventData.getPage();
        eventSettings = LegacyEventSettings.getPage();
        demoTab = AdminAttendeeDemographicsTab.getPage();
        regCodePage = NewRegCodePage.getPage();
        sessionCatalog = TrogdorSessionCatalog.getPage();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("Cisco", "Cisco Live US 2019");

        demoTab.navigate(attendeeId);
        demoTab.checkTrackingURL();
    }

    @AfterClass
    public void teardown() {
        if (!finished)
            regCodeSearchPage.deleteRegCodeApi(regCodeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-21993", firefoxIssue = "RA-51570")
    public void SessionCatalogUrlTrackingSSO() {
        //set event tracking params
        Utils.sleep(3000);
        eventData.waitForOrgVisible();
        eventData.clickEventSelect();
        eventSettings.clickOnCog();
        eventSettings.setTrackingUrlParams("src, regcode[rc], intsrc[att]");
        eventSettings.clickSubmit();

        //create reg code and get id
        regCodePage.navigate();
        regCodePage.createStandardRegCode(regCodeCode, regCodeCategory, initialRegCodeQuantity);
        regCodeSearchPage.editRegCode(regCodeCode);
        regCodeId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        //set tracking urls
        NewWebPagePage.getPage().openUrlInNewTab(PageConfiguration.getPage().getCurrentUrl());
        PageConfiguration.getPage().navigateTo(allTrackingUrl);
        PageConfiguration.getPage().justWait();
        sessionCatalog.clearAllFilters();
        sessionCatalog.clickSignInForSSO();
        CiscoLoginPage.getPage().loginWithSSO(email, password);
        PageConfiguration.getPage().justWait();
        sessionCatalog.signOut();

        PageConfiguration.getPage().switchToTab(0);
        demoTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage(); //Refresh for firefox
        Assert.assertTrue(demoTab.assertTrackUrl(urlAssert), "The tracking url was not applied");

        ordersTab.navigate(attendeeId);
        Assert.assertTrue(ordersTab.verifyRegCode(regCodeCode), "The reg code was not applied");
        ordersTab.removeRegCode(regCodeCode);
        Assert.assertFalse(ordersTab.verifyRegCode(regCodeCode), "The reg code was not deleted");

        //update tracking url
        NavigateToUrl(updatedFromURL);
        sessionCatalog.clickSignInForSSO();
        CiscoLoginPage.getPage().loginWithSSO(email, password);
        PageConfiguration.getPage().justWait();
        PageConfiguration.getPage().switchToTab(0);
        demoTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage(); //Refresh for firefox
        Assert.assertTrue(demoTab.assertTrackUrl(updateUrlAssert),"The src was not applied");
        finished = true;
        regCodeSearchPage.deleteRegCodeApi(regCodeId);
    }

    public void NavigateToUrl(String url) {
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().navigateTo(url);
        PageConfiguration.getPage().justWait();
    }
}
