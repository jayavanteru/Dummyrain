package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class DoublebookableSession {

    private String attendeeId;
    private AdminApp adminApp;
    private boolean cleanUp = false;
    private final String CATALOG = "Trogdor Catalog";
    private final String DOUBLEBOOK = "doublebook";
    private final String SESSION1 = "Trogdor Doublebook MR";
    private final String SESSION2 = "Trogdor Schedule Doublebook MR";
    private final String ORDER = "Trogdor Full Conference Pass";
    private final String EVENTID = "155784956264steph902";
    private final String EVENTSURL = PageConfiguration.getPage().getData("eventsUrl");
    private final String WIDGETID = "s8WWZFlGrtipbxWBOSj40UxNimZGpWYo";
    private final String APIPROFILEID = "y66CKcICv02PyVhUv3jhaMFfWOxvxzic";
    private final String AGENDA_ID = "1570564148013001u6By";

    private final LegacyEventSettings event = LegacyEventSettings.getPage();
    private final AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        NavigationBar.getPage().collapse();
        event.navigate(EVENTID);
        event.setDoubleBookable(DOUBLEBOOK);
        event.clickSubmit();
        attendeeId = adminApp.createAttendee();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage(ORDER);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
    }

    @AfterClass
    public void quit() {
        if(cleanUp) {
            event.navigate(EVENTID);
            event.setDoubleBookable(DOUBLEBOOK);
            event.clickSubmit();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        orders.navigate(attendeeId);
        orders.deleteOrder(ORDER);
        orders.submitOrder();
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-36609", chromeIssue = "RA-22206")
    public void doublebooking() {
        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
        String catalogUrl = PageConfiguration.getPage().getCurrentUrl();
        PageConfiguration.getPage().justWait();
            catalog.filterCatalog(DOUBLEBOOK);
            String sessionId1 = catalog.getSessionId(SESSION1);
            String sessionId2 = catalog.getSessionId(SESSION2);

            catalog.toggleFavorite(sessionId1);
            catalog.toggleFavorite(sessionId2);

            catalog.scheduleSessionById(sessionId1, true);
            catalog.scheduleSessionById(sessionId2, true);

        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " Session was not scheduled");
        Assert.assertTrue(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not scheduled");

            catalog.scheduleSessionById(sessionId2, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not unscheduled");

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorevent/trogdorCalendar");
        String calendarUrl = PageConfiguration.getPage().getCurrentUrl();

        CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION2);

            catalog.scheduleSessionById(sessionId2, true);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not scheduled");

            catalog.scheduleSessionById(sessionId2, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not unscheduled");
            calendar.closeSessionScheduleModal();

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorevent/" + AGENDA_ID);
        String agendaUrl = PageConfiguration.getPage().getCurrentUrl();

            catalog.scheduleSessionById(sessionId2, true);
        Assert.assertTrue(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not scheduled");

            catalog.scheduleSessionById(sessionId2, false);
        Assert.assertFalse(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not unscheduled");

            PageConfiguration.getPage().switchToTab(0);
            event.navigate(EVENTID);
            event.setDoubleBookable(DOUBLEBOOK + "1");
            event.clickSubmit();
            cleanUp = true;

            PageConfiguration.getPage().switchToTab(1);
            PageConfiguration.getPage().navigateTo(catalogUrl);
            PageConfiguration.getPage().justWait();

            catalog.filterCatalog(DOUBLEBOOK);
            Utils.waitForTrue(()->{
                PageConfiguration.getPage().refreshPage();
                return catalog.hasScheduleConflict(sessionId2);
            });
            if(!catalog.isFacetPillOnPage(DOUBLEBOOK)) {
                catalog.filterCatalog(DOUBLEBOOK);
            }
            if(!catalog.scheduleButtonConflict(sessionId2)) {
                PageConfiguration.getPage().navigateTo(EVENTSURL + "/api/elasticSessionLoad?rfWidgetId=" + WIDGETID + "&rfApiProfileId=" + APIPROFILEID + "&forceReindex=true");
                PageConfiguration.getPage().waitForPageLoad();
                PageConfiguration.getPage().navigateBack();
                PageConfiguration.getPage().refreshPage();
                catalog.scheduleButtonConflict(sessionId2);
            }
            catalog.doublebookableConflict();
        Assert.assertTrue(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not scheduled");
        Assert.assertFalse(catalog.isSessionScheduled(sessionId1), SESSION1 + " is scheduled and should not be");

            PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION1);

            catalog.scheduleButtonConflict(sessionId1);
            catalog.doublebookableConflict();
        Assert.assertTrue(catalog.isSessionScheduled(sessionId1), SESSION1 + " Session was not scheduled");

            PageConfiguration.getPage().navigateTo(agendaUrl);

            catalog.scheduleButtonConflict(sessionId2);
            catalog.doublebookableConflict();
        Assert.assertTrue(catalog.isSessionScheduled(sessionId2), SESSION2 + " Session was not scheduled");
        Assert.assertFalse(catalog.isSessionScheduled(sessionId1), SESSION1 + " is scheduled and should not be");
    }
}
