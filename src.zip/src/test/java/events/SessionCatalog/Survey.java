package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.forms.Form;
import apps.workflows.workflowsPageObjects.SurveyPage;
import configuration.PropertyReader;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;

public class Survey {

    private AdminApp adminApp;
    private DataGenerator generator;
    private String email;
    private String attendeeId;
    private String surveyId = PropertyReader.instance().getProperty("surveyId");

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        generator = new DataGenerator();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @BeforeMethod
    public void create() {
        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(2000);
    }

    @AfterMethod
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
//        adminApp.deleteForm(surveyId);
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

//    @Test
    public void takeSurvey() {
        String surveyName = generator.generateString(5) + "automation";
        String catalog = "Constellation Session SessionCatalog";
        String completedMsg = generator.generateString();
        Form form = adminApp.setupSurvey(surveyName, completedMsg, surveyId, email);

        Utils.sleep(500, "wait for the survey to save");
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.selectPackage("Approval Package");
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.placeOrder();

        Utils.sleep(500);
        EditAttendeePage.getPage().spoofToWidget(catalog);

        Utils.sleep(1000);
        String url = PageConfiguration.getPage().getCurrentUrl();
        String env = PropertyReader.instance().getProperty("env");
        PageConfiguration.getPage().navigateTo(url + "?testEnv="+env+"#surveys");
        Utils.sleep(500);

        SurveyPage surveyPage = SurveyPage.getPage();
        ArrayList<String> surveys = surveyPage.getAvailableSurveys();
        Assert.assertTrue(surveys.contains(surveyName), "did not find the survey '"+surveyName+"' in the list of available surveys");
        surveys = surveyPage.getCompletedSurveys();
        Assert.assertFalse(surveys.contains(surveyName), "found the survey '"+surveyName+"' in the list of completed surveys, not completed yet");

        //take the survey
        surveyPage.openSurvey(surveyName);
        Utils.sleep(2000, "for the survey iframe to load");
        String actualCompleteMsg = surveyPage.fillOutSurvey(form, completedMsg);
        Assert.assertEquals(actualCompleteMsg, completedMsg, "did not find the expected thank you message");
        surveyPage.closeSurveyModal();

        surveys = surveyPage.getAvailableSurveys();
        Assert.assertFalse(surveys.contains(surveyName), "found the survey '"+surveyName+"' in the list of available surveys, should be completed");
        surveys = surveyPage.getCompletedSurveys();
        Assert.assertTrue(surveys.contains(surveyName), "did not find the survey '"+surveyName+"' in the list of completed surveys");
    }
}
