package events.SessionCatalog;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.WidgetPage;
import apps.events.eventsPageObjects.WidgetSessionDetailsPage;
import logs.ReportingInfo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.List;

public class OpenDetails extends WidgetTest {

    @Test(dataProvider = "catalogDetails", groups = {"prodTest", ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25850", chromeIssue = "RA-25851")
    public void openDetailsTest(String eventName) {
        WidgetPage page = getPage(eventName);

        List<WebElement> dismiss = PageConfiguration.getPage().getBrowser().findElements(By.className("evidon-banner-acceptbutton"));
        if (dismiss.size() > 0) dismiss.get(0).click();

        String url = PageConfiguration.getPage().getCurrentUrl();
        page.clickLastSession();
        Assert.assertTrue(Utils.waitForTrue(()->!PageConfiguration.getPage().getCurrentUrl().equals(url)),
                "page did not change after clicking on the session");
        Assert.assertNotNull(WidgetSessionDetailsPage.getPage().getDescription(), "no session description found on page");
        Assert.assertEquals(PageConfiguration.getPage().getYScrollPosition(), 0, "scroll should be at the top of the page");
    }
}
