package events.SessionCatalog;

import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.MyJson;

public class LoadingData extends WidgetTest {

    @Test(dataProvider = "catalogs", groups = {"prodTest", ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25854", chromeIssue = "RA-25856")
    public void catalogLoadingData(String eventName) {
//        String rfWidgetId = PropertyReader.instance().getProperty(eventName + "-widgetId");
//        String rfApiProfileId= PropertyReader.instance().getProperty(eventName + "-apiProfileId");
//        eventsApp.post("/api/elasticSpeakerLoad?rfWidgetId=" + rfWidgetId + "&rfApiProfileId=" + rfApiProfileId + "&forceReindex=true");
//        eventsApp.post("/api/elasticSessionLoad?rfWidgetId=" + rfWidgetId + "&rfApiProfileId=" + rfApiProfileId + "&forceReindex=true");

        String widgetId = PropertyReader.instance().getProperty(eventName + "-widgetId");
        String apiProfileId = PropertyReader.instance().getProperty(eventName + "-apiProfileId");
        JSONObject params = new JSONObject();
        MyJson.put(params, "rfWidgetId", widgetId);
        MyJson.put(params, "rfApiProfileId", apiProfileId);
        MyJson.put(params, "type", "session");

        Log.debugEnabled = false;
        JSONObject catalogList = eventsApp.postAsUrlParams("/api/search", params);
        Log.debugEnabled = true;

        //verify there is more than 0 items
        JSONArray sectionList = MyJson.getJSONArray(catalogList, "sectionList");
        Assert.assertTrue(sectionList.length() > 0, "there should be at least one section. length is " + sectionList.length());

        JSONObject section = MyJson.getJSONObject(sectionList, 0);
        Assert.assertTrue(MyJson.getInt(section, "total") > 0, "the total should be at least one. total is " + MyJson.getInt(section, "total"));
        int numItems = MyJson.getInt(section, "numItems");
        Assert.assertTrue(numItems > 0, "the size should be atleast one. size is " + numItems);

        JSONArray items = MyJson.getJSONArray(section, "items");
        Assert.assertTrue(items.length() > 0, "there should be at least 1 item in the catalog");
        Assert.assertEquals(items.length(), numItems,"number of items should match the size for the section");
    }
}
