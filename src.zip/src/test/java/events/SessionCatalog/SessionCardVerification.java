package events.SessionCatalog;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SessionCardVerification {

  TrogdorSessionCatalog catalog;
  protected final String trystanAttendeeId = "1569962939584001h1GX";

  @BeforeClass
  public void setUp() {
    PageConfiguration.getPage().navigateTo(PropertyReader.instance().getProperty("eventsUrl") + "/widget/rainfocus/trogdorauto/TrogdorSeleniumSessionCatalog?");
    catalog = TrogdorSessionCatalog.getPage();
    catalog.signIn("carolyn.baird@rainfocus.com", "RainFocus123@");
    catalog.clickCookieConsent();
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-42662", chromeIssue = "RA-19904")
  public void cardVerification() {
    int initialCount = catalog.getSessionCardCount();
    catalog.showMore();
    int moreCount = catalog.getSessionCardCount();
    Assert.assertTrue(initialCount < moreCount, "There should be more sessions in the list after show more is clicked");

    String appleSearch = "Apple";
    catalog.filterCatalog(appleSearch);
    Assert.assertEquals(1, catalog.getSessionCardCount(), "Should have 1 session for Apple");
    Assert.assertTrue(catalog.isFacetPillOnPage(appleSearch), "Should show pill for Apple search");

    String sessionId = catalog.getSessionId(appleSearch);
    Assert.assertFalse(catalog.hasAbstractBySessionId(sessionId), "Abstract should not be on collapsed view");
    catalog.expandSessionDetails(sessionId, false);
    Assert.assertTrue(catalog.hasAbstractBySessionId(sessionId), "Abstract should be on expanded view");

    catalog.openSpeakerModal(sessionId);
    Assert.assertTrue(catalog.hasPhotoInSpeakerModal(), "Should have photo in speaker modal");
    Assert.assertTrue(catalog.hasFullNameInSpeakerModal(), "Should have full name in speaker modal");
    Assert.assertTrue(catalog.hasBioInSpeakerModal(), "Should have bio in speaker modal");
    Assert.assertTrue(catalog.hasCompanyAndJobTitleInSpeakerModal(), "Should have company and job title in speaker modal");

    String name = "Trystan Barajas";
    Assert.assertEquals(name, catalog.seeAllSessionWithThisSpeaker(), "Should have Trystan Barajas as search term");
    Assert.assertEquals(2, catalog.getSessionCardCount(), "Should have two sessions with Trystan on them");
  }
}
