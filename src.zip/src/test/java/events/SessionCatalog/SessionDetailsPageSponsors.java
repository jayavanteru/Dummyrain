package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.events.eventsPageObjects.WidgetExhibitorDetailsPage;
import apps.events.eventsPageObjects.WidgetSessionDetailsPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.Arrays;
import java.util.List;

import static org.testng.Assert.*;

public class SessionDetailsPageSponsors
{
  private DataGenerator generator = new DataGenerator();
  private AdminApp adminApp = new AdminApp();

  private EditSessionPage editSessionPage;
  private TrogdorSessionCatalog sessionCatalog;
  private WidgetSessionDetailsPage sessionDetailsPage;
  private WidgetExhibitorDetailsPage exhibitorDetailsPage;
  private PageConfiguration pageConfiguration;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

    editSessionPage = EditSessionPage.getPage();
    sessionCatalog = TrogdorSessionCatalog.getPage();
    sessionDetailsPage = WidgetSessionDetailsPage.getPage();
    exhibitorDetailsPage = WidgetExhibitorDetailsPage.getPage();
    pageConfiguration = PageConfiguration.getPage();
  }

  @AfterClass
  public void delete() {
    pageConfiguration.quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-38259", firefoxIssue = "RA-43124")
  public void VerifySessionDetailsPageSponsors()
  {
    String sessionCatalogUri = "trogdorseleniumsessiondetailscatalog";
    String exhibitorCatalogUri = "trogdorseleniumexhibitordetailscatalog";

    String sessionId = "16138281378120018KCK";
    String sessionSearchText = "\"Session Details Test Session\" 1055";

    String acuity = "Acuity";
    String burnsAndMcDonnell = "Burns & McDonnell";
    String edwardJones = "Edward Jones";

    verifyExhibitorsSetInAdminShowUpOnSessionDetailsPage(sessionCatalogUri, sessionId, sessionSearchText, Arrays.asList(acuity, burnsAndMcDonnell, edwardJones));
    verifyExhibitorsSetInAdminShowUpOnSessionDetailsPage(sessionCatalogUri, sessionId, sessionSearchText, Arrays.asList(acuity, burnsAndMcDonnell));

    sessionDetailsPage.hoverTitle(); // Moves focus away from session card
    assertTrue(sessionDetailsPage.firstExhibitorNameIsBlack(), "exhibitor name is not black before hover");
    assertFalse(sessionDetailsPage.firstExhibitorNameIsUnderlined(), "exhibitor name is underlined before hover");
    sessionDetailsPage.hoverFirstExhibitorCard();
    assertTrue(sessionDetailsPage.firstExhibitorNameIsBlue(), "exhibitor name is not blue after hover");
    assertFalse(sessionDetailsPage.firstExhibitorNameIsUnderlined(), "exhibitor name is underlined before hover");
    sessionDetailsPage.hoverFirstExhibitorName();
    assertTrue(sessionDetailsPage.firstExhibitorNameIsBlue(), "exhibitor name is not blue after hover");
    assertTrue(sessionDetailsPage.firstExhibitorNameIsUnderlined(), "exhibitor name is not underlined after hover");

    sessionDetailsPage.clickExhibitorName(acuity);
    pageConfiguration.switchToTab(1);
    assertTrue(exhibitorDetailsPage.isOnPage(exhibitorCatalogUri, acuity));
    pageConfiguration.close();
    pageConfiguration.switchToTab(0);
    sessionDetailsPage.clickExhibitorViewBooth(burnsAndMcDonnell);
    pageConfiguration.switchToTab(1);
    assertTrue(exhibitorDetailsPage.isOnPage(exhibitorCatalogUri, burnsAndMcDonnell));
  }

  private void verifyExhibitorsSetInAdminShowUpOnSessionDetailsPage(String catalogUri, String sessionId, String sessionSearchText, List<String> expectedExhibitors) {
    editSessionPage.navigate(sessionId);
    editSessionPage.setExhibitors(expectedExhibitors);

    sessionCatalog.navigateTrogdorAutomation(catalogUri);
    sessionCatalog.justWait();
    sessionCatalog.filterCatalog(sessionSearchText);
    sessionCatalog.clickFirstSession();

    assertTrue(sessionDetailsPage.exhibitorsOnPageMatchExpected(expectedExhibitors),
            "expected the following sponsors on the session details page: " + expectedExhibitors.toString());
  }
}
