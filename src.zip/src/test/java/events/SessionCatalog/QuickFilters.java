package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetBuilder;
import apps.admin.adminPageObjects.libraries.EditWidgetCatalogSettings;
import apps.admin.adminPageObjects.libraries.WidgetBuilderSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class QuickFilters {

    private String[] sessions;
    private String widgetUrl;
    private boolean cleanUp = false;
    protected final String CATALOG = "Trogdor Catalog";
    protected final String FILTER_FAVORITE = "My favorites";
    protected final String FILTER_RECOMMENDED = "Recommended for you";
    protected final String FILTER_SEATS = "Seats available";
    protected final String FILTER_SESSION = "Let Data Tell the Story";
    protected final String EMAIL = "qftrogdor@rainfocus.com";
    protected final String PASSWORD = "Rainfocus123@";
    protected final String QFTROGDOR_ID = "1573503816896001tr2F";

    private EditWidgetBuilder widgetEdits = EditWidgetBuilder.getPage();
    private WidgetBuilderSearchPage widgets = WidgetBuilderSearchPage.getPage();
    private EditWidgetCatalogSettings settingsPage = EditWidgetCatalogSettings.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");

        widgets.navigate();
        widgets.searchFor("Trogdor Catalog");
        widgets.clickTopSearchResult();

        widgetEdits.clickCatalogSettingsButton();

        widgetUrl = PageConfiguration.getPage().getCurrentUrl();
        settingsPage.clickLeftNavItem("Quick Filters");
        settingsPage.toggleAllQuickFilters(true);
        settingsPage.clickSaveSettingsButton();

        widgetEdits.clickSaveWidget();
        EditAttendeePage.getPage().navigate(QFTROGDOR_ID);
        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);
    }

    @AfterClass
    public void tearDown() {
        if(cleanUp) {
            PageConfiguration.getPage().navigateTo(widgetUrl);
            settingsPage.clickLeftNavItem("Quick Filters");
            settingsPage.toggleAllQuickFilters(true);
            settingsPage.clickSaveSettingsButton();
            widgetEdits.clickSaveWidget();
        }
        PageConfiguration.getPage().quit();
    }

    //Be sure the catalog being used does not have "sortAttributeId": "x" in the widget config
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-33633", chromeIssue = "RA-26826")
    public void quickFilters() {
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
        Assert.assertTrue(catalog.hasQuickFilters(), "Quick Filters were not showing when a user was signed in");
            catalog.signOut();
        Assert.assertFalse(catalog.hasQuickFilters(), "Quick Filters should not be visible when not signed in");
            catalog.signIn(EMAIL, PASSWORD);

        Assert.assertTrue(catalog.setQuickFilter(FILTER_FAVORITE), FILTER_FAVORITE + " filter is off");
            sessions = catalog.getSessionIds(catalog.getSessionCount());
            catalog.assertSessionsAreFavorite(sessions);
        Assert.assertFalse(catalog.setQuickFilter(FILTER_FAVORITE), FILTER_FAVORITE + " filter is on");

        Assert.assertTrue(catalog.setQuickFilter(FILTER_RECOMMENDED), FILTER_RECOMMENDED + " filter is off");
            sessions = catalog.getSessionIds(catalog.getSessionCount());
            catalog.assertSessionsAreRecommended(sessions);
        Assert.assertTrue(catalog.setQuickFilter(FILTER_FAVORITE), FILTER_FAVORITE + " filter is off");

        Assert.assertTrue(catalog.isSessionOnCatalog(FILTER_SESSION), FILTER_SESSION + " is not on the catalog");
        Assert.assertTrue(catalog.setQuickFilter(FILTER_SEATS), FILTER_SEATS + " filter is off");
        Assert.assertTrue(catalog.isSessionOnCatalog(FILTER_SESSION), FILTER_SESSION + " is not on the catalog");

            int count1 = catalog.getSessionCount();
            catalog.clearAllFilters();
            int count2 = catalog.getSessionCount();
        Assert.assertNotEquals(count1, count2, "No difference in session count");

        PageConfiguration.getPage().switchToTab(0);

        PageConfiguration.getPage().navigateTo(widgetUrl);
            settingsPage.clickLeftNavItem("Quick Filters");
            settingsPage.toggleAllQuickFilters(false);
            settingsPage.clickSaveSettingsButton();

            widgetEdits.clickSaveWidget();
            cleanUp = true;

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();

        Assert.assertFalse(catalog.hasQuickFilters(), "Quick filters should not be displayed");
    }
}
