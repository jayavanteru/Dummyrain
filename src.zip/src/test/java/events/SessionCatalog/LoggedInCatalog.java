package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.events.eventsPageObjects.ConstellationsWidgetPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class LoggedInCatalog {

    private AdminApp adminApp;
    private DataGenerator generator;
    private String email;
    private String password;
    private String attendeeId;

    @BeforeClass
    public void setUp() {
        PropertyReader property = PropertyReader.instance();

        adminApp = new AdminApp();
        generator = new DataGenerator();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        email = generator.generateValidEmail();
        password = generator.generatePassword();
        Utils.sleep(2000);
        attendeeId = adminApp.createAttendee(email, password);
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.selectPackage("Approval Package");
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.placeOrder();
        PageConfiguration.getPage().waitForPageLoad();

        ConstellationsWidgetPage constellationsWidgetPage = ConstellationsWidgetPage.getPage();
        constellationsWidgetPage.navigate();

    }

    @AfterClass
    public void tearDown() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25843", chromeIssue = "RA-25842")
    public void catalogFavorite() {
        ConstellationsWidgetPage constellationsWidgetPage = ConstellationsWidgetPage.getPage();

        constellationsWidgetPage.clickFirstFavoriteButton();
        Utils.sleep(1000);
        constellationsWidgetPage.login(email, password);
        Utils.sleep(1000);
        Assert.assertTrue(constellationsWidgetPage.firstFavoriteButtonFilled(), "favorite icon did not stay filled after clicking");

        PageConfiguration.getPage().refreshPage();
        Utils.sleep(1000);
        Assert.assertTrue(constellationsWidgetPage.firstFavoriteButtonFilled(), "favorite icon did not stay filled after clicking");

    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25830", chromeIssue = "RA-25840")
    public void scheduleSession() {
        ConstellationsWidgetPage constellationsWidgetPage = ConstellationsWidgetPage.getPage();

        constellationsWidgetPage.clickFirstScheduleButton();
        Utils.sleep(1000);
        constellationsWidgetPage.login(email, password);
        Utils.sleep(1000);
        Assert.assertTrue(constellationsWidgetPage.firstSessionButtonScheduled(), "first session was not scheduled as expected"); //todo workaround waitlist

        PageConfiguration.getPage().refreshPage();
        Utils.sleep(1000);
        Assert.assertTrue(constellationsWidgetPage.firstSessionButtonScheduled(), "after refreshing page the first session was not scheduled as expected");
    }
}
