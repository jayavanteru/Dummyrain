package events.SessionCatalog;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.WidgetPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

public class FilterCatalog extends WidgetTest {

    @Test(dataProvider = "catalogs", groups = {"prodTest", ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-25844", chromeIssue = "RA-25845")
    public void filterTest(String eventName) {
        PropertyReader.instance().setProperty("screenShotCompare", false);
        WidgetPage page = getPage(eventName);

        PageConfiguration.getPage().justWait();
        String firstSessionTitle = page.getFirstSessionTitle();
        Assert.assertNotEquals(firstSessionTitle, "");
        int resultCount = page.numberOfResults();
        page.clickFirstFilter();
        Utils.sleep(500);

        Utils.waitForTrue(()->page.numberOfResults() < resultCount);
//        Utils.waitForTrue(()->!page.getFirstSessionTitle().equals(firstSessionTitle));
        String filteredFirstSession = page.getFirstSessionTitle();
        Assert.assertNotEquals(filteredFirstSession, "");

        int filteredCount = page.numberOfResults();
        Assert.assertTrue((resultCount > filteredCount) && (filteredCount > 0), "filtered count is: " + filteredCount + " unfiltered count is: " + resultCount);
//        Assert.assertNotEquals(firstSessionTitle, filteredFirstSession, "filter did not change the first session: " + firstSessionTitle);
        PageConfiguration.getPage().deleteAllCookies();
    }
}