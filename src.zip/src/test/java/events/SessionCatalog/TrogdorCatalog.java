package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeFilesPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.List;

public class TrogdorCatalog {
    private AdminApp adminApp;
    private String attendeeId;
    private String attendeeEmail;
    private String attendeeFirstName;
    private String attendeeLastName;
    private String sessionID;
    private final String CATALOG_NAME ="1570563232530001MeU1";
    private final String TROGDOR_CATALOG ="trogdorCatalog";
    private final String EVENTS_URL = PageConfiguration.getPage().getData("eventsUrl");
    private final String WIDGET_ID = "s8WWZFlGrtipbxWBOSj40UxNimZGpWYo";
    private final String PROFILE_ID = "y66CKcICv02PyVhUv3jhaMFfWOxvxzic";
    private final String EMAIL ="stephanie.hernandez@rainfocus.com";
    private final String PASSWORD ="Rainfocus123@";
    private final String SESSION_NAME ="Order of Participants Test MR";
    private final String ORG_NAME = "RainFocus";
    private final String EVENT_NAME = "Manual Regression ONLY - Trogdor";
    private final String COMPANY_NAME = "Rainfocus";
    private final String PARTICIPANT_ROLE = "Speaker";
    private final String ORDER = "Trogdor Full Conference Pass";
    private final String ITEM_ID ="rainfocus:155784956264steph902:sessionsbyroom";
    private final String ROOM_NAME = "Casanova";
    private final String YEAR = "2022";
    private final String MONTH = "12";
    private final String DAY = "04";
    private final String HOUR = "09";
    private final String MINUTE = "00";
    private final String TARGETEDAGENDA_TILE_CATALOG = "Targeted Agenda Page - fSKvqrtthRyoEXsavh8VqiQ9gEiXWA0P";

    private final AdminAttendeeOrdersTab adminAttendeeOrdersTab = AdminAttendeeOrdersTab.getPage();
    private final TrogdorSessionCatalog trogdorSessionCatalog = TrogdorSessionCatalog.getPage();
    private final SessionSearchPage sessionSearchPage = SessionSearchPage.getPage();
    private final EditSessionPage editSessionPage = EditSessionPage.getPage();
    private final AdminSessionParticipantsTab adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    private final DigitalSignageWidgetPage digitalSignageWidgetPage = DigitalSignageWidgetPage.getPage();
    private final CalendarWidgetPage calendarWidgetPage = CalendarWidgetPage.getPage();
    private final CachePage cachePage = CachePage.getPage();

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent(ORG_NAME, EVENT_NAME);
        attendeeEmail = new DataGenerator().generateEmail();
        attendeeFirstName = new DataGenerator().generateName();
        attendeeLastName = new DataGenerator().generateName();
        attendeeId = adminApp.createAttendee(attendeeEmail,attendeeFirstName,attendeeLastName);
        //upload an image to attendee so will show up on the tile
        AdminAttendeeFilesPage.getPage().navigate(attendeeId);
        AdminAttendeeFilesPage.getPage().uploadFile("Attendee Profile Photo", "pic1.jpg");

        adminAttendeeOrdersTab.navigate(attendeeId);
        adminAttendeeOrdersTab.addOrder();
        adminAttendeeOrdersTab.selectPackage(ORDER);
        adminAttendeeOrdersTab.clickNextOnAddOrderModal();
        adminAttendeeOrdersTab.setComment("Test");
        adminAttendeeOrdersTab.submitOrder();
        //Flushing the cache before we start the test
        cachePage.navigateToCache();
        cachePage.flushItem(ITEM_ID);
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-25592", firefoxIssue = "RA-52225")
    public void addAndVerifyParticipantsOrder() {
        trogdorSessionCatalog.navigateTrogdorEvent(TROGDOR_CATALOG);
        trogdorSessionCatalog.signIn(EMAIL,PASSWORD);

        searchForSessionInTrogdorCatalog();

        List<String> trogdorSessionSpeakerNames = getSpeakerNamesBySessionId(sessionID, 2);
        Assert.assertEquals("Carolyn Baird",trogdorSessionSpeakerNames.get(0),"First speaker is not Carolyn Baird");
        Assert.assertEquals("Ryan Thompson",trogdorSessionSpeakerNames.get(1),"Second speaker is not Ryan Thompson");

        searchForSession(SESSION_NAME);
        addParticipant();
        adminSessionParticipantsTab.dragAndDropByElement();

        List<String> participantsName = adminSessionParticipantsTab.getRoleParticipantNames(PARTICIPANT_ROLE);
        Assert.assertEquals("Ryan Thompson", participantsName.get(0),"First speaker is not Ryan Thompson");
        Assert.assertEquals("Carolyn Baird", participantsName.get(1),"Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName, participantsName.get(participantsName.size()-1).split("\\s")[0],"Last speaker is not " +attendeeFirstName);
        Assert.assertEquals(attendeeLastName, participantsName.get(participantsName.size()-1).split("\\s")[1],"Last speaker is not " +attendeeLastName);

        PageConfiguration.getPage().navigateTo(EVENTS_URL + "/api/elasticSpeakerLoad?rfWidgetId=" + WIDGET_ID + "&rfApiProfileId=" + PROFILE_ID + "&forceReindex=true");
        PageConfiguration.getPage().navigateTo(EVENTS_URL + "/api/elasticSessionLoad?rfWidgetId=" + WIDGET_ID + "&rfApiProfileId=" + PROFILE_ID + "&forceReindex=true");

        List<String> speakers = getTrogdorSessionSpeakersFilterByCatalog(TROGDOR_CATALOG, true, SESSION_NAME, sessionID, 3);
        Assert.assertEquals("Ryan Thompson", speakers.get(0), "First speaker is not Ryan Thompson");
        Assert.assertEquals("Carolyn Baird", speakers.get(1), "Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName, speakers.get(speakers.size()-1).split("\\s")[0],"Last speaker is not " +attendeeFirstName);
        Assert.assertEquals(attendeeLastName, speakers.get(speakers.size()-1).split("\\s")[1],"Last speaker is not " +attendeeLastName);

        //Verifying the participant order in the calendar widget page
        trogdorSessionCatalog.clickCalenderTab();
        PageConfiguration.getPage().switchToTab(1);
        calendarWidgetPage.toggleShowFavoritesCheckbox();
        calendarWidgetPage.clickFavoriteSession(SESSION_NAME);
        List<String> calendarSessionSpeakerNames = getSpeakerNamesBySessionId(sessionID, 3);
        Assert.assertEquals("Ryan Thompson",calendarSessionSpeakerNames.get(0),"First speaker is not Ryan Thompson");
        Assert.assertEquals("Carolyn Baird",calendarSessionSpeakerNames.get(1),"Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName,calendarSessionSpeakerNames.get(calendarSessionSpeakerNames.size()-1).split("\\s")[0],"Last speaker is not " +attendeeFirstName);
        Assert.assertEquals(attendeeLastName,calendarSessionSpeakerNames.get(calendarSessionSpeakerNames.size()-1).split("\\s")[1],"Last speaker is not " +attendeeLastName);

        //Verifying the participant order in the Trogdor Attendee Facing Agenda page
        List<String> attendeeFacingAgendaSpeakerNames = getTrogdorSessionSpeakersFilterByCatalog(CATALOG_NAME, false, SESSION_NAME, sessionID, 3);
        Assert.assertEquals("Ryan Thompson", attendeeFacingAgendaSpeakerNames.get(0),"First speaker is not Ryan Thompson");
        Assert.assertEquals("Carolyn Baird", attendeeFacingAgendaSpeakerNames.get(1),"Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName, attendeeFacingAgendaSpeakerNames.get(attendeeFacingAgendaSpeakerNames.size()-1).split("\\s")[0],"Last speaker is not " +attendeeFirstName);
        Assert.assertEquals(attendeeLastName, attendeeFacingAgendaSpeakerNames.get(attendeeFacingAgendaSpeakerNames.size()-1).split("\\s")[1],"Last speaker is not " +attendeeLastName);

        //Flushing the cache before we verify the participant order
        cachePage.navigateToCache();
        cachePage.flushItem(ITEM_ID);

        //Verifying the participant order in the digital signage widget page
        digitalSignageWidgetPage.navigate();
        digitalSignageWidgetPage.searchRoom(ROOM_NAME, YEAR, MONTH, DAY, HOUR, MINUTE);
        List<String> digitalSignageSpeakers = digitalSignageWidgetPage.getParticipantNames();
        Assert.assertEquals("RYAN THOMPSON",digitalSignageSpeakers.get(0).split(",")[0],"First speaker is not Ryan Thompson");
        Assert.assertEquals("CAROLYN BAIRD",digitalSignageSpeakers.get(1).split(",")[0],"Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName.toLowerCase(),digitalSignageSpeakers.get(digitalSignageSpeakers.size()-1).split(",")[0].split("\\s")[0].toLowerCase(),"Last speaker first name is not " +attendeeFirstName);
        Assert.assertEquals(attendeeLastName.toLowerCase(),digitalSignageSpeakers.get(digitalSignageSpeakers.size()-1).split(",")[0].split("\\s")[1].toLowerCase(),"Last speaker last name is not " +attendeeLastName);

        //Verifying the participant order on the targeted agenda
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofToWidget(TARGETEDAGENDA_TILE_CATALOG);
        final String[] participantAvatarList = WidgetTargetedAgendaPage.getPage().getParticipantAvatarList();
        Assert.assertEquals("Ryan Thompson",participantAvatarList[0],"First speaker is not Ryan Thompson");
        Assert.assertEquals("Carolyn Baird",participantAvatarList[1],"Second speaker is not Carolyn Baird");
        Assert.assertEquals(attendeeFirstName + " " + attendeeLastName,participantAvatarList[participantAvatarList.length-1],"Last speaker first name is not " +attendeeFirstName + " " + attendeeLastName);

    }

    private void searchForSession(String sessionName){
        sessionSearchPage.navigate();
        sessionSearchPage.searchFor(sessionName);
        sessionSearchPage.waitForPageLoad();
        sessionSearchPage.clickResult(sessionName);
    }

    private void addParticipant(){
        editSessionPage.participantsTab();
        adminSessionParticipantsTab.clickAddParticipantButton();
        adminSessionParticipantsTab.searchExistingParticipant(attendeeEmail);
        adminSessionParticipantsTab.setCompany(COMPANY_NAME);
        adminSessionParticipantsTab.setParticipantRole(PARTICIPANT_ROLE);
        adminSessionParticipantsTab.submitAddParticipant();
    }

    private void searchForSessionInTrogdorCatalog(){
        trogdorSessionCatalog.filterCatalog(SESSION_NAME);
        sessionID = trogdorSessionCatalog.getSessionId(SESSION_NAME);
        trogdorSessionCatalog.goToSessionDetails(sessionID, SESSION_NAME);
    }

    private List<String> getTrogdorSessionSpeakersFilterByCatalog(String catalogName, boolean filterBy, String searchKey, String sessionId, int numberOfSpeakers){
        trogdorSessionCatalog.navigateTrogdorEvent(catalogName);
        if(filterBy) {
            trogdorSessionCatalog.filterCatalog(searchKey);
        }
        trogdorSessionCatalog.goToSessionDetails(sessionId, searchKey);
        return getSpeakerNamesBySessionId(sessionId, numberOfSpeakers);
    }

    private List<String> getSpeakerNamesBySessionId(String sessionId, int numberOfSpeakers){
        List<String> speakers = new ArrayList<>();
        for(int index=0; index<numberOfSpeakers; index++) {
            speakers.add(trogdorSessionCatalog.getSessionSpeakerName(sessionId, index));
        }
        return speakers;
    }

   @AfterClass
    public void testCleanup(){
        reverseDragAndDrop();
       adminApp.deleteAttendee(attendeeId);
       PageConfiguration.getPage().quit();
    }

    public void reverseDragAndDrop(){
        searchForSession(SESSION_NAME);
        editSessionPage.participantsTab();
        adminSessionParticipantsTab.dragAndDropByElement();
    }
}
