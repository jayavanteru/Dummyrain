package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class JoinWebinarButton {

    private String sessionId;
    private String sessionUrl;
    private String attendeeId;
    private AdminApp adminApp;
    private DateTime day = new DateTime().now();
    private String currentTime;
    private boolean cleanUpSessionTime = false;
    private int minutes;
    private final String ROOM = "1614044167826001hyYa"; // Automation Test Room
    private final String SESSION = "Join Webinar Button Test";
    private final String TROGDOR_CATALOG = "Details Page Session Catalog Current Week";

    private final EditSessionPage sessionEdit = EditSessionPage.getPage();
    private final SessionSearchPage sessions = SessionSearchPage.getPage();
    private final AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();
    private final AdminSchedulingTab schedule = AdminSchedulingTab.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Current Week");
        attendeeId = adminApp.createAttendee();

        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage("All Access Package");
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();

        sessions.navigate();
        sessions.search(SESSION);
        sessions.clickResult(SESSION);

        sessionEdit.scheduleTab();
        sessionUrl = PageConfiguration.getPage().getCurrentUrl();
        if(!schedule.canDeleteSession()) {
            schedule.clickAttendedResultsLink();
            schedule.removeAttendeeFromTableOnModal();
            schedule.clickCloseButtonOnModal();
        }
        schedule.deleteAllSessions();

        minutes = day.getMinuteOfHour() % 5;
        if(minutes > 0) {
            day = day.plusMinutes(5 - minutes);
        } else {
            day = day.plusMinutes(5);
        }
        String dayName = day.toString("EEEE");
        currentTime = day.toString("hh:mm a");
        schedule.scheduleSessionTime(dayName, currentTime, ROOM);
        cleanUpSessionTime = true;
        sessionEdit.setRequireAttendeesToBeScheduled(true);
    }

    @AfterClass
    public void quit() {
        if (cleanUpSessionTime) {
            PageConfiguration.getPage().navigateTo(sessionUrl);
            if(!schedule.canDeleteSession()) {
                schedule.clickAttendedResultsLink();
                schedule.removeAttendeeFromTableOnModal();
                schedule.clickCloseButtonOnModal();
            }
            schedule.deleteAllSessions();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    //If the catalog doesn't have the join button, go to the 'Details Page Session Catalog Current Week' widget and check
    //for this setting - "sessionConfig.collapsedViewComponents": ["joinWebinarButton"]
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-42120", chromeIssue = "RA-42119")
    public void sessionJoinWebinarButton() {
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofToWidget(TROGDOR_CATALOG);
        PageConfiguration.getPage().switchToTab(1);
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog("\"" + SESSION + "\"");
            sessionId = catalog.getSessionId(SESSION);

        Utils.waitForTrue(()->catalog.sessionRequiredToBeScheduled(sessionId));
        Assert.assertTrue(catalog.sessionRequiredToBeScheduled(sessionId), "Session should be requiring attendee to schedule but is not");
        Assert.assertFalse(catalog.joinWebinarButtonEnabled(sessionId), "Webinar link cannot be clicked");

        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().navigateTo(sessionUrl);

            minutes = day.getMinuteOfHour() % 5;
            if(minutes > 0) {
                day = day.minusMinutes(5 + minutes);
            } else {
                day = day.minusMinutes(5);
            }
            currentTime = day.toString("hh:mm a");
            sessionEdit.setReplayValue(true);
            sessionEdit.openSessionEdit();
            sessionEdit.editScheduleTime(currentTime);
            sessionEdit.saveScheduleEdit();
            sessionEdit.finalizeScheduleEdit();

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();

        Utils.waitForTrue(()->catalog.sessionRequiredToBeScheduled(sessionId));
        Assert.assertTrue(catalog.sessionRequiredToBeScheduled(sessionId), "Session should be requiring attendee to schedule but is not");
        Assert.assertFalse(catalog.joinWebinarButtonEnabled(sessionId), "Webinar link cannot be clicked");

            catalog.scheduleSessionById(sessionId, true);
        Assert.assertTrue(catalog.joinWebinarButtonEnabled(sessionId), "Webinar link cannot be clicked");

            catalog.clickJoinWebinarButton(sessionId);
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("/session/" + sessionId), "Link didn't take you to correct details page");
    }
}
