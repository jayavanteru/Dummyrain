package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeDemographicsTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PreferredNameGlobal {

    private AdminApp adminApp;
    private String sessionId;
    private final String ATTENDEE = "1621630142389001ylhr";
    private final String SESSION = "Baseball";
    private final String CATALOG = "Trogdor 365 Global Ondemand Catalog";
    private final String PREFERRED_NAME = "Preferred Name";
    private final String ATTENDEE_NAME = "Trogdor Global Name";
    private final String PREFERRED_NAME_BADGE = "Preferred First Name for Badge";
    private final String WIDGET_ID = "Hmqr8oMCaE8wuTf09xodN2oMBJOntZiH";
    private final String API_PROFILE = "MFbIYN3fGdaDjmuElf417LcTSspia6De";

    private final AdminAttendeeDemographicsTab demographics = AdminAttendeeDemographicsTab.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
        demographics.navigate(ATTENDEE);
        if(!demographics.getTextInputFieldValue(PREFERRED_NAME_BADGE).isEmpty()) {
            demographics.textInputFields(PREFERRED_NAME_BADGE, "");
            demographics.attendeesubmit();
        }
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        demographics.navigate(ATTENDEE);
        demographics.textInputFields(PREFERRED_NAME_BADGE, "");
        demographics.attendeesubmit();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-45804", chromeIssue =  "RA-23021")
    public void globalPreferredName() {
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor 365 Global Ondemand");
        AttendeeSearchPage search = AttendeeSearchPage.getPage();
            search.navigate();
            search.searchFor("Carolyn Baird");
            search.clickResult(0);

        EditAttendeePage.getPage().spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);

        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.filterCatalog(SESSION);
        String filteredCatalogUrl = PageConfiguration.getPage().getCurrentUrl();
            sessionId = catalog.getSessionId(SESSION);
            runElastic(filteredCatalogUrl);

        Assert.assertEquals(ATTENDEE_NAME + " Participant", catalog.getSessionSpeakerName(sessionId, 0), PREFERRED_NAME + " was not saved on the session");

        PageConfiguration.getPage().switchToTab(0);
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
            demographics.navigate(ATTENDEE);
            demographics.textInputFields(PREFERRED_NAME_BADGE, PREFERRED_NAME);
            demographics.attendeesubmit();

        PageConfiguration.getPage().switchToTab(1);
            runElastic(filteredCatalogUrl);

        String speakerName = catalog.getSessionSpeakerName(sessionId, 0);
        Assert.assertEquals(PREFERRED_NAME + " Participant", speakerName, PREFERRED_NAME + " was not saved on the speaker modal");
        Assert.assertNotEquals(ATTENDEE_NAME + " Participant", speakerName, ATTENDEE_NAME + " should not be displayed when preferred name is updated");
    }

    public void runElastic(String url) {
        String events = PageConfiguration.getPage().getData("eventsUrl");
        PageConfiguration.getPage().navigateTo(events + "/api/elasticSpeakerLoad?rfApiProfileId=" + API_PROFILE + "&rfWidgetId=" + WIDGET_ID + "&forceReindex=true");
        PageConfiguration.getPage().justWait();
        PageConfiguration.getPage().navigateTo(events + "/api/elasticSessionLoad?rfApiProfileId=" + API_PROFILE + "&rfWidgetId=" + WIDGET_ID + "&forceReindex=true");
        PageConfiguration.getPage().justWait();
        PageConfiguration.getPage().navigateTo(url);
    }
}
