package events.SessionCatalog;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PastSessionRecommendations {

    private String catalogJson;
    private String calendarJson;
    private String catalogWidgetUrl;
    private String calendarWidgetUrl;
    private boolean cleanUpCatalog = false;
    private boolean cleanUpCalendar = false;
    private String eventsUrl = PageConfiguration.getPage().getData("eventsUrl");
    private String widgetId = "Pt80HSyZ4UsUCPShwE3j5vXZVNRXgaxS";
    private String profileId = "yM7NeyEzuSbPY47cahgBcPnXjP77hZFQ";
    private final String SESSION = "Past Recommended Session";
    private final String ATTENDEE_ID = "1466442636522001ngrw";
    private final String CATALOG = "Past Trogdor Catalog";
    private final String CALENDAR = "Past Trogdor Calendar";
    private final String JSON_FALSE = "\"showPastSessionsInRecommendation\":false,";
    private final String JSON_TRUE = "\"showPastSessionsInRecommendation\":true,";
    private final String REGEX_JSON = "\"showPastSessionsInRecommendation\":(.*?),";

    private EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
    private CalendarWidgetPage calendar = CalendarWidgetPage.getPage();
    private TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
    private EditWidgetPage config = EditWidgetPage.getPage();
    private WidgetSearchPage widgetSearch = WidgetSearchPage.getPage();

    @BeforeClass
    public void testSetup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Past Event Trogdor Tests");

        widgetSearch.navigate();
        widgetSearch.searchWidgets(CATALOG);
        widgetSearch.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Catalog"));
        catalogWidgetUrl = PageConfiguration.getPage().getCurrentUrl();
        catalogJson = config.getWidgetJson();
        config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_TRUE));
        config.saveWidgetConfig();

        widgetSearch.searchWidgets(CALENDAR);
        widgetSearch.editItem();

        Assert.assertTrue(config.getWidgetName().contains("Calendar"));
        calendarWidgetUrl = PageConfiguration.getPage().getCurrentUrl();
        calendarJson = config.getWidgetJson();
        config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_TRUE));
        config.saveWidgetConfig();

        editAttendeePage.navigate(ATTENDEE_ID);
        editAttendeePage.spoofToWidget(CATALOG);
        PageConfiguration.getPage().switchToTab(1);
    }

    @AfterClass
    public void testCleanup() {
        if(cleanUpCatalog) {
            widgetSearch.navigate();
            widgetSearch.searchWidgets(CATALOG);
            widgetSearch.editItem();
            Assert.assertEquals(catalogWidgetUrl, PageConfiguration.getPage().getCurrentUrl(), "Not on the correct widget page");
            config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_TRUE));
            config.saveWidgetConfig();
        }
        if(cleanUpCalendar) {
            widgetSearch.navigate();
            widgetSearch.searchWidgets(CALENDAR);
            widgetSearch.editItem();
            Assert.assertEquals(calendarWidgetUrl, PageConfiguration.getPage().getCurrentUrl(), "Not on the correct widget page");
            config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_TRUE));
            config.saveWidgetConfig();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-28219", firefoxIssue = "RA-37975")
    public void pastRecommendation() {
        String catalogUrl = PageConfiguration.getPage().getCurrentUrl();
            catalog.filterCatalog("Recommended");
            String sessionId1 = catalog.getSessionId(SESSION);
            if(!catalog.isSessionFavorite(sessionId1)) {
                catalog.toggleFavorite(sessionId1);
            }
            if(!catalog.hasRecommendation(sessionId1)) {
                String url = PageConfiguration.getPage().getCurrentUrl();
                PageConfiguration.getPage().navigateTo(eventsUrl + "/api/recommendCache?rfWidgetId=" + widgetId + "&rfApiProfileId=" + profileId);
                PageConfiguration.getPage().navigateTo(url);
            }
        Assert.assertTrue(catalog.hasRecommendation(sessionId1), "Session is not recommended and should be");

        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorpast/pastTrogdorCalendar");
        String calendarUrl = PageConfiguration.getPage().getCurrentUrl();
            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION);
        Assert.assertTrue(catalog.hasRecommendation(sessionId1), "Session is not recommended and should be");
            calendar.closeSessionScheduleModal();

        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().navigateTo(catalogWidgetUrl);

            catalogJson = config.getWidgetJson();
            config.setWidgetJson(catalogJson.replaceFirst(REGEX_JSON, JSON_FALSE));
            config.saveWidgetConfig();
            cleanUpCatalog = true;

        PageConfiguration.getPage().navigateTo(calendarWidgetUrl);

            calendarJson = config.getWidgetJson();
            config.setWidgetJson(calendarJson.replaceFirst(REGEX_JSON, JSON_FALSE));
            config.saveWidgetConfig();
            cleanUpCalendar = true;

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().navigateTo(catalogUrl);

        Assert.assertFalse(catalog.hasRecommendation(sessionId1), "Session is recommended and should not be");
        PageConfiguration.getPage().navigateTo(calendarUrl);

            calendar.toggleShowFavoritesCheckbox();
            calendar.clickFavoriteSession(SESSION);
        Assert.assertFalse(catalog.hasRecommendation(sessionId1), "Session is recommended and should not be");
    }
}
