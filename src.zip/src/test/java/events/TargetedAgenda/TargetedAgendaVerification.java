package events.TargetedAgenda;

import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.events.eventsPageObjects.AgendaPage;
import apps.PageConfiguration;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class TargetedAgendaVerification {

    private final String SPEAKER_NAME = "Carolyn Baird";
    private final String SPEAKER_JOB = "Product Owner, RainFocus";
    private final String SPEAKER_BIO = "This is a biography. Testing the bio field in catalog";
    private final String AGENDA_ID = "1642094680690001N4A2"; //Change id to '1642095016250001XMx9' when data dup happens
    private String attendeeId;
    private AdminApp adminApp = new AdminApp();
    private DataGenerator dataGenerator = new DataGenerator();
    private String email = dataGenerator.generateEmail();
    private String password = dataGenerator.generatePassword();
    private AdminAttendeeOrdersTab ordersTab;
    private String order = "Full Conference Pass Automation";

    @BeforeClass
    public void setup() {
        ordersTab = AdminAttendeeOrdersTab.getPage();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        attendeeId = adminApp.createAttendee( email, password );
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.orderPackageForFree(order);
        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorauto/" + AGENDA_ID);
    }

    @AfterClass
    public void quit() {
        ordersTab.navigate(attendeeId);
        ordersTab.deleteOrder(order);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-52150", chromeIssue = "RA-20560")
    public void verifyAgenda() {
        AgendaPage agenda = AgendaPage.getPage();
        agenda.clickFavoriteAndSignIn(email, password);
        agenda.clickFavoriteIcon();
        Assert.assertEquals(agenda.getFavoriteIconState(), "Click to un-favorite", "Heart is not favorited");
        agenda.clickFavoriteIcon();
        agenda.clickCardCarrot();
        agenda.clickSpeakerLink();
        Assert.assertEquals(agenda.getSpeakerName(), SPEAKER_NAME, "Speaker name incorrect");
        Assert.assertEquals(agenda.getSpeakerJob(), SPEAKER_JOB, "Speaker job title incorrect");
        Assert.assertEquals(agenda.getSpeakerBio(), SPEAKER_BIO, "Speaker description incorrect");
        agenda.closeSpeakerModal();
        agenda.clickToSchedule();
        Assert.assertTrue( agenda.isScheduled(), "Session was not properly scheduled");
        agenda.unschedule();
    }
}
