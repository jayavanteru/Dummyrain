package events.ExhibitorCatalog;

import apps.PageConfiguration;
import apps.events.EventsApp;
import apps.events.eventsPageObjects.ExhibitorListPage;
import apps.events.eventsPageObjects.ExhibitorListRSAPage;
import apps.events.eventsPageObjects.ExhibitorListRSASpeakerPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import testHelp.Utils;

public class ExhibitorLists {

    EventsApp app;

    @BeforeClass
    public void setup() {
        app = new EventsApp();
    }

    @AfterClass
    public void stopBrowser() {
        PageConfiguration.getPage().quit();
    }

    //I have disabled this test because it is failing 100% of the time.
    // Rene is going to update this test so that it will match the current functionality

    //@Test(dataProvider = "events", groups = {"prodTest", ReportingInfo.BLUE})
    //@ReportingInfo(firefoxIssue = "RA-25890", chromeIssue = "RA-25887")
    public void exhibitorsLoading(String eventName) {
        final int getNExhibitor = 3;
        final ExhibitorListPage exhibitorListPage = eventName.startsWith("RSA") ?
                eventName.contains("Speaker") ?
                        ExhibitorListRSASpeakerPage.getPage() :
                        ExhibitorListRSAPage.getPage() :
                ExhibitorListPage.getPage();

        exhibitorListPage.navigateTo(eventName);
        Utils.waitForTrue(()->exhibitorListPage.getExhibitorCount() > getNExhibitor, 10);
        int exhibitorCount = exhibitorListPage.getExhibitorCount();
        Assert.assertTrue(exhibitorCount > getNExhibitor, "there should be more than "+getNExhibitor+" exhibitors on the page but only found " + exhibitorCount);

        //check the filter
        String topExhibitorName = exhibitorListPage.getTopExhibitor();
        String nthExhibitorName = exhibitorListPage.getNthExhibitor(getNExhibitor);

        exhibitorListPage.searchFor(nthExhibitorName);

        Utils.waitForTrue(()->!exhibitorListPage.getTopExhibitor().equals(topExhibitorName));
        String newTopExhibitorName = exhibitorListPage.getTopExhibitor();

        Assert.assertNotEquals(newTopExhibitorName, topExhibitorName, "searching exhibitor did not replace the top result");
        Assert.assertEquals(newTopExhibitorName, nthExhibitorName, "searched exhibitor is not at the top");

    }

    @DataProvider(name = "events")
    public Object[][] exhibitorsData() {
        return new Object[][]{
//                {"Oracle_MCX"}, {"Oracle_MCX_demo"}, {"Oracle_MBX"}, {"Oracle_MBX_demo"},
//                {"Oracle_suite"}, {"Oracle_suite_demo"}, {"Adobe_summit"}, {"RSA_APJ_Speaker"}, {"RSA_APJ"},
                {"VMware_US"}, {"VMware_US_Speaker"}
        };
    }
}
