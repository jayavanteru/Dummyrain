package events.Multiple;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.CalendarWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

public class AlmostFullIndicator
{
    private final String SESSION_CATALOG = "Trogdor Selenium Almost Full Catalog";
    private final String SESSION_CALENDAR = "Trogdor Selenium Almost Full Calendar";
    private final String SESSION_TARGETED_AGENDA = "Trogdor Selenium Almost Full Agenda";
    private final String SHOW_ALMOST_FULL_FALSE = "\"showAlmostFull\":false";
    private final String SHOW_ALMOST_FULL_TRUE = "\"showAlmostFull\":true";
    private final String SHOW_ALMOST_FULL_REGEX = "\"showAlmostFull\": ?((true)|(false))";

    protected AdminApp adminApp = new AdminApp();

    private PageConfiguration pageConfiguration = PageConfiguration.getPage();
    private SessionSearchPage sessionSearchPage = SessionSearchPage.getPage();
    private EditSessionPage editSessionPage = EditSessionPage.getPage();
    private AdminSchedulingTab schedulingTab = AdminSchedulingTab.getPage();
    private EditWidgetPage editWidgetPage = EditWidgetPage.getPage();
    private WidgetSearchPage widgetSearchPage = WidgetSearchPage.getPage();
    private AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
    private EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
    private TrogdorSessionCatalog catalogPage = TrogdorSessionCatalog.getPage();
    private CalendarWidgetPage calendarPage = CalendarWidgetPage.getPage();
    private WorkflowTargetedAgendaPage targetedAgendaPage = WorkflowTargetedAgendaPage.getPage();

    private String sessionId;
    private String sessionTitle;
    private String attendeeId1;
    private String attendeeId2;
    private String attendeeId3;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        DataGenerator dataGenerator = new DataGenerator();

        String email1 = dataGenerator.generateEmail();
        attendeeId1 = adminApp.createAttendee(email1);
        String email2 = dataGenerator.generateEmail();
        attendeeId2 = adminApp.createAttendee(email2);
        String email3 = dataGenerator.generateEmail();
        attendeeId3 = adminApp.createAttendee(email3);

        sessionTitle = "Almost Full Session";
        sessionSearchPage.navigate();
        sessionSearchPage.search(sessionTitle);
        sessionSearchPage.clickResult(sessionTitle);

        sessionId = editSessionPage.getSessionId();
        editSessionPage.scheduleTab();
        schedulingTab.deleteAllSessions();

        schedulingTab.scheduleSessionTime("Saturday, 3rd", "07:00 AM");

        schedulingTab.scheduleSessionTime("Saturday, 3rd", "07:15 AM");
        schedulingTab.enrollAttendeeInLatestSessionTime(attendeeId1, email1);

        schedulingTab.scheduleSessionTime("Saturday, 3rd", "07:30 AM");
        schedulingTab.enrollAttendeeInLatestSessionTime(attendeeId2, email2);
        schedulingTab.enrollAttendeeInLatestSessionTime(attendeeId3, email3);
    }

    @AfterClass
    public void cleanup() {
        editSessionPage.navigate(sessionId);
        editSessionPage.scheduleTab();
        schedulingTab.deleteAllSessions();
        adminApp.deleteAttendee(attendeeId1);
        adminApp.deleteAttendee(attendeeId2);
        adminApp.deleteAttendee(attendeeId3);
        pageConfiguration.quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-27151", firefoxIssue = "RA-43987")
    public void almostFullIndicator() {
        setShowAlmostFull(SESSION_CATALOG, true);
        setShowAlmostFull(SESSION_TARGETED_AGENDA, true);

        assertShowAlmostFullStatus(true);

        setShowAlmostFull(SESSION_CATALOG, false);
        setShowAlmostFull(SESSION_TARGETED_AGENDA, false);

        assertShowAlmostFullStatus(false);

        setShowAlmostFull(SESSION_CATALOG, true);
        setShowAlmostFull(SESSION_TARGETED_AGENDA, true);
    }

    private void setShowAlmostFull(String widgetName, boolean showAlmostFull)
    {
        widgetSearchPage.navigate();
        widgetSearchPage.searchWidgets(widgetName);
        widgetSearchPage.editItem();
        String json = editWidgetPage.getWidgetJson();
        String showAlmostFullJson = showAlmostFull ? SHOW_ALMOST_FULL_TRUE : SHOW_ALMOST_FULL_FALSE;
        editWidgetPage.setWidgetJson(json.replaceFirst(SHOW_ALMOST_FULL_REGEX, showAlmostFullJson));
        editWidgetPage.saveWidgetConfig();
    }

    private void assertShowAlmostFullStatus(boolean expectedShowAlmostFull)
    {
        String wrongIndicatorError = "almost full indicator was" + (expectedShowAlmostFull ? " not" : "") +
                " visible when 'showAlmostFull': " + expectedShowAlmostFull;
        String notAlmostFullError = "session had almost full indicator when it was not almost full";

        attendeeSearchPage.navigate();
        attendeeSearchPage.searchFor("scheduleindicators@rainfocus.com");
        attendeeSearchPage.clickResult(0);
        editAttendeePage.spoofToWidget(SESSION_CATALOG);

        catalogPage.filterCatalog("\"" + sessionTitle + "\"");
        assertFalse(catalogPage.sessionIsAlmostFull(sessionId, 1), notAlmostFullError);
        assertEquals(catalogPage.sessionIsAlmostFull(sessionId, 2), expectedShowAlmostFull, wrongIndicatorError + " for session catalog");
        assertFalse(catalogPage.sessionIsAlmostFull(sessionId, 3), notAlmostFullError);

        pageConfiguration.close();
        pageConfiguration.switchToTab(0);

        editAttendeePage.spoofToWidget(SESSION_CALENDAR);
        calendarPage.clickFirstAvailableTimeSlot();
        assertFalse(calendarPage.sessionIsAlmostFull(sessionId, 1), notAlmostFullError);
        assertEquals(calendarPage.sessionIsAlmostFull(sessionId, 2), expectedShowAlmostFull, wrongIndicatorError + " for session calendar");
        assertFalse(calendarPage.sessionIsAlmostFull(sessionId, 3), notAlmostFullError);

        pageConfiguration.close();
        pageConfiguration.switchToTab(0);

        editAttendeePage.spoofToWidget(SESSION_TARGETED_AGENDA);
        assertFalse(targetedAgendaPage.sessionIsAlmostFull(sessionId, 1), notAlmostFullError);
        assertEquals(targetedAgendaPage.sessionIsAlmostFull(sessionId, 2), expectedShowAlmostFull, wrongIndicatorError + " for targeted agenda");
        assertFalse(targetedAgendaPage.sessionIsAlmostFull(sessionId, 3), notAlmostFullError);

        pageConfiguration.close();
        pageConfiguration.switchToTab(0);
    }

}
