package events.virtual;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.*;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.virtual.ModeratorPage;
import apps.events.virtual.PigeonHoleLiveDashboardPage;
import apps.events.virtual.PigeonHoleLogin;
import apps.events.virtual.PigeonHoleSessionPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

public class PigeonholeSessionScheduling {
    private AdminApp adminApp;
    private String sessionId;
    private String attendeeId;
    private String attendeeEmail;
    private String sessionUrl;
    private boolean cleanUpSessionTime = false;
    private final String ORG_NAME = "RainFocus";
    private final String EVENT_NAME = "Trogdor Current Week";
    private final String SESSION_NAME = "Pigeonhole Manual Regression";
    private final String AUTOMATION_ROOM = "1614044167826001hyYa"; // Automation room
    private final String COMPANY_NAME = "Rainfocus";
    private final String QA_MODERATOR_ROLE = "Q&A Moderator";
    private final String DETAILS_PAGE_SESSION_CATALOG_WIDGET = "Details Page Session Catalog Current Week";
    private final String TEST_SPEAKER_PORTAL = "Test Speaker Portal";
    private final String ALL_ACCESS_PAGE_NAME = "All Access Package";
    private final SessionSearchPage sessionSearchPage = SessionSearchPage.getPage();
    private final AdminSchedulingTab adminSchedulingTab = AdminSchedulingTab.getPage();
    private final EditSessionPage editSessionPage = EditSessionPage.getPage();
    private final AdminSessionParticipantsTab adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    private final AttendeeSearchPage attendeeSearchPage =  AttendeeSearchPage.getPage();
    private final EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
    private final AdminAttendeeOrdersTab adminAttendeeOrdersTab = AdminAttendeeOrdersTab.getPage();
    private final TrogdorSessionCatalog trogdorSessionCatalog = TrogdorSessionCatalog.getPage();
    private final ModeratorPage moderatorPage = ModeratorPage.getPage();
    private final PigeonHoleSessionPage pigeonHoleSessionPage = PigeonHoleSessionPage.getPage();
    private final PigeonHoleLiveDashboardPage pigeonHoleLiveDashboardPage = PigeonHoleLiveDashboardPage.getPage();

    @BeforeTest
    public void testSetup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent(ORG_NAME, EVENT_NAME);
        attendeeEmail = new DataGenerator().generateEmail();
        attendeeId = adminApp.createAttendee(attendeeEmail);
        adminAttendeeOrdersTab.navigate(attendeeId);
        adminAttendeeOrdersTab.addOrder();
        adminAttendeeOrdersTab.selectPackage(ALL_ACCESS_PAGE_NAME);
        adminAttendeeOrdersTab.clickNextOnAddOrderModal();
        adminAttendeeOrdersTab.setComment("Test Pigeonhole regression session");
        adminAttendeeOrdersTab.submitOrder();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-39471", firefoxIssue = "RA-52084")
    public void testPigeonHoleQuestionAndCommentsOnSession() {
        searchForSession();
        deletePreviousSessions();
        HashMap<String, String> dateAndTimeMap = calculateDateAndTimeForNextSession();
        createSession(dateAndTimeMap);
        String[] webinarAndPigeonHoleId = adminSchedulingTab.getPigeonholeIDAndWebinarIdForSession();
        String webinarId = webinarAndPigeonHoleId[0];
        String pigeonHoleId = webinarAndPigeonHoleId[1];
        Assert.assertNotNull(webinarId,"WebinarID not generated");
        Assert.assertNotNull(pigeonHoleId,"Pigeonhole Session ID not generated");
        cleanUpSessionTime = true;
        editSessionPage.participantsTab();
        deleteParticipant();
        addParticipant();
        Assert.assertEquals("Q&A Moderator",adminSchedulingTab.getParticipantRole(),"Participant role is not set to 'Q&A Moderator'");
        searchForSessionAttendee();
        Assert.assertEquals("Profile",attendeeSearchPage.getPageTitle(),"page title mismatch");
        editAttendeePage.spoofToWidget(DETAILS_PAGE_SESSION_CATALOG_WIDGET);
        joinPigeonHoleWebinar();
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("/session/" + sessionId), "Link didn't take you to correct Pigeonhole session page");
        pigeonHoleSessionPage.askQuestion();
        String askQuestionUrl = PageConfiguration.getPage().getCurrentUrl();
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        editAttendeePage.spoofToWidget(TEST_SPEAKER_PORTAL);
        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        moderatorPage.moderationPanel();
        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        moderatorPage.approveQuestions();
        Assert.assertEquals("1",moderatorPage.getAllowedQuestion(),"The question is not allowed");
        final String moderatorUrl = PageConfiguration.getPage().getCurrentUrl();
        PageConfiguration.getPage().navigateTo(askQuestionUrl);
        pigeonHoleSessionPage.addComment();
        PageConfiguration.getPage().navigateTo(moderatorUrl);
        moderatorPage.approveComments();
        Assert.assertEquals("1",moderatorPage.getAllowedComments(),"The comment is not allowed");
        PigeonHoleLogin.getPage().loginToPigeonhole();
        pigeonHoleLiveDashboardPage.navigateToPigeonholeAgendaTrogdor();
        pigeonHoleLiveDashboardPage.searchForPigeonHoleSession("Pigeonhole Manual Regression");
        String pigeonholeSessionID = pigeonHoleLiveDashboardPage.getSessionID().replaceAll("-?[^\\d.]", "");;
        pigeonHoleLiveDashboardPage.deleteSessionSettings();
        String searchResult = pigeonHoleLiveDashboardPage.searchForSessionId(pigeonholeSessionID);
        Assert.assertEquals("There are no results found.",searchResult,"Pigeonhole Manual Regression Session is not deleted");

    }

    /**
     * Navigate to session page and search for "Pigeonhole Manual Regression"
     */
    private void searchForSession(){
        sessionSearchPage.navigate();
        sessionSearchPage.searchFor(SESSION_NAME);
        sessionSearchPage.waitForPageLoad();
        sessionSearchPage.clickResult(SESSION_NAME);
        adminSchedulingTab.clickScheduleTab();
        sessionUrl = PageConfiguration.getPage().getCurrentUrl();
    }

    /**
     * Delete previous sessions if there are any
     */
    private void deletePreviousSessions(){
            if (adminSchedulingTab.canDeleteSession()) {
                adminSchedulingTab.deleteAllSessions();
           }else{
                adminSchedulingTab.clickAttendedResultsLink();
                adminSchedulingTab.removeAttendeeFromTableOnModal();
                adminSchedulingTab.clickCloseButtonOnModal();
                adminSchedulingTab.deleteAllSessions();
        }
    }

    /**
     * Logic to calculate the day and time for scheduling a new session
     * returns a hashmap of key -> "day" to val-> "01", "time" to val-> "05"
     * @return
     */
    private HashMap<String, String> calculateDateAndTimeForNextSession(){
        HashMap<String, String> map = new HashMap<>();
        Utils.waitForTrue(() -> {
            return checkForValidNextSession();
        }, 120);
        DateTime day = DateTime.now().toDateTime(DateTimeZone.forTimeZone(TimeZone.getTimeZone("MST")));
        int minutes;
        minutes = day.getMinuteOfHour() % 5;
        if (minutes > 0) {
            day = day.plusMinutes(5 - minutes);
        } else {
            day = day.plusMinutes(5);
        }
        String dayName = day.toString("EEEE");
        String time = day.toString("hh:mm a");
        map.put("day",dayName);
        map.put("time", time);
        return map;
    }

    /**
     * create session and add details to the form
     */
    private void createSession(HashMap<String, String> dateAndTimeMap){
        Utils.waitForTrue(() -> {
            return canSessionBeCreated();
        }, 300);
        adminSchedulingTab.clickAddSessionButton();
        adminSchedulingTab.setDay(dateAndTimeMap.get("day"));
        adminSchedulingTab.setTime(dateAndTimeMap.get("time"));
        adminSchedulingTab.setRoomByRoomId(AUTOMATION_ROOM);
        adminSchedulingTab.enablePigeonHole();
        adminSchedulingTab.enableQA();
        adminSchedulingTab.clickSaveSessionButton();
    }

    /**
     * Add participant details to the form
     */
    private void addParticipant(){
        adminSessionParticipantsTab.clickAddParticipantButton();
        adminSessionParticipantsTab.searchExistingParticipant(attendeeEmail);
        adminSessionParticipantsTab.setCompany(COMPANY_NAME);
        adminSessionParticipantsTab.setParticipantRole(QA_MODERATOR_ROLE);
        adminSessionParticipantsTab.submitAddParticipant();
    }

    /**
     * Delete existing participants
     */
    private void deleteParticipant(){
        List<String> participantIds = adminSessionParticipantsTab.getParticipantIds();
        for (String participantId : participantIds) {
            adminSessionParticipantsTab.deleteParticipantById(participantId);
        }
    }

    /**
     * Go to "Details Page Session Catalog Current Week" from Attendee Page spoof
     */
    private void searchForSessionAttendee(){
        attendeeSearchPage.navigate();
        attendeeSearchPage.searchFor(attendeeEmail);
        attendeeSearchPage.clickResult(0);
    }

    /**
     * Join pigeonHoleSession Webinar
     */
    private void joinPigeonHoleWebinar(){
        trogdorSessionCatalog.filterCatalog(SESSION_NAME);
        sessionId = trogdorSessionCatalog.getSessionId(SESSION_NAME);
        Utils.waitForTrue(() -> {
            return isItTimeForSessionStart();
        }, 240);
        PageConfiguration.getPage().refreshPage();
        trogdorSessionCatalog.clickJoinWebinarButton(sessionId);
    }

    private boolean isItTimeForSessionStart(){
        DateTime day = new DateTime().now();
        return day.getMinuteOfHour() % 5 > 3;
    }

    private boolean canSessionBeCreated(){
        DateTime day = new DateTime().now();
        int minute = day.getMinuteOfHour() % 5;
        return minute > 0 && minute <4;
    }

    private boolean checkForValidNextSession(){
        DateTime day = new DateTime().now();
        int minute = day.getMinuteOfHour() % 5;
        return minute >= 0 && minute < 4;
    }

    @AfterClass
    public void testCleanup() {
        if (cleanUpSessionTime) {
            PageConfiguration.getPage().navigateTo(sessionUrl);
            deletePreviousSessions();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }
}


