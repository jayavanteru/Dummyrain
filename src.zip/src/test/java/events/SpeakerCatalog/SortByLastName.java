package events.SpeakerCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.SpeakerListWidgetPage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class SortByLastName {

    private String widgetUrl;
    private String attendeeId;
    private AdminApp adminApp;
    private final String SPEAKER_WIDGET = "Trogdor Speaker List for Selenium Tests ONLY";
    private final String ATTENDEE = "Jared Collins";
    private final String TRUE_JSON = "\"sortSpeakersByLastName\": true,";
    private final String FALSE_JSON = "\"sortSpeakersByLastName\": false,";
    private final String REGEX_JSON = "\"sortSpeakersByLastName\":.*?[a-z]+?.*";
    private final String[] SEARCH_CRITERIA = {"", "st", "RainFocus", "ee"};

    private final SpeakerListWidgetPage speakerList = SpeakerListWidgetPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");

        widgetUrl = navigateToWidgetAndGetUrl(SPEAKER_WIDGET);
        setWidgetSpeakerSort(true);

        attendeeId = adminApp.createAttendee();
        orderPackageAndSpoof(attendeeId);
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

//    @Test(groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(firefoxIssue = "RA-44485", chromeIssue = "RA-19907")
//    public void sortByLastName() {
//        assertSortedByFirstName(SEARCH_CRITERIA[0]);
//        assertSortedByFirstName(SEARCH_CRITERIA[1]);
//        assertSortedByFirstName(SEARCH_CRITERIA[2]);
//        assertSortedByFirstName(SEARCH_CRITERIA[3]);
//
//        PageConfiguration.getPage().switchToTab(0);
//        setWidgetSpeakerSort(false);
//        Utils.sleep(3000, "settings time to save");
//        PageConfiguration.getPage().switchToTab(1);
//        PageConfiguration.getPage().refreshPage();
//
//        assertSortedByLastName(SEARCH_CRITERIA[0]);
//        assertSortedByLastName(SEARCH_CRITERIA[1]);
//        assertSortedByLastName(SEARCH_CRITERIA[2]);
//        assertSortedByLastName(SEARCH_CRITERIA[3]);
//
//        assertCatalogSearchFromSpeakerModal(ATTENDEE);
//    }

    public void assertSortedByFirstName(String search) {
        speakerList.clearSpeakerSearch();
        speakerList.searchSpeakerList(search);
        String[] firstNames = speakerList.getFirstNames();
        String[] lastNames = speakerList.getLastNames();
        Assert.assertTrue(speakerList.isAlphabetical(firstNames), "List is not sort alphabetically");
        Assert.assertFalse(speakerList.isAlphabetical(lastNames), "List is sorted alphabetically and should not be");
    }

    public void assertSortedByLastName(String search) {
        speakerList.clearSpeakerSearch();
        speakerList.searchSpeakerList(search);
        String[] firstNames = speakerList.getFirstNames();
        String[] lastNames = speakerList.getLastNames();
        Assert.assertFalse(speakerList.isAlphabetical(firstNames), "List is not sort alphabetically");
        Assert.assertTrue(speakerList.isAlphabetical(lastNames), "List is sorted alphabetically and should not be");
    }

    public void assertCatalogSearchFromSpeakerModal(String attendee) {
        speakerList.clearSpeakerSearch();
        speakerList.searchSpeakerList(attendee);
        speakerList.openSpeakerModal(attendee);
        Assert.assertTrue(speakerList.modalContainsAllData(), "Speaker modal is missing data");
        speakerList.seeAllSessionsWithSpeaker();
        PageConfiguration.getPage().switchToTab(2);
        Assert.assertTrue(TrogdorSessionCatalog.getPage().isFacetPillOnPage("\"" + attendee + "\""), "Speaker search was not applied to catalog");
    }

    public void orderPackageAndSpoof(String attendeeId) {
        AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();
        orders.navigate(attendeeId);
        orders.addOrder();
        orders.selectPackage("Trogdor Full Conference Pass");
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
        EditAttendeePage.getPage().spoofToWidget(SPEAKER_WIDGET);
    }

    public void setWidgetSpeakerSort(boolean setFalse) {
        EditWidgetPage config = EditWidgetPage.getPage();
        if(!PageConfiguration.getPage().getCurrentUrl().equals(widgetUrl)) {
            PageConfiguration.getPage().navigateTo(widgetUrl);
        }
        Assert.assertEquals(config.getWidgetName(), SPEAKER_WIDGET);
        String oldJson = config.getWidgetJson();
        if(setFalse) {
            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, FALSE_JSON));
        } else {
            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, TRUE_JSON));
        }
        config.saveWidgetConfig();
    }

    public String navigateToWidgetAndGetUrl(String widgetName) {
        WidgetSearchPage search = WidgetSearchPage.getPage();
        search.navigate();
        search.searchWidgets(widgetName);
        search.editItem();
        return PageConfiguration.getPage().getCurrentUrl();
    }
}
