package events.SpeakerCatalog;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.NewSessionPage;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.EditTaskPage;
import apps.events.eventsPageObjects.TrogdorSpeakerPortal;
import interaction.files.OpenFile;
import interaction.screenshots.ScreenShotImage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.SeleniumHelpers;
import testHelp.Utils;

import java.io.File;
import java.io.IOException;

public class SpeakerFileUpload {

    private String taskID = "1586470501240001ZA0H";
    private String sessionInfo = "BPTest";
    private String sessionStatus = "On Hold";
    private String participantEmail = "brian.pulham@rainfocus.com";
    private String role1 = "Speaker";
    private String role2 = "Copy Editor";
    private String role3 = "Legal Reviewer";
    private final String comment = "automation" + new DataGenerator().generateString(5);
    private String uploadFile = "pic2.jpg";

    AdminApp adminApp = new AdminApp();
    private final EditTaskPage editTaskPage = EditTaskPage.getPage();
    private final EditSessionPage editSession = EditSessionPage.getPage();
    private final NewSessionPage newSession = NewSessionPage.getPage();
    private final SessionSearchPage sessionSearch = SessionSearchPage.getPage();
    private final SessionAddParticipant addParticipant = SessionAddParticipant.getPage();
    private final TrogdorSpeakerPortal speakerPortal = TrogdorSpeakerPortal.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
    }

    @AfterClass
    public void quit() {
        sessionSearch.navigate();
        sessionSearch.searchFor(sessionInfo);
        sessionSearch.deleteBySessionTitle(sessionInfo);
        //editTaskPage.navigate(taskID);
        //editTaskPage.toggleAllowUploads();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-35883", chromeIssue = "RA-52010")
    public void speakerUploadFile() throws IOException {

        editTaskPage.navigate(taskID);
        editTaskPage.toggleAllowUploads();
        newSession.navigate();
        newSession.setTitle(sessionInfo);
        newSession.setAbstract(sessionInfo);
        newSession.clickSubmit();
        editSession.setSessionStatus(sessionStatus);
        editSession.toggleFileReviewStatus();
        addParticipant.clickParticipantTab();
        addParticipant.clickAddParticipantButton();
        addParticipant.addParticipant(participantEmail,role1);
        addParticipant.clickAddParticipantButton();
        addParticipant.addParticipant(participantEmail,role2);
        addParticipant.clickAddParticipantButton();
        addParticipant.addParticipant(participantEmail,role3);
        adminApp.spoofIntoWorkflow(participantEmail, "speakerportal", 1);
        speakerPortal.dismissCookies();
        speakerPortal.clickOverdue();
        speakerPortal.clickFileUploadTask();
        Assert.assertTrue(speakerPortal.isSessionOnPage(), "The session title should be" +sessionInfo+ "but it isn't");
        Assert.assertTrue(speakerPortal.checkTaskStatus(), "The task does not have the status of Incomplete");
        Assert.assertTrue(speakerPortal.isFileHistoryDisplayed(), "The File History section is not showing");
        Assert.assertTrue(speakerPortal.isDueDateDisplayed(), "The Due Date section is not showing");
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        Assert.assertTrue(speakerPortal.isUploadDisabled(), "The upload button is active, but it shouldn't be");
        speakerPortal.removeFile();
        Assert.assertFalse(speakerPortal.isUploadDisabled(), "The file upload button is disabled, but it shouldn't be");
        speakerPortal.returnToTasks();
        speakerPortal.clickFileUploadTask();
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        Assert.assertTrue(speakerPortal.isUploadDisabled(), "The upload button is active, but it shouldn't be");
        speakerPortal.cancelFileUpload();
        Assert.assertFalse(speakerPortal.isUploadDisabled(), "The file upload button is disabled, but it shouldn't be");
        speakerPortal.returnToTasks();
        speakerPortal.clickFileUploadTask();
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        speakerPortal.submitFileUpload();
        speakerPortal.addComment(comment);
        speakerPortal.cancelComment();
        speakerPortal.addComment(comment);
        speakerPortal.submitComment();
        Assert.assertTrue(speakerPortal.isCommentVisible(), "The speaker notes did not save");
        speakerPortal.returnToTasks();
        speakerPortal.clickCopyEditTask();
        Assert.assertTrue(speakerPortal.isApprovalButtonOnScreen(), "The Approval button is not on the screen");
        Assert.assertFalse(speakerPortal.isUploadDisabled(), "The file upload button is disabled, but it shouldn't be");
        speakerPortal.clickApprovalButton();
        Utils.sleep(3000);
        Assert.assertFalse(speakerPortal.isApprovalButtonOnScreen(), "The Approval button should not be on the screen");
        Assert.assertTrue(speakerPortal.isTaskApproved(), "The Task is not approved, but it should be.");
        speakerPortal.returnToTasks();
        speakerPortal.clickLegalReviewerTask();
        speakerPortal.clickRequestRevisionButton();
        Assert.assertTrue(speakerPortal.isRequestedRevisionTaskOnScreen(), "The requested revision is not displayed");
        Assert.assertFalse(speakerPortal.isUploadDisabled(), "The file upload button is disabled, but it shouldn't be");
        //Lines 122-126 are for step 22 in the test case
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        editTaskPage.navigate(taskID);
        editTaskPage.toggleAllowUploads();
        adminApp.spoofIntoWorkflow(participantEmail, "speakerportal", 1);
        speakerPortal.clickOverdue();
        speakerPortal.clickFileUploadTask();
        Assert.assertTrue(speakerPortal.isSessionOnPage(), "The session title should be" +sessionInfo+ "but it isn't");
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        Assert.assertTrue(speakerPortal.isUploadDisabled(), "The upload button is active, but it shouldn't be");
        speakerPortal.submitFileUpload();
        Assert.assertTrue(speakerPortal.wasFileHistoryUpdated(), "The file history was not updated");
        speakerPortal.returnToTasks();
        speakerPortal.clickCopyEditTask();
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        Assert.assertTrue(speakerPortal.isUploadDisabled(), "The upload button is active, but it shouldn't be");
        speakerPortal.submitFileUpload();
        speakerPortal.clickApprovalButton();
        speakerPortal.returnToTasks();
        speakerPortal.clickLegalReviewerTask();
        speakerPortal.clickUploadFile();
        speakerPortal.fileUpload(uploadFile);
        Assert.assertTrue(speakerPortal.isUploadDisabled(), "The upload button is active, but it shouldn't be");
        speakerPortal.submitFileUpload();
        speakerPortal.clickApprovalButton();
        speakerPortal.downloadFile(uploadFile);
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("pic2.*\\.jpg");
        ScreenShotImage upLoadedImage = new ScreenShotImage(Utils.getResourceAsFile(uploadFile));
        ScreenShotImage downLoadedImage = new ScreenShotImage(file.getFile());
        int diffAmount = upLoadedImage.getDiffAmount(downLoadedImage);
        Assert.assertTrue(diffAmount<500, "The images don't match " +diffAmount);
        speakerPortal.downloadFromHistory();
        file = OpenFile.OpenRecentDownloadedFileMatchingPattern("pic2.*\\.jpg");
        upLoadedImage = new ScreenShotImage(new File(uploadFile));
        downLoadedImage = new ScreenShotImage(file.getFile());
        diffAmount = upLoadedImage.getDiffAmount(downLoadedImage);
        Assert.assertTrue(diffAmount<500, "The images don't match " +diffAmount);
        speakerPortal.returnToTasks();
        Assert.assertTrue(speakerPortal.areAllTasksComplete(), "All of the tasks are not showing the status completed");
    }
}
