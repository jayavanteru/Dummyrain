package workflows.OrgWorkflows;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.OracleSignOnPage;
import configuration.PropertyReader;
import events.OrgCatalogs.SsoBase;
import logs.Log;
import org.openqa.selenium.Cookie;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

import java.util.ArrayList;
import java.util.Set;

public class WorkflowSSO extends SsoBase{

//    @Test(dataProvider = "workflows", groups = "prodTest")
    public void setsSsoCookie(String org, String event, String workflowUri) {
        String url = generateUrl(org, event, workflowUri);
        PageConfiguration.getPage().navigateTo(url);

        Assert.assertTrue(OracleSignOnPage.getPage().isPageLoaded());

        PageConfiguration.getPage().navigateTo(eventsApp.getHealthCheckUrl());

        Set<Cookie> cookies = PageConfiguration.getPage().getCookies();
        ArrayList<String> cookieNames = new ArrayList<>();
        for (Cookie cookie : cookies) {
            Log.info(cookie.toString(), getClass());
            cookieNames.add(cookie.getName());
        }
        Assert.assertTrue(cookieNames.contains("ssoEncToken"), "there was no ssoEncToken cookie set for the sso to use");
    }

    private String generateUrl(String org, String event, String workflow) {
        String baseUrl = PropertyReader.instance().getProperty("eventsUrl");
        return baseUrl + "/ev:"+org+"/"+event+"/samlRequest?app=reg:" +workflow;
    }

    @DataProvider(name = "workflows")
    public Object[][] workflowData() {
        return new Object[][]{
                {"oracle", "modfinance18", "mfe18cfp"},
                {"oracle", "cwsydney18", "reg"},
                {"oracle", "sw18", "reg"},
                {"oracle", "mbx18amsterdam", "reg"},
                {"oracle", "oic18", "reg"},
//                {"oracle", "cwny18", "reg"},
                {"oracle", "mcx18", "reg"},
                {"oracle", "cwmex17", "reg"},
        };
    }
}
