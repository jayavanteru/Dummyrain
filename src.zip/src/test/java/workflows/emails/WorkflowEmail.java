package workflows.emails;

import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.*;
import emails.Email;
import interaction.gmail.EmailMessage;
import logs.Log;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;

public class WorkflowEmail extends Email {

    private String order = "automation package";

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27750", chromeIssue = "RA-21020")
    public void regConfirmationWorkflow() {
        String firstName = new DataGenerator().generateName(); //unique text for name field
        String date = DateTime.now().toString("MM/dd/yyyy");
        loginAndCreateAttendee();

        String workflowId = "1519924453505001ozRN";
        String packageGroupName = "Conference Packages";
        String uri = workflowsApp.setupWorkflowAndGetUri(adminApp, workflowId);

        workflowsApp.navigate(workflowsApp.getUrl(eventorg, eventname, uri), "login");
        WorkflowLoginPage.getPage().login(emailAddress, password);

        //fill out forms
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee-email", emailAddress);
        customValues.put("formAttendee-countryId", "US");
        customValues.put("formAttendee-lastname", firstName);
        workflowsApp.fillOutFormAndSubmit("contactInfo", customValues);
//        workflowsApp.fillOutFormAndSubmit("profile1");
//        workflowsApp.fillOutFormAndSubmit("profile3");

        //order form wire transfer
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        Utils.sleep(200);

        purchasePage.buyPackage(order);
        purchasePage.enterPayment();
        purchasePage.enterBillingAddress();
        purchasePage.submit();

        findTheEmail(confirmEmail, true, order, firstName, eventname, date);
    }

//    @Test
    public void bulkOrderWorkflow() {
        loginAndCreateAttendee();

        String bulkPackageEmail = "ACTION REQUIRED: You have been invited to register for Cisco Live 2017 Cancun!";
        String workflowId = "1492467566347001UXEJ";
        String packageGroupName = "Conference Packages";
        String uri = workflowsApp.setupWorkflowAndGetUri(adminApp, workflowId);

        workflowsApp.navigate(workflowsApp.getUrl(eventorg, eventname, uri), "login");
        WorkflowLoginPage.getPage().login(emailAddress, password);

        //fill out forms
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee.email", emailAddress);
        workflowsApp.fillOutFormAndSubmit("contactInfo", customValues);
        workflowsApp.fillOutFormAndSubmit("profile1");
        workflowsApp.fillOutFormAndSubmit("profile3");

        //order form wire transfer
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        Utils.sleep(200);
        purchasePage.buyPackage(order);
        purchasePage.enterCCPaymentInfo();
        purchasePage.enterBillingAddress();
        purchasePage.submit();

        WorkflowRegisterConfirmPage.getPage().goToManageBulkPurchase();
        WorkflowBulkPackageManagement.getPage().invite(emailAddress);

        Assert.assertTrue(checkEmail.waitForEmail(bulkPackageEmail), "waiting for email");
        EmailMessage message = checkEmail.getEmail(bulkPackageEmail);
        Assert.assertTrue(message.getBody().contains(this.emailAddress), "did not include the email keyword");
        message.deleteEmail();
    }

//    @Test
    public void editReport() {
        String visaEmail = "VMworld 2017 Europe Visa Invitation Letter";
        String workingReport = "updateAttendee";
        String tempOrgName = eventorg;
        String tempEventName = eventname;
        eventorg = "RainFocus";
        eventname = "Constellations";
        try {
            loginAndCreateAttendee();
            //do you require a visa?
            AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB1);
            customTab.navigate(attendeeId);
            Utils.sleep(500);
//            customTab.selectSelectField("ID1488996749593001BQxy", "Yes");
//            customTab.submit();
//            Utils.sleep(200);

//            AdminAttendeeOrdersTab ordersTab = adminApp.getAdminAttendeeOrdersTab();
//            ordersTab.navigate(attendeeId);
//            ordersTab.addOrder();
//            ordersTab.selectOrder("VMworld Full Conference");
//            ordersTab.fillOutOrder();
//            ordersTab.markAsPaid();
//            ordersTab.submitOrder();

//            Utils.sleep(2000);
            EditAttendeePage.getPage().spoofTo(workingReport);

            LiveTablesPage reportPage = LiveTablesPage.getPage();
            Utils.sleep(2000);

            String firstName = properties.getProperty("attendeeFirstName");
            reportPage.search("formAttendee.firstname", firstName);

            reportPage.toggleField(1, "Visa Validated");
            Assert.assertTrue(checkEmail.waitForEmail(visaEmail), "email did not show up");
            EmailMessage message = checkEmail.getEmail(visaEmail);
            Log.info(message.getBody(), getClass().getName());
            Assert.assertTrue(message.getBody().contains(firstName), "email body did not contain first name: " + firstName);
        } finally {
            eventorg = tempOrgName;   eventname = tempEventName;
        }
    }
}
