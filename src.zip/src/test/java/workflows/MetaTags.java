package workflows;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class MetaTags
{
  private AdminApp adminApp;
  DataGenerator dataGenerator = new DataGenerator();
  String workflowUri = "keywordmeta";
  String attendeeId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    adminApp = new AdminApp();
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().navigateTo(adminApp.getHost());
    adminApp.deleteAttendee(attendeeId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-38046", firefoxIssue = "RA-43982")
  public void keywordsInMetaTags()
  {
    /*
      create an attendee
      spoof into the workflow and make sure the met keyword tags are there
    */
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
    String firstName = dataGenerator.generateName();
    String lastName = dataGenerator.generateName();
    attendeeId = adminApp.createAttendee(dataGenerator.generateEmail(), firstName, lastName);
    adminApp.spoofIntoWorkflow(firstName, workflowUri, 1);

    WorkflowPage workflowPage = new WorkflowPage();

    String attendeeFirstNameMetaTag = workflowPage.getMetaTagContent("attendee-first-name");
    String attendeeLastNameMetaTag = workflowPage.getMetaTagContent("attendee-last-name");
    String eventCodeMetaTag = workflowPage.getMetaTagContent("event-code");

    Assert.assertEquals(attendeeFirstNameMetaTag, firstName, "Attendee firstName meta tag incorrect");
    Assert.assertEquals(attendeeLastNameMetaTag, lastName, "Attendee lastName meta tag incorrect");
    Assert.assertEquals(eventCodeMetaTag, "eventgers", "Event code meta tag incorrect");
  }
}
