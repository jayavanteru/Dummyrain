package workflows;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewWebPagePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowLiveTablePage;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

public class InviteVoters {
    final String EMAIL = new DataGenerator().generateValidEmail();
    final String PASSWORD = new DataGenerator().generatePassword();
    final String EMAIL_SUBJECT = "You've been invited to vote on a session";
    final String FIRSTNAME = "Invited";
    final String LASTNAME = "Voter";
    final String INVITEUSER_ID = "16249025927180012umF";
    final String WIDGETNAME = "Voting Working Report";
    final String INVITEVOTERS_TEXT = "Invite Voters";
    final String ORG = "RainFocus";
    final String EVENT = "Trogdor Automation";
    boolean cleanInvite = false;
    boolean cleanUser = false;
    WorkflowLiveTablePage votingReport = WorkflowLiveTablePage.getPage();



    @BeforeClass
    public void setup(){
        //Logs in and sets Org/Event
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent(ORG, EVENT);
    }

    @AfterTest
    public void quit(){
        //Removes invite from the invite list if one was sent
        if(cleanInvite){
            PageConfiguration.getPage().closeTabsToDefault();
            if(!AdminLoginPage.getPage().isLoggedIn()){
                AdminLoginPage.getPage().login();
            }
            EditAttendeePage.getPage().navigate(INVITEUSER_ID);
            EditAttendeePage.getPage().spoofToExact(WIDGETNAME);
            votingReport.clickLink(INVITEVOTERS_TEXT);
            votingReport.clickSpanDataText("rf-icon-session-voting-referral-remove", 0);
            votingReport.clickButtonText("Remove invite");
            PageConfiguration.getPage().close();
            }

        //deletes user if one was created
        if(cleanUser){
            PageConfiguration.getPage().closeTabsToDefault();
            if(!AdminLoginPage.getPage().isLoggedIn()){
                AdminLoginPage.getPage().login();
            }
            AttendeeSearchPage.getPage().navigate();
            AdminApp adminApp = new AdminApp();
            adminApp.deleteAttendee(AttendeeSearchPage.getPage().getIdByEmail(EMAIL));
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-53149", chromeIssue = "RA-23599")
    public void InviteVotersTest() {
        //Spoofing into "Voting Working Report" widget
        EditAttendeePage.getPage().navigate(INVITEUSER_ID);
        EditAttendeePage.getPage().spoofToExact(WIDGETNAME);
        votingReport.waitForPageLoad();

        //Gets the title of the session the user is invited for
        String invitedFor = votingReport.getCellText("Title", 0);

        //Invites a new user to vote
        votingReport.clickLink(INVITEVOTERS_TEXT);
        votingReport.sendTextToInputDataTest("rf-text-input-node-session-voting-referral-email", EMAIL);
        votingReport.clickButtonDataTest("rf-button-session-voting-referral-email");
        cleanInvite = true;

        //New user receives invite email
        EmailApi emailClient = EmailApi.emailClient();
        EmailMessage email = emailClient.getEmail(EMAIL_SUBJECT);
        String message = email.getBody();

        //Check the email was received today to avoid older emails
        Date received = email.getReceivedDate();
        LocalDate today = LocalDate.now();
        LocalDate test = received.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        Assert.assertEquals(test, today, "Day email was received is not today");

        //Deleting email after the text has been received
        emailClient.getEmail(EMAIL_SUBJECT).deleteEmail();

        //Parsing out invite link
        int linkStart = message.indexOf("https");
        String messageLink = message.substring(linkStart);
        int linkEnd = messageLink.indexOf(" ");
        messageLink = messageLink.substring(0, linkEnd);

        //Invite done closing the working report
        votingReport.clickButtonDataTest("rf-button-rf-modal-cancel-session-voting-referrals");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Logging out and clearing cookies, so we get the 'create account' page
        AdminLoginPage.getPage().logout();
        NewWebPagePage.getPage().openUrlInNewTab(messageLink);
        PageConfiguration.getPage().deleteAllCookies();
        PageConfiguration.getPage().refreshPage();

        //Creating a new user with the email that was invited to vote
        votingReport.clickButtonText("Create Account");
        votingReport.sendTextToInputID("formAttendee-firstname", FIRSTNAME);
        votingReport.sendTextToInputID("formAttendee-lastname", LASTNAME);
        votingReport.sendTextToInputID("formAttendee-email", EMAIL);
        votingReport.sendTextToInputID("password", PASSWORD);
        votingReport.sendTextToInputID("confirmpassword", PASSWORD);
        votingReport.clickButtonText("Continue");
        cleanUser = true;

        //Check to see if the invited session = the actual session the user sees
        String invitedActual = votingReport.getCellText("Title", 0);
        Assert.assertEquals(invitedActual,invitedFor, "The session the user was invited for and the session the user see are not the same");
        PageConfiguration.getPage().close();
    }
}
