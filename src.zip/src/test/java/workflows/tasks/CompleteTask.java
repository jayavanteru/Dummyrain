package workflows.tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeFilesPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.forms.Form;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.TaskList;
import apps.workflows.workflowsPageObjects.TaskPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class CompleteTask {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String taskId;
    private String taskQualifierId;

    @BeforeClass
    public void setup() {
        PropertyReader.instance().setProperty("enableDesktopAutomation", true);
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        email = generator.generateEmail();
        attendeeId = adminApp.createAttendee(email);
    }


    @AfterClass
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (taskId != null) {
            //remove the qualifier for deleting
            Utils.sleep(1000);
            EditTaskPage.getPage().navigate(taskId);
            Utils.sleep(500);
            EditTaskPage.getPage().removeQualifiers();
            EditTaskPage.getPage().submit();
            Utils.sleep(500);
            //delete now
            adminApp.deleteTask(taskId);
            adminApp.deleteTaskQualifier(taskQualifierId);
            taskId = null;
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27684", chromeIssue = "RA-27685")
    public void CompleteTaskFromWorkflow() {
        String taskWorkflow = "dashspeaker";
        String formId = "1492465807545001U5ir";
        Criteria taskQualfy = new Criteria("Email", "equal to", email);
        String taskQualifyName = "automation" + generator.generateString(5);
        String taskName = "automation" + generator.generateString(5);

        //get form
        final Form form = adminApp.getForm(formId);

        //create a task
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().createTaskQualifier(taskQualifyName, taskQualfy);

        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().createFormSpeakerTask(taskName, formId, false, taskQualifyName);

        //get the task qualifier id and task id
        TasksSearchPage.getPage().navigate();
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
        TaskQualifierSearchPage.getPage().navigate();
        taskQualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifyName);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(taskWorkflow);

        Dashboard.getPage().editTaskCard();

        final TaskList listPage = TaskList.getPage();
        final TaskPage taskPage = TaskPage.getPage();

        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);

        listPage.showCompleted(false);

        //cancel out of task
        listPage.openTask(taskName);
        taskPage.cancel();
        listPage.showCompleted(false);
        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. after cancel. looking for task name: " + taskName);

        //save the task and complete
        listPage.openTask(taskName);
        form.addOverride("formAttendee-email", email);
        form.fillOutForm();
        taskPage.saveComplete();
        listPage.showCompleted(false);
        Assert.assertFalse(listPage.isTaskOnPage(taskName), "found task on page. after completed. " + taskName);

        listPage.showCompleted(true);
        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. after showing completed. looking for task name: " + taskName);

        //save task and not complete
        listPage.openTask(taskName);
        taskPage.saveNotComplete();
        listPage.showCompleted(false);
        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. after marking not completed. " + taskName);
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-24676", chromeIssue = "RA-24675")
    public void CompleteTaskUploadFileFromWorkflow() {
        String taskWorkflow = "dashspeaker";
        Criteria taskQualfy = new Criteria("Email", "equal to", email);
        String taskQualifyName = "automation" + generator.generateString(5);
        String taskName = "automation" + generator.generateString(5);

        //create a task
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().createTaskQualifier(taskQualifyName, taskQualfy);

        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().createFileSpeakerTask(taskName, false, taskQualifyName);

        //get the task qualifier id and task id
        TasksSearchPage.getPage().navigate();
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
        TaskQualifierSearchPage.getPage().navigate();
        taskQualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifyName);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(taskWorkflow);

        Dashboard.getPage().editTaskCard();

        final TaskList listPage = TaskList.getPage();
        final TaskPage taskPage = TaskPage.getPage();

        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);

        listPage.showCompleted(false);

        //save the task and complete
        listPage.openTask(taskName);
        taskPage.uploadFile();
        taskPage.returnToList();
        listPage.showCompleted(false);
        Assert.assertFalse(listPage.isTaskOnPage(taskName), "found task on page. after completed. " + taskName);

        listPage.showCompleted(true);
        Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. after showing completed. looking for task name: " + taskName);

        AdminAttendeeFilesPage.getPage().navigate(attendeeId);
        Utils.waitForTrue(AdminAttendeeFilesPage.getPage()::isProfilePhotoUploaded);
        Assert.assertTrue(AdminAttendeeFilesPage.getPage().isProfilePhotoUploaded(), "uploaded file from task not showing photo in ui");
    }
}
