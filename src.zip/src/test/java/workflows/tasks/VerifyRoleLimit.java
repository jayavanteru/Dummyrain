package workflows.tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.TaskAddParticipantPage;
import apps.workflows.workflowsPageObjects.TaskList;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;

import static org.testng.Assert.assertEquals;

public class VerifyRoleLimit
{
  private DataGenerator generator = new DataGenerator();
  private AdminApp adminApp = new AdminApp();

  private AdminSessionParticipantsTab adminSessionParticipantsTab;
  private EditSessionPage editSessionPage;
  private SessionAddParticipant sessionAddParticipant;
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private Dashboard dashboard;
  private TaskList taskList;
  private TaskAddParticipantPage taskAddParticipantPage;

  private String spooferAttendeeId;
  private String speakerAttendeeId;
  private String spooferFirstName;
  private String speakerFirstName;
  private String newFirstName;
  private String spooferLastName;
  private String speakerLastName;
  private String newLastName;
  private String spooferFullName;
  private String speakerFullName;
  private String newFullName;
  private String spooferEmail;
  private String speakerEmail;
  private String newEmail;
  private String sessionId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

    editSessionPage = EditSessionPage.getPage();
    adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    sessionAddParticipant = SessionAddParticipant.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    taskList = TaskList.getPage();
    dashboard = Dashboard.getPage();
    taskAddParticipantPage = TaskAddParticipantPage.getPage(adminApp.getForm("1609881501402001tiHo"));

    spooferEmail = generator.generateEmail();
    spooferFirstName = generator.generateName();
    spooferLastName = generator.generateName();
    spooferFullName = String.format("%s %s", spooferFirstName, spooferLastName);
    speakerEmail = generator.generateEmail();
    speakerFirstName = generator.generateName();
    speakerLastName = generator.generateName();
    speakerFullName = String.format("%s %s", speakerFirstName, speakerLastName);
    newEmail = generator.generateEmail();
    newFirstName = generator.generateName();
    newLastName = generator.generateName();
    newFullName = String.format("%s %s", newFirstName, newLastName);

    spooferAttendeeId = adminApp.createAttendee(spooferEmail, spooferFirstName, spooferLastName);
    speakerAttendeeId = adminApp.createAttendee(speakerEmail, speakerFirstName, speakerLastName);

    sessionId = adminApp.createSession();
    editSessionPage.setSessionStatus("Accepted");
    editSessionPage.setSessionType("Birds of a feather");
    adminSessionParticipantsTab.navigate(sessionId);

    adminSessionParticipantsTab.clickAddParticipantButton();
    sessionAddParticipant.addParticipant(spooferEmail, "Speaker");

    adminSessionParticipantsTab.clickAddParticipantButton();
    sessionAddParticipant.addParticipant(speakerEmail, "Speaker");
  }

  @AfterClass
  public void delete() {
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(newEmail);
    attendeeSearchPage.deleteAttendeeByName(newLastName);
    adminApp.deleteAttendee(spooferAttendeeId);
    adminApp.deleteAttendee(speakerAttendeeId);
    adminApp.deleteSession(sessionId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-20483", firefoxIssue = "RA-42760")
  public void VerifyRoleLimit()
  {
    String workflow = "speakerPortal";

    editAttendeePage.navigate(spooferAttendeeId);
    editAttendeePage.spoofTo(workflow);

    dashboard.editTaskCard();
    taskList.openTask("Task - Manage Participants");

    HashMap<String, String> formValues = new HashMap();
    formValues.put("formAttendee-firstname", newFirstName);
    formValues.put("formAttendee-lastname", newLastName);
    formValues.put("formAttendee-jobtitle", "job");
    formValues.put("formAttendee-companyname", "company");

    taskAddParticipantPage.dismissCookie();
    assertEquals(taskAddParticipantPage.roleIsAvailableToParticipant(spooferFullName, "Co-Speaker"), true,
            "co-speaker is not an available option for " + spooferFullName);
    taskAddParticipantPage.addParticipant("Co-Speaker", newEmail, formValues);
    assertEquals(taskAddParticipantPage.participantExists(newFullName), true, "could not add participant");
    assertEquals(taskAddParticipantPage.roleIsAvailableToParticipant(spooferFullName, "Co-Speaker"), false,
            "co-speaker is an available option for " + spooferFullName + " even though it has been taken by " + newFullName);

    taskAddParticipantPage.deleteParticipant(newFullName);
    assertEquals(taskAddParticipantPage.participantExists(newEmail), false,
            "could not delete participant " + newFullName);

    assertEquals(taskAddParticipantPage.roleIsAvailableToNewParticipant("Co-Speaker"), true,
            "co-speaker is not an available option for a new participant");
    taskAddParticipantPage.modifyParticipantRole(speakerFullName, "Co-Speaker");
    assertEquals(taskAddParticipantPage.roleIsAvailableToNewParticipant("Co-Speaker"), false,
            "co-speaker is an available option for a new participant even though it has been taken by " + speakerFullName);
  }
}
