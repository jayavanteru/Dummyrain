package workflows.tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeTaskTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.TaskList;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class TaskToDoList
{
  private AdminApp adminApp = new AdminApp();
  private DataGenerator generator = new DataGenerator();
  private EditSessionPage editSessionPage;
  private AdminSessionParticipantsTab adminSessionParticipantsTab;
  private SessionAddParticipant sessionAddParticipant;
  private AdminAttendeeTaskTab adminAttendeeTaskTab;
  private EditAttendeePage editAttendeePage;
  private TasksSearchPage tasksSearchPage;
  private TaskQualifierSearchPage taskQualifierSearchPage;
  private NewTaskQualifierPage newTaskQualifierPage;
  private NewTaskPage newTaskPage;
  private String email;
  private String attendeeId;
  private String taskId;
  private String taskQualifierId;
  private String idSession01 = "";

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    editSessionPage = EditSessionPage.getPage();
    adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    sessionAddParticipant = SessionAddParticipant.getPage();
    adminAttendeeTaskTab = AdminAttendeeTaskTab.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    tasksSearchPage = TasksSearchPage.getPage();
    taskQualifierSearchPage = TaskQualifierSearchPage.getPage();
    newTaskQualifierPage = NewTaskQualifierPage.getPage();
    newTaskPage = NewTaskPage.getPage();

    email = generator.generateEmail();
    attendeeId = adminApp.createAttendee(email);

    idSession01 = adminApp.createSessionWithLength(30);
    editSessionPage.waitForPageLoad();
    editSessionPage.setSessionStatus("Accepted");

    adminSessionParticipantsTab.navigate(idSession01);
    adminSessionParticipantsTab.clickAddParticipantButton();
    sessionAddParticipant.addParticipantDontSubmit(email, "Speaker");
    sessionAddParticipant.setCompanyName();
    sessionAddParticipant.submit();
  }

  @AfterClass
  public void delete() {
    PageConfiguration.getPage().navigateTo(adminApp.getHost());
    if (attendeeId != null) {
      adminApp.deleteAttendee(attendeeId);
      attendeeId = null;
    }
    if (idSession01!= null) {
      adminApp.deleteSession(idSession01);
    }
    if (taskId != null) {
      //remove the qualifier for deleting
      Utils.sleep(200);
      EditTaskPage.getPage().navigate(taskId);
      Utils.sleep(200);
      EditTaskPage.getPage().removeQualifiers();
      EditTaskPage.getPage().submit();
      Utils.sleep(200);
      //delete now
      adminApp.deleteTask(taskId);
      adminApp.deleteTaskQualifier(taskQualifierId);
      taskId = null;
    }
    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19868", firefoxIssue = "RA-23653")
  public void ToDoListTask () {
    String formId = "15011849789780014eJ0"; // formId for Speaker Bios
    Criteria taskQualify = new Criteria("Email", "equal to", email);
    String taskQualifyName = "Speakers" + generator.generateString(5);
    String taskName = "TrogdorTest" + generator.generateString(5);

    // create a task
    newTaskQualifierPage.navigate();
    newTaskQualifierPage.createTaskQualifier(taskQualifyName, taskQualify);

    newTaskPage.navigate();
    newTaskPage.createFormSpeakerTask(taskName, false, formId, taskName, taskQualifyName);

    //get the task qualifier id and task id
    tasksSearchPage.navigate();
    taskId = tasksSearchPage.getTaskId(taskName);
    taskQualifierSearchPage.navigate();
    taskQualifierId = taskQualifierSearchPage.getId(taskQualifyName);

    //save the task and complete
    adminAttendeeTaskTab.navigate(attendeeId);
    adminAttendeeTaskTab.waitForPageLoad();
    adminAttendeeTaskTab.markTaskComplete(taskName);

    // Clicking on 'Done' in the top and verifying task is now completed
    adminAttendeeTaskTab.showCompleted();
    adminAttendeeTaskTab.waitForPageLoad();
    Assert.assertTrue(adminAttendeeTaskTab.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);

    // Spoof to workflow from Attendee Profile
    editAttendeePage.navigate(attendeeId);
    PageConfiguration.getPage().waitForPageLoad();
    Utils.sleep(500);
    editAttendeePage.spoofTo("dashspeaker");

    Dashboard.getPage().editTaskCard();

    final TaskList listPage = TaskList.getPage();

    listPage.showCompleted(true);
    Assert.assertTrue(listPage.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);

    //save the task and incomplete
    adminAttendeeTaskTab.navigate(attendeeId);
    adminAttendeeTaskTab.waitForPageLoad();
    adminAttendeeTaskTab.showCompleted();
    adminAttendeeTaskTab.markTaskIncomplete(taskName);

    // Clicking on 'To Do' in the top and verifying task is now completed
    adminAttendeeTaskTab.showToDo();
    adminAttendeeTaskTab.waitForPageLoad();
    Assert.assertTrue(adminAttendeeTaskTab.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);
  }
}
