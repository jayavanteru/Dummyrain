package workflows.rules;

import admin.Libraries.Rules;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.adminPageObjects.registration.EditLoginPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowLoginPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import apps.workflows.workflowsPageObjects.WorkflowRegisterConfirmPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.HashMap;

public class WorkflowRules extends Rules{

    WorkflowsApp wapp;

    private final String appliedField = "Attendee Type";
    private final String appliedValue = "Bob";
    private final String orgName = PropertyReader.instance().getProperty("org");
    private final String eventName = PropertyReader.instance().getProperty("event");
    private String workflowId;

    public WorkflowRules() {
        wapp = new WorkflowsApp();
    }

    @BeforeClass
    public void setup() {
        workflowId = "1519924453505001ozRN";
        AdminRuleSearchPage ruleSearchPage = new AdminRuleSearchPage();
        ruleSearchPage.navigate();
        ruleSearchPage.deleteRuleByRuleDescription(appliedField + ": " + appliedValue);
        }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(firefoxIssue = "RA-25816", chromeIssue = "RA-21972")
    public void rule_formSave() {
        String criteriaField = "State";
        String criteriaFieldId = "formAttendee-stateId";
        String criteriaFieldValue = "Texas";
        String password = generator.generatePassword();
        //set the data to enter the right fields
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put(criteriaFieldId, "TX");
        customValues.put("formAttendee-countryId", "US");
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);

        //set the attendee password so we can login to workflow
        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        EditAttendeePage.getPage().openEditLogin();
        Utils.sleep(1000);
        EditLoginPage.getPage().changePasswordTo(password);

        ruleCreatePage.navigate();

        //if state is Texas
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, "equal to", criteriaFieldValue);
        createRule(ruleCreatePage, appliedField, appliedValue, ruleCriteria);

        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);
        Assert.assertTrue(attendeeCustomTab.isFieldVisible(criteriaField), "the state field is not visible on tab 3, may need to add that");

        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //WORKFLOW STUFF
        //make sure state field is on the form
        String uri = wapp.setupWorkflowAndGetUri(app, workflowId);
        Assert.assertTrue(wapp.getFormPage("contactInfo").containsField(criteriaFieldId), "form does not have the state field, will need to add that");

        String baseUrl = wapp.getUrl(orgName.toLowerCase(), eventName, uri);

        //change state on a workflow form
        wapp.navigate(baseUrl, "login?spoofing=true");
        WorkflowLoginPage.getPage().login(email, password);
        wapp.fillOutFormAndSubmit("contactInfo", customValues);
        Utils.sleep(500);

        //verify rule took affect
        attendeeCustomTab.navigate(attendeeId);
        //assert the form saved the right stuff
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(firefoxIssue = "RA-28619", chromeIssue = "RA-28622")
    public void rule_orderCreation() {
        String conferencePassGroup = "Conference Packages";
        String packageName = "automation package";
        String criteriaField = "Paid in Full";
        String password = generator.generatePassword();
        //set the data to enter the right fields
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);

        //set the attendee password so we can login to workflow
        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        EditAttendeePage.getPage().openEditLogin();
        Utils.sleep(1000);
        EditLoginPage.getPage().changePasswordTo(password);

        ruleCreatePage.navigate();

        //if an order is paid in full
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, true);
        createRule(ruleCreatePage, appliedField, appliedValue, ruleCriteria);

        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);

        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //WORKFLOW STUFF, do dat flow
        //make sure state field is on the form
        String uri = wapp.setupWorkflowAndGetUri(app, workflowId);

        String baseUrl = wapp.getUrl(orgName.toLowerCase(), eventName, uri);

        //change state on a workflow form
        wapp.navigate(baseUrl, "login?spoofing=true");
        WorkflowLoginPage.getPage().login(email, password);
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee.email", email);
        customValues.put("formAttendee.countryId", "US");
        wapp.fillOutFormAndSubmit("contactInfo", customValues);

        //order form wire transfer
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        Utils.sleep(200);

        purchasePage.buyPackage(packageName);
        //credit card will mark it as paid - Rule Criteria*
        purchasePage.enterCCPaymentInfo();
        purchasePage.enterBillingAddress();
        purchasePage.submit();
        WorkflowRegisterConfirmPage.getPage().registrationConfirmed();
        //Utils.sleep(5000);

        //verify rule took affect
        attendeeCustomTab.navigate(attendeeId);
        //assert the form saved the right stuff
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);
    }

}
