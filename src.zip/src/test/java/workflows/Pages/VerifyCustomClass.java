package workflows.Pages;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class VerifyCustomClass {

    private String attendeeId = "1608739971303001rijt";  //attendee username is = "qatester@rainfocus.com"
    private String URI = "PageBuilderCriteriaView";

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
    }

    @Test(groups = {ReportingInfo.PBJ})
    @ReportingInfo(chromeIssue = "RA-48415", firefoxIssue = "RA-48416")
    public void verifyCustomClassTest(){
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(URI);
        Assert.assertTrue(WorkflowPage.getPage().verifyCustomClass("VerifyCustomClass"), "Couldn't find the custom class in the dynamic page");
    }

    @AfterTest
    public void cleanUp() {
        PageConfiguration.getPage().quit();
    }
}