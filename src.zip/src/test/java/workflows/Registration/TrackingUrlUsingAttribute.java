package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AdminAttendeeDemographicsTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class TrackingUrlUsingAttribute {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String workflowId;
    private String URI = "trackingurlparams" + generator.generateString(5);
    private String templateName = "TrackingURLParamenters" + generator.generateString(5);

    CreateEventAttributePage createEventAttribute = CreateEventAttributePage.getPage();
    protected String displayName = "AttributeDN" + generator.generateString(4);
    protected String attributeName = generator.generateName();
    protected String attribute1 = "Attribute1" + generator.generateString(3);
    protected String code1 = "code"+generator.generateString(3);
    protected String param = "param"+generator.generateString(2);
    private String[] value ={attribute1};
    private String[] code ={code1};

    AdminEventAttributesPage attributeSearchPage = AdminEventAttributesPage.getPage();
    private String attributeId;

    @BeforeMethod
    public void setup() {

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        //Create an Attribute
        createEventAttribute.navigate();
        createEventAttribute.createAttributeWithCodeAndParameter( displayName, attributeName, "Checkbox List", "Attendee", value, code, param);
        createEventAttribute.saveAttribute();

        //Get AttributeID
        attributeSearchPage.searchAttribute(attributeName);
        attributeId = attributeSearchPage.getAttributeId(attributeName);

        //Set URL tracking parameters
        OrgEventData.getPage().waitForOrgVisible();
        OrgEventData.getPage().clickEventSelect();
        LegacyEventSettings.getPage().clickOnCog();
        LegacyEventSettings.getPage().setTrackingUrlParams(param+"[att]");
        LegacyEventSettings.getPage().clickSubmit();

        //Create General Attendee Workflow
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().clickAddButton();
        WorkflowsSearchPage.getPage().clickNewTemplate("General Attendee");
        NewWorkflowPage.getPage().setTemplateName(templateName);
        NewWorkflowPage.getPage().setTemplateURI(URI);
        NewWorkflowPage.getPage().clickModalSave();
        workflowId = WorkflowEditBuilderPage.getPage().getWorkflowId();

        WorkflowEditBuilderPage.getPage().openStepEditor("form");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Publish Workflow
        WorkflowEditBuilderPage.getPage().publishWorkflow();

        //Create an attendee
        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);

        //Check tracking URL parameters
        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        AdminAttendeeDemographicsTab.getPage().checkTrackingURL();

        //Spoof into the workflow
        EditAttendeePage.getPage().spoofTo(URI);
        WorkflowContactInfoPage.getPage().cookiesButtonHandle();
        WorkflowContactInfoPage.getPage().click_continue();

    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-21767", firefoxIssue = "RA-27216")
    public void trackingAttributeUrlParameters() {

        String url = PageConfiguration.getPage().getCurrentUrl();
        url += (url.contains("?") ? "&" : "?") + param + "=" + code1;
        PageConfiguration.getPage().navigateTo(url);

        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeDemographicsTab.getPage().assertTrackUrl(param+"="+code1));

    }

    @AfterMethod
    public void cleanUp() {

        adminApp.deleteWorkflow(workflowId);
        adminApp.deleteAttendee(attendeeId);

        //Clearing tracking URL Parameters
        OrgEventData.getPage().clickEventSelect();
        LegacyEventSettings.getPage().clickOnCog();
        LegacyEventSettings.getPage().clearTrackingURl();
        LegacyEventSettings.getPage().clickSubmit();

        //Delete the attribute
        attributeSearchPage.navigate();
        attributeSearchPage.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }
}

