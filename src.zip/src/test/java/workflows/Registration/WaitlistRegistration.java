package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import logs.ReportingInfo;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class WaitlistRegistration {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String workflowId;
    private String packageId;
    protected String packageName = "WaitlistPackage" + generator.generateName();
    protected String code = "Code_1" + generator.generateNumber(10090);
    protected String workflowName = "Waitlist Registration " + RandomStringUtils.randomAlphabetic(5);
    protected String workflowUri = "regUri" + RandomStringUtils.randomAlphabetic(5);

    @BeforeClass
    public void setup(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
    }

    @BeforeMethod
    public void initial() {
       //Create an attendee
        email = generator.generateEmail();
        attendeeId = adminApp.createAttendee(email);

        //Create Waitlist Package
        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().createWaitlistPackage(packageName, code, "Test waitlist package through automation", 0, 1, 1, 50, false, false, 0, false);
        packageId = PackageSearchPage.getPage().getId(packageName);

        //CreateWorkflow
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().clickAddButton();
        WorkflowsSearchPage.getPage().clickNewTemplate("Registration");
        NewWorkflowPage.getPage().setTemplateName(workflowName);
        NewWorkflowPage.getPage().setTemplateURI(workflowUri);
        NewWorkflowPage.getPage().clickModalSave();
        workflowId = WorkflowEditBuilderPage.getPage().getWorkflowId();

        //Contact Info Page
        WorkflowEditBuilderPage.getPage().openStepEditor("Contact Info Page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Order Payments
        WorkflowEditBuilderPage.getPage().openStepEditor("Orders and Payment Page");
        WorkflowStepEditor.getPage().openTab("packages");
        WorkflowStepEditor.getPage().addPackage(packageName);
        WorkflowStepEditor.getPage().saveStep();

        //Account Page
        WorkflowEditBuilderPage.getPage().openStepEditor("Account Page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Publish Workflow
        WorkflowEditBuilderPage.getPage().publishWorkflow();

        //Spoofing
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().spoofTo(workflowUri);

        //WorkflowPageContactInfo
        WorkflowContactInfoPage.getPage().cookiesButtonHandle();
        WorkflowContactInfoPage.getPage().click_continue();

    }

    @Test
    (groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-24494", firefoxIssue = "RA-24495")
    public void WaitlistFunctionality() {

        //Joining the waitlist package
        WorkflowPurchasePage.getPage().joinWaitlist(packageName);

        //Moving the attendee to the top of the waitlist
        WaitlistManagementPage.getPage().navigate();
        WaitlistManagementPage.getPage().ViewWaitlistPackage(packageName);
        WaitlistManagementPage.getPage().moveToTopOfTheList(email);

        //Removing the attendee from the waitlist
        WaitlistManagementPage.getPage().ViewWaitlistPackage(packageName);
        WaitlistManagementPage.getPage().removeWaitlistAttendee(email);

        WaitlistManagementPage.getPage().ViewWaitlistPackage(packageName);
        WaitlistManagementPage.getPage().searchAttendeeOnWaitlistModal(email);
        Assert.assertEquals(WaitlistManagementPage.getPage().searchAttendeeByText(email), false, "Failed to remove attendee");

    }

    @AfterMethod
    public void afterTest() {
        adminApp.deleteWorkflow(workflowId);
        adminApp.deleteAttendee(attendeeId);

        //Deleting Package
        adminApp.deletePackage(packageId);
        PageConfiguration.getPage().quit();
    }
}

