package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.workflows.WorkflowEditPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowCreateAccountPage;
import apps.workflows.workflowsPageObjects.WorkflowLoginPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import apps.workflows.workflowsPageObjects.WorkflowRegisterConfirmPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;

public class AlternatePayment {

    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String baseUrl;
    private String password;
    private String username;
    private String paymentId;
    private String packageId;
    private DataGenerator dataGenerator;
    private String oldJson;

    //may need to be updated after data dup
    private String conferencePassGroup = "Conference Packages";
    private String workflowId;


    @BeforeClass
    public void getWorkflowInfo() {
        workflowId = PropertyReader.instance().getProperty("workflowId");
        dataGenerator = new DataGenerator();
        workflowApp = new WorkflowsApp();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        //use the same browser for all of it

        password = dataGenerator.generatePassword();
        username = dataGenerator.generateValidEmail();
        PropertyReader.instance().setProperty("attendeeEmail", username);
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void stopTest() {
        WorkflowEditPage editPage = WorkflowEditPage.getPage(workflowId);
        if (oldJson != null) {
            editPage.navigate();
            editPage.setJson(oldJson.replace("\n", ""));
            editPage.setComment();
            editPage.submit();
            Utils.sleep(200);
        }
        //delete payment type and package
        if (paymentId != null) {
            adminApp.deletePaymentType(paymentId);
        }
        if (packageId != null) {
            adminApp.deletePackage(packageId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27756", chromeIssue = "RA-27755")
    public void alternatePaymentTest() {
        String packageName = "automation" + dataGenerator.generateString(6);
        String paymentName = "automation" + dataGenerator.generateString(6);

        //create the new payment type and package using the payment type
        paymentId = adminApp.createPaymentType(paymentName);
        packageId = adminApp.createPackage(packageName, paymentName);

        String uri = workflowApp.setupWorkflowAndGetUri(adminApp, workflowId);
        WorkflowEditPage editPage = WorkflowEditPage.getPage(workflowId);

        //add the new payment type and package to the workflow
        editPage.navigate();
        oldJson = editPage.getJson();
        editPage.addPaymentTypeAndPackage(paymentId, packageId);
        editPage.setComment();
        editPage.submit();

        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        baseUrl = workflowApp.getUrl(orgName.toLowerCase(), eventName, uri);
        Utils.sleep(1000);

        //complete the workflow
        workflowApp.navigate(baseUrl, "login?spoofing=true");

        //create account
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        loginPage.createAccount();
        Utils.sleep(200);
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee.email", username);
        customValues.put("password", password);
        customValues.put("confirmpassword", password);
        customValues.put("formAttendee.countryId", "US");

        WorkflowCreateAccountPage createAccountPage = workflowApp.getCreateAccountPage();
        workflowApp.assertCorrectUrlForPage("createaccount");
        workflowApp.fillOutForm(createAccountPage, customValues);
        createAccountPage.submitForm();

        workflowApp.fillOutFormAndSubmit("contactInfo", customValues);

        //order with learning credits
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        Utils.sleep(200);
        purchasePage.buyPackage(packageName);

        //try with valid
        purchasePage.enterPaymentType(paymentId);
        purchasePage.enterBillingAddress();
        purchasePage.submit();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("autoreg/confirm");
        WorkflowRegisterConfirmPage registerConfirmPage = WorkflowRegisterConfirmPage.getPage();

        //assert that we bought the right package
        ArrayList<String> purchases = registerConfirmPage.getPurchases();
        Assert.assertEquals(purchases.size(), 1, "should have only bought one conference pass");
        Assert.assertEquals(purchases.get(0), packageName, "package bought does not match expected");
    }

}
