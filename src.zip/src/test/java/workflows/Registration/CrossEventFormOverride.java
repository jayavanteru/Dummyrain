package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CrossEventFormOverride {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email1 = generator.generateEmail();
    private String email2 = generator.generateEmail();
    private String attendeeId1;
    private String attendeeId2;

    private String URI = "crosseventworkflowtest";

    @BeforeTest
    public void Setup(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-38101", firefoxIssue = "RA-38103")
    public void FormOverrideInWorkflowTest() {

        OrgEventData.getPage().switchToOrg("RainFocus");
        OrgEventData.getPage().switchToEvent("Constellations");

        attendeeId1 = adminApp.createAttendee(email1);
        EditAttendeePage.getPage().spoofTo(URI);

        Assert.assertTrue(WorkflowPage.getPage().eventFormCheck(), "Event form is not being displayed");

        AttendeeSearchPage.getPage().navigate();
        adminApp.deleteAttendee(attendeeId1);

        OrgEventData.getPage().switchToEvent("Test Event");

        attendeeId2 = adminApp.createAttendee(email2);
        EditAttendeePage.getPage().spoofTo(URI);

        Assert.assertTrue(WorkflowPage.getPage().globalFormCheck(), "Global form is not being displayed");

        AttendeeSearchPage.getPage().navigate();
        adminApp.deleteAttendee(attendeeId2);
    }

    @AfterTest
    public void TearUp(){
        PageConfiguration.getPage().quit();
    }
}
