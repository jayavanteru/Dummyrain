package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PageBuilderCriteriaViewInWorkflow {

    private String attendeeId = "1608740006459001a1V3";  //attendee username is = "test.user@rainfocus.net"
    private String URI = "PageBuilderCriteriaView";

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
    }

    @Test(groups = {ReportingInfo.PBJ})
    @ReportingInfo(chromeIssue = "RA-44495", firefoxIssue = "RA-44494")
    public void criteriaView(){
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(URI);
        Assert.assertTrue(WorkflowPage.getPage().verifyTextInWorkflow("Left panel headline"), "PB Criteria failed to display the left panel");
        Assert.assertTrue(WorkflowPage.getPage().verifyTextInWorkflow("This is main text and image"), "PB Criteria failed to display the main headline");
        Assert.assertFalse(WorkflowPage.getPage().verifyTextInWorkflow("Main headline"), "PB Criteria shows wrong users info");
    }

    @AfterTest
    public void cleanUp() {
        PageConfiguration.getPage().quit();
    }
}