package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class RegCodeURLTracking {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    protected String regCodeCategory = "Automationregcode_" + generator.generateString(5);
    protected String regCode = "regcode_" + generator.generateString(5);
    private String regcodeCategoryId;
    private String regcodeId;
    private String regCodeCategoryCode = "code" + generator.generateString(4);
    private String URI = "trackingurlparams" + generator.generateString(5);
    private String workflowId;
    private String templateName = "Tracking regcode URLParamenters" + generator.generateString(5);

    @BeforeMethod
    public void setup() {

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        //RegCodeCategory Creation
        NewRegCodeCategoryPage.getPage().navigate();
        NewRegCodeCategoryPage.getPage().createRegCodeCategory(regCodeCategory, "2", regCodeCategoryCode);
        RegCodeCategoriesSearchPage.getPage().editRegCodeCategory(regCodeCategory);
        regcodeCategoryId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        //Create an attendee
        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);

        OrgEventData.getPage().waitForOrgVisible();
        OrgEventData.getPage().clickEventSelect();
        LegacyEventSettings.getPage().clickOnCog();
        LegacyEventSettings.getPage().setTrackingUrlParams("regcode[rc]");
        LegacyEventSettings.getPage().clickSubmit();

        //Create General Attendee Workflow
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().clickAddButton();
        WorkflowsSearchPage.getPage().clickNewTemplate("General Attendee");
        NewWorkflowPage.getPage().setTemplateName(templateName);
        NewWorkflowPage.getPage().setTemplateURI(URI);
        NewWorkflowPage.getPage().clickModalSave();
        workflowId = WorkflowEditBuilderPage.getPage().getWorkflowId();

        WorkflowEditBuilderPage.getPage().openStepEditor("form");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Publish Workflow
        WorkflowEditBuilderPage.getPage().publishWorkflow();

        //RegCode Creation
        NewRegCodePage.getPage().navigate();
        NewRegCodePage.getPage().createStandardRegCode(regCode, regCodeCategory, "5");
        RegCodeSearchPage.getPage().editRegCode(regCode);
        regcodeId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(URI);

        WorkflowContactInfoPage.getPage().cookiesButtonHandle();
        WorkflowContactInfoPage.getPage().click_continue();

    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-27214", firefoxIssue = "RA-27215")
    public void trackingUrlParameters() {

        String url = PageConfiguration.getPage().getCurrentUrl();
        url += (url.contains("?") ? "&" : "?") + "regcode="+regCode;
        PageConfiguration.getPage().navigateTo(url);

        //Verifying regcode is applied
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().verifyRegCode(regCode));

    }

    @AfterMethod
    public void cleanUp() {
        //Remove Reg Code
        AdminAttendeeOrdersTab.getPage().removeRegCode(regCode);

        //Delete RegCode through api
        RegCodeSearchPage.getPage().deleteRegCodeApi(regcodeId);

        //Delete Workflow and Attendee
        adminApp.deleteWorkflow(workflowId);
        adminApp.deleteAttendee(attendeeId);

        //Delete RegCodeCategory through api
        RegCodeCategoriesSearchPage.getPage().deleteRegCodeCategoryApi(regcodeCategoryId);

        //Clearing tracking URL Parameters
        OrgEventData.getPage().clickEventSelect();
        LegacyEventSettings.getPage().clickOnCog();
        LegacyEventSettings.getPage().clearTrackingURl();
        LegacyEventSettings.getPage().clickSubmit();

        PageConfiguration.getPage().quit();
    }

}

