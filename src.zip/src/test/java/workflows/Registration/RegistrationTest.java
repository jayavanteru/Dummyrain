package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.*;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;

public class RegistrationTest {

    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String baseUrl;
    private String password;
    private String username;
    private String attributeId;
    private DataGenerator dataGenerator;

    //may need to be updated after data dup
    private String conferencePassGroup1 = "Conference Packages";
    private String conferencePackage1 = "automation package";
    private String conferencePackage2 = "Executive VIP Package";


    @BeforeClass
    public void getWorkflowInfo() {
        dataGenerator = new DataGenerator();
        workflowApp = new WorkflowsApp();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();

        password = dataGenerator.generatePassword();
        username = dataGenerator.generateValidEmail();
        PropertyReader.instance().setProperty("attendeeEmail", username);
    }

    @AfterClass
    public void stopTest() {
        //delete newly created attribute
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if (attributeId != null) adminApp.deleteAttribute(attributeId);

        AttendeeSearchPage.getPage().navigate();
        try {
            String id = AttendeeSearchPage.getPage().getIdByEmail(username);
            adminApp.deleteAttendee(id);
        } finally {
            PageConfiguration.getPage().quit();
        }
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27674", chromeIssue = "RA-27671")
    public void happyRegistration() {
        String regCode = "ses'reg'2";
        String generatedName = dataGenerator.generateString(5) + "automation";
        OrgEventData.getPage().setOrgAndEvent();

        String workflowId = PropertyReader.instance().getProperty("workflowId");
        String uri = workflowApp.setupWorkflowAndGetUri(adminApp, workflowId);
        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        baseUrl = workflowApp.getUrl(orgName.toLowerCase(), eventName, uri);

        //add attribute to the create form
        String formId = workflowApp.getFormIdFromURI("createaccount");
        EditFormPage editFormPage = EditFormPage.getPage();
        editFormPage.navigateTo(formId);
        editFormPage.addNewAttribute(EditFormPage.ATTR_TYPE.CHECKBOX, generatedName);
        editFormPage.editList("item1", "item2");
        editFormPage.submitForm();
        FormsSearchPage.getPage().waitForPageLoad();
        PageConfiguration.getPage().refreshPage();
        FormsSearchPage.getPage().waitForPageLoad();
        editFormPage.navigateTo(formId);
        editFormPage.waitForPageLoad();
        editFormPage.expandAttribute(generatedName);
        attributeId = editFormPage.getExpandedAttributeId();

        //get the edited form page for the workflow
        workflowApp.addForm(adminApp.getForm(formId));

        //complete the workflow
        workflowApp.navigate(baseUrl, "login?spoofing=true");

        //create account
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        loginPage.createAccount();
        Utils.sleep(200);
        WorkflowCreateAccountPage createAccountPage = workflowApp.getCreateAccountPage();
        workflowApp.assertCorrectUrlForPage("createaccount");
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee-email", username);
        customValues.put("password", password);
        customValues.put("confirmpassword", password);
        customValues.put("formAttendee-countryId", "US");
        createAccountPage.fillOutForm(customValues);
        Assert.assertTrue(createAccountPage.isDisplayNameMatch(), "did not find the correct display names");
        //verify that the new attribute is on the page
        Assert.assertTrue(createAccountPage.containsField(attributeId), "form did not contain new added field: " + attributeId);
        createAccountPage.submitForm();

        //logout
        workflowApp.assertCorrectUrlForPage("contactInfo");
        WorkflowPage userProfile = workflowApp.getFormPage("contactInfo");
        userProfile.logout();
        workflowApp.navigate(baseUrl, "login");

        //login
        workflowApp.assertCorrectUrlForPage("login");
        loginPage.login(username, password);
        Utils.sleep(500);

        //fill out forms
        workflowApp.fillOutFormAndSubmit("contactInfo", customValues);

        //order form credit card
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        Utils.sleep(200);

        purchasePage.buyPackage(conferencePackage1);
        purchasePage.enterCCPaymentInfo();
        purchasePage.enterBillingAddress();
        purchasePage.SubmitPayment();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("autoreg/confirm");
        WorkflowRegisterConfirmPage registerConfirmPage = WorkflowRegisterConfirmPage.getPage();

        //assert that we bought the right package
        ArrayList<String> purchases = registerConfirmPage.getPurchases();
        Assert.assertEquals(purchases.size(), 1, "should have only bought one conference pass");
        Assert.assertEquals(purchases.get(0), conferencePackage1, "package bought does not match expected");

        //go to my account page
        registerConfirmPage.goToMyAccount();
        Utils.sleep(200);
        WorkflowMyAccountPage.getPage().addOrder();

        //order from wire transfer
        purchasePage.buyPackage(conferencePackage2);

        purchasePage.addRegCode(regCode);
        Utils.sleep(200);
        Assert.assertEquals(purchasePage.getRegCode(), regCode, "did not save the reg code");
        purchasePage.enterPayment();
        purchasePage.submit();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("autoreg/confirm");

        //assert that we bought the bulk package
        purchases = registerConfirmPage.getPurchases();
        Assert.assertEquals(purchases.size(), 1, "should have bought another package");
        Assert.assertEquals(purchases.get(0), conferencePackage2, "package bought does not match expected");
    }

}
