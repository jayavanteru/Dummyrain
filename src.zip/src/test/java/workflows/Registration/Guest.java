package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import logs.ReportingInfo;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class Guest
{

  private List<String> attendeeIdsToDelete = new ArrayList<>();
  private List<String> packageNamesToDelete = new ArrayList<>();
  private List<String> workflowIdsToDelete = new ArrayList<>();
  private Map<String, List<String>> attendeeIdToPurchasedPackageNames = new HashMap<>();

  // these random letters are added because once the package is created, it is created at the org level and will need a new name/code to be created again
  private final String packageName = "Automation Guest Package " + RandomStringUtils.randomAlphabetic(5);
  private final String packageCode = "agp_" + RandomStringUtils.randomAlphabetic(5);

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

    NewPackagePage newPackagePage = new NewPackagePage();
    newPackagePage.navigate();

    packageNamesToDelete.add(packageName);

    newPackagePage.createGuestPackage(packageName, packageCode, "Test guest package created through automation", 10, 4, 1, 0, true, false, true);
    newPackagePage.waitForPageLoad();
  }

  @AfterClass
  public void tearDown() {
    // return to admin tab for cleanup
    PageConfiguration.getPage().switchToTab(0);

    // cleanup created workflows
    AdminApp adminApp = new AdminApp();
    for(String workflowId : workflowIdsToDelete) {
      adminApp.deleteWorkflow(workflowId);
    }

    // cleanup attendee orders
    AdminAttendeeOrdersTab attendeeOrdersTab = new AdminAttendeeOrdersTab();
    attendeeIdToPurchasedPackageNames.forEach((attendeeId, packageNames) -> {
      for(String packName : packageNames) {
        attendeeOrdersTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage();
        attendeeOrdersTab.waitForPageLoad();
        attendeeOrdersTab.selectOrder(packName);
        attendeeOrdersTab.deleteOrders();
        attendeeOrdersTab.selectGuestLineItems(1);
        attendeeOrdersTab.toggleCancellationEmail();
        attendeeOrdersTab.cancelOrder();
      }
    });

    // cleanup created attendees
    for(String attendeeId : attendeeIdsToDelete) {
      adminApp.deleteAttendee(attendeeId);
    }

    // cleanup created packages
    PackageSearchPage packageSearchPage = new PackageSearchPage();
    packageSearchPage.navigate();
    for(String packageName : packageNamesToDelete) {
      packageSearchPage.searchPackage(packageName);
      if(packageSearchPage.isDeletable(0))
        packageSearchPage.deletePackage(0);
    }

    packageSearchPage.waitForPageLoad();

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.REGITEL})
  @ReportingInfo(firefoxIssue = "RA-27300", chromeIssue = "RA-27299")
  public void registerGuestInWorkflow() {
    WorkflowsSearchPage workflowsSearchPage = new WorkflowsSearchPage();
    workflowsSearchPage.navigate();
    workflowsSearchPage.clickAddButton();
    workflowsSearchPage.clickNewTemplate("Registration");

    String workflowName = "Automation Registration " + RandomStringUtils.randomAlphabetic(5);
    String workflowUri = "reg" + RandomStringUtils.randomAlphabetic(5);

    NewWorkflowPage newWorkflowPage = new NewWorkflowPage();
    newWorkflowPage.setTemplateName(workflowName);
    newWorkflowPage.setTemplateURI(workflowUri);
    newWorkflowPage.clickModalSave();

    WorkflowEditBuilderPage workflowBuilder = new WorkflowEditBuilderPage();
    String workflowId = workflowBuilder.getWorkflowId();
    workflowIdsToDelete.add(workflowId);

    workflowBuilder.openStepEditor("Contact Info Page");

    WorkflowStepEditor stepEditor = new WorkflowStepEditor();
    stepEditor.openTab("form");
    stepEditor.selectForm("Guest Attendee Form");
    stepEditor.saveStep();

    workflowBuilder.openStepEditor("Orders and Payment Page");
    stepEditor.openTab("packages");
    stepEditor.addPackage(packageName);
    stepEditor.saveStep();

    workflowBuilder.openStepEditor("Confirmation Email");
    stepEditor.openTab("emails");
    stepEditor.selectEmail("Reg Confirmation");
    stepEditor.saveStep();

    workflowBuilder.openStepEditor("Account Page");
    stepEditor.openTab("form");
    stepEditor.selectForm("Attendee Form");
    stepEditor.saveStep();

    workflowBuilder.publishWorkflow();

    workflowBuilder.exitWorkflow();

    AdminApp adminApp = new AdminApp();
    String email = "automationHostAttendee_" + RandomStringUtils.randomAlphabetic(5) + "@rainfocus.com";
    String firstName = "Automation";
    String lastName = "Host " + RandomStringUtils.randomAlphabetic(5);
    String attendeeId = adminApp.createAttendee(email, firstName, lastName);

    attendeeIdsToDelete.add(attendeeId);

    WorkflowsApp workflowsApp = new WorkflowsApp();
    workflowsApp.setupWorkflowAndGetUri(adminApp, workflowId);

    EditAttendeePage editAttendeePage = new EditAttendeePage();
    editAttendeePage.navigate(attendeeId);
    editAttendeePage.spoofTo(workflowUri);

    HashMap<String, String> customValues = new HashMap<>();
    customValues.put("formAttendee-firstname", firstName);
    customValues.put("formAttendee-lastname", lastName);
    customValues.put("formAttendee-email", email);

    workflowsApp.fillOutFormAndSubmit("contactInfo", customValues);

    WorkflowPurchasePage workflowPurchasePage = new WorkflowPurchasePage();
    workflowPurchasePage.buyPackage(packageName);
    workflowPurchasePage.submit();

    addPurchasedPackageName(attendeeId, packageName);

    // switch back to admin tab to verify guest information
    PageConfiguration.getPage().switchToTab(0);

    AdminAttendeeOrdersTab attendeeOrdersTab = new AdminAttendeeOrdersTab();
    attendeeOrdersTab.navigate(attendeeId);
    attendeeOrdersTab.waitForPageLoad();

    EditGuestModal editGuestModal = new EditGuestModal();
    editGuestModal.openGuestModal();
    String guestFirstName = "Automation";
    String guestLastName = "Guest " + RandomStringUtils.randomAlphabetic(5);
    editGuestModal.editGuestName(0, guestFirstName, guestLastName);
    editGuestModal.closeGuestModal();

    AttendeeSearchPage attendeeSearchPage = new AttendeeSearchPage();
    attendeeSearchPage.navigate();
    attendeeSearchPage.waitForPageLoad();
    attendeeSearchPage.searchFor(guestLastName);
    assertTrue(attendeeSearchPage.isAnySearchResults());
    attendeeSearchPage.clickResult(0);

    String guestEmail = editAttendeePage.getEmail();
    assertTrue(StringUtils.containsIgnoreCase(guestEmail, attendeeId), "the guest attendee did not have the id in the email. guest email: " + guestEmail + " attendee Id: " + attendeeId);
    String guestAttendeeId = editAttendeePage.getAttendeeId();
    attendeeOrdersTab.navigate(guestAttendeeId);
    attendeeOrdersTab.waitForPageLoad();

    String hostName = attendeeOrdersTab.getHostName();
    String hostFullName = firstName + " " + lastName;
    assertEquals(hostFullName, hostName);
  }

  private void addPurchasedPackageName(String attendeeId, String packageName) {
    List<String> packageNames = attendeeIdToPurchasedPackageNames.get(attendeeId);
    if(packageNames == null)
      packageNames = new ArrayList<>();

    packageNames.add(packageName);
    attendeeIdToPurchasedPackageNames.put(attendeeId, packageNames);
  }

}
