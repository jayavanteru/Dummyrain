package workflows.Registration;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import apps.admin.adminPageObjects.registration.PackageSearchPage;
import apps.admin.adminPageObjects.registration.WaitlistManagementPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class WaitListManagement {

  private DataGenerator dataGenerator;
  private NewPackagePage newPackagePage;
  private WaitlistManagementPage waitlistManagementPage;
  private PackageSearchPage packageSearchPage;

  private String packageName1;
  private String packageName2;

  @BeforeClass
  public void setup()
  {
    dataGenerator = new DataGenerator();
    newPackagePage = NewPackagePage.getPage();
    waitlistManagementPage = WaitlistManagementPage.getPage();
    packageSearchPage = PackageSearchPage.getPage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void teardown()
  {
    //Delete Packages
    packageSearchPage.navigate();
    if (packageName1 != null) packageSearchPage.searchPackage(packageName1);
    packageSearchPage.deletePackage(0);
    if (packageName2 != null) packageSearchPage.searchPackage(packageName2);
    packageSearchPage.deletePackage(0);

    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-38490", firefoxIssue = "RA-40912")
  public void WaitListWithPackages()
  {
    // Create Package with auto apply enable
    packageName1 = "auto apply " + dataGenerator.generateName();
    String code1 = dataGenerator.generateString();
    newPackagePage.navigate();
    newPackagePage.createWaitlistPackage(packageName1, code1, dataGenerator.generateString(), 0, 1, 1, 0, false, false, 0, true);

    // Create Package without auto apply enable
    packageName2 = "no auto apply " + dataGenerator.generateName();
    String code2 = dataGenerator.generateString();
    newPackagePage.navigate();
    newPackagePage.createWaitlistPackage(packageName2, code2, dataGenerator.generateString(), 0, 1, 1, 0, false, false, 0, false);

    waitlistManagementPage.navigate();
    waitlistManagementPage.selectPackage(packageName1);
    Assert.assertFalse(waitlistManagementPage.isCurrentlyInvitedSectionVisible(), "Currently Invited section mustn't be visible");

    waitlistManagementPage.selectPackage(packageName2);
    Assert.assertTrue(waitlistManagementPage.isCurrentlyInvitedSectionVisible(), "Currently Invited section must be visible");
  }
}

