package workflows.Registration;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class PackageAllocation {

  private DataGenerator dataGenerator = new DataGenerator();
  private NewPackagePage newPackagePage;
  private NewPackageAllocationPage newPackageAllocationPage;
  private CreateAttendeePage createAttendeePage;
  private EditAttendeePage editAttendeePage;
  private AttendeeSearchPage attendeeSearchPage;
  private AdminAttendeeOrdersTab adminAttendeeOrdersTab;
  private PackageSearchPage packageSearchPage;
  private PackageAllocationSearchPage packageAllocationSearchPage;
  private String packageAllocationNameTest = "Allocation - automated test - DO NOT EDIT";

  @BeforeClass
  public void setup() {

    newPackagePage = NewPackagePage.getPage();
    newPackageAllocationPage = NewPackageAllocationPage.getPage();
    createAttendeePage = CreateAttendeePage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    adminAttendeeOrdersTab = AdminAttendeeOrdersTab.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    packageSearchPage = PackageSearchPage.getPage();
    packageAllocationSearchPage = PackageAllocationSearchPage.getPage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-35911", firefoxIssue = "RA-38733")
  public void packageAllocation() {

    String packageName = dataGenerator.generateName();
    String packageCode = dataGenerator.generateString();
    String attendeeStatus = "Attended";
    String attendeeFirstName = dataGenerator.generateName();
    String attendeeLastName = dataGenerator.generateName();
    String attendeeEmail = dataGenerator.generateEmail();

    //Create Package
    newPackagePage.navigate();
    newPackagePage.createUserPackage(packageName, packageCode, "", 123, 1, 1, 0, true, false);
    newPackagePage.submit();

    // Validate if exists Package Allocation, if not create one
    packageAllocationSearchPage.navigate();
    if(packageAllocationSearchPage.searchPackageAllocation(packageAllocationNameTest))
    {
      packageAllocationSearchPage.accessPackageAllocation(packageAllocationNameTest);
    }
    else
    {
      newPackageAllocationPage.navigate();
      newPackageAllocationPage.setPackageAllocationName(packageAllocationNameTest);
      newPackageAllocationPage.selectCriteria("Attendee Status", attendeeStatus);
    }
    newPackageAllocationPage.selectPackage(packageName);
    newPackageAllocationPage.submit();

    // Create Attendee and assign Attendee Status
    createAttendeePage.navigate();
    createAttendeePage.fillOutForm(attendeeEmail, attendeeFirstName, attendeeLastName);
    editAttendeePage.selectAttendeeStatus(attendeeStatus);
    editAttendeePage.saveAttendeeProfile();

    editAttendeePage.goToOrdersTab();
    Assert.assertTrue(adminAttendeeOrdersTab.verifyPackageOrdered(packageName), "Package has not been assigned correctly to the attendee");

    // Delete Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.clickResult(0);
    editAttendeePage.removeAttendeeStatus();
    editAttendeePage.saveAttendeeProfile();
    attendeeSearchPage.navigate();
    attendeeSearchPage.deleteAttendeeByName(attendeeFirstName);

    // Delete Package
    packageSearchPage.navigate();
    packageSearchPage.searchPackage(packageName);
    packageSearchPage.deletePackage(0);
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-39182", firefoxIssue = "RA-43437")
  public void togglePackageAllocator()
  {
    /**
     * Important to note:
     * The PACKAGE_ALLOCATION feature flag needs to be turned on
     * The event needs to be an UN PAID event (so paid on the events table in the DB needs to be false)
    */
    String attendeeFirstName = dataGenerator.generateName();
    String attendeeLastName = dataGenerator.generateName();
    String attendeeEmail = dataGenerator.generateValidEmail();
    String name = "TEST AUTOMATION - DO NOT DELETE";
    String packageName = "Virtual Pass";

    // find package allocator
    packageAllocationSearchPage.navigate();
    packageAllocationSearchPage.searchPackageAllocation(name);
    packageAllocationSearchPage.accessPackageAllocation(name);

    //  make sure enabled is ON
    newPackageAllocationPage.enable();
    newPackageAllocationPage.submit();

    // Create Attendee and assign Confirmed Status
    createAttendeePage.navigate();
    createAttendeePage.fillOutForm(attendeeEmail, attendeeFirstName, attendeeLastName);
    editAttendeePage.selectAttendeeStatus("Attended");
    editAttendeePage.saveAttendeeProfile();

    // make sure waitlist auto apply is applied
    editAttendeePage.goToOrdersTab();
    Assert.assertTrue(editAttendeePage.isTextOnPage(packageName), "Package not applied");
    adminAttendeeOrdersTab.deleteOrder(packageName);

    // change status
    editAttendeePage.selectAttendeeStatus("Pending");
    editAttendeePage.saveAttendeeProfile();

    editAttendeePage.refreshPage();

    // make sure package is not applied
    Assert.assertFalse(editAttendeePage.isTextOnPage(packageName), "Package is on page when it shouldn't be");
  }

}
