package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowNominationPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class NominationWorkflow {

    CreateEventAttributePage createEventAttribute = CreateEventAttributePage.getPage();
    AdminEventAttributesPage attributeSearchPage = AdminEventAttributesPage.getPage();

    private AdminApp adminApp = new AdminApp();
    private DataGenerator generator = new DataGenerator();

    //Attendee
    private String nominatorEmail = generator.generateEmail();
    private String nominatorAttendeeId;
    private String nomineeAttendeeID;

    private String nomineeEmail = generator.generateEmail();
    private String firstName = "nomineefName" + generator.generateString(3);
    private String lastName = "nomineelname" + generator.generateString(3);

    //Attribute
    private String AttributeId = "1600985166H3a0c47674";
    private String AttributeName = "Nomination Program";

    private String valueItem = "value" + generator.generateString(4);
    private String[] value ={valueItem};

    //Form
    private String formID;
    private String formName = "Form" + generator.generateString(5);
    private String formCode = "code" + generator.generateNumber(5);

    //WorkingReportName
    private String workingReport = "WorkingReport" + generator.generateString(5);
    private String workingReportID;

    //Workflow
    private String workflowId;
    protected String URI = "NominationURI" + generator.generateString(6);
    private final String workflowName = "AutomationNomTest " + generator.generateString(5);

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        //Get Event Id
        OrgEventData.getPage().waitForOrgVisible();
        OrgEventData.getPage().clickEventSelect();
        LegacyEventSettings.getPage().clickOnCog();
        String eventId = LegacyEventSettings.getPage().geteventid();

        //Add value to Nomination attribute and get the value Id
        createEventAttribute.navigateToExistingAttribute(AttributeId);
        createEventAttribute.addOptions(value);
        createEventAttribute.saveAttribute();
        createEventAttribute.navigateToExistingAttribute(AttributeId);
        String nominationValueId = createEventAttribute.getAttributeValueId(valueItem);

        //Create form
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().addItem();
        NewFormPage.getPage().setAttendeeFormSettings(formName, formCode);
        EditFormPage.getPage().addExistingAttribute("First Name");
        EditFormPage.getPage().justWait();
        EditFormPage.getPage().addExistingAttribute("Last Name");
        EditFormPage.getPage().justWait();
        EditFormPage.getPage().addExistingAttribute("Email");
        EditFormPage.getPage().justWait();
        EditFormPage.getPage().addAttributeFromReadOnlySection("Nominator Name");
        EditFormPage.getPage().addValuesToAttribute(valueItem);
        EditFormPage.getPage().addExistingAttribute("Nominator Email");
        EditFormPage.getPage().addValuesToAttribute(valueItem);
        EditFormPage.getPage().addExistingAttribute("Nomination Program");
        EditFormPage.getPage().addValuesToAttribute(valueItem);
        EditFormPage.getPage().submitForm();
        FormsSearchPage.getPage().search(formName);
        formID = FormsSearchPage.getPage().getId(formName);

        //Create Working Report
        EditWorkingReportPage.getPage().navigate();
        EditWorkingReportPage.getPage().workingReportName(workingReport);
        EditWorkingReportPage.getPage().selectFromTypeDropDown("Nomination");
        EditWorkingReportPage.getPage().clickShowLoggedCheckBox();
        EditWorkingReportPage.getPage().clickShowSubmissionCheckBox();
        EditWorkingReportPage.getPage().selectForm(formName);
        EditWorkingReportPage.getPage().setEditType("inline");
        EditWorkingReportPage.getPage().sqlData(eventId, nominationValueId);
        EditWorkingReportPage.getPage().columnConfigData();
        EditWorkingReportPage.getPage().clickSubmit();
        workingReportID = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];

        //Create Nomination Workflow
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().clickAddButton();
        WorkflowsSearchPage.getPage().clickNewTemplate("Nomination");
        NewWorkflowPage.getPage().setTemplateName(workflowName);
        NewWorkflowPage.getPage().setTemplateURI(URI);
        NewWorkflowPage.getPage().clickShowAdvancedSettings();
        NewWorkflowPage.getPage().selectNominationProgramDropdown(valueItem);
        NewWorkflowPage.getPage().clickModalSave();
        workflowId = WorkflowEditBuilderPage.getPage().getWorkflowId();

         //Nomination home page
        WorkflowEditBuilderPage.getPage().openStepEditor("nomination home page");
        WorkflowStepEditor.getPage().openTab("live table");
        WorkflowStepEditor.getPage().selectForm(workingReport);
        WorkflowStepEditor.getPage().saveStep();

        //Self nomination node
        WorkflowEditBuilderPage.getPage().openStepEditor("self nomination page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Nomination page
        WorkflowEditBuilderPage.getPage().openStepEditor("nomination page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Publish workflow
        WorkflowEditBuilderPage.getPage().publishWorkflow();

        //Nominator Email
        nominatorAttendeeId = adminApp.createAttendee(nominatorEmail);
        EditAttendeePage.getPage().spoofTo(URI);

    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-18985", firefoxIssue = "RA-27341")
    public void NominationWorkflowValidation() {

       //Nominate Customer
        WorkflowNominationPage.getPage().selectNominateButton("Nominate a Customer");
        WorkflowNominationPage.getPage().addEmail(nomineeEmail);
        WorkflowNominationPage.getPage().enterName(firstName, lastName);
        WorkflowNominationPage.getPage().clickSubmit();
        WorkflowNominationPage.getPage().justWait();
//        WorkflowNominationPage.getPage().clickBackButton();
        Assert.assertTrue(WorkflowNominationPage.getPage().validateEmailAddress(nomineeEmail), "Nominee email is not created");

        //Nominate Self
        WorkflowNominationPage.getPage().selectNominateButton("Nominate Myself");
        WorkflowNominationPage.getPage().clickContinue();
        Assert.assertTrue(WorkflowNominationPage.getPage().validateEmailAddress(nominatorEmail), "Nominator email is missing");
        Assert.assertTrue(WorkflowNominationPage.getPage().validateEmailAddress(nomineeEmail), "Nominee email is not created");

    }

    @AfterMethod
    public void delete(){

        //delete attribute value
        createEventAttribute.navigateToExistingAttribute(AttributeId);
        createEventAttribute.deleteAttributeOptionValue(valueItem);
        createEventAttribute.saveAttribute();

        //Navigate to Nominee Attendee profile
        AttendeeSearchPage.getPage().navigate();
        nomineeAttendeeID = AttendeeSearchPage.getPage().getIdByEmail(nomineeEmail);

        //delete nominee
        adminApp.deleteAttendee(nomineeAttendeeID);

        //Delete Workflow
        adminApp.deleteWorkflow(workflowId);

        //delete workingreport
        adminApp.deleteWorkingReport(workingReportID);

        //delete form
        adminApp.deleteForm(formID);

        //delete nominator
        adminApp.deleteAttendee(nominatorAttendeeId);

        PageConfiguration.getPage().quit();
    }

}
