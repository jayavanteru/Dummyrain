package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;


public class TestWorkFlowReg {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String workflowId;
    private String packageId;

    protected String packageName = "PackageNew_" + generator.generateName();
    protected String discountName = "discount_" + generator.generateString(5);
    protected String code = "Code_1" + generator.generateNumber(10090);
    protected String regCodeCategory = "sampleregcode_" + generator.generateString(5);
    protected String regCode = "regcode_" + generator.generateString(5);
    protected String regCodeCategoryCode = "code2" + generator.generateString(4);
    protected String URI = "automationuri" + generator.generateString(6);
    String paymentTypes[] = {"Check"};

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-24209", firefoxIssue = "RA-24212")
    public void RegisterAttendeeInWorkflow() {

        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        Assert.assertEquals(AttendeeSearchPage.getPage().findAttendeeByText(email), true, "Failed to match, Attendee is not created sucessfully");

        //Package Creation
        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().enterStandardPackageData(packageName, code, "User", 100);
        NewPackagePage.getPage().submit();
        packageId = PackageSearchPage.getPage().getId(packageName);
        Assert.assertEquals(PackageSearchPage.getPage().searchForPackageByText(packageName), true, "Package submission failed");

        //Discount Creation
        CreateDiscountPage.getPage().navigate();
        CreateDiscountPage.getPage().createStandardDiscount(discountName, "Dollars Off", "50", packageName);
        CreateDiscountPage.getPage().submit();
        DiscountSearchPage.getPage().searchForDiscount(discountName);
      //  Utils.waitForTrue(()->DiscountSearchPage.getPage().searchDiscountByText(discountName));
        Assert.assertTrue(DiscountSearchPage.getPage().searchDiscountByText(discountName),"Failed to create discount");

        //RegCodeCategory Creation
        NewRegCodeCategoryPage.getPage().navigate();
        NewRegCodeCategoryPage.getPage().createRegCodeCategory(regCodeCategory, "2", regCodeCategoryCode);
        RegCodeCategoriesSearchPage.getPage().searchForRegCodeCateogry(regCodeCategory);
        Assert.assertTrue(RegCodeCategoriesSearchPage.getPage().searchRegCodeCategoryByText(regCodeCategory), "Failed to create Reg Code Category");

        //RegCode Creation
        NewRegCodePage.getPage().navigate();
        NewRegCodePage.getPage().createRegCode(regCode, regCodeCategory, "2", discountName);
        RegCodeSearchPage.getPage().searchForRegCode(regCode);
        Assert.assertTrue(RegCodeSearchPage.getPage().searchRegCodeByText(regCode), "Failed to create Reg Code");

        //Workflow Creation
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().clickAddButton();
        WorkflowsSearchPage.getPage().clickNewTemplate("Registration");
        NewWorkflowPage.getPage().setTemplateURI(URI);
        NewWorkflowPage.getPage().clickModalSave();
        workflowId = WorkflowEditBuilderPage.getPage().getWorkflowId();

        //Contact Info Page
        WorkflowEditBuilderPage.getPage().openStepEditor("Contact Info Page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Order Payments
        WorkflowEditBuilderPage.getPage().openStepEditor("Orders and Payment Page");
        WorkflowStepEditor.getPage().openTab("packages");
        WorkflowStepEditor.getPage().addPackage(packageName);
        WorkflowStepEditor.getPage().saveStep();

        //Account Page
        WorkflowEditBuilderPage.getPage().openStepEditor("Account Page");
        WorkflowStepEditor.getPage().openTab("form");
        WorkflowStepEditor.getPage().selectForm("Attendee Form");
        WorkflowStepEditor.getPage().saveStep();

        //Publish Workflow
        WorkflowEditBuilderPage.getPage().publishWorkflow();
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().searchFor(URI);
        Assert.assertEquals(WorkflowsSearchPage.getPage().workflowExists(URI), true, "Failed to submit the Workflow URI");

        //Spoofing
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().spoofTo(URI);
        Assert.assertTrue(WorkflowPage.getPage().spoofCheck(), "Failed to open the expeted constellation page with expected Attendee details");

        //Workflow Page
        WorkflowContactInfoPage.getPage().cookiesButtonHandle();
        WorkflowContactInfoPage.getPage().click_continue();
        WorkflowPurchasePage.getPage().addRegCode(regCode);
        Assert.assertTrue(WorkflowPurchasePage.getPage().regCodeCheck(), "Failed to add reg discount");
        Assert.assertTrue(WorkflowPurchasePage.getPage().verifyDiscountAppliedOnWorkflow(discountName));
        WorkflowPurchasePage.getPage().buyPackage(packageName);
        WorkflowPurchasePage.getPage().fillOutMultiplePayments(1, paymentTypes);
        WorkflowPurchasePage.getPage().enterBillingAddress();
        WorkflowPurchasePage.getPage().SubmitPayment();
        Assert.assertTrue(WorkflowPurchasePage.getPage().workflowSubmissionCheck(), "Failed to submit the order");
 }

    @AfterMethod
    public void afterTest() {

       //Deleting package on the admin side
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        AttendeeSearchPage.getPage().clickResult(0);
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().selectOrder(packageName);
        AdminAttendeeOrdersTab.getPage().deleteOrders();
        AdminAttendeeOrdersTab.getPage().cancelOrder();

        adminApp.deleteAttendee(attendeeId);

        //RegCode Delete
        RegCodeSearchPage.getPage().GoTo();
        RegCodeSearchPage.getPage().editRegCode(regCode);
        String regcodeid = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];
        RegCodeSearchPage.getPage().deleteRegCodeApi(regcodeid);

        //Delete Discount
        DiscountSearchPage.getPage().GoTo();
        DiscountSearchPage.getPage().editDiscount(discountName);
        String discountId = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];
        DiscountSearchPage.getPage().deleteDiscountApi(discountId);

        //RegCodeCategory Delete
        RegCodeCategoriesSearchPage.getPage().GoTo();
        RegCodeCategoriesSearchPage.getPage().editRegCodeCategory(regCodeCategory);
        String regcodeCategoryid = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];
        RegCodeCategoriesSearchPage.getPage().deleteRegCodeCategoryApi(regcodeCategoryid);

        adminApp.deletePackage(packageId); //delete package
        adminApp.deleteWorkflow(workflowId); //delete workflow

        PageConfiguration.getPage().quit();
    }
}