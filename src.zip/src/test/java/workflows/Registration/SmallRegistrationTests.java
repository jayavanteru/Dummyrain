package workflows.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowLoginPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import apps.workflows.workflowsPageObjects.WorkflowRegisterConfirmPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;

public class SmallRegistrationTests {

    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String baseUrl;
    private String password;
    private String username;
    private String attendeeId;
    private String attributeId;
    private DataGenerator dataGenerator;
    String regCode = "ses'reg'2";
    ArrayList<String> purchases;

    //may need to be updated after data dup
    private String conferencePassGroup1 = "Conference Packages";
    private String conferencePackage1 = "automation package";
    private String conferencePackage2 = "Executive VIP Package";


    @BeforeClass
    public void getWorkflowInfo() {
        dataGenerator = new DataGenerator();
        workflowApp = new WorkflowsApp();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login(); //log in
        OrgEventData.getPage().setOrgAndEvent();

        password = dataGenerator.generatePassword(); //create password
        username = dataGenerator.generateValidEmail(); //create email
        PropertyReader.instance().setProperty("attendeeEmail", username);
        attendeeId = adminApp.createAttendee(username, password);

        OrgEventData.getPage().setOrgAndEvent(); //login

        String workflowId = PropertyReader.instance().getProperty("workflowId"); //get set workflow id
        String uri = workflowApp.setupWorkflowAndGetUri(adminApp, workflowId); //go to workflow in admin and get the JSON
        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        baseUrl = workflowApp.getUrl(orgName.toLowerCase(), eventName, uri);


        //login
        workflowApp.navigate(baseUrl, "login?spoofing=true");
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        workflowApp.assertCorrectUrlForPage("login");
        loginPage.login(username, password);
        Utils.sleep(500);
        workflowApp.navigate(baseUrl, "order");
        Utils.sleep(200);

        //order form credit card
        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();
        purchasePage.buyPackage(conferencePackage1);
        purchasePage.enterCCPaymentInfo();
        purchasePage.enterBillingAddress();
        purchasePage.SubmitPayment();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("autoreg/confirm");

        //assert that we bought the right package
    }

    @AfterClass
    public void stopTest() {
        AttendeeSearchPage.getPage().navigate();
        String id = AttendeeSearchPage.getPage().getIdByEmail(username);
        adminApp.deleteAttendee(id);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26129", chromeIssue = "RA-17946")
    public void onePackageRegistration() {

        WorkflowRegisterConfirmPage registerConfirmPage = WorkflowRegisterConfirmPage.getPage();
        ArrayList<String> purchases = registerConfirmPage.getPurchases();
        Assert.assertEquals(purchases.size(), 1, "should have only bought one conference pass");
        Assert.assertEquals(purchases.get(0), conferencePackage1, "package bought does not match expected");
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27767", chromeIssue = "RA-27766")
    public void twoPackageRegistration() {
        //go to my account page

        workflowApp.navigate(baseUrl, "login?spoofing=true");
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        workflowApp.assertCorrectUrlForPage("login");
        loginPage.login(username, password);
        Utils.sleep(500);
        workflowApp.navigate(baseUrl, "order");
        Utils.sleep(200);

        WorkflowPurchasePage purchasePage = WorkflowPurchasePage.getPage();

        //order from wire transfer
        purchasePage.buyPackage(conferencePackage2);

        purchasePage.addRegCode(regCode);
        Utils.sleep(200);
        Assert.assertEquals(purchasePage.getRegCode(), regCode, "did not save the reg code");
        purchasePage.enterPayment();
        purchasePage.SubmitPayment();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("autoreg/confirm");

        //assert that we bought the bulk package
        WorkflowRegisterConfirmPage registerConfirmPage = WorkflowRegisterConfirmPage.getPage();
        purchases = registerConfirmPage.getPurchases();
        Assert.assertEquals(purchases.size(), 1, "should have bought another package");
        Assert.assertEquals(purchases.get(0), conferencePackage2, "package bought does not match expected");
    }

}
