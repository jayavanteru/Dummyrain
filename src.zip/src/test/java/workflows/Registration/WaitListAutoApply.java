package workflows.Registration;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.adminPageObjects.registration.WaitlistManagementPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class WaitListAutoApply {

  private DataGenerator dataGenerator;
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private WaitlistManagementPage waitlistManagementPage;
  private AdminAttendeeOrdersTab adminAttendeeOrdersTab;

  private String packageName = "automation package waitlist - do not edit";
  private String workflowCode = "automationWorkflowDoNotEdit";
  private String attendee1Id = "";
  private String attendee2Id = "";

  @BeforeClass
  public void setup()
  {
    dataGenerator = new DataGenerator();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    waitlistManagementPage = WaitlistManagementPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    adminAttendeeOrdersTab = AdminAttendeeOrdersTab.getPage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void teardown()
  {
    // In case the test fails, we need to be sure that the orders are still
    // deleted or removed from the waitlist.
    editAttendeePage.navigate(attendee1Id);
    editAttendeePage.goToOrdersTab();
    try {
      adminAttendeeOrdersTab.deleteOrder(packageName);
    } catch (Exception error) {
      System.err.println("An exception was thrown");
    }

    editAttendeePage.navigate(attendee2Id);
    editAttendeePage.goToOrdersTab();
    try {
      adminAttendeeOrdersTab.cancelWaitlist(packageName);
    } catch (Exception error) {
      System.err.println("An exception was thrown");
    }
    try {
      adminAttendeeOrdersTab.deleteOrder(packageName);
    } catch (Exception error) {
      System.err.println("An exception was thrown");
    }

    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-37681", firefoxIssue = "RA-41708")
  public void WaitListWithPackages()
  {
    attendeeSearchPage.navigate();
    attendeeSearchPage.search();
    attendeeSearchPage.clickResult(0);
    editAttendeePage.goToOrdersTab();
    adminAttendeeOrdersTab.addOrder();
    adminAttendeeOrdersTab.selectPackage(packageName);
    adminAttendeeOrdersTab.clickNextOnAddOrderModal();
    adminAttendeeOrdersTab.setComment(dataGenerator.generateString());
    adminAttendeeOrdersTab.submitOrder();
    attendee1Id = editAttendeePage.getAttendeeId();

    //Second Attendee - join waitlist
    attendeeSearchPage.navigate();
    attendeeSearchPage.search();
    attendeeSearchPage.clickResult(1);
    attendee2Id = editAttendeePage.getAttendeeId();
    editAttendeePage.spoofTo(workflowCode);
    editAttendeePage.acceptCookiesIfExistInSpoofPackage();
    editAttendeePage.joinWaitListInSpoofPackage(packageName);
    editAttendeePage.closeSpoof();

    //First Attendee - cancel order
    editAttendeePage.navigate(attendee1Id);
    editAttendeePage.goToOrdersTab();
    adminAttendeeOrdersTab.deleteOrder(packageName);

    // Waitlist validate numbers
    waitlistManagementPage.navigate();
    waitlistManagementPage.selectPackage(packageName);
    Assert.assertEquals(waitlistManagementPage.getCurrentWaitlistValue(), "1", "Current waitlist value must be 1");
    waitlistManagementPage.setNumberOfInvitations("1");
    waitlistManagementPage.clickSendEmail();
    waitlistManagementPage.selectPackage(packageName);
    Assert.assertEquals(waitlistManagementPage.getCurrentWaitlistValue(), "0", "Current waitlist value must be 0");

    //Second Attendee -  Cancel order
    editAttendeePage.navigate(attendee2Id);
    editAttendeePage.goToOrdersTab();
    Assert.assertTrue(adminAttendeeOrdersTab.verifyPackageOrdered(packageName), "Package must be paid");
  }
}

