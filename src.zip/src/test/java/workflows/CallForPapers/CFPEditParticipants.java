package workflows.CallForPapers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowCFPHome;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class CFPEditParticipants {

    AdminApp adminApp = new AdminApp();

    private String sessionTitle1 = "Breakout Session Role Limit Test - DO NOT EDIT";
    private String sessionTitle2 = "Keynote Session Overall Role Limit Test - DO NOT EDIT";
    private String attendeeEmail = "trogdortestuser@rainfocus.com";
    private String participant = "Stephanie Hernandez";
    private String role = "Speaker";
    private String role2 = "MR Test Role";
    private String TestEmail = "tester@gmail.com";
    private String role3 = "Trogdor Speaker";
    private String session1 = "Breakout Session Role Limit Test - DO NOT EDIT";
    private String session2 = "Keynote Session Overall Role Limit Test - DO NOT EDIT";

    private WorkflowPage workflow = WorkflowPage.getPage();


    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-51177", firefoxIssue = "RA-19892")
    public void CFPEditParticipants(){
        adminApp.spoofIntoWorkflow(attendeeEmail, "cfpgeneral", 1);

        //Edits the participant for Breakout session, verifies roles
        workflow.editParticipantSession(session1, participant);
        Assert.assertTrue(workflow.verifyParticipantsRole(), "Stephanie Hernandez doesn't have the MR Test Role");
        Assert.assertTrue(workflow.canMRTestRollBeAssigned(), "MR Test role is an option and it should not be");
        workflow.cancelAddParticipantModel();
        workflow.clickEditParticipant(participant);
        workflow.setParticipantRole(role);
        workflow.saveParticipantEdits();
        Assert.assertFalse(workflow.canMRTestRollBeAssigned(), "The MR Test role can't be assigned");
        workflow.cancelAddParticipantModel();

        //Set the Stephanie Hernandez participant back to MR Test Role
        workflow.clickEditParticipant(participant);
        workflow.setParticipantRole(role2);
        workflow.saveParticipantEdits();

        //Verifies that adding Trogdor speaker role requires a rainfocus email
        workflow.addParticipantWithInvalidEmail(TestEmail, role3);
        Assert.assertTrue(workflow.didAddParticpantErrorDisplay(), "An error should have displayed saying email must end with @rainfocus.com");
        workflow.cancelAddParticipantModel();

        //Verifies that the add participant button is not on the Keynote session
        workflow.clickBackButton();
        workflow.editParticipantSession(session2,participant);
        Assert.assertFalse(workflow.isAddParticipantButtonDisplayed(), "The Add Participant buttons should not be visible");
    }

}
