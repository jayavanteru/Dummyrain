package workflows.CallForPapers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.*;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;
import java.util.List;

public class CallForPapersTest {

    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String baseUrl;
    private String password;
    private String username;
    private String SessionId;
    private DataGenerator dataGenerator;

    @BeforeClass
    public void getWorkflowInfo() {
        dataGenerator = new DataGenerator();
        workflowApp = new WorkflowsApp();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();

        password = dataGenerator.generatePassword();
        username = dataGenerator.generateValidEmail();
        PropertyReader.instance().setProperty("attendeeEmail", username);
    }

    @AfterClass
    public void stopTest() {

        AttendeeSearchPage.getPage().navigate();
        String id = AttendeeSearchPage.getPage().getIdByEmail(username);
        adminApp.deleteAttendee(id);

        adminApp.deleteSession(SessionId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19888", firefoxIssue = "RA-20969")
    public void simpleCFP() {
        //String generatedName = dataGenerator.generateString(5) + "automation";
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        PropertyReader.instance().setProperty("event", "Trogdor Automation");
        PropertyReader.instance().setProperty("callForPapersWorkflowId", "1610576933978001q714");

        String sessionTitle = "BPAutomation"+dataGenerator.generateString(5);
        String callForPapersWorkflowIdId = PropertyReader.instance().getProperty("callForPapersWorkflowId");
        String uri = workflowApp.setupWorkflowAndGetUri(adminApp, callForPapersWorkflowIdId);
        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        baseUrl = workflowApp.getUrl(orgName.toLowerCase(), eventName, uri);

        //complete the workflow
        workflowApp.navigate(baseUrl, "login?spoofing=true");

        //create account
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        loginPage.createAccount();
        Utils.sleep(200);
        WorkflowCreateAccountPage createAccountPage = workflowApp.getCreateAccountPage();
        workflowApp.assertCorrectUrlForPage("createaccount");
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee-email", username);
        customValues.put("password", password);
        customValues.put("confirmpassword", password);
        customValues.put("formSession-title", sessionTitle);
        //customValues.put("formAttendee.countryId", "US");
        createAccountPage.fillOutForm(customValues);
       // Assert.assertTrue(createAccountPage.isDisplayNameMatch(), "did not find the correct display names");
        //verify that the new attribute is on the page
        //Assert.assertTrue(createAccountPage.containsField(attributeId), "form did not contain new added field: " + attributeId);
        createAccountPage.submitForm();

        //logout
        workflowApp.assertCorrectUrlForPage("cfpHome");
        WorkflowPage userProfile = workflowApp.getFormPage("session");
        userProfile.logoutNOMOBILENAV();
        workflowApp.navigate(baseUrl, "login");

        //login
        workflowApp.assertCorrectUrlForPage("login");
        loginPage.login(username, password);
        Utils.sleep(500);

        //cfpHome start
        workflowApp.assertCorrectUrlForPage("cfpHome");
        WorkflowCFPHome.getPage().start();

        //fill out forms
        workflowApp.fillOutFormAndSubmit("session", customValues);

        //cfpConfirmation
        //workflowApp.assertCorrectUrlForPage("cfpConfirmation");
        PageConfiguration.getPage().waitForPageLoad();
        SessionId = WorkflowCFPConfirmation.getPage().getSessionId();
        WorkflowCFPConfirmation.getPage().home();

        //confirmation page
        workflowApp.assertCorrectUrlForPage("cfpHome");
        List<String> Titles = WorkflowCFPHome.getPage().GetTitles();
        Assert.assertEquals(Titles.size(),1 );
        Assert.assertEquals(Titles.get(0), sessionTitle);


    }
}
