package workflows.CallForPapers;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowCFPHome;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class CallForPapersEditSession {

    private String sessionTitle1 = "CFP Session Edit";
    private String sessionTitle2 = "Edit Session CFP";
    private final String ATTENDEE_ID = "1616772721691001OfHh";
    private final String WORKFLOW = "Call for Papers No Branding";

    private WorkflowCFPHome cfpHome = WorkflowCFPHome.getPage();
    private WorkflowPage workflow = WorkflowPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        NavigationBar.getPage().collapse();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19891", firefoxIssue = "RA-43773")
    public void cfpEditSession() {
        EditAttendeePage.getPage().navigate(ATTENDEE_ID);
        EditAttendeePage.getPage().spoofToWidget(WORKFLOW);
        PageConfiguration.getPage().switchToTab(1);

        List<String> titles = cfpHome.GetTitles();
        String newTitle = sessionTitle1;
        for(String title : titles) {
            if(title.equals(sessionTitle1)) {
                cfpHome.clickEditSession(title);
                newTitle = sessionTitle2;
                break;
            }
            if(title.equals(sessionTitle2)) {
                cfpHome.clickEditSession(title);
                newTitle = sessionTitle1;
                break;
            }
        }
        cfpHome.setSessionTitle(newTitle);
        cfpHome.clickContinue();
    Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("cfpHome"), "Continue button did not navigate back to cfpHome page");
    Assert.assertTrue(cfpHome.proposalIsOnPageByTitle(newTitle), "Proposal title was not updated properly");

    List<String> participants = cfpHome.getParticipants();
        String participant = participants.get(0);
        cfpHome.clickEditParticipant(participant);

        String role = workflow.getParticipantRole(participant);
        workflow.clickEditParticipant(participant);
        if(role.equals("Speaker")) {
            workflow.setParticipantRole("Co-Speaker");
        } else {
            workflow.setParticipantRole("Speaker");
        }
        workflow.saveParticipantEdits();
        String newRole = workflow.getParticipantRole(participant);
    Assert.assertNotEquals(role, newRole, "Role editing did not save");
        workflow.clickContinue();
    Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("cfpHome"), "Continue button did not navigate back to cfpHome page");
    }
}
