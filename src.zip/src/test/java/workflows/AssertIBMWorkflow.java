package workflows;

import apps.PageConfiguration;
import apps.workflows.workflowsPageObjects.WorkflowCreateAccountPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AssertIBMWorkflow {
    
    private String IBM_Workflow_URL = "https://events.tools.ibm.com/pages/ibm/tierstemplate1/1581037797007001PJAd.html";

    @BeforeClass
    public void getWorkflowInfo() {
        PageConfiguration.getPage().navigateTo(IBM_Workflow_URL);
    }

//    @Test(groups = {ReportingInfo.HOTELSTRATION})
//    @ReportingInfo(firefoxIssue = "RA-34107", chromeIssue = "RA-34109")
    public void TestToVerifyIBMWorkflowLoads() {
        
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().assertRegisterNow());
        WorkflowCreateAccountPage.getPage().clickRegisterNow();
        PageConfiguration.getPage().justWait();
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().assertLink());
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().IBMBanner());
        PageConfiguration.getPage().justWait();
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().assertContinueButton());
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().verifyInputEmailField());
        Assert.assertTrue(WorkflowCreateAccountPage.getPage().verifyInputTelephoneField());
    }

    @AfterClass
    public void stopTest() {
        PageConfiguration.getPage().quit();
    }


}
