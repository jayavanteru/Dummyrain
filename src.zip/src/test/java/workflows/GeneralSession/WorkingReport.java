package workflows.GeneralSession;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.LiveTablesPage;
import logs.Log;
import logs.ReportingInfo;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class WorkingReport {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp;
    private WorkflowsApp workflowsApp;
    private String attendeeId;
    private String email;
    private String password;

    @BeforeClass
    public void createAttendee() {
        adminApp = new AdminApp();
        workflowsApp = new WorkflowsApp();
        email = generator.generateValidEmail();
        password = generator.generateString();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        Utils.sleep(1000);

        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(1000);
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB2);
        customTab.navigate(attendeeId);
        Utils.waitForTrue(()->{try {
            return customTab.isFieldVisible("Voting Permissions");
        } catch (StaleElementReferenceException e){
            Log.error("the element is stale, Voting permissions", getClass().getName());
            return false;
        }});
        customTab.checkCheckBoxField("Voting Permissions", 0);
        customTab.checkCheckBoxField("Voting Permissions", 1);
        customTab.checkCheckBoxField("Voting Permissions", 2);
        customTab.checkCheckBoxField("Voting Permissions", 3);
        customTab.submit();
        //wait for submit to be done
        Utils.sleep(500);
    }

    @AfterClass
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    //if failing make the abstract value not read-only on form https://app-stg.rainfocus.com/rain.focus#form.do?id=15010866578820016mPf
    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-29540", chromeIssue = "RA-29539")
    public void editReport() {
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(1000);
//        String workflowUrl = PropertyReader.instance().getProperty("adminUrl")+"/flow/cisco/cllatam17/MarianaSessionApproval/login";
        String newValue = generator.generateString();
//        workflowsApp.getBrowser().navigate().to(workflowUrl);

//        workflowsApp.getLoginPage().login(email, password);
        //spoof into working report
        EditAttendeePage editAttendeepage = EditAttendeePage.getPage();
        editAttendeepage.spoofTo("voting");
        LiveTablesPage reportPage = LiveTablesPage.getPage();
        reportPage.waitForPageLoad();
        String value = reportPage.getFieldValue(1, "Abstract");

        reportPage.setAbstract(1, newValue);
        Utils.sleep(200);
        PageConfiguration.getPage().refreshPage();
        reportPage.waitForPageLoad();
        Assert.assertEquals(reportPage.getFieldValue(1, "Abstract"), newValue, "should have set the abstract to the new value");

        reportPage.setAbstract(1, value);
        Utils.sleep(200);
        PageConfiguration.getPage().refreshPage();
        reportPage.waitForPageLoad();
        Assert.assertEquals(reportPage.getFieldValue(1, "Abstract"), value, "should have set the abstract back to what it was");
    }
}
