package workflows.Admin;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowCreateAccountPage;
import apps.workflows.workflowsPageObjects.WorkflowLoginPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;

public class WorkflowForm {
    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String baseUrl;
    private String password;
    private String username;
    private String attributeId;
    private DataGenerator dataGenerator;


    @BeforeClass
    public void getWorkflowInfo() {
        dataGenerator = new DataGenerator();
        workflowApp = new WorkflowsApp();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login(); //log in

        password = "Test"+dataGenerator.generateString(); //create password
        username = dataGenerator.generateValidEmail(); //create email
        PropertyReader.instance().setProperty("attendeeEmail", username);
    }

    @AfterClass
    public void stopTest() {
        //delete newly created attribute
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if (attributeId != null) adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27715", chromeIssue = "RA-27714")
    public void formValidation() {
        String generatedName = dataGenerator.generateString(5) + "automation";
        OrgEventData.getPage().setOrgAndEvent(); //login

        String workflowId = PropertyReader.instance().getProperty("workflowId"); //get set workflow id
        String uri = workflowApp.setupWorkflowAndGetUri(adminApp, workflowId); //go to workflow in admin and get the JSON
        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        baseUrl = workflowApp.getUrl(orgName.toLowerCase(), eventName, uri);

        //add attribute to the create form
        String formId = workflowApp.getFormIdFromURI("createaccount");
        EditFormPage editFormPage = EditFormPage.getPage();
        editFormPage.navigateTo(formId); //go to the edit form page
        editFormPage.addNewAttribute(EditFormPage.ATTR_TYPE.CHECKBOX, generatedName); //add a checkbox attribute with a generated string
        editFormPage.editList("item1", "item2"); //add two items to the checkbox
        editFormPage.submitForm(); //submit
        FormsSearchPage.getPage().waitForPageLoad();
        editFormPage.navigateTo(formId); //go back to the form
        PageConfiguration.getPage().refreshPage(); //refresh
        editFormPage.waitForPageLoad();
        editFormPage.expandAttribute(generatedName); //expand the attribute we created
        attributeId = editFormPage.getExpandedAttributeId(); //get the id for the attribute we made

        //get the edited form page for the workflow
        workflowApp.addForm(adminApp.getForm(formId));

        //complete the workflow
        workflowApp.navigate(baseUrl, "login?spoofing=true");

        //create account
        WorkflowLoginPage loginPage = WorkflowLoginPage.getPage();
        loginPage.createAccount(); //go to workflow login page
        Utils.sleep(200);
        WorkflowCreateAccountPage createAccountPage = workflowApp.getCreateAccountPage();
        workflowApp.assertCorrectUrlForPage("createaccount"); //make sure we're on the right page
        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formAttendee.email", username);
        customValues.put("password", password);
        customValues.put("confirmpassword", password);
        customValues.put("formAttendee.countryId", "US");
        createAccountPage.fillOutForm(customValues); //fill out the create account page with the custom values
        Assert.assertTrue(createAccountPage.isDisplayNameMatch(), "did not find the correct display names"); //makes sure all the form attributes are equal to what we thought
        //verify that the new attribute is on the page
        Assert.assertTrue(createAccountPage.containsField(attributeId), "form did not contain new added field: " + attributeId); //makes sure the new form attribute is there
    }
}
