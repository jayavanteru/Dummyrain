package workflows;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CkEditors
{
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private WorkflowContactInfoPage workflowContactInfoPage;
  AdminApp adminApp = new AdminApp();
  EditFormPage editFormPage;
  private String testDescription = " - Automation test - do not edit";
  private DataGenerator dataGenerator = new DataGenerator();
  String regCteba4FormName = "REG Tiers - Master Email Validation";
  String regCteba4WorkflowCode = "regcteba4";

  @BeforeClass
  public void setup() {
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    workflowContactInfoPage = WorkflowContactInfoPage.getPage();
    editFormPage = EditFormPage.getPage();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-42196", chromeIssue = "RA-42195")
  public void testCkEditors()
  {
    String TEXT_AREA_CK_EDITOR = "Text area Ck Editor Test - AUTOMATION";
    String INPUT_CK_EDITOR = "Input Ck Editor Test - AUTOMATION";

    // set ck editors as basic
    FormsSearchPage.getPage().navigate();
    FormsSearchPage.getPage().search(regCteba4FormName);
    FormsSearchPage.getPage().edit(regCteba4FormName);
    editFormPage.expandAttributeByName(INPUT_CK_EDITOR);
    editFormPage.setBasicCk();
    editFormPage.expandAttributeByName(TEXT_AREA_CK_EDITOR);
    editFormPage.setBasicCk();
    editFormPage.submitForm();

    // spoof into the workflow
    attendeeSearchPage.navigate();
    // need to create the attendee
    String attendeeId = adminApp.createAttendee(dataGenerator.generateEmail());
    EditAttendeePage.getPage().navigate(attendeeId);
    editAttendeePage.spoofTo(regCteba4WorkflowCode);
    editAttendeePage.acceptCookiesIfExistInSpoofPackage();
    // check if basic editor is there
    workflowContactInfoPage.scrollToQuestion(TEXT_AREA_CK_EDITOR);
    int boldIconCount = workflowContactInfoPage.boldIconCount();
    Assert.assertEquals(boldIconCount, 2, "Not correct amount of bold icons, basic ck editor not working");
    boolean isAdvancedCkEditorOnPage = workflowContactInfoPage.isAdvancedCkEditorOnPage();
    Assert.assertFalse(isAdvancedCkEditorOnPage, "Smiley icon on the page, meaning advanced ck editor is on page, and it should not be");
    editAttendeePage.closeSpoof();

    // change ck editor to advanced
    FormsSearchPage.getPage().navigate();
    FormsSearchPage.getPage().search(regCteba4FormName);
    FormsSearchPage.getPage().edit(regCteba4FormName);
    editFormPage.expandAttributeByName(INPUT_CK_EDITOR);
    editFormPage.setAdvancedCK();
    editFormPage.expandAttributeByName(TEXT_AREA_CK_EDITOR);
    editFormPage.setAdvancedCK();
    editFormPage.submitForm();

    // spoof into workflow again
    EditAttendeePage.getPage().navigate(attendeeId);
    editAttendeePage.spoofTo(regCteba4WorkflowCode);
    editAttendeePage.acceptCookiesIfExistInSpoofPackage();
    // check if basic editor is there
    workflowContactInfoPage.scrollToQuestion(TEXT_AREA_CK_EDITOR);
    boldIconCount = workflowContactInfoPage.boldIconCount();
    Assert.assertEquals(boldIconCount, 2, "Not correct amount of bold icons, advanced ck editor not working");
    isAdvancedCkEditorOnPage = workflowContactInfoPage.isAdvancedCkEditorOnPage();
    Assert.assertTrue(isAdvancedCkEditorOnPage, "Smiley icon is NOT on the page and it should not be, advanced ck editor not working");
    editAttendeePage.closeSpoof();
  }
}
