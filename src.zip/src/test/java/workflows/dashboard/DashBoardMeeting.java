package workflows.dashboard;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.meetings.*;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.adminPageObjects.workflows.WorkflowEditPage;
import apps.workflows.workflowsPageObjects.Dashboard;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;

public class DashBoardMeeting {

    private AdminApp adminApp;
    private DataGenerator generator;
    private String email;
    private String attendeeId;
    private String dashBoard = "dashattendee";
    private String speakerDashboard = "dashspeaker";
    private String workflowId = "1497564553614001s8qp";
    private PageConfiguration pageConfig = PageConfiguration.getPage();
    private String meetingId;

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        generator = new DataGenerator();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @BeforeMethod
    public void create() {
        email = generator.generateEmail();
        Utils.sleep(2000);
        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(2000);
    }

    @AfterMethod
    public void delete() {
        pageConfig.navigateTo(adminApp.getHost());
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (meetingId != null) {
            adminApp.deleteMeeting(meetingId);
            meetingId = null;
        }
        int size = pageConfig.getWindowHandles().size();
        for (int i = 1; i < size; ++i) {
            pageConfig.switchToTab(i);
            pageConfig.close();
        }
        pageConfig.switchToTab(0);
    }


    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27775", chromeIssue = "RA-19010")
    public void requestMeetingCard() {
        String meetingDesc = generator.generateString();
        Dashboard dashboardPage = Dashboard.getPage();

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(dashBoard);
        Utils.sleep(1000);

        dashboardPage.requestMeeting(meetingDesc);

        ArrayList<String> meetingNames = dashboardPage.requestedMeetings();
        Assert.assertEquals(meetingNames.size(), 1, "should be one meeting that we just created");

        MeetingsSearchPage.getPage().navigate();
        String meetingName = meetingNames.get(0);
        MeetingsSearchPage.getPage().searchFor(meetingName);
        meetingId = MeetingsSearchPage.getPage().getId(meetingName);
    }


    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27788", chromeIssue = "RA-27777")
    public void meetingRequestsCard() {
        String meetingName = generator.generateString(5) + "automation";

        //create meeting program
        String meetingProgramName = "automation" + generator.generateString(5);
        String meetingProgramId = "1517005328126001MXk9";
        MeetingProgramsSearchPage.getPage().navigate();
        MeetingProgramsSearchPage.getPage().addMeetingProgram();
        NewMeetingProgramPage.getPage().waitForPageLoad();
        meetingProgramId = NewMeetingProgramPage.getPage().createMeetingProgram(meetingProgramName, "");
        MeetingProgramSchedulePage.getPage().waitForPageLoad();
        MeetingProgramSchedulePage.getPage().pickOneRandomMeetingLength();
        MeetingProgramSchedulePage.getPage().pickSomeRandomTimes();
        MeetingProgramSchedulePage.getPage().saveAndContinue();
        MeetingProgramSchedulePage.getPage().saveAndContinue();
        MeetingProgramSchedulePage.getPage().saveAndContinue();
        MeetingProgramRoomsPage.getPage().pickSomeRandomRooms();
        MeetingProgramRoomsPage.getPage().saveAndContinue();
        MeetingProgramRolesPage.getPage().goToRolesTab();
        MeetingProgramRolesPage.getPage().useHostRole();
        MeetingProgramRolesPage.getPage().saveAndContinue();

        //create meeting
        EditMeetingPage editMeeting = EditMeetingPage.getPage();
        Utils.sleep(200);
        NewMeetingPage.getPage().navigate();
        meetingId = NewMeetingPage.getPage().createMeeting(meetingProgramName);
//        MeetingsSearchPage.getPage().waitForPageLoad();
        editMeeting.waitForPageToLoad();
        editMeeting.setAbstract();
        editMeeting.setFirstLength();
        editMeeting.setStatus("Pending");
        Utils.sleep(1000); //wait for the save

        //add participant
        MeetingParticipants meetingParticipants = MeetingParticipants.getPage();
        meetingParticipants.navigate(meetingId);
        meetingParticipants.addParticipant();
        Utils.sleep(800);
        SessionAddParticipant.getPage().addParticipant(email, "Host");
        Utils.sleep(1000);

        //schedule meeting
        String url = PropertyReader.instance().getProperty("adminUrl")+"/rain.focus#meeting.do?id="+meetingId+"&tab=scheduleTab";
        PageConfiguration.getPage().navigateTo(url);
        AdminMeetingScheduleTab.getPage().waitForPageLoad();
        AdminMeetingScheduleTab.getPage().scheduleSession(3);

        //add the meeting program id to the workflow
        WorkflowEditPage workflowEdit = WorkflowEditPage.getPage(workflowId);
        workflowEdit.navigate();
        String json = workflowEdit.getJson();
        //set the new program id
        String newJson = json.replaceAll("\\\"meetingProgramId\\\": \\\".+\\\"", "\"meetingProgramId\": \""+meetingProgramId+"\"");
        workflowEdit.setJson(newJson.replace("\n", ""));
        Utils.sleep(200);
        workflowEdit.setComment();
        workflowEdit.submit();
        Utils.sleep(1000);

        EditAttendeePage.getPage().navigate(attendeeId);

        EditAttendeePage.getPage().spoofTo(speakerDashboard);

        Dashboard dashboardPage = Dashboard.getPage();
        Utils.waitForTrue(()->dashboardPage.getPendingMeetingRequests() == 1);

        Assert.assertEquals(dashboardPage.getAcceptedMeetingRequests(), 0, "did not get the correct number of accepted meeting requests");
        Assert.assertEquals(dashboardPage.getPendingMeetingRequests(), 1, "did not get the correct number of pending meeting requests");
        Assert.assertEquals(dashboardPage.getDeclinedMeetingRequests(), 0, "did not get the correct number of declined meeting requests");
        String dashUrl = PageConfiguration.getPage().getCurrentUrl();

        meetingParticipants.navigate(meetingId);
        editMeeting.waitForPageToLoad();
        Utils.sleep(200);
        editMeeting.setStatus("Approved");
        Utils.sleep(1000); //wait for the save

        PageConfiguration.getPage().navigateTo(dashUrl);
        Utils.waitForTrue(()->dashboardPage.getAcceptedMeetingRequests() == 1);

        Assert.assertEquals(dashboardPage.getAcceptedMeetingRequests(), 1, "did not get the correct number of accepted meeting requests");
        Assert.assertEquals(dashboardPage.getPendingMeetingRequests(), 0, "did not get the correct number of pending meeting requests");
        Assert.assertEquals(dashboardPage.getDeclinedMeetingRequests(), 0, "did not get the correct number of declined meeting requests");

        meetingParticipants.navigate(meetingId);
        editMeeting.waitForPageToLoad();
        Utils.sleep(200);
        editMeeting.setStatus("Declined");
        Utils.sleep(1000); //wait for the save

        PageConfiguration.getPage().navigateTo(dashUrl);
        Utils.waitForTrue(()->dashboardPage.getDeclinedMeetingRequests() == 1);

        Assert.assertEquals(dashboardPage.getAcceptedMeetingRequests(), 0, "did not get the correct number of accepted meeting requests");
        Assert.assertEquals(dashboardPage.getPendingMeetingRequests(), 0, "did not get the correct number of pending meeting requests");
        Assert.assertEquals(dashboardPage.getDeclinedMeetingRequests(), 1, "did not get the correct number of declined meeting requests");

    }
}
