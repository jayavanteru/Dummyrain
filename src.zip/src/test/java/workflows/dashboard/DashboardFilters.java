package workflows.dashboard;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.workflows.workflowsPageObjects.DashboardFilter;
import interaction.screenshots.ScreenShotImage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.io.File;
import java.util.List;
import java.util.Map;

public class DashboardFilters {

    @BeforeMethod
    public void setIBM() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterMethod
    public void cleanup() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-30432", chromeIssue = "RA-45282")
    public void filteredDashboard() {
        AdminApp adminApp = new AdminApp();
        final DashboardFilter filterDash = DashboardFilter.getPage();
        String spoof = "chrisregressionfilteredtest";

        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor("%automation%");
        String attendeeId = AttendeeSearchPage.getPage().getTopResultId();
        adminApp.spoofIntoWorkflow(attendeeId, spoof, 1);
        final List<String> originalTableData = filterDash.getTableData();
        Assert.assertTrue(originalTableData.size() > 50, "table not full of data");

        filterDash.selectFilter("Attendee");
        Utils.sleep(5000);
        final List<String> filteredTableData = filterDash.getTableData();
        Assert.assertNotEquals(filteredTableData, originalTableData, "filtered data did not change");

        filterDash.clearFilters();
        final List<String> unfilteredData2 = filterDash.getTableData();
        Assert.assertEquals(unfilteredData2, originalTableData, "unfiltered data did not revert back to previous unfiltered data");

        //export data
        final List<Map<String, String>> kpicsv = filterDash.exportKPITileCSV();
        Assert.assertTrue(kpicsv.size() > 50, "exported an empty csv file");

        final List<Map<String, String>> kpixlsx = filterDash.exportKPITileXLSX();
        Assert.assertTrue(kpixlsx.size() > 50, "exported an empty xlsx file");
        Assert.assertEquals(kpicsv, kpixlsx, "2 exports have different data, csv and xlsx");

    }
}
