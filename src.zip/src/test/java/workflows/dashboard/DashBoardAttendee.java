package workflows.dashboard;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeSummaryTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.forms.Form;
import apps.events.EventsApp;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.SurveyPage;
import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.Arrays;

public class DashBoardAttendee {

    private AdminApp adminApp;
    private DataGenerator generator;
    private String email;
    private String attendeeId;
    private String dashBoard = "dashattendee";
    private String sessionId;

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        generator = new DataGenerator();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @BeforeMethod
    public void create() {
        email = generator.generateValidEmail();
        Utils.sleep(2000);
        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(2000);
    }

    @AfterMethod
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        Utils.sleep(200);
        if (sessionId != null) {
            adminApp.deleteSession(sessionId);
            sessionId = null;
        }
        adminApp.deleteAttendee(attendeeId);
//        adminApp.deleteForm(surveyId);
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {"prodTest",ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27701", chromeIssue = "RA-19002")
    public void takeSurveyFromSurveysCard() {
        String surveyName = generator.generateString(5) + "automation";
        String completedMsg = generator.generateString();
        String surveyId = PropertyReader.instance().getProperty("surveyId");
        Form form = adminApp.setupSurvey(surveyName, completedMsg, surveyId, email);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(dashBoard);

        Dashboard dashboardPage = Dashboard.getPage();
        String[] surveys = dashboardPage.getAvailableSurveys();
        int startingAmountOfSurveys = surveys.length;
        Assert.assertTrue(surveys.length > 0, "expected atleast 1 available survey in the survey card");
        Assert.assertTrue(Arrays.asList(surveys).contains(surveyName), "did not get the expected survey name in the survey card: " + surveyName);

        dashboardPage.openSurvey(surveyName);

        //complete the survey
        String actualCompleteMsg = SurveyPage.getPage().fillOutSurvey(form, completedMsg);
        Assert.assertEquals(actualCompleteMsg, completedMsg, "did not find the expected thank you message");
        dashboardPage.closeSurveyModal();
        PageConfiguration.getPage().refreshPage();

        Utils.waitForTrue(()->dashboardPage.getAvailableSurveys().length == 0);
        surveys = dashboardPage.getAvailableSurveys();
        Assert.assertNotEquals(surveys.length, startingAmountOfSurveys, "expected 1 less survey available, because we just took the survey");

        surveys = dashboardPage.getCompletedSurveys();
        Assert.assertEquals(surveys.length, 1, "expected 1 completed survey in the survey card");
        Assert.assertEquals(surveys[0], surveyName, "did not get the expected survey name in the survey card");
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27687", chromeIssue = "RA-27686")
    public void registeredSessionsCard() {
        String sessionId = "1506713320704001u86Q";
        String sessionTimeId = "15083455501770019xqw";
        String sessionName = "IT Workshop";
        //register to see the sessions
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.selectPackage("Approval Package");
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.placeOrder();
        PageConfiguration.getPage().waitForPageLoad();
        Utils.sleep(1000, "extra time to make sure we will be able to schedule new attendee to a session");
        AdminAttendeeSummaryTab.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeSummaryTab.getPage().waitForAccessRulesToLoad("All", 1) > 0, "did not ever get the access rule applied to it");

        //register for a session
        JSONObject response = adminApp.addSessionToAttendeeSchedule(attendeeId, sessionId, sessionTimeId);
        Log.info("adding session to schedule response: " + response, getClass());
        String responseMsg = MyJson.getString(MyJson.getJSONObject(response, "data"), "responseMessage");
        if (!responseMsg.equals("Success")) {
            Utils.sleep(1000, "failed to schedule session, waiting and trying again");
            response = adminApp.addSessionToAttendeeSchedule(attendeeId, sessionId, sessionTimeId);
            Log.info("adding session to schedule response: " + response, getClass());
        }

        EditAttendeePage.getPage().spoofTo(dashBoard);
        Utils.waitForTrue(()->Dashboard.getPage().getRegisteredSessions().size() > 0);
        ArrayList<String> sessions = Dashboard.getPage().getRegisteredSessions();
        Assert.assertEquals(sessions.size(), 1, "did not show the one session registered");
        Assert.assertEquals(sessions.get(0), sessionName, "did not see the right session in the registered sessions card");

        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.removeSessionFromAttendeeSchedule(attendeeId, sessionId, sessionTimeId);
    }

    @Test(groups = {"prodTest",ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27689", chromeIssue = "RA-27688")
    public void scheduleCard() {
        //get the number of days
//        HashSet<String> days = new HashSet<>();
//        MeetingDaysSearchPage.getPage().navigate();
//        days.addAll(MeetingDaysSearchPage.getPage().getNames());
//        SessionDaysSearchPage.getPage().navigate();
//        Utils.sleep(500);
//        PageConfiguration.getPage().waitForPageLoad();
//        days.addAll(SessionDaysSearchPage.getPage().getNames());

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().waitForPageLoad();
        EditAttendeePage.getPage().spoofTo(dashBoard);

        //the bars will not show because we are not registered but they are there in the html
        int bars = Dashboard.getPage().scheduleCardAvailableSessionsBars();
        Assert.assertTrue(bars > 5, "expected bars on the build your schedule card");
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27738", chromeIssue = "RA-27737")
    public void recommendSessionCard() {
        String widgetId = "TJLJEekJPIiPhcaRyD81DzfqeYisoD8e";
        String apiProfileId = "lgCL43C3Dh3WaUsbKZiipHbssIkRain25";

        //load recommended sessions
        EventsApp eventsApp = new EventsApp();
        String recommendUrl = "/api/recommendCache.do?rfApiProfileId="+apiProfileId+"&rfWidgetId=" + widgetId;
        JSONObject response = eventsApp.post(recommendUrl);

        String orgName = PropertyReader.instance().getProperty("org");
        String eventName = PropertyReader.instance().getProperty("event");
        Assert.assertEquals(MyJson.getString(response, "org").toLowerCase(), orgName.toLowerCase(), "json for recommendCache call did not show the right org, response: " + response);
        Assert.assertEquals(MyJson.getString(response, "eventCode").toLowerCase(), eventName.toLowerCase(), "json for recommendCache call did not show the right event code, response: " + response);
        int recommendations = MyJson.getInt(response, "recommendations");
        Assert.assertTrue(recommendations > 0, "did not find any recommendations in the recommendCache call, response: " + response);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(dashBoard);

        Utils.waitForTrue(()->Dashboard.getPage().getRecommendedSessions().size() > 0);
        ArrayList<String> sessions = Dashboard.getPage().getRecommendedSessions();
        Assert.assertTrue(sessions.size() > 0,  "no recommendations are showing up in the recommendations card");
    }

}
