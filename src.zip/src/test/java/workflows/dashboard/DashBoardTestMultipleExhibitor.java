package workflows.dashboard;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorFilesTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorNewContactPage;
import apps.admin.adminPageObjects.exhibits.EditRegCodeAllocationPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.workflowsPageObjects.Dashboard;
import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class DashBoardTestMultipleExhibitor {

    private AdminApp adminApp;
    private String exhibitorDashboard = "dashexhibitor";
    private PageConfiguration pageConfig;
    private DataGenerator generator;
    private String email;
    private String attendeeId;
    private String fileId;
    private String exhibitorId1;
    private String exhibitorId2;
    private String regCodeAllocationId = "1610582095765002g4cU";

    @BeforeClass
    public void setup() {
        PropertyReader.instance().setProperty("enableDesktopAutomation", true);
        generator = new DataGenerator();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        pageConfig = PageConfiguration.getPage();
    }

    @BeforeMethod
    public void createAttendee() {
        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);
    }

    @AfterMethod
    public void delete() {
        pageConfig.navigateTo(adminApp.getHost());
        Utils.sleep(200);
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (fileId != null) {
            adminApp.deleteFile(fileId);
            fileId = null;
        } if (exhibitorId2 != null) {
            adminApp.deleteExhibitor(exhibitorId1);
            adminApp.deleteExhibitor(exhibitorId2);
            exhibitorId2 = null;
        }
    }

    @AfterClass
    public void close() {
        pageConfig.quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27771", chromeIssue = "RA-27768")
    public void filesCard() {
//        String fileTypeId = "1493158055167001BFsU";
        String fileDisplayName = "pic1.jpg";

        String exhibitorName1 = generator.generateString(6) + "automation";
        String exhibitorName2 = generator.generateString(6) + "automation";
        Log.info("exhibitor 1 name: " + exhibitorName1, getClass());
        Log.info("exhibitor 2 name: " + exhibitorName2, getClass());

        exhibitorId1 = createExhibitor(exhibitorName1);
        Utils.sleep(500);
        exhibitorId2 = createExhibitor(exhibitorName2);

        //upload a file to one exhibitor
        AdminExhibitorFilesTab.getPage().navigate(exhibitorId1);
        AdminExhibitorFilesTab.getPage().uploadFile("Logo", fileDisplayName);
//        JSONObject response = adminApp.uploadFileExhibitors(exhibitorId1, fileTypeId);
//        JSONObject data = MyJson.getJSONObject(response, "data");
//        fileId = MyJson.getString(data, "fileId");
//        String[] fileUrl = MyJson.getString(data, "fileUrl").split("/");
//        String fileDisplayName = fileUrl[fileUrl.length-1];

        //verify exhibitor shows files and the other exhibitor shows no files
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(exhibitorDashboard);

        //choose the exhibitor with no files
        Dashboard.getPage().chooseExhibitor(exhibitorName2);
        Utils.sleep(500, "to load the exhibitor");
        String[] files = Dashboard.getPage().getFiles();
        Assert.assertEquals(files.length, 0, "showing uploaded files on exhibitor when there is none, possibly showing the wrong exhibitor, should be showing exhibitor " + exhibitorName2);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(exhibitorDashboard);

        Dashboard.getPage().chooseExhibitor(exhibitorName1);
        Utils.sleep(500, "to load the exhibitor");
        files = Dashboard.getPage().getFiles();
        Assert.assertEquals(files.length, 1, "did not find the uploaded file for exhibitor " + exhibitorName1);
        Assert.assertTrue(files[0].startsWith("pic1"), "did not get the right file name, displayed filename: " + files[0]);
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27773", chromeIssue = "RA-27772")
    public void managePassesCard() {
        String packageName = "Full Conference Pass";
        String exhibitorName1 = generator.generateString(6) + "automation";
        String exhibitorName2 = generator.generateString(6) + "automation";
        Log.info("exhibitor 1 name: " + exhibitorName1, getClass());
        Log.info("exhibitor 2 name: " + exhibitorName2, getClass());

        exhibitorId1 = createExhibitor(exhibitorName1);
        exhibitorId2 = createExhibitor(exhibitorName2);

        //create a reg code allocation
        EditRegCodeAllocationPage.getPage().navigate(regCodeAllocationId);
        EditRegCodeAllocationPage.getPage().setExhibitorName(exhibitorName1);

        //let the reg code do its work ya know
        Utils.sleep(2000, "waiting for the reg code allocation to find the exhibitor");
        Dashboard dashboardPage = Dashboard.getPage();

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(exhibitorDashboard);

        Dashboard.getPage().chooseExhibitor(exhibitorName1);
        Utils.waitForTrue(()->dashboardPage.getPassesPurchased() >= 10);
        Assert.assertTrue(dashboardPage.getPassesPurchased() >= 10, "not showing the number from the reg code allocation for passes purchased for this exhibitor");
        Assert.assertEquals(dashboardPage.getPassesDistributed(), 0, "should be set to 0, passes distributed");
        Assert.assertEquals(dashboardPage.getPassesRegistered(), 0, "should be set to 0, passes registered");


        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(exhibitorDashboard);

        Dashboard.getPage().chooseExhibitor(exhibitorName2);
        Utils.sleep(1000, "to load the exhibitor");
        Assert.assertEquals(dashboardPage.getPassesPurchased(), 0, "passes purchased should be set to 0 for this exhibitor");
        Assert.assertEquals(dashboardPage.getPassesDistributed(), 0, "should be set to 0, passes distributed");
        Assert.assertEquals(dashboardPage.getPassesRegistered(), 0, "should be set to 0, passes registered");
    }

    private String createExhibitor(String name) {
        Utils.sleep(500);
        String id = adminApp.createExhibitor(name);

        //add attendee to exhibitor
        AdminExhibitorContactsTab contactsPage = AdminExhibitorContactsTab.getPage();

        contactsPage.navigate(id);
        contactsPage.clickAddParticipantButton();
        AdminExhibitorNewContactPage.getPage().fillOutForm(email, "Primary Owner");

        return id;
    }
}
