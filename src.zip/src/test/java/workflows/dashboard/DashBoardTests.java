package workflows.dashboard;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.forms.Form;
import apps.admin.forms.formAttributes.FormAttribute;
import apps.workflows.workflowsPageObjects.Dashboard;
import apps.workflows.workflowsPageObjects.TaskList;
import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class DashBoardTests {

    private AdminApp adminApp;
    private String attendeeId;
    private final String speakerDashboard = "dashspeaker";
    private final String packageName = "Approval Package";
    private final PageConfiguration pageConfig = PageConfiguration.getPage();
    private DataGenerator generator;
    private String email;
    private String taskId;
    private String taskQualifierId;
    private String meetingId;
    private String meetingProgramId;

    @BeforeClass
    public void setup() {
        generator = new DataGenerator();
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @BeforeMethod
    public void createAttendee() {
        email = generator.generateEmail();
        Utils.sleep(1500);
        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(2000);
    }

    @AfterClass
    public void close() {
        pageConfig.quit();
    }

    @AfterMethod
    public void delete() {
        pageConfig.navigateTo(adminApp.getHost());
         if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (taskId != null) {
            //remove the qualifier for deleting
            Utils.sleep(1000);
            EditTaskPage.getPage().navigate(taskId);
            Utils.sleep(500);
            EditTaskPage.getPage().removeQualifiers();
            EditTaskPage.getPage().submit();
            Utils.sleep(500);
            //delete now
            adminApp.deleteTask(taskId);
            adminApp.deleteTaskQualifier(taskQualifierId);
            taskId = null;
        } if (meetingId != null) {
            adminApp.deleteMeeting(meetingId);
            adminApp.deleteMeetingProgram(meetingProgramId);
            meetingId = null;
        }
        pageConfig.switchToTab(0);
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27732", chromeIssue = "RA-27731")
    public void orderSummaryCard() {
        AdminAttendeeOrdersTab ordersPage = AdminAttendeeOrdersTab.getPage();
        Dashboard dashboardPage = Dashboard.getPage();

        ordersPage.navigate(attendeeId);
        Utils.sleep(1000);
        ordersPage.addOrder();
        ordersPage.selectPackage(packageName);
        ordersPage.clickNextOnAddOrderModal();
        ordersPage.placeOrder();
        Utils.sleep(1000);

        PageConfiguration.getPage().refreshPage();

        EditAttendeePage.getPage().spoofTo(speakerDashboard);
        Assert.assertTrue(dashboardPage.getOrderBalance() > 0, "the order balance was not more than 0 in the order summary card");
        Assert.assertTrue(dashboardPage.getOrderTotal() > 0, "the order balance was not more than 0 in the order summary card");

        Assert.assertEquals(dashboardPage.getOrderCount(), 1, "purchased one order, showing incorrect number of orders in the order summary card");
        Assert.assertEquals(dashboardPage.getOrderName(0), packageName, "did not show correct order in the order summary card");
    }

    @Test(groups = {"prodTest", ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27736", chromeIssue = "RA-27734")
    public void detailsCard() {
        String formId = "961c4940-1fbf-11e7-822e-06fe95280409";
        Form form = adminApp.getForm(formId);
        form.setBrowser(pageConfig.getBrowser());
        EditAttendeePage.getPage().navigate(attendeeId);

        EditAttendeePage.getPage().spoofTo(speakerDashboard);

        //check the display names
        Dashboard.getPage().detailsCardLoaded();
        for (FormAttribute attr : form.getFormAttributes()) {
            if (!attr.getAttributeData().isHiddenField() && attr.getAttributeData().getParentInfo().length <= 0) {
                Log.info("checking for attribute being displayed: " + attr.getAttributeData().getDisplayName(), getClass());
                Assert.assertTrue(attr.isDisplayNameCorrect(),"did not find the display name: " + attr.getAttributeData().getDisplayName());
            }
        }

        //edit form
        Dashboard.getPage().editFormDetailsCard();
        Utils.sleep(1000);
        Assert.assertTrue(pageConfig.waitForPageUrlToEndWith("/form/speakerdetails"), "Did not redirect to the right page, looking for '/form/speakerdetails' found: " + pageConfig.getCurrentUrl());

        //assert attributes are on page again
        for (FormAttribute attr : form.getFormAttributes()) {
            if (!attr.getAttributeData().isHiddenField() && attr.getAttributeData().getParentInfo().length <= 0) {
                Log.info("checking for attribute being displayed: " + attr.getAttributeData().getDisplayName(), getClass());
                Assert.assertTrue(attr.isDisplayNameCorrect(),"did not find the display name: " + attr.getAttributeData().getDisplayName());
            }
        }
    }

    @Test(groups = {"prodTest", ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27743", chromeIssue = "RA-27742")
    public void speakingSessionCard() {
        String sessionName = generator.generateString(6) + "automation";
        String sessionId = adminApp.createSession(sessionName);
        Dashboard dashboardPage = Dashboard.getPage();

        AdminSessionParticipantsTab.getPage().navigate(sessionId);
        AdminSessionParticipantsTab.getPage().clickAddParticipantButton();
        Utils.sleep(500);
        SessionAddParticipant.getPage().addParticipant(email, "Speaker");

        //schedule the session
        AdminSchedulingTab.getPage().navigate(sessionId);
        AdminSchedulingTab.getPage().scheduleSession(2);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(speakerDashboard);

        //assert that the session is showing in speaking sessions card
        Assert.assertEquals(dashboardPage.getSessionCountFromSpeakerSessionCard(), 1, "should be just the one session that we assigned to the user");
        Assert.assertEquals(dashboardPage.getSessionNameFromSpeakerSessionCard(0), sessionName, "session name did not match the session we created");
        String room = dashboardPage.getSessionRoomFromSpeakerSessionCard(0);
        String time = dashboardPage.getSessionTimeFromSpeakerSessionCard(0);
        Assert.assertTrue(room.length() > 0, "room not being displayed on the session found: " + room);
        Assert.assertTrue(time.length() > 0, "time not being displayed on the session found: " + time);

        //start a clean up
        pageConfig.navigateTo(adminApp.getHost());
        adminApp.deleteSession(sessionId);
    }

    @Test(groups = {"prodTest", ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27745", chromeIssue = "RA-27744")
    public void tasksCard() {
        Criteria taskQualfy = new Criteria("Email", "equal to", email);
        String taskQualifyName = "automation" + generator.generateString(5);
        String taskName = "automation" + generator.generateString(5);

        //create a task
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().createTaskQualifier(taskQualifyName, taskQualfy);
        Utils.sleep(1000); //time to save
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().createFormSpeakerTask(taskName, taskQualifyName);
        Utils.sleep(500); //time to save

        //get the task qualifier id and task id
        TasksSearchPage.getPage().navigate();
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
        TaskQualifierSearchPage.getPage().navigate();
        taskQualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifyName);

        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().spoofTo(speakerDashboard);

        //should see informational task
        if (Dashboard.getPage().getIncompleteTasks() > 0) PageConfiguration.getPage().refreshPage();
        Assert.assertEquals(Dashboard.getPage().getIncompleteTasks(),0, "did not get the expected number of incomplete tasks");
        Assert.assertEquals(Dashboard.getPage().getInformationalTasks(),1, "did not get the expected number of informational tasks");
        Assert.assertEquals(Dashboard.getPage().getReviewTasks(),0, "did not get the expected number of review tasks");
        Assert.assertEquals(Dashboard.getPage().getRevisionTasks(),0, "did not get the expected number of revision tasks");

        String dashboardUrl = PageConfiguration.getPage().getCurrentUrl();

        //change the task to not be informational
        EditTaskPage.getPage().navigate(taskId);
        Utils.sleep(200);
        EditTaskPage.getPage().checkInformational();
        EditTaskPage.getPage().submit();
        Utils.sleep(1000); //let it save

        PageConfiguration.getPage().navigateTo(dashboardUrl);
        Utils.waitForTrue(()->Dashboard.getPage().getIncompleteTasks() > 0);
        //turned off informational should see incomplete
        Assert.assertEquals(Dashboard.getPage().getIncompleteTasks(),1, "did not get the expected number of incomplete tasks");
        Assert.assertEquals(Dashboard.getPage().getInformationalTasks(),0, "did not get the expected number of informational tasks");
        Assert.assertEquals(Dashboard.getPage().getReviewTasks(),0, "did not get the expected number of review tasks");
        Assert.assertEquals(Dashboard.getPage().getRevisionTasks(),0, "did not get the expected number of revision tasks");

        //go to tasks page
        Dashboard.getPage().editTaskCard();
        boolean taskOnPage = TaskList.getPage().isTaskOnPage(taskName);
        Assert.assertTrue(taskOnPage, "did not find task on page. looking for task name: " + taskName);
        String eventcode = PropertyReader.instance().getProperty("eventCode");
        String endUrl = "flow/rainfocus/"+eventcode+"/dashspeaker/tasks";
        Assert.assertTrue(PageConfiguration.getPage().waitForPageUrlToEndWith(endUrl), "link from the tasks card did not go to " + endUrl);
    }

}
