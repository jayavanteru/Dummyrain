package admin.Events;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import apps.admin.events.EventSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Events {
  DataGenerator dataGenerator = new DataGenerator();

  @BeforeClass
  public void login() {
    AdminLoginPage.getPage().login();
  }

  @AfterClass
  public void quit() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-37836", chromeIssue = "RA-37835")
  public void newAdminUserEventOwner() {
    EditUserPage editUserPage = EditUserPage.getPage();
    UsersPage usersPage = UsersPage.getPage();
    NavigationBar navigationBar = NavigationBar.getPage();
    EventSearchPage eventSearchPage = EventSearchPage.getPage();

    String originalAutomationUser = PropertyReader.instance().getProperty("adminEmail");
    String originalAutomationPass = PropertyReader.instance().getProperty("adminPassword");

    String userName = dataGenerator.generateName();
    String userLastName = dataGenerator.generateName();
    String email = dataGenerator.generateValidEmail();
    String pass = dataGenerator.generatePassword();

    // Go to IBM - GLOBAL
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Create a new user in global, with 'New Branding - Option' role
    editUserPage.navigateNewUser();
    editUserPage.fillNewUserInfo(userName, userLastName, email, pass);
    editUserPage.setSecurityRole("New Branding - Locked");
    editUserPage.submit();

    // Change to a not Global event, then add 'Event Owner' role to the user
    usersPage.selectUserByEmail(email);
    editUserPage.toggleSecurityRole("Event Owner");
    editUserPage.submit();

    // Login with new user
    AdminLoginPage.getPage().logout();
    PropertyReader.instance().setProperty("adminEmail", email);
    PropertyReader.instance().setProperty("adminPassword", pass);
    AdminLoginPage.getPage().login();

    Assert.assertTrue(navigationBar.isOrgPanelVisible(), "We are not in new branding");
    Assert.assertFalse(eventSearchPage.isNewEventButtonVisible(), "New Event button should not be visible");
    Assert.assertEquals(eventSearchPage.numberOfRowsNewAdmin(), 1, "There should be just one event");

    // return to default values
    PropertyReader.instance().setProperty("adminEmail", originalAutomationUser);
    PropertyReader.instance().setProperty("adminPassword", originalAutomationPass);
  }
}
