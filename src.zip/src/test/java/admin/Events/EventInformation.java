package admin.Events;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import apps.admin.events.EventInformationPage;
import apps.admin.events.EventSearchPage;
import apps.admin.newAdmin.guide.GeneralTabPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.aspectj.weaver.ast.Or;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EventInformation {
  DataGenerator dataGenerator;
  EditUserPage editUserPage;
  UsersPage usersPage;
  NavigationBar navigationBar;
  EventSearchPage eventSearchPage;
  EventInformationPage eventInformationPage;
  AdminApp adminApp;
  GeneralTabPage generalTabPage;
  AdminLoginPage adminLoginPage;


  @BeforeClass
  public void login() {
    dataGenerator = new DataGenerator();
    editUserPage = EditUserPage.getPage();
    usersPage = UsersPage.getPage();
    navigationBar = NavigationBar.getPage();
    eventSearchPage = EventSearchPage.getPage();
    eventInformationPage = EventInformationPage.getPage();
    generalTabPage = GeneralTabPage.getPage();
    adminLoginPage = AdminLoginPage.getPage();
    adminApp = new AdminApp();

    adminLoginPage.login();
    OrgEventData.getPage().setOrgAndEvent(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void quit() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-41062", chromeIssue = "RA-37864")
  public void newAdminUserEventOwner()
  {

    String name = dataGenerator.generateName();

    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_NAME_EVENTGERS_TEST, true);

    eventInformationPage.goToBudgetsTab();
    String overallValue = eventInformationPage.getOverallValueBudgetTab();

    eventInformationPage.goToConfigurationTab();
    String vatTaxValue = eventInformationPage.getVatTaxValueConfigurationTab();

    eventInformationPage.goToInformationTab();
    eventInformationPage.setWebsiteInformationTab(name);

    eventInformationPage.saveInformationTab();

    validateValues(overallValue, vatTaxValue);

//    adminLoginPage.logout();
    adminApp.loginAsAdminUser();
    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_CODE_EVENTGERS_TEST, false);
    generalTabPage.editEventInformationInput("City", dataGenerator.generateString());
    adminLoginPage.logout();
    adminLoginPage.login();
    OrgEventData.getPage().setOrgAndEvent(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    validateValues(overallValue, vatTaxValue);

    // switch city back
    eventInformationPage.goToInformationTab();
    eventInformationPage.setCity("City");
  }

  private void validateValues(String overallValue, String vatTaxValue)
  {
    // Validate saved values
    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_NAME_EVENTGERS_TEST, true);

    eventInformationPage.goToBudgetsTab();
    Assert.assertEquals(overallValue, eventInformationPage.getOverallValueBudgetTab(), "'Overall event budget' value is incorrect");

    eventInformationPage.goToConfigurationTab();
    Assert.assertEquals(vatTaxValue, eventInformationPage.getVatTaxValueConfigurationTab(), "'VAT tax rate' value is incorrect");
  }
}
