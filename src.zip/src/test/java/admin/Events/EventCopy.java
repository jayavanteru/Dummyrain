package admin.Events;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.events.EventSearchPage;
import apps.admin.events.NewEventPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EventCopy {

  private DataGenerator dataGenerator;
  private SoftAssert softAssert;

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    softAssert = new SoftAssert();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RF Event Copy Automation", "GLOBAL");
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-45260", chromeIssue = "RA-19017")
  public void testEventCopy()
  {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    LocalDate localDate = LocalDate.now();

    String eventName = "Event Copy (" + dtf.format(localDate) + ")";
    String eventCode = "eventcopy" + dataGenerator.generateString(6);

    EventSearchPage.getPage().navigate();

    EventSearchPage.getPage().search(eventName);

    int num = EventSearchPage.getPage().getNumResults() + 1;
    eventName += " " + num;

    EventSearchPage.getPage().selectEventCopyFromEventId("1620677eventcopytemp");

    NewEventPage.getPage().fillEventInformation(eventName, eventCode);

    EventSearchPage.getPage().switchToEvent(eventCode);

    AdminEventAttributesPage.getPage().navigate();
    AdminEventAttributesPage.getPage().search("Attendee Type");
    String attributeId = AdminEventAttributesPage.getPage().getAttributeId("Attendee Type");
    softAssert.assertTrue(AdminEventAttributesPage.getPage().attributeExists(attributeId), "Attendee Type attribute did not exist when it should have.");

    AdminEventAttributesPage.getPage().navigateToAttribute(attributeId);
    softAssert.assertTrue(EditEventAttributePage.getPage().valueExists("Attendee"), "Attendee attribute value did not exist when it should have.");
    softAssert.assertTrue(EditEventAttributePage.getPage().valueExists("Employee"), "Employee attribute value did not exist when it should have.");
    softAssert.assertTrue(EditEventAttributePage.getPage().valueExists("Guest"), "Guest attribute value did not exist when it should have.");

    FormsSearchPage.getPage().navigate();
    FormsSearchPage.getPage().search("Create Attendee Form");
    softAssert.assertTrue(FormsSearchPage.getPage().formExists("Create Attendee Form"), "Create Attendee Form did not exist when it should have.");

    String formId = FormsSearchPage.getPage().getId("Create Attendee Form");
    EditFormPage.getPage().navigateTo(formId);
    softAssert.assertTrue(EditFormPage.getPage().attributeExists("formAttendee.firstname"), "First Name was not on form when it should have been.");
    softAssert.assertTrue(EditFormPage.getPage().attributeExists("formAttendee.lastname"), "Last Name was not on form when it should have been.");
    softAssert.assertTrue(EditFormPage.getPage().attributeExists("formAttendee.email"), "Email was not on form when it should have been.");

    EmailsSearchPage.getPage().navigate();
    EmailsSearchPage.getPage().searchFor("Reg Invoice");
    softAssert.assertTrue(EmailsSearchPage.getPage().emailExists("Reg Invoice"), "Reg Invoice email did not exist when it should have.");

    WebPageSearchPage.getPage().navigate();
    WebPageSearchPage.getPage().searchFor("Default Invoice");
    softAssert.assertTrue(WebPageSearchPage.getPage().webPageExists("Default Invoice"), "Default Invoice webpage did not exist when it should have.");

    softAssert.assertAll();
  }
}
