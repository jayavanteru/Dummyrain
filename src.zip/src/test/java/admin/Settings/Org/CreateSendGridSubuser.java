package admin.Settings.Org;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.ViewAllOriganizations;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CreateSendGridSubuser{
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String data;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-53509", firefoxIssue = "RA-53510")
    public void CreateSendGridSubuser() {
        ViewAllOriganizations.getPage().navigate().editOrg("RF Automation");
        Assert.assertTrue(new ViewAllOriganizations().getPage().checkElementHidden(), "SEND GRID SUBUSER EXISTS");

        ViewAllOriganizations.getPage().urlSwitch().justWait();
        Assert.assertFalse(new ViewAllOriganizations().getPage().checkElementHidden(),"SEND GRID SUBUSER DOESN'T EXIST");
    }

}
