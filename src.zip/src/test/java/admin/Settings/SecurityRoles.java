package admin.Settings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminDashboardPage;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.NewSecurityRolePage;
import apps.admin.adminPageObjects.manageUsers.SecurityRolesPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;
import testHelp.SeleniumHelpers;
import testHelp.Utils;

import java.util.concurrent.TimeUnit;

public class SecurityRoles {

    private AdminApp adminApp;
    private SoftAssert softAssert;
    private SeleniumHelpers helpers;
    String roleId;
    String systemRoleName = "System Administrator";
    String workflowRoleName = "Workflow Administrator";
    String userId;
    String org = "RainFocus";
    String event = "GLOBAL";
    String event1 = "Constellations";
    String event2 = "Automation Use Only";

    @BeforeClass
    public void startApp() {
        helpers = new SeleniumHelpers();
        softAssert = new SoftAssert();
        userId = PropertyReader.instance().getProperty("adminSecurityUserId");
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent(org, event);
    }

    @AfterClass
    public void close() {
        SecurityRolesPage securityRoles = SecurityRolesPage.getPage();
        securityRoles.navigate();
        Utils.sleep(800);
        try {
            if (roleId != null) {
                securityRoles.deleteRole(roleId);
            }
            //give it time to delete
            Utils.sleep(200);
        } finally {
            PageConfiguration.getPage().quit();
        }
    }

    @Test(groups = {ReportingInfo.TVA})
    @ReportingInfo(firefoxIssue = "RA-26692", chromeIssue = "RA-26691")
    public void createSecurityRole() {
        String[] allTabs = {"events-tab", "orders-tab", "demographics-tab", "emails-tab", "profileSchedule-tab", "profileTasks-tab",
                "form-tab-1", "form-tab-3", "form-tab-4", "form-tab-5", "form-tab-6", "form-tab-7", "onsite-tab",
                "events-tab", "form-tab-2", "compliance-tab", "history-tab", "upload-Tab"};
        String[] hiddenTabs = {"orders-tab", "demographics-tab", "emails-tab", "profileSchedule-tab", "profileTasks-tab",
                "form-tab-1", "form-tab-3", "form-tab-4", "form-tab-5", "form-tab-6", "form-tab-7", "onsite-tab"};
        String[] visibleTabs = {"events-tab", "form-tab-2", "compliance-tab", "history-tab", "upload-Tab"};
        NavigationBar navigationBar = NavigationBar.getPage();
        By[] navItems = {navigationBar.WORKFLOWS_IDENTIFIER, navigationBar.CONTENT, navigationBar.MEETINGS,
                navigationBar.EXHIBITS, navigationBar.LIBRARIES, navigationBar.ONSITE};
        By[] AllnavItems = {navigationBar.WORKFLOWS_IDENTIFIER, navigationBar.REGISTRATION, navigationBar.CONTENT, navigationBar.MEETINGS,
                navigationBar.EXHIBITS, navigationBar.LIBRARIES, navigationBar.ONSITE};

        DataGenerator dataGen = new DataGenerator();
        String name = "automation" + dataGen.generateString(5);

        UsersPage usersPage = UsersPage.getPage();
        SecurityRolesPage securityRolesPage = SecurityRolesPage.getPage();
        NewSecurityRolePage newSecurityRolePage = NewSecurityRolePage.getPage();
        AdminAttendeeCustomTab attendee = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB1);


        usersPage.navigate();
        usersPage.goToEditRoles();
        PageConfiguration.getPage().refreshPage();
        securityRolesPage.addSecurityRole();
        newSecurityRolePage.createNewRole(name, "Attendee Compliance Tab", "Attendee File Tab", "Attendee Form Tab 2", "Attendee History Tab", "Attendee CRM");
        //get that new roles id
        roleId = securityRolesPage.getRoleId(name);

        //assign role to user
        assignRole(userId, name);

        //assign an event level role
        //go to the other event
        OrgEventData.getPage().setOrgAndEvent(org, event2);
        Utils.sleep(1000);
        //assign all roles to this event
        assignRole(userId, systemRoleName, workflowRoleName);

        //go to event1 where global settings are set
        spoofToAttendeePage();
        PageConfiguration.getPage().setImplicitWait(100L, TimeUnit.MILLISECONDS);

        Utils.waitForTrue(()->attendee.isTabVisible("events-tab"));
        //verify event1 has the global settings
        for (String tab : visibleTabs) {
            softAssert.assertTrue(attendee.isTabVisible(tab), "unable to see tab with new security role while other event has system admin permission " + tab);
        }

        for (String tab : hiddenTabs) {
            softAssert.assertFalse(attendee.isTabVisible(tab), "tab not hidden with new security role while other event has system admin permission " + tab);
        }

        for (By nav : navItems) {
            softAssert.assertFalse(navigationBar.isItemVisible(nav), "nav item was visible when it should not be (custom role): " + nav);
        }

        //go to the other event and make sure everything is visible
        OrgEventData.getPage().setOrgAndEvent(org, event2);
        Utils.sleep(1000);

        //find an attendee
        PageConfiguration.getPage().setImplicitWait(5L, TimeUnit.SECONDS);
        findAnAttendee();

        PageConfiguration.getPage().setImplicitWait(100L, TimeUnit.MILLISECONDS);
        Utils.waitForTrue(()->attendee.isTabVisible("events-tab"));
        for (String tab : allTabs) {
            softAssert.assertTrue(attendee.isTabVisible(tab), "unable to see tab as system admin for this event: " + tab);
        }

        for (By nav : AllnavItems) {
            softAssert.assertTrue(navigationBar.isItemVisible(nav), "nav item was hidden when it should not be (system admin access for this event): " + nav);
        }

        PageConfiguration.getPage().setImplicitWait(5L, TimeUnit.SECONDS);
        returnToUser();

        //remove all permissions under other event
        PageConfiguration.getPage().justWait();
        OrgEventData.getPage().setOrgAndEvent(org, event2);
        Utils.sleep(2000);
        //remove all roles from this event
        assignRole(userId);

        OrgEventData.getPage().setOrgAndEvent(org, event);
        Utils.sleep(2000);
        //un-assigns the role, back to normal
        assignRole(userId, systemRoleName, workflowRoleName);


        spoofToAttendeePage();

        for (String tab : allTabs) {
            softAssert.assertTrue(attendee.isTabVisible(tab), "unable to see tab as system admin: " + tab);
        }

        for (By nav : AllnavItems) {
            softAssert.assertTrue(navigationBar.isItemVisible(nav), "nav item was hidden when it should not be (system admin access): " + nav);
        }

        returnToUser();
        OrgEventData.getPage().setOrgAndEvent(org, event);

        softAssert.assertAll();
    }

    private void assignRole(String userId, String... rolename) {
        EditUserPage editUserPage = EditUserPage.getPage();
        editUserPage.navigate(userId);
        editUserPage.setSecurityRole(rolename);
        editUserPage.submit();
        Utils.sleep(1000);
        editUserPage.navigate(userId);
    }

    private void spoofToAttendeePage() {
        spoofIn();
        AdminDashboardPage.getPage().waitTillLoaded();
        OrgEventData.getPage().setOrgAndEvent(org, event1);
        findAnAttendee();
    }

    private void spoofIn() {
        EditUserPage editUserPage = EditUserPage.getPage();
        editUserPage.navigate(userId);
        editUserPage.spoofIntoAdmin();
        Utils.sleep(1000);
    }

    private void findAnAttendee() {
        AttendeeSearchPage searchPage = AttendeeSearchPage.getPage();
        searchPage.navigate();
        Utils.sleep(200);
        searchPage.searchFor("");
        searchPage.clickResult(0);
    }

    private void returnToUser() {
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        browser.findElement(By.xpath("//button[text()='Return to User']")).click();

        //set back to org
        Utils.sleep(5000);
    }
}
