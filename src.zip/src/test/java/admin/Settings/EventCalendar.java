package admin.Settings;

import apps.PageConfiguration;
import apps.events.eventsPageObjects.RodanFieldsEventCalendarPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class EventCalendar {


    @BeforeClass
    public void setUp(){

       RodanFieldsEventCalendarPage.getPage().navigate();
    }


    @Test(groups = {ReportingInfo.TVA})
    @ReportingInfo(firefoxIssue = "RA-38991", chromeIssue = "RA-32721")
    public void eventCalendar(){
        Assert.assertEquals(RodanFieldsEventCalendarPage.getPage().getTitle(), "R+F Event Calendar");
        Assert.assertTrue(RodanFieldsEventCalendarPage.getPage().checkCalendar(), "The Calendar did not load.");
    }


    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

}
