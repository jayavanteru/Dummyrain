package admin.Settings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewBrandingSecurityRoles {

  private AdminApp adminApp;
  private SoftAssert softAssert;

  private String userId;
  private String userId2;

  @BeforeClass
  public void setup() {
    adminApp = new AdminApp();
    softAssert = new SoftAssert();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", "GLOBAL");

    userId = adminApp.createUserByEmailIfNotExists("branding+superuser1234@rainfocus.com", AdminApp.orgIBMCode);
    userId2 = adminApp.createUserByEmailIfNotExists("oldbranding+superuser1234@rainfocus.com", AdminApp.orgIBMCode);
    OrgEventData.getPage().setOrgAndEvent("IBM", "Eventgers Test Event");
  }

  @AfterClass
  public void cleanUp() {
    PageConfiguration.getPage().quit();
  }

  @AfterMethod
  public void afterMethod() {
    EditUserPage.getPage().assignRole(userId);
    OrgEventData.getPage().setOrgAndEvent("IBM", "GLOBAL");
    EditUserPage.getPage().assignRole(userId);
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-32192", chromeIssue = "RA-32191")
  public void testNewBrandingSecurityRole() {
    EditUserPage.getPage().assignRole(userId, "New Branding - Locked", "Call Center Administrator");

    // todo change this from spoofing to actually logging in as the user
    EditUserPage.getPage().spoofUser(userId);

    NavigationBar navigationBar = NavigationBar.getPage();
    softAssert.assertTrue(navigationBar.isOrgPanelVisible(), "New admin org panel should be visible");
    softAssert.assertFalse(navigationBar.isExitButtonVisible(), "Exit new admin button should not be visible");

    // todo this is a temporary way to unspoof from a user while the "Return to User" button is not visible in the new admin branding
    PageConfiguration.getPage().post(PropertyReader.instance().getProperty("adminUrl") + "/unspoofUser.focus");
    PageConfiguration.getPage().refreshPage();

    softAssert.assertAll();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-32212", chromeIssue = "RA-32211")
  public void testOldBrandingSecurityRole() {
    EditUserPage.getPage().assignRole(userId2, "Workflow Administrator");

    // todo change this from spoofing to actually logging in as the user
    EditUserPage.getPage().spoofUser(userId2);

    NavigationBar navigationBar = NavigationBar.getPage();
    softAssert.assertFalse(navigationBar.isOrgPanelVisible(), "New admin org panel should not be visible");
    softAssert.assertFalse(navigationBar.isExitButtonVisible(), "Exit new admin button should not be visible");
    softAssert.assertFalse(navigationBar.isSwitchToBetaVisible(), "Enter new admin button should not be visible");

    softAssert.assertTrue(navigationBar.isWorkflowIdentifierVisible(), "User should have access to Workflows");

    // todo this is a temporary way to unspoof from a user while the "Return to User" button is not visible in the new admin branding
    PageConfiguration.getPage().post(PropertyReader.instance().getProperty("adminUrl") + "/unspoofUser.focus");
    PageConfiguration.getPage().refreshPage();

    softAssert.assertAll();
  }

}
