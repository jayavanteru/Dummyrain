package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorPackageSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorPrerequisitePackages {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName, exhibitorId,
            package1Name, package1Id,
            package2Name, package2Id;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deletePackage(package1Id);
        adminApp.deletePackage(package2Id);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20203", firefoxIssue = "RA-25774")
    public void prerequisitePackage() {
        setUp();
        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().packageIsChildOrSubpackage(package1Name, package2Name), "PACKAGE DID NOT APPEAR AS SUBPACKAGE");
    }

    public void setUp(){
        packages();
        exhibitor();
    }

    public void packages(){
        package1Id = adminApp.createExhibitorPackage(package1Name = dataGenerator.generateName(), package1Name, "100","0");
        package2Id = adminApp.createExhibitorPackage(package2Name = dataGenerator.generateName(), package2Name, "100","0");

        ExhibitorPackageSearchPage.getPage().navigate();
        ExhibitorPackageSearchPage.getPage().searchForPackageByText(package2Name);
        ExhibitorPackageSearchPage.getPage().clickResult(0);
        NewPackagePage.getPage().clickPackageRelationsDropDown();
        NewPackagePage.getPage().selectPrerequisitePackage(package1Name);
        NewPackagePage.getPage().submit();
    }

    public void exhibitor(){
        exhibitorId =  adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        EditExhibitorPage.getPage().clickOrdersTab();
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(package1Name);
    }
}
