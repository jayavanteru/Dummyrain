package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPackagePage;
import apps.admin.adminPageObjects.exhibits.ExhibitorPackageSearchPage;
import apps.admin.adminPageObjects.exhibits.NewExhibitorPackagePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

/**
 * Created by nic on 11/14/17.
 */
public class PackageCreation {

    private AdminApp adminApp;
    private String packageId;

    @BeforeClass
    public void adminSetup(){
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event F");
    }

    @Test(groups = {"prodTest", ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25612", chromeIssue = "RA-20198")
    public void createPackage(){
        String name = "Automation"+new DataGenerator().generateString(5);
        String name2 = "Automation"+new DataGenerator().generateString(5);

        NewExhibitorPackagePage packagePage = NewExhibitorPackagePage.getPage();
        EditExhibitorPackagePage editPackagePage = EditExhibitorPackagePage.getPage();

        packagePage.navigate();
        packagePage.waitForPageLoad();
        packagePage.createPackage(name);
        ExhibitorPackageSearchPage exhibitorPackages = ExhibitorPackageSearchPage.getPage();
        exhibitorPackages.waitForPageLoad();
        String packageName = exhibitorPackages.searchPackage(name);
        packageId = exhibitorPackages.getId(packageName);
        Assert.assertEquals(packageName, name, "Could not find a package that is named: "  + name);

        //edit package
        editPackagePage.navigate(packageId);
        editPackagePage.setName(name2);
        editPackagePage.submit();

        //verify saved edit
        packageName = exhibitorPackages.searchPackage(name);
        Assert.assertNotEquals(packageName, name, "changed package name should not have found "  + name);
        packageName = exhibitorPackages.searchPackage(name2);
        Assert.assertEquals(packageName, name2, "Could not find a package that is named: "  + name2);

        //delete package
        exhibitorPackages.deletePackage(0);
        Utils.sleep(200);
        packageName = exhibitorPackages.searchPackage(name2);
        Assert.assertNotEquals(packageName, name2, "deleted package should not be found "  + name2);
        packageId = null;
    }

    @AfterClass
    public void end(){
        if (packageId != null) {
            adminApp.deletePackage(packageId);
        }
        PageConfiguration.getPage().quit();
    }
}
