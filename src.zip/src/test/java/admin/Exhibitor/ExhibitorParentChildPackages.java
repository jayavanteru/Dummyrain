package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorPackageSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorParentChildPackages {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName, exhibitorId,
            parentPackageName, parentPackageId,
            childPackageName, childPackageId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deletePackage(parentPackageId);
        adminApp.deletePackage(childPackageId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20202", firefoxIssue = "RA-25775")
    public void parentChildPackages() {
        setUp();

        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().packageIsChildOrSubpackage(parentPackageName, childPackageName), "PACKAGE IS NOT CHILD PACKAGE");
    }

    private void setUp() {
        packages();
        exhibitor();
    }

    private void packages() {
        parentPackageId = adminApp.createExhibitorPackage(parentPackageName = dataGenerator.generateName(), parentPackageName, "100", "0");
        childPackageId = adminApp.createExhibitorPackage(childPackageName = dataGenerator.generateName(), childPackageName, "100", "0");

        ExhibitorPackageSearchPage.getPage().navigate();
        ExhibitorPackageSearchPage.getPage().searchForPackageByText(childPackageName);
        ExhibitorPackageSearchPage.getPage().clickResult(0);
        NewPackagePage.getPage().clickPackageRelationsDropDown();
        NewPackagePage.getPage().selectParentPackage(parentPackageName);
        NewPackagePage.getPage().submit();
    }

    private void exhibitor() {
        exhibitorId =  adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        EditExhibitorPage.getPage().clickOrdersTab();
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(parentPackageName);
    }
}
