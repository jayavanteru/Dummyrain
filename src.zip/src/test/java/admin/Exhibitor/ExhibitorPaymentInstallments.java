package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorOrdersTab;
import apps.admin.adminPageObjects.exhibits.CreateExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ExhibitorPaymentInstallments {
    private AdminApp adminApp;
    DataGenerator dataGenerator = new DataGenerator();
    String exhibitorId, exhibitorName;
    ExhibitorSearchPage exhibitorSearchPage;
    AdminExhibitorOrdersTab adminExhibitorOrdersTab;

    @BeforeMethod
    public void setUp(){
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();

    }

    @AfterClass
    public void deleteExhibitor() {
        adminApp.deleteExhibitor(exhibitorId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20183", firefoxIssue = "RA-25791")
    public void paymentInstallments() throws InterruptedException {
        exhibitorSearchPage = ExhibitorSearchPage.getPage();
        adminExhibitorOrdersTab = AdminExhibitorOrdersTab.getPage();
        exhibitorSearchPage.navigate();

        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        adminExhibitorOrdersTab.navigate(exhibitorId);
        adminExhibitorOrdersTab.addOrder();
        adminExhibitorOrdersTab.selectPackage("Carpet");
        adminExhibitorOrdersTab.clickNextOnAddOrderModal();
        adminExhibitorOrdersTab.fillOutOrder();
        adminExhibitorOrdersTab.toggleSendInvoice();
        adminExhibitorOrdersTab.submitOrder();
        adminExhibitorOrdersTab.clickInstallments();
        adminExhibitorOrdersTab.selectFirstInstallmentOrder();
        adminExhibitorOrdersTab.clickAddInstallment();
        adminExhibitorOrdersTab.enterPaymentAmount("100");
        adminExhibitorOrdersTab.selectDate(DateTime.now().plusDays(5));
        adminExhibitorOrdersTab.clickSaveInstallment();
        adminExhibitorOrdersTab.clickInstallments();
        Assert.assertTrue(adminExhibitorOrdersTab.installmentExists(), "Installment does not exist");

    }
}
