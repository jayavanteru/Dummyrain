package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadsTab;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LeadsTab {
    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24359", firefoxIssue = "RA-25834")
    public void leadSearch(){
        String exhibitorName = "Acuity";
        String leadName = "Brett";
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        ExhibitorSearchPage.getPage().clickFirstExhibitor();
        EditExhibitorPage.getPage().clickLeadsTab();
        AdminExhibitorLeadsTab.getPage().search(leadName);
        Assert.assertTrue(AdminExhibitorLeadsTab.getPage().leadExists(leadName));
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }
}
