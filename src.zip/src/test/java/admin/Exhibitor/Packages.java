package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Packages {

    private AdminApp adminApp;
    String package1Id, package2Id, package3Id, exhibitorId;

    @BeforeClass
    public void setUp(){
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event F");
    }

    @AfterClass
    public void tearDown(){
        if(!(exhibitorId == null)){
            adminApp.deleteExhibitor(exhibitorId);
        }

        if (package1Id != null) {
            adminApp.deletePackage(package1Id);
        }
        if (package2Id != null) {
            adminApp.deletePackage(package2Id);
        }
        if (package3Id != null) {
            adminApp.deletePackage(package3Id);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20204", firefoxIssue = "RA-25772")
    public void canNotPurchasePackageWith(){
        DataGenerator dataGenerator = new DataGenerator();
        String packageName1 = dataGenerator.generateName();
        String packageName2 = dataGenerator.generateName();

        //create Package 1
        NewExhibitorPackagePage.getPage().navigate();
        NewExhibitorPackagePage.getPage().createPackage(packageName1);
        ExhibitorPackageSearchPage.getPage().searchPackage(packageName1);
        package1Id = ExhibitorPackageSearchPage.getPage().getId(packageName1);

        //create Package 2
        NewExhibitorPackagePage.getPage().navigate();
        NewExhibitorPackagePage.getPage().setName(packageName2);
        NewExhibitorPackagePage.getPage().setTypeToExhibitor();
        NewExhibitorPackagePage.getPage().setCode(dataGenerator.generateString(20));
        NewExhibitorPackagePage.getPage().setSubType("Auto Generated");
        NewExhibitorPackagePage.getPage().clickPackageRelationsDropDown();
        NewExhibitorPackagePage.getPage().setCannotPurchaseDropDown(packageName1);
        NewExhibitorPackagePage.getPage().submit();

        ExhibitorPackageSearchPage.getPage().searchPackage(packageName2);
        package2Id = ExhibitorPackageSearchPage.getPage().getId(packageName2);

        //select any exhibitor
        ExhibitorSearchPage.getPage().navigate();
        if(ExhibitorSearchPage.getPage().isAnySearchResults()){
            ExhibitorSearchPage.getPage().editItem();
        } else {
            exhibitorId = adminApp.createExhibitorInCurrentEvent(dataGenerator.generateName());
        }
        EditExhibitorPage.getPage().clickOrdersTab();
        AdminExhibitorOrdersTab.getPage().waitForPageLoad();
        AdminExhibitorOrdersTab.getPage().addOrder();
        AdminExhibitorOrdersTab.getPage().selectPackage(packageName2);
        AdminExhibitorOrdersTab.getPage().selectPackage(packageName1);
        AdminExhibitorOrdersTab.getPage().clickNextOnAddOrderModal();
        AdminExhibitorOrdersTab.getPage().setComment("doh");
        Assert.assertEquals(packageName2, AdminExhibitorOrdersTab.getPage().getFirstOrderText());
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20200", firefoxIssue = "RA-25776")
    public void deletePackage(){
        //create package
        String packageName = new DataGenerator().generateName();
        NewExhibitorPackagePage.getPage().navigate();
        NewExhibitorPackagePage.getPage().createPackage(packageName);

        //search for package
        ExhibitorPackageSearchPage.getPage().searchPackage(packageName);

        //delete package
        ExhibitorPackageSearchPage.getPage().deletePackage(0);

        //search for package
        ExhibitorPackageSearchPage.getPage().searchPackage(packageName);

        //assert package has been deleted
        Assert.assertFalse(ExhibitorPackageSearchPage.getPage().elementExists(packageName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20199", firefoxIssue = "RA-25777")
    public void editPackage(){
        // create package
        String packageName = new DataGenerator().generateName();
        String packageRename = new DataGenerator().generateName();
        NewExhibitorPackagePage.getPage().navigate();
        NewExhibitorPackagePage.getPage().createPackage(packageName);
        ExhibitorPackageSearchPage.getPage().searchPackage(packageName);
        package3Id = ExhibitorPackageSearchPage.getPage().getId(packageName);

        // edit package
        ExhibitorPackageSearchPage.getPage().searchPackage(packageName);
        ExhibitorPackageSearchPage.getPage().clickResult(0);
        EditExhibitorPackagePage.getPage().clearName();
        EditExhibitorPackagePage.getPage().setName(packageRename);
        EditExhibitorPackagePage.getPage().submit();

        // assert edit happened
        ExhibitorPackageSearchPage.getPage().searchPackage(packageRename);
        Assert.assertTrue(ExhibitorPackageSearchPage.getPage().elementExists(packageRename));
    }
}
