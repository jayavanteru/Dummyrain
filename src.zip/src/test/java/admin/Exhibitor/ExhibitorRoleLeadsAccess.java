package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.leads.leadsPageObjects.LeadsAppPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorRoleLeadsAccess {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorId, exhibitorName,
            role1Id, role1Name,
            role2Id, role2Name,
            attendee1Email, attendee1Id,
            attendee2Email, attendee2Id;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        AttendeeSearchPage.getPage().navigate();

        adminApp.deleteAttendee(attendee1Id);
        adminApp.deleteAttendee(attendee2Id);
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteExhibitorRole(role1Id);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-40595", firefoxIssue = "RA-40596")
    public void exhibitorRoleLeadsAccess() {
        setUp();
        adminApp.spoofIntoLeads(attendee1Email, 1);
        Assert.assertTrue(LeadsAppPage.getPage().appRendered(), "APP DID NOT RENDER");
        adminApp.spoofIntoLeads(attendee2Email, 1);
        Assert.assertTrue(LeadsAppPage.getPage().accessErrorAppears(), "ERROR MESSAGE DID NOT RENDER");
    }

    private void setUp() {
        //attendees
        attendee1Id = adminApp.createAttendee(attendee1Email = dataGenerator.generateEmail());
        attendee2Id = adminApp.createAttendee(attendee2Email = dataGenerator.generateEmail());

        //roles
        role1Id = adminApp.createExhibitorRole(role1Name = dataGenerator.generateName(), "Primary Owner", true, true);
        role2Id = adminApp.createExhibitorRole(role2Name = dataGenerator.generateName(), "Other", false, false);

        //exhibitor
        adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendee1Email, role1Name);
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendee2Email, role2Name);
    }
}
