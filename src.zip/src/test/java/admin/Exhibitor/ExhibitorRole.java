package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorRole {

    private AdminApp adminApp;
    String roleName;
    String roleId;

    @BeforeClass
    public void setUp(){
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event E");
        NavigationBar.getPage().collapse();

        //ExhibitorRolesSearchPage.getPage().navigate();

        //create exhibitor role
        adminApp.createExhibitorRoleWithRoleAndPermissions(roleName = new DataGenerator().generateName(), "Primary Owner", new String[]{});

    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20193", firefoxIssue = "RA-25782")
    public void createExhibitorRole(){
        //assert exhibitor role exists
        ExhibitorRolesSearchPage.getPage().navigate();
        ExhibitorRolesSearchPage.getPage().search(roleName);
        Assert.assertTrue(ExhibitorRolesSearchPage.getPage().roleExists(roleName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20197", firefoxIssue = "RA-25779")
    public void deleteExhibitorRole(){
        String deleteRole;
        //create exhibitor role
        adminApp.createExhibitorRoleWithRoleAndPermissions(deleteRole = new DataGenerator().generateName(), "Primary Owner", new String[]{});

        //delete exhibitor role
        ExhibitorRolesSearchPage.getPage().search(deleteRole);
        ExhibitorRolesSearchPage.getPage().deleteFirstExhibitorRole();

        //assert exhibitor has been deleted
        ExhibitorRolesSearchPage.getPage().search(deleteRole);
        Assert.assertFalse(ExhibitorRolesSearchPage.getPage().roleExists(deleteRole));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20194", firefoxIssue = "RA-25781")
    public void assignedExhibitorRole(){

        //create attendee
        String attendeeEmail = new DataGenerator().generateEmail();
        String attendeeId = adminApp.createAttendee(attendeeEmail);

        //create exhibitor
        String exhibitorName = new DataGenerator().generateName();
        String exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName);

        //assign attendee to exhibitor
        AdminExhibitorContactsTab.getPage().clickAddParticipantButton();
        AdminExhibitorNewContactPage.getPage().fillOutForm(attendeeEmail, roleName);
        EditExhibitorPage.getPage().clickContactsTab();
        Assert.assertTrue(AdminExhibitorContactsTab.getPage().isContactOnExhibitor(attendeeEmail));

        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteExhibitor(exhibitorId);

    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20195", firefoxIssue = "RA-24812")
    public void givePortalAccess(){
        //give portal access
        ExhibitorRolesSearchPage.getPage().navigate();
        ExhibitorRolesSearchPage.getPage().search(roleName);
        ExhibitorRolesSearchPage.getPage().clickResult(0);
        EditExhibitorRolePage.getPage().givePortalAccess();
        EditExhibitorRolePage.getPage().submit();

        //assert portal role has portal access
        ExhibitorRolesSearchPage.getPage().search(roleName);
        ExhibitorRolesSearchPage.getPage().clickResult(0);
        Assert.assertTrue(EditExhibitorRolePage.getPage().hasPortalAccess());
    }

    @AfterClass
    public void tearDown(){
        ExhibitorRolesSearchPage.getPage().navigate();
        ExhibitorRolesSearchPage.getPage().search(roleName);
        roleId = ExhibitorRolesSearchPage.getPage().getIdByName(roleName);
        adminApp.deleteExhibitor(roleId);
        PageConfiguration.getPage().quit();
    }
}
