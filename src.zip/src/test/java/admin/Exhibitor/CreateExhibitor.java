package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.CreateExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CreateExhibitor {

    DataGenerator dataGenerator = new DataGenerator();
    String exhibitorName = dataGenerator.generateName();
    private String exhibitorId;
    private AdminApp adminApp;

    @BeforeClass
    public void login() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event B");
    }

    @AfterClass
    public void quit() {
        adminApp.deleteExhibitor(exhibitorId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25616", chromeIssue = "RA-20178")
    public void exhibitorCreation() {
        String exhibitorName = dataGenerator.generateName();
        String exhibitorID = adminApp.createExhibitorInCurrentEvent(exhibitorName);

        //search for exhibitor
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName));

        //delete exhibitor
        adminApp.deleteExhibitor(exhibitorID);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25615", chromeIssue = "RA-20179")
    public void duplicateExhibitor() {
        final CreateExhibitorPage createpage = CreateExhibitorPage.getPage();
        String name = new DataGenerator().generateString(6) + "automation";

        exhibitorId = adminApp.createExhibitorInCurrentEvent(name);

        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().add();


        createpage.filloutForm(OrgEventData.getPage().getCurrentEvent(), name);

        //the error message includes an x in the text we don't care about that
        String errorMsg = createpage.getErrorMessage().replace("x", "").trim();
        Assert.assertEquals(errorMsg, "Company Name is required");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24461", firefoxIssue = "RA-25839")
    public void deleteExhibitorAdmin(){
        CreateExhibitorPage.getPage().navigate();
        CreateExhibitorPage.getPage().filloutForm( "Blue Event B", exhibitorName);
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName), "EXHIBITOR WAS NOT CREATED");
        ExhibitorSearchPage.getPage().deleteFirstExhibitor();
        Assert.assertFalse(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName), "EXHIBITOR WAS NOT DELETED");
    }
}
