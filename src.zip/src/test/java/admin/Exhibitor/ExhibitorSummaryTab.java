package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorSummaryTab {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName, exhibitorId,
            boothName, boothId,
            packageName, packageId;
    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event B");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteBooth(boothId);
        adminApp.deletePackage(packageId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-39767", firefoxIssue = "RA-39768")
    public void summaryTab() {
        setUp();
        EditExhibitorPage.getPage().navigate(exhibitorId);
        Assert.assertTrue(ExhibitorSummaryTabPage.getPage().boothExists(boothName), "BOOTH DOES NOT EXISTS");
        Assert.assertTrue(ExhibitorSummaryTabPage.getPage().packageExists(boothName), "PACKAGE DOES NOT EXISTS");
        Assert.assertTrue(ExhibitorSummaryTabPage.getPage().leadOrdersExists(), "LEAD DEVICE DOES NOT EXISTS");
    }

    public void setUp(){
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        assignBooth();
        purchasePackage();
        purchaseLead();
    }

    public void assignBooth(){
        boothId = adminApp.createBooth(boothName = dataGenerator.generateName(), exhibitorName);
    }

    public void purchasePackage(){
        packageId = adminApp.createExhibitorPackage(packageName = dataGenerator.generateName(), packageName, "1", "0");

        EditExhibitorPage.getPage().navigate(exhibitorId);

        EditExhibitorPage.getPage().clickOrdersTab();
        PageConfiguration.getPage().refreshPage();
        AdminExhibitorOrdersTab.getPage().addOrder();
        AdminExhibitorOrdersTab.getPage().orderPackageForFree(packageName);
    }

    public void purchaseLead(){
        EditExhibitorPage.getPage().clickLeadOrdersTab();
        PageConfiguration.getPage().refreshPage();
        AdminExhibitorOrdersTab.getPage().addOrder();
        AdminExhibitorOrdersTab.getPage().orderPackageForFree("Leads Device");
    }
}
