package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadOrdersTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorOrdersTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import configuration.PropertyReader;
import interaction.gmail.EmailApi;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ExhibitorOrder {

    private AdminApp adminApp;
    private String exhibitorId;
    DataGenerator dataGenerator = new DataGenerator();

    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event B");

        exhibitorId = adminApp.createExhibitorInCurrentEvent(dataGenerator.generateName());
    }

    @AfterClass
    public void deleteExhibitor() {
        adminApp.deleteExhibitor(exhibitorId);
        PageConfiguration.getPage().quit();
    }

    @BeforeMethod
    public void navigateHome() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20201", firefoxIssue = "RA-20796")
    public void placeOrderForExhibitor() {
        String packageName = "Package A";
        String emailInvoice = "Exhibitor Invoice";
        String cancelEmail = "Exhibitor Invoice";
        String realEmail = PropertyReader.instance().getProperty("adminRealEmail");
        EmailApi emailApi = EmailApi.emailClient();
        AdminExhibitorOrdersTab ordersTab = AdminExhibitorOrdersTab.getPage();
        ordersTab.navigate(exhibitorId);

        ordersTab.addOrder();
        ordersTab.selectPackage(packageName);
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.fillOutOrder();
        ordersTab.setEmailList(realEmail);
        ordersTab.submitOrder();
        Assert.assertTrue(emailApi.waitForEmail(emailInvoice));
        Assert.assertTrue(emailApi.getEmail(emailInvoice).getAttachments().get(0).contains(packageName), "problem with the email invoice attachment");
        PageConfiguration.getPage().refreshPage();

        Assert.assertTrue(ordersTab.verifyPackageOrdered(packageName), "package was not ordered " + packageName);

        ordersTab.checkFirstOrder();
        ordersTab.deleteOrders();
        ordersTab.setEmailList(realEmail);
        ordersTab.cancelOrder();
        Assert.assertTrue(emailApi.waitForEmail(cancelEmail));
        Assert.assertTrue(emailApi.getEmail(cancelEmail).getAttachments().get(0).contains(packageName), "problem with the email invoice attachment");
        Assert.assertFalse(ordersTab.verifyPackageOrdered(packageName), "package was not deleted " + packageName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20184", firefoxIssue = "RA-25613")
    public void placeLeadOrder() {
        String packageName = "Leads Device";
        AdminExhibitorLeadOrdersTab leadOrdersTab = AdminExhibitorLeadOrdersTab.getPage();

        leadOrdersTab.navigate(exhibitorId);
        EditExhibitorPage.getPage().clickLeadOrdersTab();
        AdminExhibitorOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().orderPackageForFree(packageName);

        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(leadOrdersTab.verifyPackageOrdered(packageName), "package was not ordered " + packageName);

        leadOrdersTab.selectAllOrders();
        leadOrdersTab.deleteOrders();
        leadOrdersTab.toggleCancellationEmail();
        leadOrdersTab.cancelOrder();
        Assert.assertFalse(leadOrdersTab.verifyPackageOrdered(packageName), "package was not deleted " + packageName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20185", firefoxIssue = "RA-25789")
    public void deleteLeadOrder(){
        String packageName = "Leads Device";
        AdminExhibitorLeadOrdersTab leadOrdersTab = AdminExhibitorLeadOrdersTab.getPage();

        leadOrdersTab.navigate(exhibitorId);
        EditExhibitorPage.getPage().clickLeadOrdersTab();
        AdminExhibitorOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().orderPackageForFree(packageName);

        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(leadOrdersTab.verifyPackageOrdered(packageName), "package was not ordered " + packageName);

        leadOrdersTab.checkFirstOrder();
        leadOrdersTab.deleteOrders();
        leadOrdersTab.toggleCancellationEmail();
        leadOrdersTab.cancelOrder();
        Assert.assertFalse(leadOrdersTab.verifyPackageOrdered(packageName), "package was not deleted " + packageName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24345", firefoxIssue = "RA-25828")
    public void cancelExhibitorOrder(){
        String packageName = "Package A";
        AdminExhibitorOrdersTab ordersTab = AdminExhibitorOrdersTab.getPage();
        ordersTab.navigate(exhibitorId);

        ordersTab.addOrder();
        ordersTab.selectPackage(packageName);
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.fillOutOrder();
        ordersTab.toggleSendInvoice();
        ordersTab.submitOrder();
        Utils.sleep(1000);
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(1000);

        Assert.assertTrue(ordersTab.verifyPackageOrdered(packageName), "package was not ordered " + packageName);

        ordersTab.checkFirstOrder();
        ordersTab.deleteOrders();
        ordersTab.toggleCancellationEmail();
        ordersTab.cancelOrder();
        Assert.assertFalse(ordersTab.verifyPackageOrdered(packageName), "package was not deleted " + packageName);
    }
}
