package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.NewRegCodeAllocationPage;
import apps.admin.adminPageObjects.exhibits.RegCodeAllocationSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorRegCodeAllocations {

    private AdminApp adminApp;
    DataGenerator dataGenerator = new DataGenerator();

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-25010", firefoxIssue = "RA-25011")
    public void createRegCodeAllocation() {
        String regCodeName = dataGenerator.generateName();
        NewRegCodeAllocationPage.getPage().navigate();
        NewRegCodeAllocationPage.getPage().setName(regCodeName);
        NewRegCodeAllocationPage.getPage().removeFirstCriteria();
        NewRegCodeAllocationPage.getPage().selectPackage("2 Day Conference Pass");
        NewRegCodeAllocationPage.getPage().selectDiscount("CertifiedUser");
        NewRegCodeAllocationPage.getPage().selectCategory("Exhibitors");
        NewRegCodeAllocationPage.getPage().setQuantity("1");
        NewRegCodeAllocationPage.getPage().setAvailableActions("Invite");
        NewRegCodeAllocationPage.getPage().clickSubmit();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(!RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation was not created successfully");
        String id = RegCodeAllocationSearchPage.getPage().getId(regCodeName);
        adminApp.deleteRegCodeAllocation(id);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24357", firefoxIssue = "RA-24820")
    public void deleteRegCodeAllocation() {
        //create test reg code
        String regCodeName = dataGenerator.generateName();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().addItem();
        NewRegCodeAllocationPage.getPage().setName(regCodeName);
        NewRegCodeAllocationPage.getPage().selectPackage("2 Day Conference Pass");
        NewRegCodeAllocationPage.getPage().selectDiscount("CertifiedUser");
        NewRegCodeAllocationPage.getPage().selectCategory("Exhibitors");
        NewRegCodeAllocationPage.getPage().setQuantity("1");
        NewRegCodeAllocationPage.getPage().setAvailableActions("Invite");
        NewRegCodeAllocationPage.getPage().clickSubmit();

        RegCodeAllocationSearchPage.getPage().search(regCodeName);

        //delete reg code
        RegCodeAllocationSearchPage.getPage().deleteRegCode();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation not deleted successfully");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-29321", firefoxIssue = "RA-29621")
    public void multiEventRegCode(){
        String regCodeName = dataGenerator.generateName();

        //create reg code in event 1 - Assert Reg Code Exists
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().addItem();
        NewRegCodeAllocationPage.getPage().setName(regCodeName);
        NewRegCodeAllocationPage.getPage().removeFirstCriteria();
        NewRegCodeAllocationPage.getPage().selectPackage("2 Day Conference Pass");
        NewRegCodeAllocationPage.getPage().selectDiscount("CertifiedUser");
        NewRegCodeAllocationPage.getPage().selectCategory("Exhibitors");
        NewRegCodeAllocationPage.getPage().setQuantity("1");
        NewRegCodeAllocationPage.getPage().setAvailableActions("Invite");
        NewRegCodeAllocationPage.getPage().clickSubmit();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(!RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation was not created successfully");

        //create reg code in event 2 - Assert Reg Code Exists
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Test Event");
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().addItem();
        NewRegCodeAllocationPage.getPage().setName(regCodeName);
        NewRegCodeAllocationPage.getPage().removeFirstCriteria();
        NewRegCodeAllocationPage.getPage().selectPackage("A Most Rad Package");
        NewRegCodeAllocationPage.getPage().selectDiscount("Test Discount");
        NewRegCodeAllocationPage.getPage().selectCategory("Exhibitor");
        NewRegCodeAllocationPage.getPage().setQuantity("1");
        NewRegCodeAllocationPage.getPage().setAvailableActions("Invite");
        NewRegCodeAllocationPage.getPage().clickSubmit();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(!RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation was not created successfully");

        //delete reg code event 1
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
        RegCodeAllocationSearchPage.getPage().deleteRegCode();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation not deleted successfully");

        //delete reg code event 2
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
        RegCodeAllocationSearchPage.getPage().deleteRegCode();
        RegCodeAllocationSearchPage.getPage().navigate();
        RegCodeAllocationSearchPage.getPage().search(regCodeName);
        Assert.assertTrue(RegCodeAllocationSearchPage.getPage().elementDoesNotExist(regCodeName), "Reg code allocation not deleted successfully");
    }
}