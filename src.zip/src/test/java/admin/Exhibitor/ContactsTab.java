package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ContactsTab {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName = dataGenerator.generateName();
    String exhibitorID;
    String participantEmail = dataGenerator.generateEmail();
    String participantID;

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");
        NavigationBar.getPage().collapse();

        //create attendee
        participantID = adminApp.createAttendee(participantEmail);

        //create exhibitor
        exhibitorID = adminApp.createExhibitorInCurrentEvent(exhibitorName);
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(participantEmail, "Primary Owner");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27874", firefoxIssue = "RA-27875")
    public void addParticipantToExhibitor(){
        Assert.assertTrue(AdminExhibitorNewContactPage.getPage().participantExists(participantEmail),"Participant has not bee added");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27882", firefoxIssue = "RA-27883")
    public void editParticipant(){
        PageConfiguration.getPage().refreshPage();
        EditExhibitorPage.getPage().clickContactsTab();
        String newParticipantName = new DataGenerator().generateName();
        AdminExhibitorContactsTab.getPage().editParticipant(participantEmail);
        AdminExhibitorNewContactPage.getPage().setFirstName(newParticipantName);
        AdminExhibitorNewContactPage.getPage().setLastName(newParticipantName);
        AdminExhibitorNewContactPage.getPage().submit();
        Assert.assertTrue(AdminExhibitorContactsTab.getPage().isContactOnExhibitor(newParticipantName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27880", firefoxIssue = "RA-27881")
    public void removeParticipant(){
        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(AdminExhibitorContactsTab.getPage().isContactOnExhibitor(participantEmail), "YOU DUN GOOFED BOI, DER DUN NOT BE A PERSON RIGHT THER");
        AdminExhibitorContactsTab.getPage().removeParticipant(participantEmail);
        PageConfiguration.getPage().refreshPage();
        Assert.assertFalse(AdminExhibitorContactsTab.getPage().isContactOnExhibitor(participantEmail), "YOU DUN GOOFED BOI, DER DUN BE A PERSON RIGHT THER, BUT DONT NOT NEED ONE");
    }

    @AfterClass
    public void tearDown(){
        adminApp.deleteAttendee(participantID);
        adminApp.deleteExhibitor(exhibitorID);
        PageConfiguration.getPage().quit();
    }
}