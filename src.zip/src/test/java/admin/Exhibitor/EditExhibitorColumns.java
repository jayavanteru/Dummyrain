package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.EditColumnsModal;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EditExhibitorColumns {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorId, exhibitorName,
            attributeId, attributeName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttribute(attributeId);
        adminApp.deleteExhibitor(exhibitorId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-40208", firefoxIssue = "RA-40209")
    public void editExhibitorColumns() {
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{"One"}, CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor);
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();

        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "One");
        PersistentProfileForm.getPage().submit();

        ExhibitorSearchPage.getPage().navigate();
        EditColumnsModal.getPage().addColumn(attributeName);

        Assert.assertTrue(ExhibitorSearchPage.getPage().columnExists(attributeName), "COLUMN WAS NOT ON SEARCH PAGE");
        ExhibitorSearchPage.getPage().searchForExhibitor(exhibitorName);
        Assert.assertTrue(ExhibitorSearchPage.getPage().attributeValueExists(exhibitorName, "One"), "ATTRIBUTE VALUE DOES NOT EXIST");
    }
}
