package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.CreateExhibitorPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.exhibits.GlobalExhibitorPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class GlobalExhibitors {
    DataGenerator dataGenerator = new DataGenerator();
    String exhibitorName = dataGenerator.generateName();

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        //create exhibitor
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().add();
        CreateExhibitorPage.getPage().filloutForm("Constellations", exhibitorName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27977", firefoxIssue = "RA-27978")
    public void multiEventExhibitor(){
        //add exhibitor to another event
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        ExhibitorSearchPage.getPage().clickFirstExhibitor();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
        GlobalExhibitorPage.getPage().addEvent("Test Event");
        ExhibitorSearchPage.getPage().navigate();

        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Test Event");
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName), "Exhibitor is not showing on the other event");
    }

    @AfterClass
    public void tearDown(){
        //delete exhibitor from Constellations
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        ExhibitorSearchPage.getPage().deleteFirstExhibitor();

        //delete exhibitor from Test Event
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Test Event");
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        ExhibitorSearchPage.getPage().deleteFirstExhibitor();

        PageConfiguration.getPage().quit();
    }
}