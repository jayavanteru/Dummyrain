package admin.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorTasks {
    /*
        Not Gonna lie ... i'm super concerned about the corona virus!
     */
    DataGenerator dataGenerator = new DataGenerator();
    String taskName = dataGenerator.generateName(), taskId,
            qualifierName = dataGenerator.generateName(), qualifierId;
    AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event B");
        NavigationBar.getPage().collapse();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27365", firefoxIssue = "RA-27366")
    public void createExhibitorTask(){
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setName(taskName);
        NewTaskPage.getPage().setGroup("alpha");
        NewTaskPage.getPage().setEntityType("Exhibitor");
        NewTaskPage.getPage().setType("External URL");
        NewTaskPage.getPage().createNewQualifier();
        NewTaskQualifierModal.getPage().setName(qualifierName);
        NewTaskQualifierModal.getPage().setCriteria("First Name", "equal to", dataGenerator.generateString(10));
        NewTaskQualifierModal.getPage().save();
        NewTaskPage.getPage().setExternalURL("google.com");
        NewTaskPage.getPage().submit();
        TasksSearchPage.getPage().search(taskName);
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
        TasksSearchPage.getPage().navigate();
        TasksSearchPage.getPage().search(taskName);
        Assert.assertTrue(TasksSearchPage.getPage().taskExists(taskName));
        TasksSearchPage.getPage().editItem();
        EditTaskPage.getPage().removeQualifiers();
        NewTaskPage.getPage().submit();
    }

    @AfterClass
    public void tearDown(){
        //remove task qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        qualifierId = TaskQualifierSearchPage.getPage().getId(qualifierName);
        adminApp.deleteTaskQualifier(qualifierId);

        adminApp.deleteTask(taskId);

        PageConfiguration.getPage().quit();
    }
}
