package admin.LogIn;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import apps.admin.adminPageObjects.marketing.AdminAccountsSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LogIn {

    private String brandingUserEmail = "automation+brandinguser@rainfocus.com";
   // private String oldBrandingUser = "betatestrainfocus@gmail.com";
    private String oldBrandingUser = "jayasree.vanteru@rainfocus.com";
    private String oldBrandingUserPass = "Rainclouds!23";

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-28600", firefoxIssue = "RA-28601")
    public void loginRedirectsUserToHomePage(){
        //WORK FLOWS
        //navigate to work flows
        WorkflowsSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //ATTENDEES
        //navigate to attendees
        AttendeeSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //SESSIONS
        //navigate to sessions
        SessionSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //MEETINGS
        //navigate to meetings
        MeetingsSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //EXHIBITS
        //navigate to exhibits
        ExhibitorSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //DEMOS
        //navigate to demos
        DemosSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //ACCOUNTS
        //navigate to accounts
        AdminAccountsSearchPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //ATTRIBUTES
        //navigate to attributes
        AdminEventAttributesPage.getPage().navigate();

        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));

        //REPORTS
        //navigate to reports
        ReportsListPage.getPage().navigateToReportList();
        //log out / log in
        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();

        // assert we are at home page
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("rain.focus#home.do"));
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "AUT-6023", firefoxIssue = "AUT-6024")
  public void loginAndLogoutBetweenBrandings()
  {
    String originalAutomationUser = PropertyReader.instance().getProperty("adminEmail");
    NavigationBar navigationBar = NavigationBar.getPage();
    changeUserRole(brandingUserEmail, "Old Branding - Option", "System Administrator");
    PropertyReader.instance().setProperty("adminEmail", brandingUserEmail);

    // In old admin: logout and login, then validate we continue in old admin
    AdminLoginPage.getPage().logout();
    AdminLoginPage.getPage().login();
    Assert.assertTrue(navigationBar.isOldAdminNavVisible(), "It has not been changed to old branding");

    // In new admin: logout and login, then validate we continue in new admin
    navigationBar.switchToNewAdmin();
    AdminLoginPage.getPage().logout();
    AdminLoginPage.getPage().login();
    Assert.assertTrue(navigationBar.isOrgPanelVisible(), "It has not been changed to new branding");

    PropertyReader.instance().setProperty("adminEmail", originalAutomationUser);
    navigationBar.switchToOldAdmin();
  }

  private void changeUserRole(String userEmail, String... securityNames)
  {
    EditUserPage editUserPage = EditUserPage.getPage();
    UsersPage usersPage = UsersPage.getPage();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");

    usersPage.navigate();
    usersPage.selectUserByEmail(userEmail);

    editUserPage.setSecurityRole(securityNames);
    editUserPage.submit();
    OrgEventData.getPage().setOrgAndEvent();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-37839", chromeIssue = "RA-37838")
  public void switchOldNewAdmin()
  {
    String originalAutomationUser = PropertyReader.instance().getProperty("adminEmail");
    String originalAutomationPass = PropertyReader.instance().getProperty("adminPassword");
    NavigationBar navigationBar = NavigationBar.getPage();
    changeUserRole(oldBrandingUser, "User Administrator");
    changeUserRole(brandingUserEmail, "Old Branding - Option", "System Administrator");

    // Login with betaTestrainfocus@gmail.com user, should not be able to see new branding button
    AdminLoginPage.getPage().logout();
    PropertyReader.instance().setProperty("adminEmail", oldBrandingUser);
    PropertyReader.instance().setProperty("adminPassword", oldBrandingUserPass);
    AdminLoginPage.getPage().login();
    Assert.assertFalse(navigationBar.isSwitchToBetaVisible(), "Beta switch button should not be visible");
    AdminLoginPage.getPage().logout();

    // Login with automation+brandinguser@rainfocus.com user, be able to switch to new admin and return to the old one
    PropertyReader.instance().setProperty("adminEmail", brandingUserEmail);
    PropertyReader.instance().setProperty("adminPassword", originalAutomationPass);
    AdminLoginPage.getPage().login();

    if(navigationBar.isExitButtonVisible())
      navigationBar.switchToOldAdmin();

    Assert.assertTrue(navigationBar.isOldAdminNavVisible(), "It has not been changed to old branding");

    navigationBar.switchToNewAdmin();
    Assert.assertTrue(navigationBar.isOrgPanelVisible(), "It has not been changed to new branding");

    navigationBar.switchToOldAdmin();
    AdminLoginPage.getPage().logout();

    // return to default values
    PropertyReader.instance().setProperty("adminEmail", originalAutomationUser);
  }
}
