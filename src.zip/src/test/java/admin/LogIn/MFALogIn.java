package admin.LogIn;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import configuration.PropertyReader;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.openqa.selenium.Cookie;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class MFALogIn {
    AdminLoginPage loginPage = AdminLoginPage.getPage();
    String userEmail = "rainfocustestautomationuser+mfa@gmail.com",
    userPassword = PropertyReader.instance().getProperty("adminPassword");

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-44712", firefoxIssue = "RA-48589")
    public void emailMFA() {
        EmailApi email = EmailApi.emailClient();
        loginPage.navigate();
        loginPage.setEmail(userEmail);
        loginPage.setPassword(userPassword);
        loginPage.clickLoginButton();
        loginPage.sendMfaCode();
        email.waitForEmail("Mfa Code");
        EmailMessage mfaEmail = email.getEmail("Mfa Code");
        String emailBody = mfaEmail.getBody();
        String mfaCode = Utils.regexStringExtractor(emailBody, "([0-9]+)");
        loginPage.submitMfaCode(mfaCode, true);

        Assert.assertTrue(loginPage.isLoggedIn(), "Login failed");

        Cookie cookie = PageConfiguration.getPage().getCookieNamed("rfDevId");

        Assert.assertNull(cookie, "Remember device cookie is there when it shouldn't be.");

        loginPage.logout();

        loginPage.setEmail(userEmail);
        loginPage.setPassword(userPassword);
        loginPage.clickLoginButton();
        loginPage.sendMfaCode();
        email.waitForEmail("Mfa Code");
        mfaEmail = email.getEmail("Mfa Code");
        emailBody = mfaEmail.getBody();
        mfaCode = Utils.regexStringExtractor(emailBody, "([0-9]+)");
        loginPage.submitMfaCode(mfaCode, false);
        cookie = PageConfiguration.getPage().getCookieNamed("rfDevId");

        Assert.assertNotNull(cookie, "Remember device cookie is there.");
    }
}
