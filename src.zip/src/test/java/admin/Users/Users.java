package admin.Users;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

public class Users {

  private DataGenerator dataGenerator;
  private SoftAssert softAssert;
  private final String DAG = ("Core Reports - Attendee");

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    softAssert = new SoftAssert();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-45456", chromeIssue = "RA-19021")
  public void testCreateNewUser()
  {
    UsersPage.getPage().navigate();
    UsersPage.getPage().clickNewUserFab();

    String firstName = dataGenerator.generateName();
    String lastName = dataGenerator.generateName();
    String email = dataGenerator.generateEmail();

    String password = dataGenerator.generatePassword();

    EditUserPage.getPage().fillNewUserInfo(firstName, lastName, email, password);
    EditUserPage.getPage().setSecurityRole("Workflow Administrator");
    EditUserPage.getPage().setDAGRole(DAG);
    EditUserPage.getPage().submit();

    UsersPage.getPage().navigate();
    softAssert.assertTrue(UsersPage.getPage().userExists(email), "User did not exist when it should have.");

    softAssert.assertAll();
  }
}
