package admin.birst;

import apps.admin.adminPageObjects.analysis.birstReporting.NewReportPage;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.analysis.reporting.VisualizationReports;
import org.testng.Assert;

import java.util.List;

public class ReportTypes extends BirstReport{

    VisualizationReports reportType = VisualizationReports.getPage();

//    @Test
    public void everythingReportTypes() {
        //--------------------------------- Everything Report ---------------------------------
        getToNewReport();
        reportType.createEverythingReport();

        String[] allFilters = {"Attendee Attributes", "Attendee ReportingPage",
                "Exhibitor Attributes", "Exhibitor ReportingPage", "Meeting Attributes", "Meeting ReportingPage", "RF Survey ReportingPage",
                "Session Attributes", "Session ReportingPage", "Survey ReportingPage"};
        String[] noFilters = {};
        verifyReportSubjectAreas(allFilters, noFilters, "create everything report");
    }

//    @Test
    public void attendeeReportTypes() {
        //--------------------------------- Attendee Report ---------------------------------
        getToNewReport();
        reportType.createAttendeeReport();

        String[] allFilters = new String[]{"Attendee Attributes", "Attendee ReportingPage"};
        String[] noFilters = new String[]{"Exhibitor Attributes", "Exhibitor ReportingPage", "Meeting Attributes", "RF Survey ReportingPage",
                "Session Attributes", "Session ReportingPage", "Survey ReportingPage", "Meeting ReportingPage"};
        verifyReportSubjectAreas(allFilters, noFilters, "create attendee report");

    }

//    @Test
    public void exhibitorReportTypes() {
        //--------------------------------- Exhibitor Report ---------------------------------
        getToNewReport();
        reportType.createExhibitorReport();

        String[] allFilters = new String[]{"Exhibitor Attributes", "Exhibitor ReportingPage"};
        String[] noFilters = new String[]{"Attendee Attributes", "Attendee ReportingPage", "Meeting Attributes", "RF Survey ReportingPage",
                "Session Attributes", "Session ReportingPage", "Survey ReportingPage", "Meeting ReportingPage"};
        verifyReportSubjectAreas(allFilters, noFilters, "create exhibitor report");
    }

//    @Test
    public void sessionReportTypes() {
        //--------------------------------- Session Report ---------------------------------
        getToNewReport();
        reportType.createSessionReport();

        String[] allFilters = new String[]{"Session Attributes", "Session ReportingPage"};
        String[] noFilters = new String[]{"Exhibitor Attributes", "Exhibitor ReportingPage", "Attendee Attributes",
                "Attendee ReportingPage", "Meeting Attributes", "RF Survey ReportingPage", "Survey ReportingPage", "Meeting ReportingPage"};
        verifyReportSubjectAreas(allFilters, noFilters, "create session report");
    }

//    @Test
    public void meetingReportTypes() {
        //--------------------------------- Meeting Report ---------------------------------
        getToNewReport();
        reportType.createMeetingReport();

        String[] allFilters = new String[]{"Meeting ReportingPage", "Meeting Attributes"};
        String[] noFilters = new String[]{"Session Attributes", "Session ReportingPage", "Exhibitor Attributes",
                "Exhibitor ReportingPage", "Attendee Attributes", "Attendee ReportingPage", "RF Survey ReportingPage", "Survey ReportingPage"};
        verifyReportSubjectAreas(allFilters, noFilters, "create meeting report");
    }

//    @Test
    public void surveyReportTypes() {
        //--------------------------------- Survey Report ---------------------------------
        getToNewReport();
        reportType.createSurveyReport();

        String[] allFilters = new String[]{"RF Survey ReportingPage", "Survey ReportingPage"};
        String[] noFilters = new String[]{"Session Attributes", "Session ReportingPage", "Exhibitor Attributes","Meeting ReportingPage", "Meeting Attributes",
                "Exhibitor ReportingPage", "Attendee Attributes", "Attendee ReportingPage"};
        verifyReportSubjectAreas(allFilters, noFilters, "create survey report");
        //----------------------------------------------------------------------------------
    }

    private void getToNewReport() {
        ReportingPage.getPage().navigateTo();
        ReportingPage.getPage().addNewReport();
    }

    private void verifyReportSubjectAreas(String[] allFilters, String[] noFilters, String report) {
        adminApp.getToBirstReportPage();

        List<String> reportFilters = NewReportPage.getPage().getReportFilters();

        for (String filter : allFilters) {
            Assert.assertTrue(reportFilters.contains(filter), report + " does not contain subject areas " + filter);
        }

        for (String filter : noFilters) {
            Assert.assertFalse(reportFilters.contains(filter), report + " contains subject area it shouldn't: " + filter);
        }
    }
}
