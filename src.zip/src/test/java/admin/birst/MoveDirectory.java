package admin.birst;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import org.testng.Assert;
import testHelp.Utils;

import java.util.List;

public class MoveDirectory extends BirstReport{

    private String directoryName = "Attendee";

//   @Test
    public void moveToDirectory() {
        ReportingPage.getPage().navigateTo();

        List<String> reportList = ReportingPage.getPage().getReportList();
        String reportName = reportList.get(reportList.size() -1);

        ReportingPage.getPage().moveToDirectory(reportName, directoryName);
        String currentDir = ReportingPage.getPage().getCurrentDirectory();
        Assert.assertEquals(currentDir,directoryName, "Current directory doesn't match expected");

        reportList = ReportingPage.getPage().getReportList();
        Assert.assertTrue(reportList.contains(reportName), "Report not found in directory");
        Assert.assertEquals(ReportingPage.getPage().getReportLocation(reportName), "All Reports/" + directoryName, "moved report is not showing the right location");

        ReportingPage.getPage().moveToDirectory(reportName, "shared");

        reportList = ReportingPage.getPage().getReportList();
        Assert.assertTrue(reportList.contains(reportName), "Report not found in top directory");
        Assert.assertEquals(ReportingPage.getPage().getReportLocation(reportName), "All Reports", "moved report is not showing the right location");
    }

//    @Test
    public void favoritingReport() {
        ReportingPage.getPage().navigateTo();

        List<String> reportList = ReportingPage.getPage().getReportList();
        while (reportList.size() == 0) reportList = ReportingPage.getPage().getReportList();
        String bottomReport = reportList.get(reportList.size() - 1);

        //favorite a report
        ReportingPage.getPage().favoriteReport(bottomReport);
        PageConfiguration.getPage().refreshPage();

        reportList = ReportingPage.getPage().getReportList();
        while (reportList.size() == 0) reportList = ReportingPage.getPage().getReportList();
        String newBottomReport = reportList.get(reportList.size() - 1);

        List<String> favoritedReports = ReportingPage.getPage().getFavoritedReports();
        Assert.assertNotEquals(bottomReport, newBottomReport, "favorited report "+bottomReport+" so it should be at the top now");
        Assert.assertTrue(favoritedReports.contains(bottomReport), "the report "+bottomReport+" should now be in the favorited list");

        //un-favorite that report
        ReportingPage.getPage().favoriteReport(bottomReport);
        PageConfiguration.getPage().refreshPage();
        favoritedReports = ReportingPage.getPage().getFavoritedReports();
        while (favoritedReports.size() == 0) favoritedReports = ReportingPage.getPage().getReportList();

        Assert.assertFalse(favoritedReports.contains(bottomReport), "the report "+bottomReport+" should not be in the favorited list, it was unfavorited");
    }

//    @Test
    public void favoriteFromDirectory() {
        ReportingPage reportsPage = ReportingPage.getPage();
        reportsPage.navigateTo();

        List<String> reportList = reportsPage.getReportList();
        String reportName = reportList.get(reportList.size() -1);

        reportsPage.favoriteReport(reportName);
        Utils.sleep(2000);
        reportsPage.moveToDirectory(reportName, directoryName);
        reportsPage.goToDirectory(directoryName);

        reportsPage.goUpDirectory("All Reports");
        List<String> favoritedReports = reportsPage.getFavoritedReports();
        Assert.assertTrue(favoritedReports.contains(reportName), "the favorited report is not showing up in the favorite list");
        String location = reportsPage.getReportLocation(reportName);
        Assert.assertEquals(location, "All Reports/" + directoryName, "the favorited report is not showing the right location");

        //report not favorited no more
        reportsPage.favoriteReport(reportName);
        favoritedReports = reportsPage.getFavoritedReports();
        Assert.assertFalse(favoritedReports.contains(reportName), "the favorited report is showing up in the favorite list after un favoriting it");

        //move the report back to where we found it
        reportsPage.goToDirectory(directoryName);
        reportsPage.moveToDirectory(reportName, "shared");
    }

}
