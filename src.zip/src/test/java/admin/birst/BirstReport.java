package admin.birst;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

public class BirstReport {

    protected String reportName;
    protected AdminApp adminApp;

    @BeforeClass
    public void login() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("Cisco", "Cisco Live LATAM 2018");
        PageConfiguration.getPage().waitForPageLoad();
    }

    @AfterClass
    public void exit() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        OrgEventData.getPage().setOrgAndEvent();
        PageConfiguration.getPage().quit();
    }

    //shared and private reports
}
