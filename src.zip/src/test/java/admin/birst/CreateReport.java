package admin.birst;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.analysis.birstReporting.NewReportPage;
import apps.admin.adminPageObjects.analysis.birstReporting.ViewBirstReport;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.analysis.reporting.VisualizationReports;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.List;

public class CreateReport extends BirstReport{

    @AfterMethod
    public void deleteReport() {
        ReportingPage.getPage().navigateTo();
        if (reportName != null) {
            adminApp.deleteBirstReport(reportName);
            reportName = null;
        }
    }

//    @Test
    public void editReport() {
        reportName = "automation report " + new DataGenerator().generateString(5);
        String column1 = "# of Sessions";
        String column2 = "# of Sessions Attended";
        String column3 = "# of Sessions Registered";
        NewReportPage reportPage = NewReportPage.getPage();
        ReportingPage.getPage().navigateTo();

        //create a new report
        ReportingPage.getPage().addNewReport();
        VisualizationReports.getPage().createSessionReport();

        adminApp.getToBirstReportPage();

        reportPage.openSearch();
        reportPage.addItemToReport(column1);
        reportPage.addItemToReport(column2);
        reportPage.closeSearch();
        reportPage.saveNew(reportName);
        Utils.sleep(2000, "time to wait for report to save");

        //verify new report created as we wanted
        openReport(reportName);
        Utils.sleep(5000);
        verifyColumns(column1, column2);
        ViewBirstReport.getPage().closeModal();
        ReportingPage.getPage().resetSearch();

        ReportingPage.getPage().editReport(reportName);
        adminApp.getToBirstReportPage();

        //edit the report, remove a column and add a different one
        Utils.sleep(2000, "time to load the report");
        reportPage.editMeasurements();
        reportPage.deleteColumn(column2);

        reportPage.openSearch();
        reportPage.addItemToReport(column3);
        reportPage.closeSearch();
        Utils.sleep(3000, "time to add the new row to the report");
        reportPage.save();

        openReport(reportName);
        Utils.sleep(5000);
        verifyColumns(column1, column3);

        ViewBirstReport.getPage().closeModal();
    }

//    @Test
    public void renameReport() {
        reportName = "automation report " + new DataGenerator().generateString(5);
        String changedName = "automation report " + new DataGenerator().generateString(5);
        String column1 = "# of Exhibitors";
        NewReportPage reportPage = NewReportPage.getPage();
        ReportingPage.getPage().navigateTo();

        //create a new report
        ReportingPage.getPage().addNewReport();
        VisualizationReports.getPage().createExhibitorReport();

        adminApp.getToBirstReportPage();

        reportPage.openSearch();
        reportPage.addItemToReport(column1);
        reportPage.closeSearch();
        reportPage.saveNew(reportName);
        Utils.sleep(2000, "time to wait for report to save");

        ReportingPage.getPage().navigateTo();
        Utils.waitForTrue(()->ReportingPage.getPage().getReportList().contains(reportName));

        Assert.assertTrue(ReportingPage.getPage().getReportList().contains(reportName), "report " + reportName + " was not in the list");

        ReportingPage.getPage().changeReportName(reportName, changedName);
        Utils.sleep(2000);
        PageConfiguration.getPage().refreshPage();

        Assert.assertFalse(ReportingPage.getPage().getReportList().contains(reportName), "report " + reportName + " name was changed, should not see it anymore");
        Assert.assertTrue(ReportingPage.getPage().getReportList().contains(changedName), "report " + changedName + " was not in the list");

        reportName = changedName;
    }

    private void openReport(String reportName) {
        ReportingPage.getPage().navigateTo();
        List<String> reportList = ReportingPage.getPage().getReportList();
        Assert.assertTrue(reportList.contains(reportName));

        ReportingPage.getPage().clickOnReport(reportName);
        Utils.sleep(5000, "wait for report to open");
    }

    private void verifyColumns(String... columns) {
        List<String> columnNames = ViewBirstReport.getPage().getColumnNames();

        for (String column : columns) {
            Assert.assertTrue(columnNames.contains(column), "report does not have column " + column);
        }
        Assert.assertEquals(columns.length, columnNames.size(), "created a report with "+columns.length+" columns, should see only those columns");

    }
}
