package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.SessionScanConfigPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class SessionsShowConfig {

    private AdminApp app;

    @BeforeClass
    public void login() {
        app = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18822", firefoxIssue = "RA-22435")
    public void ShowSessionConfig() {
        SessionScanConfigPage configPage = SessionScanConfigPage.getPage();
        configPage.navigate();
        Assert.assertTrue(configPage.isConfigVisible(), "we should see config image");
        configPage.showToken();
        Assert.assertTrue(configPage.isTokenVisible(), "we have clicked the 'Show Token' and should see the token");
        configPage.showToken();
        Assert.assertFalse(configPage.isTokenVisible(), "we have clicked the 'Hide Token' and should not see the token");
    }
}

