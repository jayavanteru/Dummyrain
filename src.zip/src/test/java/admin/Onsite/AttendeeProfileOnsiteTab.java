package admin.Onsite;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOnsiteTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class AttendeeProfileOnsiteTab
{
    protected AdminApp adminApp;
    protected String attendeeId;
    protected PropertyReader properties;

    @BeforeClass
    public void setup() {
        properties = PropertyReader.instance();

        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent(RFConstants.ORG_RF_AUTOMATION, "Onsite Automation");
        attendeeId = adminApp.createAttendee();
        //register
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().justDoWhateverYouNeedToOrderThePackage(attendeeId, "Full Event");
        AdminAttendeeOnsiteTab.getPage().navigate(attendeeId);
    }

    @AfterClass
    public void tearDown()
    {
        // Doesn't actually delete the attendee, just removes it from the in-scope event.
        if (StringUtils.isNotEmpty(attendeeId)) {
            adminApp.deleteAttendee(attendeeId);
        }

        PageConfiguration.getPage().quit();
    }

    @Test(groups = { ReportingInfo.ONSITE })
    @ReportingInfo(firefoxIssue = "RA-51977", chromeIssue = "RA-33628")
    public void testAttendeeOnsiteTab()
    {
        AdminAttendeeOnsiteTab page = AdminAttendeeOnsiteTab.getPage();

        // Edit the attendee badge form values
        // - Set the Preferred first name
        // - Select a value for the first dropdown input
        // - Save the form
        page.clickBadgeFormEdit();
        page.enterPreferredFirstNameForBadge("Pref Name" + properties.getProperty("unique"));
        String selectedValue = page.clickOptionOnFirstSelectElement();
        page.clickBadgeFormSubmit();

        Utils.sleep(500);

        // Check that the preferred first name is found in the badge info box
        Assert.assertTrue(page.getBadgeInfo().contains("Pref Name" + properties.getProperty("unique")), "Attendee preferred name was not found in the badge info after saving the badge form.");

        // Check that the selected value is found in the badge info box
        Assert.assertTrue(page.getBadgeInfo().contains(selectedValue), "The selected value (" + selectedValue + ") was not found in the badge info after saving the badge form.");

        // Click print, select default print location, print the badge.
        page.checkInAttendee();

        Utils.sleep(500);

        // Check that we have a badge history record
        Assert.assertEquals(page.getCheckinStatus(), "Active", "An active badge was not found after the attendee was checked-in.");

        // Click delete, click yes on confirmation dialog.
        page.deleteCheckin();

        Utils.sleep(500);

        // Check that checkin is not completed
        Assert.assertEquals(page.getCheckinStatus(), "Check-in: Not Completed", "The checkin status was not reset after undoing the attendees checkin.");

        // Check that the badge history records were deleted
        Assert.assertEquals(page.numberOfBadgeHistoryRecords(), 0, "A badge history record still exists after undoing the attendees checkin.");
    }
}
