package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.GiftSearchPage;
import apps.admin.adminPageObjects.onsite.NewGiftPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOnsiteTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import static org.testng.Assert.*;


public class GiftRedemption {

    private AdminApp adminApp;
    private String attendeeId;
    private String giftID;
    private String giftName;

    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        DataGenerator gen = new DataGenerator();
        attendeeId = adminApp.createAttendee(gen.generateValidEmail());
        Utils.sleep(1000);
    }

    @AfterClass
    public void delete() {
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteGift(giftID);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(firefoxIssue = "RA-26033", chromeIssue = "RA-26030")
    public void redeemAttendeeGift() {
        giftName = new DataGenerator().generateName();
        giftID = adminApp.createGift(giftName);
        AdminAttendeeOnsiteTab onsiteTab = new AdminAttendeeOnsiteTab();
        onsiteTab.navigate(attendeeId);
        onsiteTab.clickGiftRedemption();
        Utils.sleep(500);
        assertTrue(onsiteTab.giftIneligible(giftName), "Gift was not in ineligible section when it should be");

        Utils.sleep(500);
        EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
        final AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB3);
        //set attendee type to vendor
        customTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage();
        customTab.selectSelectField("1600985166N064c6cec4","Vendor");
        customTab.submit();

        onsiteTab.navigate(attendeeId);
        PageConfiguration.getPage().refreshPage();

        onsiteTab.clickGiftRedemption();
        assertTrue(onsiteTab.giftEligible(giftName), "Gift was not moved into eligible section");

        onsiteTab.clickClaimButton(giftName);

        String date = DateTime.now().toString("MM/dd/yy");

        assertTrue(onsiteTab.giftRedeemed(giftName, date), "Pick up time was not populated");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18806", firefoxIssue = "RA-21122")
    public void createGift(){
        DataGenerator gen = new DataGenerator();
        giftName = "Automation"+new DataGenerator().generateString(5);

        NewGiftPage newGiftPage = NewGiftPage.getPage();
        newGiftPage.navigate();
        newGiftPage.setName(giftName);
        newGiftPage.setQuantity("100");
        newGiftPage.setAttribute("Attendee Type: Vendor");
        Utils.sleep(1000);
        newGiftPage.clickHasData();
        newGiftPage.clickSubmit();
        GiftSearchPage giftSearchPage = GiftSearchPage.getPage();
        giftSearchPage.waitForPageLoad();
        assertTrue(giftSearchPage.giftExists(giftName), "Gift "+giftName+" was not created successfully");

        giftSearchPage.editGift(giftName);
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        giftID = url[url.length - 1];
        newGiftPage.setQuantity("200");
        newGiftPage.clickSubmit();
        giftSearchPage.waitForPageLoad();
        Utils.sleep(1000, "needs some extra time of waiting");

        giftSearchPage.editGift(giftName);
        assertEquals(newGiftPage.getQuantity(), 200);
        newGiftPage.cancel();
        giftSearchPage.waitForPageLoad();

        giftSearchPage.deleteGift(giftName);
        Utils.sleep(1000);
        assertFalse(giftSearchPage.giftExists(giftName), "Gift "+giftName+" was not deleted");
    }
}
