package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.BadgePrintLocationsSearchPage;
import apps.admin.adminPageObjects.onsite.EditBadgePrintLocationPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;


public class BadgePrintLocations {

    private AdminApp adminApp;
    protected String locationId;

    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void delete() {
        adminApp.deleteLocationApi(locationId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18799", firefoxIssue = "RA-21350")
    public void searchBadgePrintLocations() {
        BadgePrintLocationsSearchPage bplSearchPage =  BadgePrintLocationsSearchPage.getPage();
        bplSearchPage.navigate();
        bplSearchPage.addItem();

        EditBadgePrintLocationPage edplPage = new EditBadgePrintLocationPage();
        edplPage.waitForPageLoad();

        DataGenerator gen = new DataGenerator();
        String printLocationName = gen.generateName();
        edplPage.setName(printLocationName);
        String externalId = gen.generateString(5);
        edplPage.setExternalId(externalId);
        edplPage.clickSubmit();
        locationId = bplSearchPage.getId(printLocationName);

        bplSearchPage.search(printLocationName);
        //Verify location created appears in a search
        assertTrue(bplSearchPage.printLocationExists(printLocationName), "Location '" + printLocationName + "' did not appear in search results");

        bplSearchPage.editItem();
        edplPage.waitForPageLoad();
        //Verify correct location page is loaded to edit
        assertEquals(edplPage.getExternalId(), externalId, "The wrong location page was loaded");

        bplSearchPage.navigate();
        bplSearchPage.deleteItem(printLocationName);
        Utils.sleep(200);
        bplSearchPage.search(printLocationName);
        //Verify the location was deleted
        assertTrue(bplSearchPage.isSearchEmpty(), "Location '" + printLocationName + "' was not deleted");
    }
}
