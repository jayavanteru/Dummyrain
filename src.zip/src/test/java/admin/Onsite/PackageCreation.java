package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.LeadPackageSearchPage;
import apps.admin.adminPageObjects.onsite.NewLeadPackagePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class PackageCreation {

    private String packageid;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void close() {
        new AdminApp().deletePackage(packageid);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18819", firefoxIssue = "RA-21288")
    public void createLeadsPackage() {
        final DataGenerator dataGenerator = new DataGenerator();
        String packageName1 = "automation"+dataGenerator.generateString(5);
        String code1 = dataGenerator.generateString(4);
        String packageNameError = "Package Name is already in use";
        String packageCodeError = "Package Code is already in use";
        String packageTypeError = "Package Type is required";
        String packageNameRequired = "Package Name is required";
        String packageCodeRequired = "Package Code is required";

        final LeadPackageSearchPage searchPage = LeadPackageSearchPage.getPage();
        final NewLeadPackagePage newPackagePage = NewLeadPackagePage.getPage();

        searchPage.navigate();

        //package not created yet
        Assert.assertNull(searchPage.searchPackage(packageName1), "found a package matching the name");

        //create the package
        newPackagePage.navigate();
        newPackagePage.submit();
        final String requiredError = newPackagePage.getErrorMessage();
        Assert.assertTrue(requiredError.contains(packageNameRequired), "error message did not contain " + packageNameRequired);
        Assert.assertTrue(requiredError.contains(packageCodeRequired), "error message did not contain " + packageCodeRequired);
        Assert.assertTrue(requiredError.contains(packageTypeError), "creating duplicate package did not get the error: " + packageTypeError);

        newPackagePage.enterStandardPackageData(packageName1, code1, "Leads", 100);
        newPackagePage.submit();

        //assert we can find that package
        Assert.assertEquals(searchPage.searchPackage(packageName1), packageName1, "search did not find the package created");
        packageid = searchPage.getId(packageName1);

        //attempt to create a second package with the same info
        newPackagePage.navigate();
        newPackagePage.enterStandardPackageData(packageName1, code1, "Leads", 100);
        newPackagePage.submit();
        final String errorMessage = newPackagePage.getErrorMessage();

        //make sure we got the right error messages
        Assert.assertTrue(errorMessage.contains(packageNameError), "creating duplicate package did not get the error: " + packageNameError);
        Assert.assertTrue(errorMessage.contains(packageCodeError), "creating duplicate package did not get the error: " + packageCodeError);
    }
}
