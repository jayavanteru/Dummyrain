package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.SessionDevicesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SessionDevices {

    String room;

    SessionDevicesPage sessionDevices = SessionDevicesPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18821", firefoxIssue = "RA-27812")
    public void SessionDevicesSearch() {
        sessionDevices.navigate();
        room = sessionDevices.getLastDevice();
        sessionDevices.search(room);
        Assert.assertTrue(sessionDevices.roomExists(room), "Device does not appear in search results");

    }
}