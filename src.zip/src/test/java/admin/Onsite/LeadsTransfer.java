package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadOrdersTab;
import apps.admin.adminPageObjects.onsite.LeadTransferPage;
import apps.admin.adminPageObjects.onsite.LeadsDeviceConfigurationPage;
import apps.leads.LeadsApp;
import apps.leads.leadsPageObjects.LeadsDeviceModal;
import apps.leads.leadsPageObjects.LeadsEquipRentalAgreement;
import apps.leads.leadsPageObjects.LeadsManageDevice;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class LeadsTransfer {

    AdminApp adminApp = new AdminApp();
    LeadsApp leadsApp = new LeadsApp();
    private String exhibitorId1;
    private String exhibitorId2;
    private String attendeeId1;
    private String exhibitor1;
    private String exhibitor2;
    private String fName;
    private String lName;
    private String email;
    private String device1;
    private String deviceName1;

    AdminExhibitorLeadOrdersTab leadOrdersTab = AdminExhibitorLeadOrdersTab.getPage();
    AdminExhibitorContactsTab Contacts = AdminExhibitorContactsTab.getPage();
    LeadsDeviceConfigurationPage LeadsConfig = LeadsDeviceConfigurationPage.getPage();
    LeadsEquipRentalAgreement eraPage = LeadsEquipRentalAgreement.getPage();
    LeadTransferPage LeadsTransfer = LeadTransferPage.getPage();
    LeadsManageDevice ManageDevice = LeadsManageDevice.getPage();
    LeadsDeviceModal Modal = LeadsDeviceModal.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        PropertyReader.instance().setProperty("org", "RF Automation" );
        PropertyReader.instance().setProperty("event", "Onsite Automation" );
        PropertyReader.instance().setProperty("eventId", "1603141373onsiteauto" );
    }

    @AfterClass
    public void cleanup() {
        adminApp.deleteExhibitor(exhibitorId1);
        adminApp.deleteExhibitor(exhibitorId2);
        adminApp.deleteAttendee(attendeeId1);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18820", firefoxIssue = "RA-29614")
    public void leadsTransferTest() {
        //Setup
        exhibitor1 = new DataGenerator().generateName();
        exhibitor2 = new DataGenerator().generateName();
        fName = new DataGenerator().generateName();
        lName = new DataGenerator().generateName();
        deviceName1 = new DataGenerator().generateName();
        email = new DataGenerator().generateEmail();
        attendeeId1 = adminApp.createAttendee(email, fName, lName);
        exhibitorId1 = adminApp.createExhibitor(exhibitor1);
        Utils.sleep(500);
        leadOrdersTab.navigate(exhibitorId1);
        Utils.sleep(500);
        leadOrdersTab.addOrder();
        leadOrdersTab.selectPackage("Leads Device");
        leadOrdersTab.clickNextOnAddOrderModal();
        leadOrdersTab.fillOutOrder();
        leadOrdersTab.toggleSendInvoice();
        leadOrdersTab.submitOrder();
        Contacts.navigate(exhibitorId1);
        Contacts.setStatusToApproved();
        Contacts.addExistingParticipant(fName, "Primary Owner");
        exhibitorId2 = adminApp.createExhibitor(exhibitor2);
        leadOrdersTab.navigate(exhibitorId2);
        leadOrdersTab.addOrder();
        leadOrdersTab.selectPackage("Leads Device");
        leadOrdersTab.clickNextOnAddOrderModal();
        leadOrdersTab.fillOutOrder();
        leadOrdersTab.toggleSendInvoice();
        leadOrdersTab.submitOrder();
        Contacts.navigate(exhibitorId2);
        Contacts.setStatusToApproved();
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor1);
        String leadToken = LeadsConfig.getLeadToken(exhibitorId1);
        Utils.sleep(200);
        LeadsConfig.spoof(fName+" "+lName);
        eraPage.fillOutForm();
        ManageDevice.editFirstDevice();
        Modal.nameDevice(deviceName1);
        Modal.clickSave();
        leadsApp.addLead(attendeeId1, leadToken);
        device1 = leadsApp.getDeviceId(0);
        //Test
        LeadsTransfer.navigate();
        LeadsTransfer.selectFromExhibitor(exhibitor1);
        LeadsTransfer.selectToExhibitor(exhibitor2);
        LeadsTransfer.enterDeviceID(device1);
        LeadsTransfer.clickSave();
        LeadsConfig.navigate();
        LeadsConfig.search(exhibitor2);
        LeadsConfig.inUse(exhibitor2, 0);
        Assert.assertTrue(LeadsConfig.isDeviceInUse(deviceName1), "The device "+deviceName1+" should be assigned to exhibitor "+exhibitor2+" but was not found");
    }
}
