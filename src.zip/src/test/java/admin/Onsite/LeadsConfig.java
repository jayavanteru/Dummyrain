package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorLeadOrdersTab;
import apps.admin.adminPageObjects.onsite.LeadsDeviceConfigurationPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class LeadsConfig {

    private AdminApp adminApp;
    private String exhibitorId;
    private String boothId;
    //    private String exhibitorId2;
    private String name;
    //    private String name2;
    private String booth;
    private String tag;
    private String fName;
    private String lName;

    AdminExhibitorLeadOrdersTab leadOrdersTab = AdminExhibitorLeadOrdersTab.getPage();
    LeadsDeviceConfigurationPage leadConfigPage = LeadsDeviceConfigurationPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        //---create an exhibitor---
        adminApp = new AdminApp();
        name = new DataGenerator().generateName();

//        name2 = new DataGenerator().generateName();
        booth = new DataGenerator().generateName();
        exhibitorId = adminApp.createExhibitor(name);
        //---purchase leads package for exhibitor---
        String packageName = "Leads Device";
        leadOrdersTab.navigate(exhibitorId);
        leadOrdersTab.addOrder();
        leadOrdersTab.selectPackage(packageName);
        leadOrdersTab.clickNextOnAddOrderModal();
        leadOrdersTab.fillOutOrder();
        leadOrdersTab.toggleSendInvoice();
        leadOrdersTab.submitOrder();
    }

    @AfterClass
    public void close() {
        adminApp.deleteLeadsOrder(exhibitorId);
        adminApp.deleteExhibitor(exhibitorId);
//        adminApp.deleteLeadsOrder(exhibitorId2);
//        adminApp.deleteExhibitor(exhibitorId2);
        adminApp.deleteBooth(boothId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-27114", firefoxIssue = "RA-27118")
    public void leadsConfigSearchTest() {
        //TODO: update once issues have been fixed
        //---add booth to exhibitor---
        boothId = adminApp.createBooth(booth, name);
        //---create second exhibitor to mark as paid---
//        exhibitorId2 = adminApp.createExhibitor(name2);
//        leadOrdersTab.navigate(exhibitorId2);
//        leadOrdersTab.addOrder();
//        leadOrdersTab.selectPackage(packageName);
//        leadOrdersTab.fillOutOrder();
//        le adOrdersTab.toggleSendInvoice();
//        leadOrdersTab.markAsPaid();
//        leadOrdersTab.submitOrder();
        //---Search via exhibitor---
        leadConfigPage.navigate();
        leadConfigPage.search(name);
        Assert.assertTrue(leadConfigPage.nameExists(name), "Exhibitor does not appear in search results");
        //---Search via booth---
        leadConfigPage.search(booth);
        Assert.assertTrue(leadConfigPage.boothExists(booth), "Exhibitor booth does not appear in search results");
        //---Search via Asset Tag---
        tag = new DataGenerator().generateName();
        leadConfigPage.search(name);
        leadConfigPage.inUse(name, 0);
        leadConfigPage.setAsset(tag);
        leadConfigPage.closeInUseModel();
        leadConfigPage.searchAsset(tag);
        leadConfigPage.inUse(name, 0);
        Assert.assertTrue(leadConfigPage.tagExists(tag), "Device Asset Tag does not appear in search results");
        leadConfigPage.setAsset("");
        leadConfigPage.closeInUseModel();
//      //---Search for Paid Exhibitor (broken)---
//        leadConfigPage.search(name2);
//        Assert.assertFalse(leadConfigPage.nameExists(name), "Exhibitor does appear in search results");
//        leadConfigPage.paidCheckbox();
//        leadConfigPage.search(name2);
//        Assert.assertTrue(leadConfigPage.nameExists(name), "Exhibitor does not appear in search results");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-28186", firefoxIssue = "RA-28187")
    public void leadsConfigExhibitorLink() {
        leadConfigPage.navigate();
        leadConfigPage.search(name);
        leadConfigPage.clickExhibitorLink(name);
        Assert.assertEquals(AdminExhibitorLeadOrdersTab.getPage().buildUrl(exhibitorId), PageConfiguration.getPage().getCurrentUrl(), "The URL did not match what is should have been");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18811", firefoxIssue = "RA-28182")
    public void leadsConfigAddingNotes() {
        String text = "This is a note for automation!";
        String text2 = "This note has been edited for automation!";
        leadConfigPage.navigate();
        leadConfigPage.search(name);
        leadConfigPage.setNote(text);
        Assert.assertTrue(leadConfigPage.containsNote(), "The icon did not change");
        Assert.assertEquals(leadConfigPage.getNote(), text, "The note does not match");
        leadConfigPage.setNote(text2);
        Assert.assertEquals(leadConfigPage.getNote(), text2, "The note does not match");
        leadConfigPage.clearNote();
        Assert.assertTrue(leadConfigPage.emptyNote(), "The note field is not empty");
        Assert.assertFalse(leadConfigPage.containsNote(), "The icon did not change");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18813", firefoxIssue = "RA-18815")
    public void leadsConfigReturnPickup() {
        fName = new DataGenerator().generateName();
        lName = new DataGenerator().generateName();
        leadConfigPage.navigate();
        leadConfigPage.search(name);
        Assert.assertTrue(leadConfigPage.isReturnDisabled(), "The confirm return button is not disabled");
        leadConfigPage.clickConfirmPickup();
        leadConfigPage.confirmERA();
        Assert.assertTrue(leadConfigPage.isERAErrorsVisible(), "The four error messages did not appear");
        leadConfigPage.completeEquipmentAgreement();
        Assert.assertTrue(leadConfigPage.isConfirmDisabled(), "The confirm button is not disabled");
        leadConfigPage.completeAgreement(fName, lName);
        leadConfigPage.closeThankYou();
        Assert.assertTrue(leadConfigPage.isViewAgreementVisible(), "The Agreement Signed link is not visible");
        leadConfigPage.clickConfirmReturn();
        leadConfigPage.clickReturnConfirm();
        Assert.assertTrue(leadConfigPage.isReturnDisabled(), "The confirm return button is not disabled");
        leadConfigPage.clickAgreementSigned();
        Assert.assertTrue(leadConfigPage.isAgreementSigned(fName, lName), "The attendee signature does not match the test user");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18810", firefoxIssue = "RA-20852")
    public void leadsConfigShowConfig() {
        leadConfigPage.navigate();
        leadConfigPage.search(name);
        Assert.assertFalse(leadConfigPage.isConfigVisible(), "no config should be visible yet");
        leadConfigPage.showConfig();
        Assert.assertTrue(leadConfigPage.isConfigVisible(), "we have clicked the 'Show config' should see config image");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(firefoxIssue = "RA-51976", chromeIssue = "RA-18814")
    public void leadsConfigViewInUse() {
        LeadsDeviceConfigurationPage leadsConfig = LeadsDeviceConfigurationPage.getPage();
        leadsConfig.navigate();
        leadsConfig.inUse("", 0);
        leadsConfig.clickShowHistory();
        Assert.assertTrue(leadsConfig.isHistoryTableVisible(), "History table should be shown for the leads device selected");
    }
}
