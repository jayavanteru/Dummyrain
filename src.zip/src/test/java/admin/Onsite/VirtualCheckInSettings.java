package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.VirtualCheckInSettingsPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOnsiteTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import logs.ReportingInfo;
import org.testng.annotations.*;
import org.testng.Assert;
import testHelp.DataGenerator;
import testHelp.Utils;

public class VirtualCheckInSettings {

    private AdminApp adminApp = new AdminApp();

    private String attendeeId1;
    private String attendeeId2;
    private String attendeeId3;
    private String attendeeId4;
    private String attendeeId5;
    private boolean rules;

    private VirtualCheckInSettingsPage CheckInSettings = VirtualCheckInSettingsPage.getPage();
    private AdminAttendeeOnsiteTab AttendeeOnsite = new AdminAttendeeOnsiteTab();
    private AdminAttendeeOrdersTab AttendeeOrder = new AdminAttendeeOrdersTab();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
        CheckInSettings.navigate();
        if(CheckInSettings.areRulesSet()){CheckInSettings.removeAllRules();}
    }

    @AfterClass
    public void close() {
        adminApp.deleteAttendee(attendeeId1);
        adminApp.deleteAttendee(attendeeId2);
        adminApp.deleteAttendee(attendeeId3);
        adminApp.deleteAttendee(attendeeId4);
        adminApp.deleteAttendee(attendeeId5);
        if(rules) {
            CheckInSettings.navigate();
            CheckInSettings.removeAllRules();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-42368", firefoxIssue = "RA-42376")
    public void VirtualCheckInSettingsTest() {
        rules = false;
        String fName1 = new DataGenerator().generateName();
        String fName3 = new DataGenerator().generateName();
        String lName1 = new DataGenerator().generateName();
        String lName2 = new DataGenerator().generateName();
        String lName3 = new DataGenerator().generateName();
        String lName4 = new DataGenerator().generateName();
        String lName5 = new DataGenerator().generateName();
        String email1 = new DataGenerator().generateEmail();
        String email2 = new DataGenerator().generateEmail();
        String email3 = new DataGenerator().generateEmail();
        String email4 = new DataGenerator().generateEmail();
        String email5 = new DataGenerator().generateEmail();
        String Attribute1 = "First Name";
        String Operator1 = "contains";
//        Create Attendee1, Attendee2, Attendee3, Attendee4 and purchase reg packages and checkin Attendee4
        attendeeId1 = adminApp.createAttendee(email1, fName1, lName1);
        attendeeId2 = adminApp.createAttendee(email2, fName1, lName2);
        attendeeId3 = adminApp.createAttendee(email3, fName3, lName3);
        attendeeId4 = adminApp.createAttendee(email4, fName1, lName4);
        AttendeeOrder.justDoWhateverYouNeedToOrderThePackage(attendeeId1, "Full Event");
        AttendeeOrder.justDoWhateverYouNeedToOrderThePackage(attendeeId2, "Full Event");
        AttendeeOrder.justDoWhateverYouNeedToOrderThePackage(attendeeId3, "Full Event");
        AttendeeOrder.justDoWhateverYouNeedToOrderThePackage(attendeeId4, "Full Event");
//        Checkin attendee4
        AttendeeOnsite.navigate(attendeeId4);
        AttendeeOnsite.checkInAttendee();
//        Add rules to capture attendees 1, 2, & 4 but not 3
        CheckInSettings.navigate();
        CheckInSettings.selectAttribute(0, Attribute1);
        CheckInSettings.selectAttributeOperator(0, Operator1);
        CheckInSettings.setAttributeValue(0, fName1);
        CheckInSettings.saveNoConfirm();
        Assert.assertEquals(CheckInSettings.getCheckinNum(), 2);
        CheckInSettings.confirm();
        rules = true;
//        Verify attendee 1, 2, and 4 are checked in
        AttendeeOnsite.navigate(attendeeId1);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
        AttendeeOnsite.navigate(attendeeId2);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
        AttendeeOnsite.navigate(attendeeId4);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
//        Verify attendee 3 is not checked in
        AttendeeOnsite.navigate(attendeeId3);
//        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "");
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Check-in: Not Completed");
//        Create Attendee5 to fit current rules
        attendeeId5 = adminApp.createAttendee(email5, fName1, lName5);
        AttendeeOrder.justDoWhateverYouNeedToOrderThePackage(attendeeId5, "Full Event");
//        Verify rules auto-checked in Attendee5
        AttendeeOnsite.navigate(attendeeId5);
        Utils.waitForTrue(()->{
            boolean result = AttendeeOnsite.getCheckinStatus().equals("Active");
            if (!result) PageConfiguration.getPage().refreshPage();
            return result;
        });
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
//        Modify Attendee 3 to fit rules by changing first name to fName1
        AttendeeOnsite.navigate(attendeeId3);
        AttendeeOnsite.changeFirstName(fName1);
//        refresh page and Verify attendee3 is checked in
        Utils.waitForTrue(()->{
            PageConfiguration.getPage().refreshPage();
            return AttendeeOnsite.getCheckinStatus().equals("Active");
        });
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
//        Remove rules
        CheckInSettings.navigate();
        CheckInSettings.removeAllRules();
        rules = false;
//        Verify attendees 1,2,3,5 are checked out and attendee4 is still checked in
        AttendeeOnsite.navigate(attendeeId1);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Check-in: Not Completed");
        AttendeeOnsite.navigate(attendeeId2);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Check-in: Not Completed");
        AttendeeOnsite.navigate(attendeeId3);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Check-in: Not Completed");
        AttendeeOnsite.navigate(attendeeId4);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Active");
        AttendeeOnsite.navigate(attendeeId5);
        Assert.assertEquals(AttendeeOnsite.getCheckinStatus(), "Check-in: Not Completed");
    }
}