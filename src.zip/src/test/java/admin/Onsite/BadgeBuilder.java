package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.onsite.BadgeBuilderSearchPage;
import apps.admin.adminPageObjects.onsite.NewBadgeBuilderPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOnsiteTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class BadgeBuilder {

    private String fileName1;
    private String fileName2;
    private String fileName3;
    private String attributeName1;
    private String attributeName2;
    private String attendeeId1;
    private String attendeeId2;
    private String attendeeId3;
    private String attendeeFN1;
    private String attendeeFN2;
    private String attendeeFN3;
    private String attendeeLN1;
    private String attendeeLN2;
    private String attendeeLN3;
    private String attendeeEmail1;
    private String attendeeEmail2;
    private String attendeeEmail3;
    private String file1 = "pic1.jpg";
    private String file2 = "pic2.jpg";
    private String value1;
    private String value2;
    private String value3;
    private String fileId1;
    private String fileId2;
    private String fileId3;
    private Boolean deleteBadge = false;
    private Boolean left_nav = false;
    private Boolean onsite = false;
    private String badge = new DataGenerator().generateName();

    BadgeBuilderSearchPage SearchPage = BadgeBuilderSearchPage.getPage();
    NewBadgeBuilderPage NewBadgePage = NewBadgeBuilderPage.getPage();
    FormsSearchPage FormsSearch = FormsSearchPage.getPage();
    EditFormPage EditForm = EditFormPage.getPage();
    apps.admin.AdminApp AdminApp = new AdminApp();
    private AdminAttendeeOnsiteTab AttendeeOnsite = new AdminAttendeeOnsiteTab();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Onsite Automation");
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void cleanup() {
        if (deleteBadge) {
            SearchPage.navigate();
            SearchPage.deleteItem(badge);
            deleteBadge = false;
        }
        AdminApp.deleteAttendee(attendeeId1);
        AdminApp.deleteAttendee(attendeeId2);
        AdminApp.deleteAttendee(attendeeId3);
        AdminApp.deleteFile(fileId1);
        AdminApp.deleteFile(fileId2);
        AdminApp.deleteFile(fileId3);
        if (left_nav) {
            FormsSearch.navigate();
            FormsSearch.search("Attendee_Profile_Left_Nav_Form");
            FormsSearch.editItem();
            EditForm.expandAttribute(attributeName1);
            EditForm.deleteExpandedAttribute();
            EditForm.expandAttribute(attributeName2);
            EditForm.deleteExpandedAttribute();
            EditForm.submitForm();
            left_nav = false;
        }
        if (onsite) {
            FormsSearch.navigate();
            FormsSearch.search("onsiteBadge");
            FormsSearch.editItem();
            EditForm.expandAttribute(attributeName1);
            EditForm.deleteExpandedAttribute();
            EditForm.expandAttribute(attributeName2);
            EditForm.deleteExpandedAttribute();
            EditForm.submitForm();
            onsite = false;
        }
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18796", firefoxIssue = "RA-47810")
    public void badgeBuilderSearchTest() {
        //Search for no result
        SearchPage.navigate();
        SearchPage.search(badge);
        Assert.assertTrue(SearchPage.returnNoResults(), "No results should return as the badge has not yet been created");
        //Search for valid result
        SearchPage.add();
        NewBadgePage.setName(badge);
        deleteBadge = true;
        SearchPage.navigate();
        SearchPage.search(badge);
        Assert.assertTrue(SearchPage.returnResult(badge), "Results should contain the name of the badge created");
        //Search for deleted result
        SearchPage.deleteItem(badge);
        deleteBadge = false;
        SearchPage.search(badge);
        Assert.assertTrue(SearchPage.returnNoResults(), "No results should return as the badge has  been deleted");
    }


    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-26344", firefoxIssue = "RA-47811")
    public void badgeBuilderVersioningTest() {

        fileName1 = new DataGenerator().generateName() + ".jpg";
        fileName2 = new DataGenerator().generateName() + ".jpg";
        fileName3 = new DataGenerator().generateName() + ".jpg";
        //Create Version 1
        NewBadgePage.navigate();
        NewBadgePage.setName(badge);
        deleteBadge = true;
        Assert.assertEquals(NewBadgePage.returnVersion(), "Version  1 - a few seconds ago  - PUBLISHED", "These versions should match");
        //Upload an image to create Version 2
        NewBadgePage.clickImagesTab();
        Utils.getResourceAsFile(file1, fileName1);
        NewBadgePage.uploadImage(fileName1);
        NewBadgePage.clickDone();
        fileId1 = NewBadgePage.getFileID(fileName1);
        //check if checkbox is checked
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName1), fileName1 + " checkbox has been checked");
        NewBadgePage.saveBadge();
        NewBadgePage.clickGeneralTab();
        Assert.assertEquals(NewBadgePage.returnVersion(), "Version  2 - a few seconds ago  - PUBLISHED", "The version should now show Version 2");
        //Upload another image to create Version 3
        NewBadgePage.clickImagesTab();
        Utils.getResourceAsFile(file2, fileName2);
        NewBadgePage.uploadImage(fileName2);
        NewBadgePage.clickDone();
        fileId2 = NewBadgePage.getFileID(fileName2);
        //check if both checkboxes are checked
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName1), fileName1 + " checkbox has been checked");
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName2), fileName2 + " checkbox has been checked");
        NewBadgePage.saveBadge();
        NewBadgePage.clickGeneralTab();
        Assert.assertEquals(NewBadgePage.returnVersion(), "Version  3 - a few seconds ago  - PUBLISHED", "The version should now show Version 3");
        //Switch to Version 2
        NewBadgePage.changeVersion("2");
        //Verify save button changes to publish
        Assert.assertTrue(NewBadgePage.changedToPublish(), "Button should now say 'Publish'");
        NewBadgePage.publishBadge();
        //Check if only one checkbox is checked
        NewBadgePage.clickImagesTab();
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName1), fileName1 + " checkbox has been checked");
        Assert.assertFalse(NewBadgePage.isImageChecked(fileName2), fileName2 + " checkbox is not checked");
        //Upload another image to create Version 4
        Utils.getResourceAsFile(file1, fileName3);
        NewBadgePage.uploadImage(fileName3);
        NewBadgePage.clickDone();
        fileId3 = NewBadgePage.getFileID(fileName3);
        //Check if only two checkboxes are checked (1 & 3)
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName1), fileName1 + " checkbox has been checked");
        Assert.assertFalse(NewBadgePage.isImageChecked(fileName2), fileName2 + " checkbox is not checked");
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName3), fileName3 + " checkbox has been checked");
        NewBadgePage.saveBadge();
        NewBadgePage.clickGeneralTab();
        Assert.assertEquals(NewBadgePage.returnVersion(), "Version  4 - a few seconds ago  - PUBLISHED", "The version should now show Version 4");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-26364", firefoxIssue = "RA-47812")
    public void badgeBuilderImageTest() {
        fileName1 = new DataGenerator().generateName() + ".jpg";
        fileName2 = new DataGenerator().generateName() + ".jpg";
        fileName3 = new DataGenerator().generateName() + ".jpg";
        String fileNewName2 = new DataGenerator().generateName() + ".jpg";
        String fileNewName3 = new DataGenerator().generateName() + ".jpg";
        //Create badge
        NewBadgePage.navigate();
        NewBadgePage.setName(badge);
        deleteBadge = true;
        //Upload an image and change the name of the file uploaded
        NewBadgePage.clickImagesTab();
        Utils.getResourceAsFile(file2, fileName1);
        NewBadgePage.uploadImage(fileName1);
        //verify the image is previewed
        int size = NewBadgePage.getImageSize(1);
        Assert.assertTrue(size > 30000, "expected size is: " + size);
        NewBadgePage.clickDone();
        fileId1 = NewBadgePage.getFileID(fileName1);
        //verify the use this image checkbox is checked
        Assert.assertTrue(NewBadgePage.isImageChecked(fileName1), fileName1 + " checkbox has been checked");
        //upload multiple files
        Utils.getResourceAsFile(file1, fileName2);
        Utils.getResourceAsFile(file2, fileName3);
        NewBadgePage.uploadMultipleImages(fileName2, fileName3);
        //verify the images are previewed
        Assert.assertTrue(NewBadgePage.getImageSize(1) > 80000, "expected size should be greater than 80000, but the actual size is: " + NewBadgePage.getImageSize(1));
        Assert.assertTrue(NewBadgePage.getImageSize(2) > 30000, "expected size should be greater than 30000, but the actual size is: " + NewBadgePage.getImageSize(2));
        NewBadgePage.changeUploadName(1, fileNewName2);
        NewBadgePage.changeUploadName(2, fileNewName3);
        NewBadgePage.clickDone();
        fileId2 = NewBadgePage.getFileID(fileNewName2);
        fileId3 = NewBadgePage.getFileID(fileNewName3);
        //verify the use this image checkboxes are checked
        Assert.assertTrue(NewBadgePage.isImageChecked(fileNewName2), fileNewName2 + " checkbox has been checked and the image has a new name");
        Assert.assertTrue(NewBadgePage.isImageChecked(fileNewName3), fileNewName3 + " checkbox has been checked and the image has a new name");
    }

    // TODO: First selectAttribute is where this test fails.
    /**
     * 11-11-21 Only Chrome failed
     */
    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-26706", firefoxIssue = "RA-47813")
    public void badgeBuilderMappingTest() {
        attendeeFN1 = new DataGenerator().generateName();
        attendeeFN2 = new DataGenerator().generateName();
        attendeeFN3 = new DataGenerator().generateName();
        attendeeLN1 = new DataGenerator().generateName();
        attendeeLN2 = new DataGenerator().generateName();
        attendeeLN3 = new DataGenerator().generateName();
        attendeeEmail1 = new DataGenerator().generateEmail();
        attendeeEmail2 = new DataGenerator().generateEmail();
        attendeeEmail3 = new DataGenerator().generateEmail();
        attributeName1 = new DataGenerator().generateName();
        attributeName2 = new DataGenerator().generateName();
        String Name1 = new DataGenerator().generateName();
        fileName1 = Name1 + ".jpg";
        String Name2 = new DataGenerator().generateName();
        fileName2 = Name2 + ".jpg";
        value1 = new DataGenerator().generateName();
        value2 = new DataGenerator().generateName();
        value3 = new DataGenerator().generateName();
        //Create Attendees to use with the mappings
        attendeeId1 = AdminApp.createAttendee(attendeeEmail1, attendeeFN1, attendeeLN1);
        attendeeId2 = AdminApp.createAttendee(attendeeEmail2, attendeeFN2, attendeeLN2);
        attendeeId3 = AdminApp.createAttendee(attendeeEmail3, attendeeFN3, attendeeLN3);
        //Edit Onsite Badge Form to include attributes needed for mapping
        FormsSearch.navigate();
        FormsSearch.search("onsiteBadge");
        FormsSearch.editItem();
        EditForm.addNewSelect(attributeName1, new String[]{value1});
        EditForm.addAttributeValues(value2);
        EditForm.addNewSelect(attributeName2, new String[]{value3});
        EditForm.submitForm();
        onsite = true;
        //navigate to attendee and add responses to questions added
        FormsSearch.search("Attendee_Profile_Left_Nav_Form");
        FormsSearch.editItem();
        EditForm.addExistingAttribute(attributeName1);
        EditForm.addExistingAttribute(attributeName2);
        EditForm.submitForm();
        left_nav = true;
        AttendeeOnsite.navigate(attendeeId1);
        AttendeeOnsite.addAttributeChoice(attributeName1, value1);
        AttendeeOnsite.navigate(attendeeId2);
        AttendeeOnsite.addAttributeChoice(attributeName1, value2);
        AttendeeOnsite.navigate(attendeeId3);
        AttendeeOnsite.addAttributeChoice(attributeName2, value3);
        //Create badge layout
        NewBadgePage.navigate();
        NewBadgePage.setName(badge);
        deleteBadge = true;
        //Upload an image to use for mapping
        NewBadgePage.clickImagesTab();
        Utils.getResourceAsFile(file1, fileName1);
        Utils.getResourceAsFile(file2, fileName2);
        NewBadgePage.uploadMultipleImages(fileName1, fileName2);
        NewBadgePage.clickDone();
        fileId1 = NewBadgePage.getFileID(fileName1);
        fileId2 = NewBadgePage.getFileID(fileName2);
        //Create mappings
        NewBadgePage.clickMappingsTab();
        NewBadgePage.clickAddMapping();
        NewBadgePage.selectAttribute(attributeName1); // Fails here
        NewBadgePage.addMappingValue(attributeName1, value1);
        NewBadgePage.addMappingValue(attributeName1, value2);
        NewBadgePage.selectImage(attributeName1, value1, fileName1);
        NewBadgePage.selectImage(attributeName1, value2, fileName2);
        NewBadgePage.clickAddMapping();
        NewBadgePage.scrollToMapping(2);
        NewBadgePage.selectAttribute(attributeName2);
        NewBadgePage.addMappingValue(attributeName2, value3);
        NewBadgePage.changeTypeToText(attributeName2);
        NewBadgePage.saveBadge();
        NewBadgePage.clickLayoutTab();
        //Verify: both mappings are available to use
        NewBadgePage.expandMappings();
        Assert.assertTrue(NewBadgePage.isMappingAvailable(attributeName1), attributeName1 + " should be available on the layout builder");
        Assert.assertTrue(NewBadgePage.isMappingAvailable(attributeName2), attributeName2 + " should be available on the layout builder");
        //Drag and drop the mappings into the layout field
        NewBadgePage.addMappingToCanvas(attributeName2);
        NewBadgePage.addMappingToCanvas(attributeName1);
        //Verify text shows for attribute 2
        Assert.assertTrue(NewBadgePage.doesTextShowInLayout(attributeName2), "The text: "+attributeName2+" should show in the layout");
        //Verify image 1 shows for attribute 1
        Assert.assertTrue(NewBadgePage.doesImageShowInLayout(attributeName1), "The layout should show image 1");
        //Preview on attendee 1 and verify image 1 shows
        NewBadgePage.saveBadge();
        NewBadgePage.previewAttendee(attendeeFN1);
        Assert.assertTrue(NewBadgePage.doesImageMatch(Name1), "Preview should show desert image");
        //Preview on attendee 2 and verify image 2 shows
        NewBadgePage.previewAttendee(attendeeFN2);
        Assert.assertTrue(NewBadgePage.doesImageMatch(Name2), "Preview should show palace image");
        //Preview on attendee 3 and verify text shows
        NewBadgePage.previewAttendee(attendeeFN3);
        Assert.assertTrue(NewBadgePage.doesTextMatch(value3), "Preview should show text");
    }
}