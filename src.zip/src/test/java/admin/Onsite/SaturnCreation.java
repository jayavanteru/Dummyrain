package admin.Onsite;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.onsite.EditSaturnServerPage;
import apps.admin.adminPageObjects.onsite.NewSaturnServerPage;
import apps.admin.adminPageObjects.onsite.SaturnServerSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class SaturnCreation {

    DataGenerator gen = new DataGenerator();

    protected String saturnName;
    protected String saturnId;
    private AdminApp adminApp;
    final SaturnServerSearchPage searchPage = SaturnServerSearchPage.getPage();
    final NewSaturnServerPage newPage = NewSaturnServerPage.getPage();
    final EditSaturnServerPage editPage = EditSaturnServerPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @BeforeMethod
    public void createNewSaturn() {
        saturnName = gen.generateName();
        searchPage.navigate();
        //Add a new server
        searchPage.addItem();
        newPage.setName(saturnName);
        newPage.submit();
        saturnId = searchPage.getId(saturnName);
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void delete(){
            adminApp.deleteSaturnApi(saturnId);
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-22977", firefoxIssue = "RA-22978")
    public void editSaturn() {
        searchPage.searchFor(saturnName);
        searchPage.editItem();
        editPage.setName(saturnName);
        editPage.submit();
        searchPage.searchFor(saturnName);
        Assert.assertTrue(searchPage.nameExists(saturnName), "Edited saturn server does not appear in search results");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-18804", firefoxIssue = "RA-22602")
    public void createdSaturn() {
        //Verify server was created and search works
        Assert.assertTrue(searchPage.nameExists(saturnName), "We have searched for the created saturn server but did not find one");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-22836", firefoxIssue = "RA-22837")
    public void saturnErrors() {
        searchPage.addItem();
        newPage.submit();
        //Verify required field error
        Assert.assertTrue(newPage.isErrorDisplayed(), "We clicked submit without filling in the name field and should see an error");

        newPage.setName(saturnName);
        newPage.submit();
        //Verify duplicate server name error
        Assert.assertTrue(newPage.isErrorDisplayed(), "We clicked submit with a duplicate name in the name field and should see an error");
    }
}


