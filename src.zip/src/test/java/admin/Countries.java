package admin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.CountrySearchPage;
import apps.admin.NewCountryPage;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;
import java.util.ArrayList;
import java.util.List;

public class Countries {

  private final DataGenerator dataGenerator = new DataGenerator();
  private NewCountryPage newCountryPage;
  private CountrySearchPage countrySearchPage;
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private List<String> countryIdsToDelete = new ArrayList<>();
  private SoftAssert softAssert;
  private AdminApp adminApp;

  @BeforeClass
  public void setupTest() {
    newCountryPage = NewCountryPage.getPage();
    countrySearchPage = CountrySearchPage.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    adminApp = new AdminApp();
    softAssert = new SoftAssert();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void closeBrowser() {
    try {
      for(String country : countryIdsToDelete){
        adminApp.deleteCountry(country);
      }
    }
    catch (Exception e){
    }
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-45323", chromeIssue = "RA-42966")
  public void addNewEmailDomainMapping() {
    String twoCharacterCode = "ZZ";
    String threeCharacterCode = "ZZZ";
    String callingCode = "+999";
    String numericCode = "999";
    String longitude = "-12.073096";
    String latitude = "-77.169437";
    String countryName = dataGenerator.generateName();

    newCountryPage.navigate();
    newCountryPage.fillCountryInformation(twoCharacterCode, threeCharacterCode, countryName, callingCode, numericCode, longitude, latitude);
    newCountryPage.save();
    countryIdsToDelete.add(twoCharacterCode);

    countrySearchPage.search(countryName);
    countrySearchPage.clickRow(0);

    softAssert.assertTrue(newCountryPage.existText(twoCharacterCode), "2-character code must exist");
    softAssert.assertTrue(newCountryPage.existText(threeCharacterCode), "3-character code must exist");

    countryName = dataGenerator.generateName();
    newCountryPage.setCountryDisplayName(countryName);
    newCountryPage.save();

    countrySearchPage.search(countryName);
    countrySearchPage.clickRow(0);

    Assert.assertEquals(newCountryPage.getCountryNameValue(), countryName, "Country name is different");

    attendeeSearchPage.navigate();
    attendeeSearchPage.search();
    attendeeSearchPage.clickResult(0);

    editAttendeePage.goToDemographicsTab();
    editAttendeePage.openCountrySelectDemographicsTab();

    softAssert.assertTrue(editAttendeePage.existCountryDemographicsTab(countryName), "Country should exist");

    softAssert.assertAll();
  }
}
