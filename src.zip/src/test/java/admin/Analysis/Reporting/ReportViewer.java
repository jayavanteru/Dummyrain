package admin.Analysis.Reporting;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import apps.admin.adminPageObjects.analysis.reporting.ReportViewerPage;
import interaction.files.OpenFile;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.io.IOException;
import java.util.*;

public class ReportViewer {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendee1Email, attendee1Id,
            attendee2Email, attendee2Id;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttendee(attendee1Id);
        adminApp.deleteAttendee(attendee2Id);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(chromeIssue = "RA-43382", firefoxIssue = "RA-34537")
    public void reportViewer() throws IOException {
        List<Map<String, String>> table;

        //create attendees
        attendee1Id = adminApp.createAttendee(attendee1Email = dataGenerator.generateValidEmail(), attendee1Email, attendee1Email);
        attendee2Id = adminApp.createAttendee(attendee2Email = dataGenerator.generateValidEmail(), attendee2Email, attendee2Email);

        //open report
        ReportsListPage.getPage().navigateToReportList();
        ReportsListPage.getPage().openFolderByName("_REGRESSION");
        ReportsListPage.getPage().openReport("Attendee - DO NOT DELETE");
        Utils.sleep(3000);

        int numberOfResults = ReportViewerPage.getPage().getNumberOfResults();

        //email export
        ReportViewerPage.getPage().actions();
        ReportViewerPage.getPage().emailExport();

        //wrong email & assert
        ReportViewerPage.getPage().setEmailExportEmailAddresses("123@a");
        ReportViewerPage.getPage().sendEmailExportEmails();
        Assert.assertTrue(ReportViewerPage.getPage().emailExportErrorExists("123@a is not formatted correctly"), "ERROR MESSAGE DID NOT RENDER");
        ReportViewerPage.getPage().emailExportCancel();

        //correct email
        ReportViewerPage.getPage().actions();
        ReportViewerPage.getPage().emailExport();
        ReportViewerPage.getPage().setEmailExportEmailAddresses(attendee1Email, attendee2Email, "rene.vanderwatt@rainfocus.com");
        ReportViewerPage.getPage().sendEmailExportEmails();

        //wait for 10 seconds cuz some times emails take like forever to get sent out you know
        Utils.sleep(10000);
        EmailApi.emailClient().waitForEmail("Report: Attendee - DO NOT DELETE");
        EmailMessage[] recentEmails = EmailApi.emailClient().getRecentEmails(10);

        boolean attendee1GotEmail = false;
        boolean attendee2GotEmail = false;
        boolean attendee1GotAttachment = false;
        boolean attendee2GotAttachment = false;
        boolean attendee1AttachmentWasRightSize = false;
        boolean attendee2AttachmentWasRightSize = false;


        for (EmailMessage email: recentEmails) {
            if (!(attendee1GotEmail && attendee2GotEmail)) {
                if (Arrays.asList(email.getRecipients()).contains(attendee1Email)) {
                    attendee1GotEmail = true;
                    String attachment = email.getAttachments().get(0);
                    final OpenFile openFile = new OpenFile(attachment);
                    final List<Map<String, String>> attachContent = openFile.parseXLSX();
                    attendee1GotAttachment = openFile.getName().contains("Attendee - DO NOT DELETE");
                    attendee1AttachmentWasRightSize = (attachContent.size() == numberOfResults);
                }
                if (Arrays.asList(email.getRecipients()).contains(attendee2Email)) {
                    attendee2GotEmail = true;
                    String attachment = email.getAttachments().get(0);
                    final OpenFile openFile = new OpenFile(attachment);
                    final List<Map<String, String>> attachContent = openFile.parseXLSX();
                    attendee2GotAttachment = openFile.getName().contains("Attendee - DO NOT DELETE");
                    attendee2AttachmentWasRightSize = (attachContent.size() == numberOfResults);
                }
            } else {
                break;
            }
        }

        Assert.assertTrue(attendee1GotEmail, "ATTENDEE 1 DID NOT GET AN EMAIL");
        Assert.assertTrue(attendee2GotEmail, "ATTENDEE 2 DID NOT GET AN EMAIL");
        Assert.assertTrue(attendee1GotAttachment, "ATTENDEE 1 DID NOT GET AN EXCEL FILE");
        Assert.assertTrue(attendee2GotAttachment, "ATTENDEE 2 DID NOT GET AN EXCEL FILE");
        Assert.assertTrue(attendee1AttachmentWasRightSize, "ATTENDEE 1 EXCEL FILE WAS NOT THE RIGHT SIZE");
        Assert.assertTrue(attendee2AttachmentWasRightSize, "ATTENDEE 2 EXCEL FILE WAS NOT THE RIGHT SIZE");

        //edit report
        ReportViewerPage.getPage().actions();
        ReportViewerPage.getPage().editReport();

        //assert report builder loaded
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("reportBuilder.do"), "CURRENT URL IS NOT THE WIDGET BUILDER URL");
        Assert.assertTrue(ReportBuilderPage.getPage().pageLoaded(), "THE REPORT BUILDER DID NOT RENDER");

        //run report
        ReportBuilderPage.getPage().runReport();

        //assert report viewer loaded
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        table = ReportViewerPage.getPage().getTableData();
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("reportViewer.do"));

        //filter by text
        ReportViewerPage.getPage().openColumnSortingModal("First Name");
        ReportViewerPage.getPage().setColumnFilterText("Chris");
        ReportViewerPage.getPage().applyColumnFilter();

        //assert first name of first attendee is 'chris'
        table = ReportViewerPage.getPage().getTableData();
        Assert.assertTrue(table.get(0).get("FIRST NAME").equals("Chris"), "THE FIRST NAME OF ROW 1 WAS NOT 'CHRIS'");

        //sort last name ascending
        ReportViewerPage.getPage().openColumnSortingModal("Last Name");
        ReportViewerPage.getPage().sortByAscending();

        //assert last name sorted ascending
        table = ReportViewerPage.getPage().getTableData();

        String lastName1 = table.get(0).get("LAST NAME");
        String lastName2 = table.get(1).get("LAST NAME");
        String lastName3 = table.get(2).get("LAST NAME");

        List<String> lastNames = new ArrayList<>();
        lastNames.add(lastName1);
        lastNames.add(lastName2);
        lastNames.add(lastName3);

        Collections.sort(lastNames);

        Assert.assertTrue(lastNames.get(0).equals(lastName1) && lastNames.get(1).equals(lastName2) && lastNames.get(2).equals(lastName3), "THE LAST NAMES WERE NOT SORTED IN ASCENDING ORDER");

        //attendee type 'Employee'
        ReportViewerPage.getPage().openColumnSortingModal("Registered Date");
        ReportViewerPage.getPage().openColumnSortingModal("Attendee Type");
        ReportViewerPage.getPage().columnFilterDeselectAll();
        ReportViewerPage.getPage().columnFilterClickCheckbox("Employee");
        ReportViewerPage.getPage().applyColumnFilter();

        PageConfiguration.getPage().justWait();

        //assert checkbox filter worked
        table = ReportViewerPage.getPage().getTableData();

        Assert.assertTrue(table.get(0).get("ATTENDEE TYPE").equals("Employee"));

        //export csv
        ReportViewerPage.getPage().clearAllFilters();
        ReportViewerPage.getPage().openColumnSortingModal("First Name");
        ReportViewerPage.getPage().setColumnFilterText("Chris");
        ReportViewerPage.getPage().applyColumnFilter();

        PageConfiguration.getPage().justWait();
        table = ReportViewerPage.getPage().getTableData();
        ReportViewerPage.getPage().actions();
        ReportViewerPage.getPage().exportExcel();

        OpenFile openFile = OpenFile.OpenRecentDownloadedFile();
        Assert.assertTrue(openFile.getName().contains("Attendee - DO NOT DELETE"));

        List<Map<String, String>> xlsx = openFile.parseXLSX();
        Assert.assertTrue(table.equals(xlsx));


        //export xlsx
        ReportViewerPage.getPage().actions();
        ReportViewerPage.getPage().exportCsv();

        openFile = OpenFile.OpenRecentDownloadedFile();
        Assert.assertTrue(openFile.getName().contains("Attendee - DO NOT DELETE"));

        List<Map<String, String>> csv = openFile.getCsvMap();
        Assert.assertTrue(table.equals(csv));
    }
}
