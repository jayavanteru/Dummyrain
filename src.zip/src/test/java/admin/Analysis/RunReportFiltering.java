package admin.Analysis;

import apps.admin.AdminApp;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.analysis.reporting.RunReportPage;
import interaction.api.Api;
import interaction.api.ApiConfig;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RunReportFiltering {

    ReportingPage reportingPage;
    RunReportPage runReportPage;
    protected AdminApp adminApp;

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        adminApp.loginApi();
    }
    //This test is being rewritten as a unit test, it is failing 100% of the time so I am stopping it from running for now
    //@Test(groups = {ReportingInfo.DATATRON})
    //@ReportingInfo(firefoxIssue = "RA-28451", chromeIssue = "RA-28452")
    public void openPages() {

        Api apiclient=adminApp.getApi();
        ApiConfig response = apiclient.post(new ApiConfig("{{adminUrl}}/runReportFilteringTest.do"));
        int failedtests= (int) response.getResponseAsApiBody().get("numFailedTests").getOriginalValue();
        Assert.assertEquals(failedtests,0,response.getResponse().toString());
    }


}