package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.analysis.reporting.RunReportPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

public class ReportingMiscellaneous
{
    ReportingPage reportingPage = ReportingPage.getPage();
    RunReportPage runReportPage = RunReportPage.getPage();
    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();
        
        // Uncomment for local development (admin.properties local override didn't seem to work)
        // AdminLoginPage.getPage().setAdminUrl("http://localhost:8080");
        
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }
    
    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-19562", chromeIssue = "RA-26102")
    public void openPages()
    {
        runReportPage.navigate();
        assertTrue(runReportPage.waitUntilFinished(),"Report did not finish running");
        
        final String errorsCount = runReportPage.getErrorsText();
        assertTrue(errorsCount.startsWith("0 errors"), "There should be 0 errors, but found " + errorsCount);
    }
}
