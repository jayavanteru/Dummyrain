package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportActionsModal;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.Collections;

public class ReportSumAndAvg {

    private final String ATTENDEE_TEMPLATE = "15381699461510010SC8";
    private final String ReportName = "automation" + new DataGenerator().generateString(5);

    private final ReportsListPage reportsListPage = ReportsListPage.getPage();
    private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();
    private final ReportActionsModal reportActionsModal = ReportActionsModal.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-46966", chromeIssue = "RA-47108")
    public void columnSumAndAvg(){

        //Edit Chris R Avg Voting Report
        reportsListPage.navigateToReportList();
        reportsListPage.search("Chris R AVG Voting");
        reportsListPage.editReport("Chris R AVG Voting");

        //Reset column action
        reportBuilderPage.removeColumnCount(1);
        reportBuilderPage.closeColumnAction(1);
        reportBuilderPage.removeSumTotal(1);
        reportBuilderPage.closeColumnAction(1);
        reportBuilderPage.removeAvg(1);

        //Select Add sum total and verify Avg is disabled
        reportBuilderPage.closeColumnAction(1);
        reportBuilderPage.columnActionAddSumTotal(1);
        Assert.assertTrue(reportBuilderPage.isAvgDisabled(1), "Avg is not disabled");
        reportBuilderPage.closeColumnAction(1);
        reportBuilderPage.removeSumTotal(1);

        //Select Avg and verify Sum Total is not visible
        reportBuilderPage.addAvgToColumn(1);
        Assert.assertTrue(reportBuilderPage.sumTotalIsHidden(1),"The sum total is showing, it should be hidden");

        //Add filter to verify column can not be deleted
        reportBuilderPage.clearFilters();
        reportBuilderPage.addFilter();
        reportBuilderPage.fillFilterValues(1, "Vote", "equals", "2");
        reportBuilderPage.applyFilter();
        reportBuilderPage.removeColumn(1,true);
    }
}
