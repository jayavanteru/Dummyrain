package admin.Analysis.Dashboards;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.DashboardBuilder.DashboardBuilderPage;
import apps.admin.adminPageObjects.analysis.DashboardsListPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.List;
import java.util.Map;

public class DashboardReportingTypes {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(chromeIssue = "RA-43695", firefoxIssue = "RA-30632")
    public void dashboardReportingTypes() {

        String attendeeOrders = "Attendee Orders - DO NOT DELETE";

        //open builder
        DashboardsListPage.getPage().navigateToDashboardsListPage().navigateToDashboardBuilder();

        //assert render
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("dashboardBuilder.do"));

        //navigate to report
        DashboardBuilderPage.getPage().
                addTiles().
                existingReport().
                selectReportNew(attendeeOrders);

        //open blade
        DashboardBuilderPage.getPage().editTile();

        //assert blade open
        Assert.assertTrue(DashboardBuilderPage.getPage().editTileBladeRendered());

        //configure tile
        DashboardBuilderPage.getPage().
                setVisualization("Horizontal Bar").
                setCategoryColumn("Attendee Type").
                setMetricColumn("Quantity");

        //assert horizontal render
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsHorizontalBar());

        //get tile data
        List<Map<String, String>> previewXAxisValuesBefore = DashboardBuilderPage.getPage().getPreviewXAxisValues();

        //configure tile - font size & order
        DashboardBuilderPage.getPage().
                preferences().
                style().
                setFontSize("16").
                barChart().
                reverse();

        //get new tile data
        List<Map<String, String>> previewXAxisValues = DashboardBuilderPage.getPage().getPreviewXAxisValues();

        //assert font size changed
        previewXAxisValues.forEach((map)->{
            Assert.assertTrue(map.get("fontSize").contains("16"), "PREVIEW FONT SIZE WAS NOT CHANGED");
        });

        //assert order changed
        Assert.assertFalse(previewXAxisValuesBefore.get(0).get("text").contains(previewXAxisValues.get(0).get("text")), "PREVIEW ORDER WAS NOT CHANGED");

        //old labels
        previewXAxisValuesBefore = DashboardBuilderPage.getPage().getPreviewXAxisValues();

        //configure tile as vertical bar
        DashboardBuilderPage.getPage().
                setUp().
                setVisualization("Vertical Bar");

        //new labels
        previewXAxisValues = DashboardBuilderPage.getPage().getPreviewXAxisValues();

        //assert vertical render
        Assert.assertFalse(previewXAxisValues.get(0).get("text").contains(previewXAxisValuesBefore.get(0).get("text")), "PREVIEW DID NOT RENDER AS VERTICAL BAR - LABELS");
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsVerticalBar(), "PREVIEW DID NOT RENDER AS VERTICAL BAR - CLASS");

        //configure line render
        DashboardBuilderPage.getPage().setVisualization("Line");

        //assert line render
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsLine());

        //configure kpi
        DashboardBuilderPage.getPage().
                setVisualization("KPI").
                setKpiColumn(1, "Quantity").
                setKpiRow(1, "Summary");

        //assert kpi render
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsKpiTile(), "PREVIEW WAS NOT A KPI TILE");

        //kpi format
        // - percent
        DashboardBuilderPage.getPage().setKpiFormat(1, "Percent");
        Assert.assertTrue(DashboardBuilderPage.getPage().kpiContains("%"), "KPI FORMAT WAS NOT PERCENT");

        // - currency
        DashboardBuilderPage.getPage().setKpiFormat(1, "Currency");
        Assert.assertTrue(DashboardBuilderPage.getPage().kpiContains("$"), "KPI FORMAT WAS NOT CURRENCY");

        // - decimal
        DashboardBuilderPage.getPage().
                setKpiFormat(1, "Decimal").
                setKpiDecimalPrecision(1, "2");
        Assert.assertTrue(DashboardBuilderPage.getPage().kpiContains("."), "KPI FORMAT WAS NOT DECIMAL");

        //label
        DashboardBuilderPage.getPage().setLabel(1,"Label");
        Assert.assertTrue(DashboardBuilderPage.getPage().kpiContains("Label"), "KPI DID NOT CONTAIN LABEL");

        //color
        DashboardBuilderPage.getPage().
                preferences().
                style().
                setColor(1, "#000000");
        PageConfiguration.getPage().justWait();

        //assert color
        Assert.assertTrue(DashboardBuilderPage.getPage().kpiTextIsColor("rgb(0, 0, 0)"), "TEXT COLOR WAS NOT SET");

        //pie chart
        DashboardBuilderPage.getPage().
                setUp().
                setVisualization("Pie").
                setCategoryColumn("Attendee Type").
                setMetricColumn("Quantity");

        //assert pie chart
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsPieChart(), "PREVIEW WAS NOT A PIE CHART");

        //apply
        DashboardBuilderPage.getPage().apply();

        //assert tile
        Assert.assertTrue(DashboardBuilderPage.getPage().tileIsPie(), "TILE IS NOT PIE");

        //edit tile
        DashboardBuilderPage.getPage().editTile();

        //assert blade open
        Assert.assertTrue(DashboardBuilderPage.getPage().editTileBladeRendered());

        //configure tile to set row limit
        DashboardBuilderPage.getPage().
                setVisualization("Horizontal Bar").
                setCategoryColumn("Attendee Type").
                setMetricColumn("Quantity").
                setRowLimit("5").
                apply();

        //assert horizontal render
        Assert.assertTrue(DashboardBuilderPage.getPage().previewRenderedAsHorizontalBar());
        Assert.assertEquals(5,DashboardBuilderPage.getPage().numberOfBars(),"There should be 5 rows displayed in the graph");

    }
}
