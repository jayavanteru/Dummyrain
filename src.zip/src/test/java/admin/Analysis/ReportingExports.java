package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.analysis.reporting.RunReportPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class ReportingExports {

    ReportingPage reportingPage;
    RunReportPage runReportPage;
    protected AdminApp adminApp;

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
        reportingPage = ReportingPage.getPage();
        reportingPage.navigateTo();
        reportingPage.clickOnReport("Attendee - DO NOT DELETE");
        Utils.sleep(1000);
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-26645", chromeIssue = "RA-26640")
    public void exportCSV(){

        runReportPage = RunReportPage.getPage();
        runReportPage.ExportAsCSV();
        Utils.sleep(1000, "wait for export to finish");
        Assert.assertTrue(OpenFile.fileTypeMatches("csv"), "File Type didn't match");
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-26647", chromeIssue = "RA-26646")
    public void exportXLSX(){
        runReportPage = RunReportPage.getPage();
        runReportPage.ExportAsXLSX();
        Utils.sleep(1000, "wait for export to finish");
        Assert.assertTrue(OpenFile.fileTypeMatches("xlsx"), "File Type didn't match");
    }
}
