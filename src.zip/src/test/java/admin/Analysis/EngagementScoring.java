package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.EngagementScorePage;
import apps.admin.adminPageObjects.libraries.AdminOrgAttributesPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class EngagementScoring {
  CreateEventAttributePage createEventAttributePage = CreateEventAttributePage.getPage();
  EngagementScorePage engagementScorePage = EngagementScorePage.getPage();
  AdminOrgAttributesPage adminOrgAttributesPage = AdminOrgAttributesPage.getPage();


  private DataGenerator generator = new DataGenerator();
  String eventAttributeName = generator.generateName();
  String responseType = "Radio List";
  String audienceType = "Focus";
  int optionNameLength = 24;
  String[] radioListOptions = {
          generator.generateString(optionNameLength),
          generator.generateString(optionNameLength),
          generator.generateString(optionNameLength),
          generator.generateString(optionNameLength),
  };
  String[] codes = {
          "",
          "",
          "",
          "",
  };

  @BeforeClass
  public void setup () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
  }

  @AfterClass
  public void closeBrowser () {
    PageConfiguration.getPage().quit();
  }

  @BeforeMethod
  public void createAttribute () {
    createEventAttributePage.navigate();
    createEventAttributePage.waitForPageLoad();
    createEventAttributePage.createAttributeWithCodeAndParameter(eventAttributeName, eventAttributeName, responseType, audienceType, radioListOptions, codes, "");
    createEventAttributePage.saveAttribute();
  }

  @AfterMethod
  public void tearDown () {
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
    adminOrgAttributesPage.navigateToPage();
    adminOrgAttributesPage.waitForPageToLoad();
    adminOrgAttributesPage.findAndDeleteAttribute(eventAttributeName);
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-31080", chromeIssue = "RA-19886")
  public void verifyAttribute () {
    engagementScorePage.navigate();
    engagementScorePage.waitForPageLoad();
    for (int i = 0; i < radioListOptions.length; i++) {
      Assert.assertTrue(engagementScorePage.optionExists(radioListOptions[i]),"Cannot find Attribute '"+radioListOptions[i]+"' on Engagement Scoring page"
      );
    }
  }
}
