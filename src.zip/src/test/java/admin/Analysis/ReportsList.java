package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import configuration.PropertyReader;

import logs.ReportingInfo;

import okhttp3.internal.Util;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ReportsList {

  private DataGenerator generator = new DataGenerator();

  private String newReportName = generator.generateName();
  private String attendeeReport = "Attendee-name";
  private String attendeeCheckinReport = "Attendee-Check-ins--name";

  private final ReportsListPage reportsListPage = ReportsListPage.getPage();
  private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();

  @BeforeClass
  public void login() {
    PropertyReader.instance().setProperty("enableDesktopAutomation", true);
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    reportsListPage.navigateToReportList();
  }

  @BeforeMethod
  public void goToReportsList() {
    reportsListPage.assertReportListUrl();
  }

  @Test(groups = ReportingInfo.DATATRON)
  @ReportingInfo(firefoxIssue = "RA-41917", chromeIssue = "RA-19446")
  public void reportsList() {

    reportsListPage.goToCoreDirectory();

    reportsListPage.selectFavorites();
    reportsListPage.switchToFavoritesFolder();
    reportsListPage.assertFavoriteRowsVisible();
    reportsListPage.deselectFavorites();
    Assert.assertFalse(reportsListPage.isFavoriteReportInList(attendeeReport), "Attendee report is visible, but should not be");
    Assert.assertFalse(reportsListPage.isFavoriteReportInList(attendeeCheckinReport), "Attendee Check-in report is visible, but should not be");

    reportsListPage.expandCoreAttendeeFolder ();

    reportsListPage.editReport("Attendee");

    reportBuilderPage.saveAs(newReportName);
    Utils.sleep(3000);
    reportsListPage.returnToPrivateDirectory();

    reportsListPage.copyReport(newReportName);
    reportsListPage.assertReportCopied(newReportName + " copy");

    reportsListPage.deleteReport(newReportName + " copy");
    reportsListPage.assertReportDeleted(newReportName + " copy");

    reportsListPage.openRenameModal(newReportName);
    reportsListPage.checkForSlashError();
    reportsListPage.renameReport(newReportName + "_RENAMED");
    reportsListPage.assertReportRenamed(newReportName + "_RENAMED");

    reportsListPage.openMoveReportModal(newReportName + "_RENAMED");
    reportsListPage.moveReportToShared();
    reportsListPage.goToSharedDirectory();
    reportsListPage.assertReportMoved(newReportName + "_RENAMED");

    reportsListPage.deleteReport(newReportName + "_RENAMED");
    reportsListPage.assertReportDeleted(newReportName + "_RENAMED");

    reportsListPage.returnToCoreDirectory();
    reportsListPage.search("Attendee Online Payment Reconciliation");
    reportsListPage.editReport("Attendee Online Payment Reconciliation");
    Assert.assertTrue(reportsListPage.isSQLEditPageVisable(), "Type or paste SQL here is not on page");
    reportsListPage.cancelSQLEdit();

    reportsListPage.openReportTypePickerModal();
    reportsListPage.openSQLReportBuilder();
    reportsListPage.assertSQLBuilderUrl();

    reportsListPage.cancelCreateSQLReport();
    reportsListPage.assertReportListUrl();

  }


  @AfterClass
  public void closeBrowser()
  {
    PageConfiguration.getPage().quit();
  }
}

