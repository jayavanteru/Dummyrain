package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.*;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

public class ReportMenu {

    private final String ATTENDEE_TEMPLATE = "15381699461510010SC8";
    private DataGenerator generator = new DataGenerator();

    private String newReportName = generator.generateName();

    private final ReportsListPage reportsListPage = ReportsListPage.getPage();
    private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();

    @BeforeClass
    public void login() {
        PropertyReader.instance().setProperty("enableDesktopAutomation", true);
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        reportsListPage.navigateToReportList();

        reportsListPage.openReportTypePickerModal();
        reportsListPage.openTemplatePickerModal();
        reportsListPage.selectTemplate(ATTENDEE_TEMPLATE);
    }

    @AfterClass
    public void cleanup() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-18990", chromeIssue = "RA-43495")
    public void headerMenuButtons() {
        final ReportBuilderPage reportBuilder = ReportBuilderPage.getPage();
        final ReportActionsModal actionsModal = ReportActionsModal.getPage();

        int startSize = reportBuilder.getColumnPills().size();
        reportBuilder.removeColumn(0, false);
        int afterSize = reportBuilder.getColumnPills().size();

        //undo the change
        reportBuilder.menuActionUndo();
        Assert.assertEquals(reportBuilder.getColumnPills().size(), startSize, "did not undo the action of removing a column");

        //redo the change
        reportBuilder.menuActionRedo();
        Assert.assertEquals(reportBuilder.getColumnPills().size(), afterSize, "did not redo the action of removing a column");

        //switch template
        reportBuilder.switchTemplate();
        reportBuilder.cancelContinueWithoutSaving();
        reportBuilder.switchTemplate();
        reportBuilder.continueWithoutSaving();

        //cancel template switch
        reportsListPage.cancelTemplate();

        //remove column by editing json
        reportBuilder.editJson();

        final ReportEditJson editJsonPage = ReportEditJson.getPage();
        final JSONObject json = editJsonPage.getJson();

        final JSONArray columns = MyJson.getJSONArray(json, "columns");
        final JSONArray newjson = new JSONArray();
        for (int i = 1; i < columns.length(); ++i) {
            newjson.put(MyJson.getJSONObject(columns, i));
        }
        try {
            json.put("columns", newjson);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        editJsonPage.setJson(json);
        editJsonPage.apply();

        //verify the column was removed
        Assert.assertEquals(reportBuilderPage.getColumnPills().size(), afterSize - 1, "editing json did not remove the one column");

        //debug info
        reportBuilderPage.viewDebugInfo();

        ReportDebugPage debugPage = ReportDebugPage.getPage();
        //assert all the debug info
        Assert.assertTrue(debugPage.getReportName().length() > 5, "debug info does not have report name");
        Assert.assertTrue(debugPage.getJson().length() > 10, "debug info does not have json info");
        Assert.assertTrue(debugPage.getSQL().length() > 10, "debug info does not have SQL info");
        Assert.assertTrue(debugPage.getSQLExplainPlan().length() > 10, "debug info does not have SQL explain info");
        Assert.assertTrue(debugPage.getSQLMD5Hash().length() > 10, "debug info does not have MD5 hash");

        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //save as
        reportBuilder.actionsSaveAs();
        actionsModal.setReportSaveAsName("");
        Assert.assertEquals(actionsModal.getSaveErrorMsg(), "Unable to save report as specified");
        actionsModal.setReportSaveAsName("/");
        Assert.assertEquals(actionsModal.getSaveErrorMsg(), "Name cannot contain a '/'");

        String folderName = generator.generateName();
        actionsModal.createNewFolder("/");
        Assert.assertEquals(actionsModal.getSaveErrorMsg(), "A folder name cannot include an '/'");
        actionsModal.setNewFolderName(folderName);
        Assert.assertTrue(actionsModal.findFolder(folderName), "did not save the folder name");
        Assert.assertFalse(actionsModal.isNewFolderLinkPresent(), "did not remove the add new folder after adding one");
        actionsModal.cancelSaveAs();

        //make sure the folder is gone because of cancel
        reportBuilder.actionsSaveAs();
        Assert.assertFalse(actionsModal.findFolder(folderName), "saved the folder after cancel");

        //create a valid report in a new folder
        String reportDescription = generator.generateString();
        actionsModal.createNewFolder(folderName);
        Assert.assertFalse(actionsModal.isNewFolderLinkPresent(), "did not remove the add new folder after adding one");
        actionsModal.setReportName(newReportName);
        actionsModal.setReportDescription(reportDescription);

        //play with some of those security roles
        actionsModal.gotoAccessSecurityTab();
        int roles = actionsModal.getAccessRoles().size();
        actionsModal.removeAccessRole(0);
        Assert.assertEquals(actionsModal.getAccessRoles().size(), roles - 1, "did not remove the role");
        actionsModal.addAccessRole(0);
        Assert.assertEquals(actionsModal.getAccessRoles().size(), roles, "did not add the role");

        actionsModal.saveModal();
        Utils.sleep(3000);
        reportBuilder.navigateBackViaBreadcrumb();

        //find the new report
        reportsListPage.goToPrivateDirectory();
        reportsListPage.openFolder(folderName);
        Assert.assertTrue(reportsListPage.isReportInList(newReportName), "report not saved");

        reportsListPage.deleteReport(newReportName);
        //reportsListPage.goToAllReports();
        Assert.assertFalse(reportsListPage.isFolderInList(folderName), "did not delete the folder after deleting report");
    }
}
