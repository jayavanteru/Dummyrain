package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.NewReportNotificationPage;
import apps.admin.adminPageObjects.analysis.ReportNotificationSearchPage;
import configuration.PropertyReader;
import interaction.files.OpenFile;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportNotificationsV2 {

    String reportNotificationId;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NewReportNotificationPage.getPage().navigate();
    }

    @AfterClass
    public void cleanup() {
        if (reportNotificationId != null) {
            ReportNotificationSearchPage.getPage().deleteNotificationApi(reportNotificationId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-47987", chromeIssue = "RA-49642")
    public void ReportNotificationScheduled() throws IOException {
        DataGenerator generator = new DataGenerator();
        String reportName = "Attendee copy no data copy-Brian";
        String time = "1:00";
        String timeZone = "US/Pacific";
        String random = "automation" + generator.generateString(5);
        String notename = "zzzautomation" + generator.generateString(5);
        String emailSubject = "Report Notification: " + notename;
        String email1 = generator.generateEmail();
        String email2 = generator.generateValidEmail();

        NewReportNotificationPage newNotifications = NewReportNotificationPage.getPage();
        ReportNotificationSearchPage searchPage = ReportNotificationSearchPage.getPage();

        newNotifications.notificationName(notename);
        newNotifications.selectReport(reportName);
        Assert.assertTrue(newNotifications.getNoDataReport(), "did not select the right report");
        newNotifications.addReports();
        newNotifications.submitReports();
        newNotifications.addRecipients(random);
        Assert.assertEquals(newNotifications.getRecipientError(), "Invalid email(s) entered.", "Error message did not display correctly");

        newNotifications.addRecipients(email1, email2);
        List<String> recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 2, "not all recipient emails are there");
        Assert.assertTrue(recipients.contains(email1), "recipient email " + email1 + " was not added");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was not added");

        newNotifications.removeRecipient(email1);
        recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 1, "not all recipient emails are there");
        Assert.assertFalse(recipients.contains(email1), "recipient email " + email1 + " was not removed");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was removed");

        //Using a scheduled time
        newNotifications.scheduledTime();
        newNotifications.stdSelectTime(time);
        Assert.assertEquals(newNotifications.getSelectedTime(), time, "did not select the time");
        newNotifications.clickPM();
        newNotifications.toggleNotificationFrequency("Sunday", "Monday", "Tuesday");
        List<String> activeDays = newNotifications.getActiveDays();
        Assert.assertEquals(activeDays.size(), 3, "not all days were selected");
        Assert.assertTrue(activeDays.contains("Sunday"), "S was not selected for notification frequency");
        Assert.assertTrue(activeDays.contains("Monday"), "M was not selected for notification frequency");
        Assert.assertTrue(activeDays.contains("Tuesday"), "T was not selected for notification frequency");

        newNotifications.toggleNotificationFrequency("Monday", "Tuesday");
        activeDays = newNotifications.getActiveDays();
        Assert.assertEquals(activeDays.size(), 1, "not all days were selected");
        Assert.assertTrue(activeDays.contains("Sunday"), "S was not selected for notification frequency");
        Assert.assertFalse(activeDays.contains("Monday"), "M was not deselected for notification frequency");
        Assert.assertFalse(activeDays.contains("Tuesday"), "T was not deselected for notification frequency");
        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertTrue(newNotifications.isSendOnlyIfReportChangedChecked(), "did not check send only if report has changed");
        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertTrue(newNotifications.isSendOnlyIfReportChangedUnChecked(), "did not uncheck send only if report has changed");

        DateTime startDate = DateTime.now().minusDays(2);
        DateTime endDate = DateTime.now().plusDays(2);
        newNotifications.setStartDate(startDate);
        newNotifications.setEndDate(endDate);
        Assert.assertEquals(newNotifications.getStartDate(), startDate.toString("yyyy-MM-dd"), "start date not set");
        Assert.assertEquals(newNotifications.getEndDate(), endDate.toString("yyyy-MM-dd"), "end date not set");

        newNotifications.save();

        HashMap<String, String> lastRow = searchPage.getLastRow();
        Assert.assertNotNull(lastRow.get("id"), "did not get the id");
        reportNotificationId = lastRow.get("id");
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee copy no data copy-Brian", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        //verify all the search
        searchPage.search(notename);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee copy no data copy-Brian", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        searchPage.search("");
        searchPage.searchByRecipients(email2);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee copy no data copy-Brian", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        //send the notification and check the email
        final JSONObject response = searchPage.forceNotificationEmail(reportNotificationId);
        Assert.assertTrue(response.toString().contains("resultEmailsNotSentDataEmpty"), "did not fire the notification email");

        searchPage.deleteNotification(reportNotificationId);

        searchPage.search("");
        lastRow = searchPage.getLastRow();
        Assert.assertNotEquals(lastRow.get("emails"), email2, "did not delete the last row");
        reportNotificationId = null;

}

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-18992", chromeIssue = "RA-43597")
    public void ReportNotificationRecurring() throws IOException {

        DataGenerator generator = new DataGenerator();

        String reportName = "Attendee Summary";
        String time = "1:00";
        String timeZone = "US/Pacific";
        String random = "automation" + generator.generateString(5);
        String notename = "zzzautomation" + generator.generateString(5);
        String emailSubject = "Report Notification: " + notename;
        String email1 = generator.generateEmail();
        String email2 = generator.generateValidEmail();


        NewReportNotificationPage newNotifications = NewReportNotificationPage.getPage();
        ReportNotificationSearchPage searchPage = ReportNotificationSearchPage.getPage();

        //Using a recurring interval
        NewReportNotificationPage.getPage().navigate();
        newNotifications.notificationName(notename);
        newNotifications.selectReport(reportName);
        Assert.assertTrue(newNotifications.getAttendeeSummaryReport(), "did not select the right report");
        newNotifications.addReports();
        newNotifications.submitReports();
        newNotifications.addRecipients(random);
        Assert.assertEquals(newNotifications.getRecipientError(), "Invalid email(s) entered.", "Error message did not display correctly");

        newNotifications.addRecipients(email1, email2);
        List<String> recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 2, "not all recipient emails are there");
        Assert.assertTrue(recipients.contains(email1), "recipient email " + email1 + " was not added");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was not added");

        newNotifications.removeRecipient(email1);
        recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 1, "not all recipient emails are there");
        Assert.assertFalse(recipients.contains(email1), "recipient email " + email1 + " was not removed");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was removed");

        //newNotifications.resetSchedule();
        newNotifications.recurringInterval();
        newNotifications.everyInterval();
        newNotifications.selectTime(time);
        newNotifications.stopTime(time);
        Assert.assertTrue(newNotifications.isEndTimeSet(),"did not select the time");

        newNotifications.clickPM();
        newNotifications.toggleNotificationFrequency("Monday", "Tuesday", "Sunday");
        List<String> activeDaysr = newNotifications.getActiveDays();
        Assert.assertEquals(activeDaysr.size(), 3, "not all days were selected");
        Assert.assertTrue(activeDaysr.contains("Sunday"), "S was not selected for notification frequency");
        Assert.assertTrue(activeDaysr.contains("Monday"), "M was not selected for notification frequency");
        Assert.assertTrue(activeDaysr.contains("Tuesday"), "T was not selected for notification frequency");

        newNotifications.toggleNotificationFrequency("Monday", "Tuesday");
        List<String> activeDays = newNotifications.getActiveDays();
        Assert.assertEquals(activeDays.size(), 1, "not all days were selected");
        Assert.assertTrue(activeDays.contains("Sunday"), "S was not selected for notification frequency");
        Assert.assertFalse(activeDays.contains("Monday"), "M was not deselected for notification frequency");
        Assert.assertFalse(activeDays.contains("Tuesday"), "T was not deselected for notification frequency");
        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertTrue(newNotifications.isSendOnlyIfReportChangedChecked(), "did not check send only if report has changed");
        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertTrue(newNotifications.isSendOnlyIfReportChangedUnChecked(), "did not uncheck send only if report has changed");

        DateTime startDater = DateTime.now().minusDays(2);
        DateTime endDater = DateTime.now().plusDays(2);
        newNotifications.setStartDate(startDater);
        newNotifications.setEndDate(endDater);
        Assert.assertEquals(newNotifications.getStartDate(), startDater.toString("yyyy-MM-dd"), "start date not set");
        Assert.assertEquals(newNotifications.getEndDate(), endDater.toString("yyyy-MM-dd"), "end date not set");

        newNotifications.save();

        HashMap<String, String> lastRow = searchPage.getLastRow();
        Assert.assertNotNull(lastRow.get("id"), "did not get the id");
        reportNotificationId = lastRow.get("id");
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee Summary", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), "Every 2 hours", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        //verify all the search
        searchPage.search(notename);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee Summary", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), "Every 2 hours", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        searchPage.search("");
        searchPage.searchByRecipients(email2);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), notename, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("reports"), "Attendee Summary", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron1"), "Every 2 hours", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("cron2"), "S", "last row did not have the right info");

        //send the notification and check the email
        final JSONObject response = searchPage.forceNotificationEmail(reportNotificationId);
        Assert.assertTrue(response.toString().contains("Success"), "did not fire the notification email");

        EmailApi.emailClient().waitForEmail(emailSubject);
        final EmailMessage mostRecentEmail = EmailApi.emailClient().getEmail(emailSubject);
        Assert.assertEquals(mostRecentEmail.getSubject(), emailSubject, "not the right email");
        Assert.assertEquals(mostRecentEmail.getRecipients()[0], email2, "not sent to the right email address");
        Assert.assertTrue(mostRecentEmail.getBody().contains(notename), "does not have the report name in the body");
        Assert.assertTrue(mostRecentEmail.getBody().contains(PropertyReader.instance().getProperty("event")), "does not have the event name in the email");
        Assert.assertTrue(mostRecentEmail.hasAttachment(), "did not attach the report");
        String savedFile = mostRecentEmail.getAttachments().get(0);
        final List<Map<String, String>> fileContent = new OpenFile(savedFile).parseXLSX();
        Assert.assertTrue(fileContent.size() > 10, "there are less than 10 rows in the attached report file");
        Assert.assertTrue(fileContent.get(0).size() > 10, "there are less than 10 columns in the attached report file");

        searchPage.deleteNotification(reportNotificationId);

        searchPage.search("");
        lastRow = searchPage.getLastRow();
        Assert.assertNotEquals(lastRow.get("emails"), email2, "did not delete the last row");
        reportNotificationId = null;
    }
}
