package admin.Analysis.HistoryTracking;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.content.NewSessionRoomPage;
import apps.admin.adminPageObjects.content.RoomsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionRoomsHistoryTracking
{
  private DataGenerator generator;
  private ReportingPage reportingPage;
  private AdminApp adminApp;
  private String roomId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
    generator = new DataGenerator();

    adminApp = new AdminApp();
    reportingPage = ReportingPage.getPage();
  }

  @AfterClass
  public void closeBrowser () {
    adminApp.deleteSessionRoom(roomId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21907", firefoxIssue = "RA-29075")
  public void verifyingSessionRoomsHistoryTracking () {
    NewSessionRoomPage newRoomPage = NewSessionRoomPage.getPage();

    newRoomPage.navigate();
    int capacity = generator.generateNumber(1000);
    String roomName = generator.generateName();
    String newRoomName = generator.generateName();

    newRoomPage.setRoomSingleCapacity(capacity);
    newRoomPage.setRoomName(roomName);
    newRoomPage.clickSubmitButton();

    RoomsSearchPage roomsSearchPage = RoomsSearchPage.getPage();
    roomsSearchPage.searchFor(roomName);
    roomId = roomsSearchPage.getTopResultId();
    roomsSearchPage.editItem();
    newRoomPage.setRoomName(newRoomName);
    newRoomPage.clickSubmitButton();

    reportingPage.navigateTo();
    reportingPage.clickOnReport("History Tracking: Session Rooms");
    if (reportingPage.isPaginated()) {
      reportingPage.selectLastPage();
    }
    PageConfiguration.getPage().justWait();
    String reportProperty = reportingPage.getCellValueFromNthFromBottomRow(0, 7);
    String reportOldValue = reportingPage.getCellValueFromNthFromBottomRow(0, 8);
    String reportNewValue = reportingPage.getCellValueFromNthFromBottomRow(0, 9);
    String reportSubmitterName = reportingPage.getCellValueFromNthFromBottomRow(0, 10);

    Assert.assertEquals(reportProperty, "name");
    Assert.assertEquals(reportOldValue, roomName);
    Assert.assertEquals(reportNewValue, newRoomName);
    Assert.assertEquals(reportSubmitterName, "TROGDOR automation");
  }
}
