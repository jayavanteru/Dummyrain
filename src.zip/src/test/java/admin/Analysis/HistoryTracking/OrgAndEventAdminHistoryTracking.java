package admin.Analysis.HistoryTracking;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class OrgAndEventAdminHistoryTracking {
  private UsersPage usersPage;
  private EditUserPage editUserPage;
  private ReportingPage reportingPage;

  @BeforeClass
  public void startApp () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
    usersPage = UsersPage.getPage();
    editUserPage = EditUserPage.getPage();
    reportingPage = ReportingPage.getPage();
  }

  @AfterClass
  public void teardown () {
    PageConfiguration.getPage().quit();
  }

  @DataProvider(name = "user history tracking data")
  public Object[][] userHistoryTrackingData () {
    return new Object[][]{
            {
                    "Test - Report Builder",
                    "History Tracking: Event Admin",
            },
            {
                    "1546970872799001am8c",
                    "History Tracking: Org Admin",
            },
    };
  }

  @Test(dataProvider = "user history tracking data", groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-21912", chromeIssue = "RA-28959")
  public void testEventAdminUserHistoryTracking (String roleId, String reportName) {

    String org = "RainFocus";
    String event = "Manual Regression ONLY - Trogdor";
    String expectedReportProperty = "Security Role";
    String roleName = "Test - Report Builder";
    String submitterName = "TROGDOR automation";
    String email = "trogdortest+org@rainfocus.com";

    boolean roleIsSelected;

    usersPage.navigate();
    OrgEventData.getPage().setOrgAndEvent(org, event);
    usersPage.selectUserByEmail(email);

    editUserPage.toggleSecurityRole(roleName);
    roleIsSelected = editUserPage.securityRoleIsSelected(roleName);


    editUserPage.submit();
    reportingPage.navigateTo();
    reportingPage.resetSearch();
    reportingPage.clickOnReport(reportName);

    if (reportingPage.isPaginated()) {
      reportingPage.selectLastPage();
    }
    PageConfiguration.getPage().justWait();
    String reportProperty = reportingPage.getCellValueFromNthFromBottomRow(0, 3);
    String reportOldValue = reportingPage.getCellValueFromNthFromBottomRow(0, 4);
    String reportNewValue = reportingPage.getCellValueFromNthFromBottomRow(0, 5);
    String reportSubmitterName = reportingPage.getCellValueFromNthFromBottomRow(0, 6);
    String expectedOldValue = roleIsSelected ? "" : roleId;
    String expectedNewValue = roleIsSelected ? roleId : "";

    Assert.assertEquals(reportProperty, expectedReportProperty);
    Assert.assertEquals(reportOldValue, expectedOldValue);
    Assert.assertEquals(reportNewValue, expectedNewValue);
    Assert.assertEquals(reportSubmitterName, submitterName);
  }
}
