package admin.Analysis.HistoryTracking;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.content.LengthsSearchPage;
import apps.admin.adminPageObjects.content.NewLengthPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionLengthsHistoryTracking
{
  private DataGenerator generator;
  private ReportingPage reportingPage;
  private AdminApp adminApp;
  private int sessionLengthId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
    generator = new DataGenerator();

    adminApp = new AdminApp();
    reportingPage = ReportingPage.getPage();
  }

  @AfterClass
  public void closeBrowser () {
    adminApp.deleteSessionLength(sessionLengthId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21909", firefoxIssue = "RA-29074")
  public void verifyingSessionLengthsHistoryTracking () {
    NewLengthPage newLengthPage = NewLengthPage.getPage();

    newLengthPage.navigate();
    sessionLengthId = generator.generateNumber(600);
    String lengthDisplayValue = generator.generateName();
    String newLengthDisplayValue = generator.generateName();
    newLengthPage.setLength(Integer.toString(sessionLengthId));
    newLengthPage.setDisplayValue(lengthDisplayValue);
    newLengthPage.clickSubmitButton();

    LengthsSearchPage lengthsSearchPage = LengthsSearchPage.getPage();

    lengthsSearchPage.navigate();
    lengthsSearchPage.searchFor(Integer.toString(sessionLengthId));
    lengthsSearchPage.editItem();
    newLengthPage.setDisplayValue(newLengthDisplayValue);
    newLengthPage.clickSubmitButton();

    reportingPage.navigateTo();
    reportingPage.clickOnReport("History Tracking: Session Lengths");
    if (reportingPage.isPaginated()) {
      reportingPage.selectLastPage();
    }
    PageConfiguration.getPage().justWait();
    String reportProperty = reportingPage.getCellValueFromNthFromBottomRow(0, 5);
    String reportOldValue = reportingPage.getCellValueFromNthFromBottomRow(0, 6);
    String reportNewValue = reportingPage.getCellValueFromNthFromBottomRow(0, 7);
    String reportSubmitterName = reportingPage.getCellValueFromNthFromBottomRow(0, 8);

    Assert.assertEquals(reportProperty, "displayValue");
    Assert.assertEquals(reportOldValue, lengthDisplayValue);
    Assert.assertEquals(reportNewValue, newLengthDisplayValue);
    Assert.assertEquals(reportSubmitterName, "TROGDOR automation");
  }
}
