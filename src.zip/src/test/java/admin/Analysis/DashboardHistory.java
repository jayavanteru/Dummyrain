package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.AdminDashBulderPage;
import apps.admin.adminPageObjects.analysis.DashboardsListPage;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class DashboardHistory {


    private final String NEW_DASHBOARD_NAME =  "automation" + new DataGenerator().generateString(5);
    private final DashboardsListPage listPage = DashboardsListPage.getPage();
    private final AdminDashBulderPage builderPage = AdminDashBulderPage.getPage();
    private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();


    @BeforeClass
    public void login() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        listPage.searchForDashboard(NEW_DASHBOARD_NAME)
                .hoverOverRowActionsTrigger()
                .deleteDashboard()
                .confirmToDeleteDashboard();

        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-34548", chromeIssue = "RA-43633")
    public void DashboardHistory(){

        listPage.navigateToDashboardsListPage().assertDashboardListUrl();
        listPage.navigateToDashboardBuilder();
        builderPage.assertDashboardBuilderUrl();
        String attendeereport = "Attendee - DO NOT DELETE";
        String attendeeCountReport = "Attendee Count - DO NOT DELETE";

        // add tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeereport)
                .assertTilesExistOnDashboard(1);

        // modify report settings
        builderPage.openActionsMenu()
                .openSettingsSlideOut()
                .enterDashboardName(NEW_DASHBOARD_NAME)
                .selectCategory()
                .applyEditSettings()
                .assertDashboardLabel0Text(NEW_DASHBOARD_NAME)
                .assertSaveButtonText("Save")
                .saveDashboard();

        // Put in sleep to allow time for screen to be refreshed after save
        Utils.sleep(3000);

        // add second tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeeCountReport)
                .assertTilesExistOnDashboard(2);

        // Undo second report
        builderPage.undo()
                .assertTilesExistOnDashboard(1);

        // Redo second report
        builderPage.redo()
                .assertTilesExistOnDashboard(2);

        // save report
        builderPage.saveDashboard()
               .assertSaveButtonText("Save");

       // Check History
        builderPage.viewHistory();
        Assert.assertTrue(reportBuilderPage.isHistoryShowing(),"History not showing");

        // Restore History
        builderPage.clickRestoreHistory()
                .saveDashboard()
                .assertSaveButtonText("Save");


        // Check History 2nd Time
        builderPage.viewHistory();
        Assert.assertTrue(reportBuilderPage.isHistoryShowing(),"History not showing");
        builderPage.cancelHistory();

        // Return to dashboard list
        listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();
    }

}
