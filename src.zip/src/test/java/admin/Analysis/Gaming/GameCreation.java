package admin.Analysis.Gaming;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.GameBuilderPage;
import apps.admin.adminPageObjects.analysis.GamesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class GameCreation {

    private final String NameOfGame = "automation" + new DataGenerator().generateString(5);
    private final String PlayerQualifier = "Attendee Type";
    private final String QualifierAttribute = "Attendee";
    private final String PlayerDisqualifier = "Attendee Type";
    private final String DisqualifierAttribute = "Vendor";
    private final String PlayerNameDisplay = "Text";
    private final String PlayeNameAttribute = "Nickname";
    private final String LeaderboardOptOut = "Attendee Type";
    private final String OptOutAttribute = "Speaker";


    private final GamesPage gamePage = GamesPage.getPage();
    private final GameBuilderPage gameBuilderPage = GameBuilderPage.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-43485", chromeIssue = "RA-44514")
    public void gamification(){

        gamePage.navigateToGames();
        gamePage.addGame();
        gameBuilderPage.gameName(NameOfGame);
        gameBuilderPage.gameQualifier(PlayerQualifier);
        gameBuilderPage.gameQualifierAttribute(QualifierAttribute);
        gameBuilderPage.gameDisqualifier(PlayerDisqualifier);
        gameBuilderPage.gameDisqualifierAttribute(DisqualifierAttribute);
        gameBuilderPage.displayPlayersName(PlayerNameDisplay);
        gameBuilderPage.playerNameAttribute(PlayeNameAttribute);
        gameBuilderPage.leaderboardOptOut(LeaderboardOptOut);
        gameBuilderPage.optOutAttribute(OptOutAttribute);
        gameBuilderPage.createGame();
        gameBuilderPage.activateGame();
        Assert.assertTrue(gameBuilderPage.isActivationShowing(),"Activation is not showing");
        gameBuilderPage.exitGameBuilder();
        gamePage.searchForGame(NameOfGame);
        gamePage.deleteGame();


    }
}
