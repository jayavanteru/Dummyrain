package admin.Analysis.Gaming;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.GameBuilderPage;
import apps.admin.adminPageObjects.analysis.GamesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class GameAchievements {

    private final String NameOfGame = "automation" + new DataGenerator().generateString(5);
    private final String AchievementName = "automation" + new DataGenerator().generateString(4);
    private final String PlayerMust = ("Attend a session");
    private final String Qualifer = ("Any Session");
    private final String Qualifer2 = ("Session Attribute");
    private final String Qualifier3 = ("Specific session(s)");
    private final String SessionAttribute = ("Session track");
    private final String AttributeValue = ("Data integration");
    private final String RewardTimes = ("2");
    private final String Session = ("Data is King");
    private final String DateConstraint = ("Ending on");
    private final String DateConstraint2 = ("Between");
    private final String DateConstraint3 = ("none");
    private final String FirstDate = ("2021-10-15");
    private final String SecondDate = ("2021-10-31");
    private final String Points = ("10");
    private final String TrophyName = ("Trophy Name");
    private final String TrophyDescription = ("Trophy Description");


    private final GamesPage gamePage = GamesPage.getPage();
    private final GameBuilderPage gameBuilderPage = GameBuilderPage.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        gamePage.searchForGame(NameOfGame);
        gamePage.deleteGame();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-43505", chromeIssue = "RA-45153")
    public void GameAchievement(){

        gamePage.navigateToGames();
        gamePage.addGame();
        gameBuilderPage.gameName(NameOfGame);
        gameBuilderPage.createGame();
        Assert.assertTrue(gameBuilderPage.isRequiredWarningDisplayed(),"Required fields are not being enforced");
        gameBuilderPage.cancelAchievement();

        //Create an Achievement rule
        gameBuilderPage.createAchievementAnySession(AchievementName, PlayerMust);
        Utils.sleep(1000);

        //Edit achievement to change qualifier type from Any Session to Session Attribute
        gameBuilderPage.editAchievement();
        Assert.assertTrue(gameBuilderPage.isQualifierTypeAnySession(),"Qualifier Type is not set to Any Session");
        gameBuilderPage.createAchievementSessionAttribute(PlayerMust, Qualifer2, SessionAttribute, AttributeValue, RewardTimes);
        Utils.sleep(1000);

        //Edit achievement again to change qualifier type from Session Attribute to Specific Sessions
        gameBuilderPage.editAchievement();
        Assert.assertTrue(gameBuilderPage.isQualifierTypeSessionAttribute(),"Qualifier Type is not set to Session Attribute");
        gameBuilderPage.createAchievementSpecificSession(PlayerMust, Qualifier3, Session, RewardTimes);

        //Edit achievement to verify that qualifier type has been set to Specific Sessions
        gameBuilderPage.editAchievement();
        Assert.assertTrue(gameBuilderPage.isQualifierTypeSpecificSessions(),"Qualifier Type is not set to Specific session");

        //Set Date Constraint to EndOn
        gameBuilderPage.achievementDateConstraintEndOn(DateConstraint, FirstDate);

        //Set Date constraint to Between
        gameBuilderPage.editAchievement();
        Assert.assertTrue(gameBuilderPage.isDateConstraintEndingOn(),"The Date Constraint is not set to Ending On");
        gameBuilderPage.achievementDateConstraintBetween(DateConstraint2, FirstDate, SecondDate);

        //Set Points and Trophy on Achievement
        gameBuilderPage.editAchievement();
        gameBuilderPage.achievementAddPoints(Points);
        gameBuilderPage.achievementAddTrophy(TrophyName, TrophyDescription);
        gameBuilderPage.uploadPhoto1();
        Utils.sleep(3000);
        gameBuilderPage.uploadPhoto2();
        Utils.sleep(3000);
        gameBuilderPage.saveAchievement();
        gameBuilderPage.editAchievement();
        Assert.assertTrue(gameBuilderPage.isPhoto1Uploaded(),"Photo 1 is missing");
        gameBuilderPage.deletePhoto1();
        Assert.assertTrue(gameBuilderPage.hasPhoto1BeenDeleted(),"Photo 1 has not been deleted");
        Utils.sleep(3000);
        gameBuilderPage.cancelAchievement();
        gameBuilderPage.editAchievement();
        gameBuilderPage.removeReward(DateConstraint3);

        //Copy and Delete achievement
        gameBuilderPage.copyAchievement();
        Assert.assertEquals(gameBuilderPage.getAchievementListCount(),2, "Count is off");
        Utils.sleep(3000);
        gameBuilderPage.deleteAchievement();
        Utils.waitForTrue(()->gameBuilderPage.getAchievementListCount()==1);
        Assert.assertEquals(gameBuilderPage.getAchievementListCount(),1,"Count is not Correct");

        gameBuilderPage.exitGameBuilder();


    }
}
