package admin.Analysis.Gaming;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.GameBuilderPage;
import apps.admin.adminPageObjects.analysis.GamesPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import apps.admin.adminPageObjects.analysis.reporting.ReportViewerPage;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import logs.ReportingInfo;
import org.checkerframework.checker.units.qual.A;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.List;
import java.util.Map;

public class GameScoring {

    private final String SessionID = "1503068408350001UE7h";
    private final String AttendeeID = "14879755386940018cQc";
    private final String AttendeeEmail = "brian.pulham@rainfocus.com";
    private final String NameOfGame = "automation" + new DataGenerator().generateString(5);
    private final String AchievementName = "Game Scoring Test";
    private final String PlayerMust = "Attend a session";
    private final String Qualifer = "Specific session(s)";
    private final String Session = "Data is King";
    private final String RewardTimes = "2";
    private final String Points = "100";
    private final String EndDate = "2025-12-30";
    private final String ReportName = "Game Leaderboard";
    private final String ReportColumn = "Game";

    private AdminSchedulingTab scheduleSession = AdminSchedulingTab.getPage();
    private final GamesPage gamePage = GamesPage.getPage();
    private final GameBuilderPage gameBuilderPage = GameBuilderPage.getPage();
    private final ReportsListPage reportList = ReportsListPage.getPage();
    private final ReportViewerPage reportViewer = ReportViewerPage.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        gamePage.navigateToGames();
        gamePage.searchForGame(NameOfGame);
        gamePage.deleteGame();
        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-44283", chromeIssue = "RA-45564")
    public void GameScoring(){

        // Adding attendee on Attended List
        scheduleSession.navigate(SessionID);
        scheduleSession.clickAttendedResultsLink();
        scheduleSession.clickAddAttendeeOnModal();
        scheduleSession.clickSelectAttendeeDropdown();
        scheduleSession.selectAttendeeByEmail(AttendeeID, AttendeeEmail);
        scheduleSession.clickEnrollButtonOnModal();
        scheduleSession.clickCloseButtonOnModal();

        //Create Game
        gamePage.navigateToGames();
        gamePage.addGame();
        gameBuilderPage.gameName(NameOfGame);
        gameBuilderPage.createGame();
        gameBuilderPage.addNewAchievement(AchievementName);
        gameBuilderPage.createAchievementSpecificSession(PlayerMust, Qualifer, Session, RewardTimes);
        gameBuilderPage.editAchievement();
        gameBuilderPage.achievementAddPoints(Points);
        gameBuilderPage.saveAchievement();
        gameBuilderPage.activateGame();
        gameBuilderPage.SetDeactivateDate(EndDate);
        gameBuilderPage.saveGame();
        gameBuilderPage.confirmGameSave();

        //View Game Leaderboard report to verify points were added
        reportList.navigateToReportList();
        reportList.goToCoreDirectory();
        reportList.search(ReportName);
        reportList.openReport(ReportName);
        reportViewer.openColumnSortingModal(ReportColumn);
        reportViewer.columnFilterDeselectAll();
        reportViewer.setColumnFilterText(NameOfGame);
        reportViewer.columnFilterClickCheckbox(NameOfGame);
        reportViewer.applyColumnFilter();
        List<Map<String, String>> tableData = reportViewer.getTableData();
        Map<String, String> Row=tableData.stream().filter(m->m.get("EMAIL").equals(AttendeeEmail)).findFirst().orElse(null);
        Assert.assertNotNull(Row, "The added user is not showing in the report");
        Assert.assertEquals(Row.get("# OF POINTS"),Points, "The number of points awarded are not correct");

        // Removing attendee on Attended List
        scheduleSession.navigate(SessionID);
        scheduleSession.clickAttendedResultsLink();
        scheduleSession.attendedModalSearch(AttendeeEmail);
        scheduleSession.removeAttendeeFromTableOnModal();
        scheduleSession.clickCloseButtonOnModal();

        //View Game Leaderboard report to verify points were removed
        reportList.navigateToReportList();
        reportList.openReport(ReportName);
        reportViewer.openColumnSortingModal(ReportColumn);
        reportViewer.columnFilterDeselectAll();
        reportViewer.setColumnFilterText(NameOfGame);
        reportViewer.columnFilterClickCheckbox(NameOfGame);
        reportViewer.applyColumnFilter();
        tableData = reportViewer.getTableData();
        Row=tableData.stream().filter(m->m.get("EMAIL").equals(AttendeeEmail)).findFirst().orElse(null);
        Assert.assertNull(Row, "The added user is showing in the report, but it shouldn't be");


    }
}
