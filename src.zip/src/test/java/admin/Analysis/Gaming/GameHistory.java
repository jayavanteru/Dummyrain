package admin.Analysis.Gaming;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.GameBuilderPage;
import apps.admin.adminPageObjects.analysis.GamesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class GameHistory {
    private final String NameOfGame = "automation" + new DataGenerator().generateString(5);
    private final String NameOfGame2 = "automation" + new DataGenerator().generateString(5);
    private final String PlayerQualifier = "Attendee Type";
    private final String QualifierAttribute = "Attendee";
    private final String PlayerDisqualifier = "Attendee Type";
    private final String DisqualifierAttribute = "Vendor";
    private final String PlayerQualifier2 = "Attendee Type";
    private final String QualifierAttribute2 = "Exhibitor";
    private final String PlayerDisqualifier2 = "Attendee Type";
    private final String DisqualifierAttribute2 = "Speaker";

    private final String AchievementName = "automation" + new DataGenerator().generateString(4);
    private final String AchievementName2 = "automation" + new DataGenerator().generateString(4);
    private final String PlayerMust = ("Attend a session");
    private final String Qualifer2 = ("Session Attribute");
    private final String SessionAttribute = ("Session track");
    private final String AchievementName3 = "automation" + new DataGenerator().generateString(4);
    private final String Qualifier3 = ("Specific session(s)");
    private final String AttributeValue = ("NoSQL databases");
    private final String RewardTimes = ("2");
    private final String Session = ("Data is King");
    private final String Points = ("10");
    private final String TrophyName = ("Trophy Name");
    private final String TrophyDescription = ("Trophy Description");
    private final String DisplayOrder1 = ("1");
    private final String DisplayOrder2 = ("2");
    private final String NewValue = ("3");
    private final String EndDate = ("2021-11-30");


    private final GamesPage gamePage = GamesPage.getPage();
    private final GameBuilderPage gameBuilderPage = GameBuilderPage.getPage();
    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass

    public void endTest() {
        gamePage.searchForGame(NameOfGame2);
        gamePage.deleteGame();
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-46450", chromeIssue = "RA-46815")
    public void GameHistory(){

        gamePage.navigateToGames();
        gamePage.addGame();
        gameBuilderPage.gameName(NameOfGame);
        gameBuilderPage.gameQualifier(PlayerQualifier);
        gameBuilderPage.gameQualifierAttribute(QualifierAttribute);
        gameBuilderPage.gameDisqualifier(PlayerDisqualifier);
        gameBuilderPage.gameDisqualifierAttribute(DisqualifierAttribute);
        gameBuilderPage.createGame();

        //Create an Achievement rule
        gameBuilderPage.createAchievementAnySession(AchievementName, PlayerMust);
        Utils.sleep(1000);
        gameBuilderPage.editAchievement();
        gameBuilderPage.achievementAddPoints(Points);
        gameBuilderPage.addTrophySetDisplayOrder(TrophyName, TrophyDescription, DisplayOrder1);
        gameBuilderPage.uploadPhoto1();
        Utils.sleep(6000);
        gameBuilderPage.saveAchievement();
        Utils.sleep(3000);

        //Set Deactivate Date
        gameBuilderPage.SetDeactivateDate(EndDate);

        //Rename Game
        gameBuilderPage.goToGameSetup();
        gameBuilderPage.gameName(NameOfGame2);
        gameBuilderPage.resetQualifier();
        gameBuilderPage.resetQualifier();
        gameBuilderPage.gameQualifier(PlayerQualifier2);
        gameBuilderPage.gameQualifierAttribute(QualifierAttribute2);
        gameBuilderPage.gameDisqualifier(PlayerDisqualifier2);
        gameBuilderPage.gameDisqualifierAttribute(DisqualifierAttribute2);
        gameBuilderPage.saveGame();

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        //Add 2nd and 3rd Achievement
        gameBuilderPage.addNewAchievement(AchievementName2);
        gameBuilderPage.createAchievementSessionAttribute(PlayerMust,Qualifer2,SessionAttribute, AttributeValue, RewardTimes);
        gameBuilderPage.editSpecificAchievement(AchievementName2);
        gameBuilderPage.achievementAddPoints(Points);
        gameBuilderPage.addTrophySetDisplayOrder(TrophyName, TrophyDescription, DisplayOrder2);
        gameBuilderPage.uploadPhoto1();
        Utils.sleep(6000);
        gameBuilderPage.saveAchievement();
        gameBuilderPage.addNewAchievement(AchievementName3);
        gameBuilderPage.createAchievementSpecificSession(PlayerMust, Qualifier3,Session, RewardTimes);

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        //Edit achievement and remove trophy
        gameBuilderPage.editSpecificAchievement(AchievementName);
        gameBuilderPage.removeTrophy();
        gameBuilderPage.saveAchievement();
        Assert.assertFalse(gameBuilderPage.doesTrophyOrderHaveAValue(), "The trophy still has a value");

        //Delete achievement
        gameBuilderPage.deleteAchievement();
        Utils.waitForTrue(()->gameBuilderPage.getAchievementListCount()==2);
        Assert.assertEquals(gameBuilderPage.getAchievementListCount(),2,"Count is not Correct");

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        //Activate the Game
        gameBuilderPage.activateGame();
        gameBuilderPage.saveGame();
        gameBuilderPage.confirmGameSave();

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        //Edit Achievement SQL
        gameBuilderPage.editAchievement();
        Utils.sleep(3000);
        gameBuilderPage.editAchievementAdvanced();
        gameBuilderPage.editGameSQL(NewValue);

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        //Edit Achievement Generate SQL
        gameBuilderPage.editAchievement();
        gameBuilderPage.generateAchievementSQL();

        //Check history
        gameBuilderPage.gameHistory();
        Assert.assertTrue(gameBuilderPage.isHistoryRowVisible(), "History row is not visible");
        gameBuilderPage.cancelGameHistory();

        gameBuilderPage.exitGameBuilder();
    }
}
