package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.AdminDashBulderPage;
import apps.admin.adminPageObjects.analysis.DashboardsListPage;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;


public class AdminDashBuilder {

    private DataGenerator generator = new DataGenerator();

    private final String CUSTOM_TILE_HEADING = "CUSTOM TILE HEADING";
    private final String CUSTOM_TILE_HEADING_2 = "CUSTOM TILE HEADING 2";
    private final String ATTENDEE_COUNT_REPORT_ID = "1571338074174002TZzQ";
    private final String NEW_DASHBOARD_NAME = generator.generateName();
    private final String RENAME_DASHBOARD = generator.generateName();

    private final DashboardsListPage listPage = DashboardsListPage.getPage();
    private final AdminDashBulderPage builderPage = AdminDashBulderPage.getPage();

    @BeforeClass
    public void login() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }


    /**
     * RA-21248: Analysis > Dashboards | Tests for Dashboards
     */

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-26989", chromeIssue = "RA-21248")
    public void test_createDashboardAndDelete() {

        String attendeeCountReport = "Attendee Count - DO NOT DELETE";

        listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();

        listPage.navigateToDashboardBuilder();

        builderPage.assertDashboardBuilderUrl();

        // add tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeeCountReport)
                .assertTilesExistOnDashboard(1);

        // modify report settings
        builderPage.openActionsMenu()
                .openSettingsSlideOut()
                .enterDashboardName(NEW_DASHBOARD_NAME)
                .selectCategory()
                .applyEditSettings()
                .assertDashboardLabel0Text(NEW_DASHBOARD_NAME)
                .assertSaveButtonText("Save");

        // test unsaved changes
        builderPage.goBackToDashboardsList()
                .cancelUnsavedChanges();

        // save report
        builderPage.saveDashboard()
                .assertSaveButtonText("Save");

        builderPage.goBackToDashboardsList();

        listPage.searchForDashboard(NEW_DASHBOARD_NAME)
                .selectDashboard();

        builderPage.assertDashboardBuilderUrlHasId();

        builderPage.goBackToDashboardsList();
        PageConfiguration.getPage().refreshPage();

        // rename a dashboard and delete a dashboard
        listPage.searchForDashboard(NEW_DASHBOARD_NAME)
                .hoverOverRowActionsTrigger()
                .renameDashboard(RENAME_DASHBOARD)
                .searchForDashboard(RENAME_DASHBOARD)
                .hoverOverRowActionsTrigger()
                .deleteDashboard()
                .confirmToDeleteDashboard();

        // successfully deleted
        listPage.searchForDashboard(NEW_DASHBOARD_NAME);
        Assert.assertEquals(listPage.getResultCount(), 0);

    }


    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-27134", chromeIssue = "RA-27135")
    public void test_editDashboardTile() {

        String attendeeCountReport = "Attendee Count - DO NOT DELETE";

        listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();

        listPage.navigateToDashboardBuilder();

        builderPage.assertDashboardBuilderUrl();

        // add tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeeCountReport)
                .assertTilesExistOnDashboard(1);

        // modify report settings
        builderPage.openActionsMenu()
                .openSettingsSlideOut()
                .enterDashboardName(NEW_DASHBOARD_NAME)
                .selectCategory()
                .applyEditSettings()
                .assertDashboardLabel0Text(NEW_DASHBOARD_NAME)
                .assertSaveButtonText("Save");

        // check json editor
        builderPage.openActionsMenu()
                .openJsonSlideOut()
                .changeDashboardNameInJson(CUSTOM_TILE_HEADING_2)
                .applyEditJson()
                .assertTileHeaderTitle(CUSTOM_TILE_HEADING_2);
    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-27136", chromeIssue = "RA-27137")
    public void test_addTilesToDashboard() {

        String attendeeCountReport = "Attendee Count - DO NOT DELETE";
        String attendeereport = "Attendee - DO NOT DELETE";

        listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();

        listPage.navigateToDashboardBuilder();

        builderPage.assertDashboardBuilderUrl();

        // add first tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeeCountReport)
                .assertTilesExistOnDashboard(1);

        // add second tile
        builderPage.expandMenu()
                .openReportSelectorModal()
                .selectReportNew(attendeereport)
                .assertTilesExistOnDashboard(2);

        // undo / redo
        builderPage.undo()
                .assertTilesExistOnDashboard(1)
                .redo()
                .assertTilesExistOnDashboard(2);

        builderPage.dragTile(1);

        // delete a tile
        builderPage.deleteTile()
                .assertTilesExistOnDashboard(1);
    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-30613", chromeIssue = "RA-32441")
    public void test_filterTile() {

        String attendeeReport = "Attendee - DO NOT DELETE";

        listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();

        listPage.navigateToDashboardBuilder();

        builderPage.assertDashboardBuilderUrl();

        // add filter to new dash should be disabled
        builderPage.expandMenu()
                .assertAddNewFilterTileIsDisabled();

        // add a tile to the dashboard
        builderPage
                .openReportSelectorModal()
                .selectReportNew(attendeeReport)
                .assertTilesExistOnDashboard(1);

        int initialTotalRowCount = builderPage.getTotalRowCount();

        // create the filter tile
        builderPage
                .expandMenu()
                .openDashboardFilterSelectorSlideOut()
                .selectAllTilesForFilter()
                .selectFiltersTab()
                .searchForFilterColumn("first name")
                .toggleAttendeeFirstNameColumn()
                .assertSelectedFilterCount(1)
                .searchForFilterColumn("attendee type")
                .toggleAttendeeTypeColumn() //select
                .assertSelectedFilterCount(2)
                .toggleAttendeeTypeColumn() //un-select
                .assertSelectedFilterCount(1)
                .applyFilterEditSettings()
                .assertTilesExistOnDashboard(2);

        // add filter to new dash should be disabled
        builderPage.expandMenu()
                .assertAddNewFilterTileIsDisabled();

        // apply a filter
        builderPage
                .setFirstNameFilter("mike")
                .clickOnApplyFilterButton()
                .assertFilterIconIsVisible();

        int filteredTotalRowCount = builderPage.getTotalRowCount();

        Assert.assertTrue(filteredTotalRowCount < initialTotalRowCount, "Filtered result count is less than the initial total row count.");

        // clear filter
        builderPage
                .clickOnClearAllFiltersButton()
                .assertFilterIconIsHidden();

        int totalRowCount = builderPage.getTotalRowCount();

        Assert.assertTrue(totalRowCount == initialTotalRowCount, "Total row count should be the initial total row count after filter cleared.");

    }

    @Test(groups = ReportingInfo.DATATRON)
    @ReportingInfo(firefoxIssue = "RA-30627", chromeIssue = "RA-33077")
    public void test_editTile() {

        String attendeeReport = "Attendee - DO NOT DELETE";

      listPage.navigateToDashboardsListPage()
                .assertDashboardListUrl();

      listPage.navigateToDashboardBuilder();

      builderPage.assertDashboardBuilderUrl();

      builderPage
              .expandMenu()
              .createReportInNewTab();

      PageConfiguration.getPage().switchToTab(1);

      PageConfiguration.getPage().close();

      PageConfiguration.getPage().switchToTab(0);

      builderPage.expandMenu()
              .openReportSelectorModal()
              .selectReportNew(attendeeReport)
              .assertTilesExistOnDashboard(1);

      builderPage
              .resizeTile()
              .dragTile(0);

      builderPage
              .editTile()
              .openChangeReportModal()
              .selectAttendeeCountReport();

      builderPage.editReportInANewTab();

      // necessary so that the assertion below grabs the correct url
      PageConfiguration.getPage().switchToTab(1);

      ReportBuilderPage.getPage().assertReportBuilderUrl(ATTENDEE_COUNT_REPORT_ID);

      PageConfiguration.getPage().switchToTab(0);

      builderPage
              .refreshReport()
              .assertSpinnerVisible();

      builderPage.enterTileHeading(CUSTOM_TILE_HEADING)
              .assertPreviewTileHeaderTitle(CUSTOM_TILE_HEADING);

      builderPage
              .cancelEditTile();

    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }
}

