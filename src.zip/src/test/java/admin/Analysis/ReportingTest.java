package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.openqa.selenium.WebElement;
import org.testng.annotations.*;
import testHelp.Utils;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.testng.Assert.*;

public class ReportingTest
{
  private final String ATTENDEE_TEMPLATE = "15381699461510010SC8";
  private final String ATTENDEE_ORDERS_TEMPLATE = "1537547384455001tlWH";
  private final String TEST_STRING_1 = "x1xx1xx1xx1xx1xx1xx1xx1x";
  private final int NUMBER_OF_DEFAULT_FILTERS = 2;


  private final String CUSTOM_EXPRESSION_ERR1 = "Expression must use \"and\" or \"or\" at least once";
  private final String CUSTOM_EXPRESSION_ERR2 = "Invalid filter identifier: 5";
  private final String CUSTOM_EXPRESSION_ERR3 = "Invalid filter identifier: 4";
  private final String CUSTOM_EXPRESSION_ERR4 = "Expressions must include all filters, missing 3, 4";


  private final ReportsListPage reportsListPage = ReportsListPage.getPage();
  private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();

  @BeforeClass
  public void login()
  {
    PropertyReader.instance().setProperty("enableDesktopAutomation", true);
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    // Go to Analysis > Reporting
    Utils.sleep(200, "extra time for chrome");
    reportsListPage.navigateToReportList();
  }

  @BeforeMethod
  public void goToReportsList()
  {
    reportsListPage.waitForPageLoad(5);
    // Expected Result: reportsList.do loads
    reportsListPage.assertReportListUrl();
    reportsListPage.waitForReportsList();
  }

  /**
   * RA-18984: Analysis > Reporting | Create a Report Builder report
   */
  private void selectTemplate(final String reportId)
  {
    // Click on the purple '+' button in the bottom right hand corner of the page
    // Expected Result: A modal giving the option to choose a report type pops up. (Report Builder / Visualizations / SQL)
    reportsListPage.openReportTypePickerModal();

    // Click on the 'Report Builder' box
    // Expected Result: A modal to choose a template pops up (Attendee Report / Content Report / Exhibitor Report / Meeting Report)
    reportsListPage.openTemplatePickerModal();

    /*
      Choose any of the available templates (I've used the 'Attendee' template for testing).
      Double click the template name to select it or click on the "Select Template" button
     */
    reportsListPage.selectTemplate(reportId);
    // Expected Result: The template should load in reportBuilder.do
    reportBuilderPage.assertReportBuilderUrl(reportId);
  }

  /**
   * RA-18987: Analysis > Reporting | Sort a Report Builder Report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-18987", chromeIssue = "RA-23879")
  public void testSortAReportBuilderReport()
  {
    // Initialize template and assert default conditions
    selectTemplate(ATTENDEE_TEMPLATE);
    reportBuilderPage.waitForPageLoad();

    // Clear any pre-existing sort criteria
    reportBuilderPage.clearSortCriteria();

    int sortCriterionCount = 0;

    // Assert no pre-existing sort criteria
    reportBuilderPage.assertNumberOfSortingCriteria(sortCriterionCount);

    // Click on the "+ ADD SORTING CRITERIA" button
    reportBuilderPage.addSortingCriterion();
    /*
      Expected Result: A drop down box appears that says 'Select a Column'
     */
    reportBuilderPage.assertNumberOfSortingCriteria(++sortCriterionCount);

    // Click into the drop-down box
    /*
      Expected Result
      -You should see all of the columns that are displayed on the report available to choose from (except for the already sorted column).
      -The column names should be displayed in the same order they appear on the report.
     */
    reportBuilderPage.verifySortColumnOptions();

    // Choose a column to sort by
    reportBuilderPage.chooseColumnForNewSortCriterion("First Name");
    /*
      Expected Result: The report should be sorted first by pre-existing sort criteria, if any, and then in ascending order by the column you selected.
     */
    reportBuilderPage.verifyModifiedSort(1, "First Name", 0, "ascending");

    // Verify sort indicators are active and the # of active sorts is displayed
    /*
      Expected Result
      -Next to the drop down box(es) the icon for ascending should be highlighted.
      -The same highlighted icon should appear in the column name(s) on the report.
      -The # of active sorts indicated at the top of the sorting section is now 2.
     */
    reportBuilderPage.verifySortIndicatorsAndSortCount(sortCriterionCount, 0);

    // Click on the descending sort icon next to the drop down box for the column you added.
    reportBuilderPage.changeToSortDescending(sortCriterionCount - 1);
    /*
      Expected Result
      -The report should be sorted in ascending order based on the original selected column and then in descending order based on the column you added.
      -The icons for ascending and descending should be highlighted respectively for each column.
     */
    reportBuilderPage.verifySortIndicatorsAndSortCount(0, sortCriterionCount);

    // Choose a column on the report that has not been sorted and click on the small arrow in the column name header on the report.
    //  - Choosing "Last Name"
    /*
      Expected Result: A menu of column actions displays
     */
    reportBuilderPage.clickColumnActionsMenu(1);

    // Choose the 'Sort Ascending' or 'Sort Descending' menu option
    /*
      Expected Result
      -The report should now be sorted by ONLY the newly selected column
      -The newly selected column name should be shown in the Sorting area and the previously sorted columns should be removed.
      -Sort icons should appear by the column name on the report and the drop down column name in the "Sorting" area.
      -The # of active sorts indicated at the top of the sorting section is now 1
     */
    reportBuilderPage.sortColumnFromActionsMenu(1, "Last Name", "ascending");
    reportBuilderPage.verifySortIndicatorsAndSortCount(sortCriterionCount, 0);

    // In the "Sorting" area, click on the 'x' next to the remaining 'Sort by' column name
    /*
      Expected Result
      -The sorted column should be removed from the "Sorting" area
      -The report will re-sort to a default
      -There should be no icons indicating a sort is present on any of the column names on the report.
      -The # of active sorts indicated at the top of the sorting section is now 0
     */
    reportBuilderPage.removeSortCriterion(0);
    reportBuilderPage.verifySortIndicatorsAndSortCount(0, 0);

    // Click the ^ in the sorting header
    /*
      Expected Result: The sorting section is collapsed
     */
    reportBuilderPage.collapseSorting();
  }

  /**
   * RA-20768: Automate: Analysis > Reporting | Exiting a Report Builder report
   * - TODO. We could not make the browser close and refresh honor the alerts produced.
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-18991", chromeIssue = "RA-29504")
  public void testReportBuilderUnsavedChanges()
  {

    selectTemplate(ATTENDEE_TEMPLATE);

    reportBuilderPage.removeColumn(0, false);

    reportBuilderPage.navigateBackToReportsList();
    reportBuilderPage.cancelContinueWithoutSaving();
    reportBuilderPage.assertReportBuilderUrl(ATTENDEE_TEMPLATE);

    PageConfiguration.getPage().navigateBack();
    reportBuilderPage.cancelContinueWithoutSaving();
    reportBuilderPage.assertReportBuilderUrl(ATTENDEE_TEMPLATE);

  }

  /**
   * RA-18988:	Analysis > Reporting | Filtering on a Report Builder report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-18988", chromeIssue = "RA-23880")
  public void testFilteringOnAReportBuilderReport()
  {
    selectTemplate(ATTENDEE_TEMPLATE);

    reportBuilderPage.assertReportBuilderUrl(ATTENDEE_TEMPLATE);

    reportBuilderPage.assertNumberOfFilters(NUMBER_OF_DEFAULT_FILTERS);

    // Verify add new filter functionality and insert values
    reportBuilderPage.addFilter();
    reportBuilderPage.assertNumberOfFilters(NUMBER_OF_DEFAULT_FILTERS + 1);

    reportBuilderPage.fillFilterValues(2, "First Name", "contains", "a");
    reportBuilderPage.applyFilter();

    reportBuilderPage.addFilter();
    reportBuilderPage.assertNumberOfFilters(NUMBER_OF_DEFAULT_FILTERS + 2);
    reportBuilderPage.fillFilterValues(3, "Last Name", "contains", "e");
    reportBuilderPage.applyFilter();

    // Verify Custom Expression field
    reportBuilderPage.selectCustomExpressionField();
    reportBuilderPage.verifyFilterNumbersAreDisplayed(NUMBER_OF_DEFAULT_FILTERS + 2);
    reportBuilderPage.enterCustomExpression("1");
    reportBuilderPage.verifyCustomExpressionErrorDisplays(CUSTOM_EXPRESSION_ERR1);

    reportBuilderPage.selectCustomExpressionField();
    reportBuilderPage.enterCustomExpression("2 and (3 or 5)");
    reportBuilderPage.verifyCustomExpressionErrorDisplays(CUSTOM_EXPRESSION_ERR2);

    reportBuilderPage.selectCustomExpressionField();
    reportBuilderPage.enterCustomExpression("1 and (2 or 1)");
    reportBuilderPage.verifyCustomExpressionErrorDisplays(CUSTOM_EXPRESSION_ERR4);

    reportBuilderPage.selectCustomExpressionField();
    reportBuilderPage.enterCustomExpression("1 and 2 and (3 or 4)");

    reportBuilderPage.applyFilter();

    reportBuilderPage.removeFilter(3);
    reportBuilderPage.verifyCustomExpressionErrorDisplays(CUSTOM_EXPRESSION_ERR3);

    reportBuilderPage.selectCustomExpressionField();
    reportBuilderPage.enterCustomExpression("1 and (2 or 3)");

    reportBuilderPage.applyFilter();

    // Verify Clear Filters  and Undo Changes links
    reportBuilderPage.clearFilters();

    reportBuilderPage.assertNumberOfFilters(1);

    reportBuilderPage.undoChanges();
    reportBuilderPage.applyFilter();
    reportBuilderPage.assertNumberOfFilters(NUMBER_OF_DEFAULT_FILTERS);
    Utils.sleep(500);

    // Verify aggregation
    reportBuilderPage.openMenu(0);
    reportBuilderPage.selectAggregation(0, "count distinct");

    reportBuilderPage.addFilter();

    Utils.sleep(1000);
    reportBuilderPage.fillFilterValues(2, "First Name", "equals", "1");
    Utils.sleep(3000);

    reportBuilderPage.applyFilter();

    // Verify column deletion prohibited for column with aggregated filter

    Utils.sleep(1000);

    reportBuilderPage.removeColumn(0, true);
    reportBuilderPage.closeModal();

    Utils.sleep(500); // wait for modal to close as backdrop obscures other elements

    // Verify multi select values
    reportBuilderPage.clearFilters();
    reportBuilderPage.fillMultiSelectFilterValues(0, "Attendee Type", Collections.singletonList("Vendor"));
    reportBuilderPage.verifyMultiSelectedValuePills(Collections.singletonList("1503084567476002s1Ay"));
    reportBuilderPage.applyFilter();
    Utils.sleep(2000);

    reportBuilderPage.collapseFilters();
  }

  /**
   * RA-18989: Analysis > Reporting | Column Actions within a Report Builder report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-18989", chromeIssue = "RA-24060")
  public void testColumnActions_columnPickerModal()
  {
    // Initialize template and assert default conditions
    selectTemplate(ATTENDEE_ORDERS_TEMPLATE);
    reportBuilderPage.waitForPageLoad(10);
    reportBuilderPage.waitForDataLoad(10);

    // Click on the '+ ADD COLUMNS' link in the columns section of the report
    /*
      Expected Result: A new "Add Columns" modal opens
     */
    reportBuilderPage.openAddColumnsModal();
    assertTrue(reportBuilderPage.isAddColumnsModalOpen(), "Expected the columns-picker modal to be open.");

    // Validate "Add Columns" modal
    final int defaultSearchColumnCount = validateDefaultSearchColumnsCount();
    validateAddColumnsModalBlockAccordions();

    // Search for a value (time)
    /*
      Expected Result
      -The number of results is shown under the search field
      -Columns with that value in their name are shown and the block that column is in is expanded. A 'show all' link is also seen in the expanded block.
      -A block name that contains the searched for value, but does not have any column names with the searched for value will also be shown, but will be in a collapsed state.
     */
    final String columnLabel = "time";
    reportBuilderPage.searchForColumnToAdd(columnLabel);
    validateUpdatedSearchColumnsCount(defaultSearchColumnCount, columnLabel);
    validateSearchColumnBlocks(columnLabel);

    // Click the 'show all' link on a block where it is available.
    /*
      Expected Result
      - All of the columns within the block are shown.
      - None of the newly-shown columns will contain the searched-for value
     */
    final String reportBlock = "Attendee";
    validateSearchColumnBlockChildContent(reportBlock, columnLabel);
    reportBuilderPage.toggleShowHideColumnsForBlock(reportBlock);
    assertFalse(reportBuilderPage.additionalContentIsHidden(reportBlock), "Expected the additional content to be hidden for report block \"" + reportBlock + "\".");

    // Click the 'hide' link.
    /*
      Expected Result: The additional columns are hidden again and only columns with the searched for value in their name are shown again.
     */
    reportBuilderPage.toggleShowHideColumnsForBlock(reportBlock);
    assertTrue(reportBuilderPage.additionalContentIsHidden(reportBlock), "Expected the additional content to not be hidden for report block \"" + reportBlock + "\".");

    // Use the '^' symbol to expand and contract the blocks.
    /*
      Expected Result: The blocks are contracted and expanded.
     */
    reportBuilderPage.expandColumnBlocks();
    reportBuilderPage.getSearchColumnBlockAccordionTitleAnchors().forEach(accordion -> assertFalse(reportBuilderPage.accordionIsCollapsed(accordion), "Expected the accordion to not be collapsed."));
    reportBuilderPage.collapseColumnBlocks();
    reportBuilderPage.getSearchColumnBlockAccordionTitleAnchors().forEach(accordion -> assertTrue(reportBuilderPage.accordionIsCollapsed(accordion), "Expected the accordion to be collapsed."));
    reportBuilderPage.expandColumnBlocks();

    // Select some of the available columns.
    /*
      Expected Result
      -The selected columns are checked.
      -The selected columns are added to the right hand side of the modal.
     */
    List<String> columns = Arrays.asList("Checkin Date/Time", "Registered Time");
    reportBuilderPage.selectColumns(columns);
    validateCheckedColumns(columns);
    validateAddColumnsModalColumnPills(columns);

    reportBuilderPage.clearSearchTextBox();

    // Remove a column from the right hand side of the modal by click the small 'x' in the column 'pill'
    /*
      Expected Result
      -The column is removed from the right hand side.
      -The column is unchecked on the left hand side.
     */
    final String columnToRemove = "First Name";
    reportBuilderPage.removeColumnViaColumnsModal(columnToRemove);
    validateAddColumnsModalPillsDoNotContain(columnToRemove);
    validateCheckedColumnsDoNotContain(columnLabel);

    // Click the 'Apply' button.
    /*
      Expected Result: The modal will close and the newly selected columns will be added to the report
     */
    reportBuilderPage.applyColumnsModal();
    assertFalse(reportBuilderPage.isAddColumnsModalOpen(), "Expected the columns-picker modal to not be open.");
    validateColumnPills(Arrays.asList("Last Name", "Job Title", "Email", "Company Name", "Attendee Type", "Registered Date", "Checkin Date/Time", "Registered Time"));
  }

  private int validateDefaultSearchColumnsCount()
  {
    final String searchColumnCountString = reportBuilderPage.getAddColumnsModalSearchColumnsCount();
    assertTrue(StringUtils.contains(searchColumnCountString, " columns"), "Expected the columns-modal columns-count string to contain \" columns\".");

    final String defaultSearchColumnCountAsString = searchColumnCountString.split(" ", 2)[0];
    assertTrue(NumberUtils.isParsable(defaultSearchColumnCountAsString), "Expected the columns-modal columns count to be a parsable number, was \"" + defaultSearchColumnCountAsString + "\".");

    int defaultSearchColumnCount = Integer.parseInt(defaultSearchColumnCountAsString);
    assertTrue(defaultSearchColumnCount > 0, "Expected the columns-modal default-columns count to be > 0, was " + defaultSearchColumnCount + ".");
    return defaultSearchColumnCount;
  }

  private void validateAddColumnsModalBlockAccordions()
  {
    List<WebElement> searchColumnBlockAccordionTitleAnchors = reportBuilderPage.getSearchColumnBlockAccordionTitleAnchors();
    assertTrue(searchColumnBlockAccordionTitleAnchors.stream().allMatch(reportBuilderPage::accordionIsCollapsed), "Expected the columns-modal column-block accordions to all be collapsed.");
  }

  private void validateUpdatedSearchColumnsCount(final int defaultSearchColumnsCount, @Nonnull final String columnLabel)
  {
    final String searchColumnCountString = reportBuilderPage.getAddColumnsModalSearchColumnsCount();
    assertTrue(StringUtils.contains(searchColumnCountString, " column(s) containing \"" + columnLabel + "\""), "Expected the columns-modal columns-count string to contain \" column(s) containing \\\"\" + columnLabel + \"\\\"\".");

    final String updatedSearchColumnCountAsString = searchColumnCountString.split(" ", 2)[0];
    assertTrue(NumberUtils.isParsable(updatedSearchColumnCountAsString), "Expected the columns-modal columns count to be a parsable number, was \"" + updatedSearchColumnCountAsString + "\".");

    int columnCount = Integer.parseInt(updatedSearchColumnCountAsString);
    assertTrue(columnCount < defaultSearchColumnsCount, "Expected the columns-modal updated-columns count to be less than the default count, was " + columnCount + ".");
  }

  private void validateSearchColumnBlocks(@Nonnull final String columnLabel)
  {
    List<WebElement> searchColumnBlockElements = reportBuilderPage.getSearchColumnBlockAccordions();
    searchColumnBlockElements.forEach(element -> validateSearchColumnBlock(columnLabel, element));
  }

  private void validateSearchColumnBlock(@Nonnull final String columnLabel, @Nonnull final WebElement columnBlock)
  {
    List<WebElement> columnCheckBoxes = reportBuilderPage.getColumnCheckBoxesForColumnBlock(columnBlock);
    if (reportBuilderPage.accordionIsCollapsed(reportBuilderPage.getColumnBlockTitleAnchor(columnBlock)))
    {
      assertTrue(columnCheckBoxes.stream().noneMatch(checkBox -> StringUtils.containsIgnoreCase(checkBox.getText(), columnLabel)), "Expected none of the collapsed-accordion checkboxes to contain column label \"" + columnLabel + "\".");
      assertFalse(StringUtils.containsIgnoreCase(columnBlock.getText(), "show all"), "Expected the column block to not contain \"Show All\".");
    }
    else
    {
      assertTrue(columnCheckBoxes.stream().allMatch(checkBox -> StringUtils.containsIgnoreCase(checkBox.getText(), columnLabel)), "Expected all of the collapsed-accordion checkboxes to contain column label \"" + columnLabel + "\".");
      assertTrue(StringUtils.containsIgnoreCase(columnBlock.getText(), "show all"), "Expected the column block to contain \"Show All\".");
      assertNotNull(reportBuilderPage.getColumnBlockShowHide(columnBlock), "Expected the column-block's show-hide element to exist.");
    }
  }

  private void validateSearchColumnBlockChildContent(@Nonnull final String reportBlock, @Nonnull final String columnLabel)
  {
    assertTrue(reportBuilderPage.additionalContentIsHidden(reportBlock), "Expected the additional content to be hidden for report block \"" + reportBlock + "\".");
    List<String> hiddenColumns = reportBuilderPage.getHiddenColumnsForBlock(reportBlock);
    assertTrue(hiddenColumns.stream().noneMatch(column -> StringUtils.containsIgnoreCase(column, columnLabel)), "Expected none of the report-block's hidden columns to contain column label \"" + columnLabel + "\".");
  }

  private void validateCheckedColumns(@Nonnull final List<String> columns)
  {
    // Verify that the checkboxes are checked for each of the specified columns
    List<String> checkedColumnsLabels = reportBuilderPage.getActiveVisibleColumnCheckBoxes().stream().map(WebElement::getText).collect(Collectors.toList());
    assertTrue(checkedColumnsLabels.containsAll(columns), "Expected the active, visible checkboxes to contain " + columns + ".");
  }

  private void validateAddColumnsModalColumnPills(@Nonnull final List<String> columns)
  {
    // Verify that a column "pill" exists for each of the specified columns
    List<String> dragDropColumnLabels = reportBuilderPage.getAddColumnsModalColumnPills().stream().map(column -> column.getAttribute("title")).collect(Collectors.toList());
    assertTrue(dragDropColumnLabels.containsAll(columns), "Expected the columns-modal column-pills labels to contain " + columns + ".");
  }

  private void validateAddColumnsModalPillsDoNotContain(@Nonnull final String columnLabel)
  {
    // Verify that the column "pills" don't contain the specified column
    List<String> dragDropColumnLabels = reportBuilderPage.getAddColumnsModalColumnPills().stream().map(column -> column.getAttribute("title")).collect(Collectors.toList());
    assertFalse(dragDropColumnLabels.contains(columnLabel), "Expected the columns-modal column-pills labels to not contain \"" + columnLabel + "\".");
  }

  private void validateCheckedColumnsDoNotContain(@Nonnull final String columnLabel)
  {
    List<String> checkedColumnLabels = reportBuilderPage.getAddColumnsModalCheckBoxLabels();
    assertFalse(checkedColumnLabels.contains(columnLabel), "Expected the columns-modal checkbox labels to not contain \"" + columnLabel + "\".");
  }

  private void validateColumnPills(@Nonnull final List<String> columns)
  {
    List<String> columnLabels = getColumnPillsLabels(reportBuilderPage.getColumnPills());
    assertTrue(columnLabels.containsAll(columns), "Expected the report-builder column-pills labels to contain " + columns + ".");
  }

  private List<String> getColumnPillsLabels(List<WebElement> columnPills)
  {
    return columnPills.stream().map(pill -> pill.getAttribute("title")).collect(Collectors.toList());
  }

  /**
   * RA-18989: Analysis > Reporting | Column Actions within a Report Builder report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-24061", chromeIssue = "RA-24062")
  public void testColumnActions_columnPills()
  {
    // Initialize template and assert default conditions
    selectTemplate(ATTENDEE_TEMPLATE);
    reportBuilderPage.waitForPageLoad(10);
    reportBuilderPage.waitForDataLoad(10);

    // From the columns section of the report, click and drag one of the 'column pills' to a new location
    /*
      Expected Result: The report will reload and the moved column will be in the new location on the report
     */
    List<String> columnPillLabels = getColumnPillsLabels(reportBuilderPage.getColumnPills());
    reportBuilderPage.dragAndDropByElement("First Name", "Last Name");
    List<String> reorderedColumnPillLabels = getColumnPillsLabels(reportBuilderPage.getColumnPills());
    validateReorderedColumnPills(columnPillLabels, reorderedColumnPillLabels);

    // From the columns section of the report, click the 'x' on one of the 'column pills' to remove the column.
    /*
      Expected Result: The column will be removed from the report and the report will reload.
     */
    final String columnLabel = "Job Title";
    assertTrue(reportBuilderPage.isColumnOnPage(columnLabel), "Expected the report-builder column pills to contain \"" + columnLabel + "\".");
    reportBuilderPage.removeColumnViaPill(columnLabel);
    assertFalse(reportBuilderPage.isColumnOnPage(columnLabel), "Expected the report-builder column pills to not contain \"" + columnLabel + "\".");
  }

  private void validateReorderedColumnPills(@Nonnull final List<String> columnPillLabels, @Nonnull final List<String> reorderedColumnPillLabels)
  {
    assertEquals(columnPillLabels.size(), reorderedColumnPillLabels.size(), "Expected the count of the columns to be unchanged after reordering.");
    assertEquals(columnPillLabels.get(0), reorderedColumnPillLabels.get(1), "Expected the column pills at indexes " + 0 + " and " + 1 + " to have switched.");
    assertEquals(columnPillLabels.get(1), reorderedColumnPillLabels.get(0), "Expected the column pills at indexes " + 0 + " and " + 1 + " to have switched.");
  }

  /**
   * RA-18989: Analysis > Reporting | Column Actions within a Report Builder report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-24063", chromeIssue = "RA-24064")
  public void testColumnActions_columnRename()
  {
    // Initialize template and assert default conditions
    selectTemplate(ATTENDEE_ORDERS_TEMPLATE);
    reportBuilderPage.waitForPageLoad(10);
    reportBuilderPage.waitForDataLoad(10);

    // Choose a column on the report and click on the small arrow in the column name
    /*
      Expected Result: A menu of column actions displays
     */
    reportBuilderPage.openMenu(0);

    // Change the name of the column
    /*
      Expected Result:
      -The column name should change on the report and in the 'column pill'
      -The report will reload.
     */
    assertNotEquals(reportBuilderPage.getColumnPillText(0), TEST_STRING_1, "Expected the column-pill label at index " + 0 + " to not equal \"" + TEST_STRING_1 + "\".");
    reportBuilderPage.renameColumnViaColumnOptions(0, TEST_STRING_1);
    String columnPillText = reportBuilderPage.getColumnPillText(0);
    assertEquals(columnPillText, TEST_STRING_1, "Expected the column-pill label at index " + 0 + " to equal \"" + TEST_STRING_1 + "\", was \"" + columnPillText + "\".");

    // Double click on the name area of a different column
    /*
      Expected Result: The cursor should appear in the column name section allowing you to change the name
     */
    // Give this column the same name as the previously renamed column
    /*
      Expected Result:
      -The new column name should be followed by a ' (1)' to indicate that it's a duplicate name.
      -The report will reload.
     */
    columnPillText = reportBuilderPage.getColumnPillText(2);
    assertNotEquals(columnPillText, TEST_STRING_1, "Expected the column-pill label at index " + 2 + " to not equal \"" + TEST_STRING_1 + "\".");
    reportBuilderPage.renameColumnViaDoubleClick(2, TEST_STRING_1);
    columnPillText = reportBuilderPage.getColumnPillText(2);
    assertEquals(columnPillText, TEST_STRING_1 + " (1)", "Expected the column-pill label at index " + 2 + " to equal \"" + TEST_STRING_1 + " (1)\", was \"" + columnPillText + "\".");

    // Double click on the name area of the column again and this time delete all the characters to give it a 'blank' name
    /*
      Expected Result: The name will reset to the last name of the column
     */
    final String originalColumnLabel = reportBuilderPage.getColumnPillText(1);
    reportBuilderPage.renameColumnViaDoubleClick(1, "");
    columnPillText = reportBuilderPage.getColumnPillText(1);
    assertEquals(columnPillText, originalColumnLabel, "Expected the column-pill label at index " + 1 + " to be unchanged, was \"" + columnPillText + "\".");

    // Hover over the column name section on the report
    /*
      Expected Result: The 'Block' and original 'Column Name' are shown.
     */
    final String columnHeaderOverlay = reportBuilderPage.hoverOverColumnHeader(0);
    final String expectedOverlayText = "Block\nAttendee\nColumn Name\nFirst Name";
    assertEquals(columnHeaderOverlay, expectedOverlayText, "Expected the column-header-overlay text at index " + 0 + " to equal \"" + expectedOverlayText + "\", was \"" + columnHeaderOverlay + "\".");

    // Hover over a 'column pill' that has '...' in the name.
    /*
      Expected Result: The full column name is shown
     */
    final String columnPillOverlay = reportBuilderPage.hoverOverColumnPill(2);
    assertEquals(columnPillOverlay, "ellipsis", "Expected the column-pill-overlay text at index " + 2 + " to contain \"...\".");
  }

  /**
   * RA-18989: Analysis > Reporting | Column Actions within a Report Builder report
   */
  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(firefoxIssue = "RA-24065", chromeIssue = "RA-24066")
  public void testColumnActions_columnMenu()
  {
    // Initialize template and assert default conditions
    selectTemplate(ATTENDEE_ORDERS_TEMPLATE);
    reportBuilderPage.waitForPageLoad(15);
    reportBuilderPage.waitForDataLoad(15);
    reportBuilderPage.waitForColumnPills();

    // Remove all columns except "Email" to simplify the report
    List<String> columnLabels = getColumnPillsLabels(reportBuilderPage.getColumnPills()).stream()
        .filter(columnLabel -> !Arrays.asList("Email", "Total Price (after tax)", "Quantity").contains(columnLabel))
        .collect(Collectors.toList());
    columnLabels.forEach(reportBuilderPage::removeColumnViaPill);

    Utils.sleep(5000);

    // Prepare for testing column-total options
    if (reportBuilderPage.columnHasSummary(1))
      reportBuilderPage.removeColumnTotal(1);
    if (reportBuilderPage.columnHasSummary(2))
      reportBuilderPage.removeColumnTotal(2);

    // Open the menu for the "Total Price (after tax)" column and choose the "Add Column Total" option
    /*
      Expected Result:
      -A row is added to the bottom of the template which displays the Sum of the selected column.
      -The sum should be in a currency format
     */
    assertFalse(reportBuilderPage.columnHasSummary(1), "Expected column " + 1 + " to not have a summary.");
    reportBuilderPage.addColumnTotal(1);
    assertTrue(reportBuilderPage.columnHasSummary(1), "Expected column " + 1 + " to have a summary.");
    validateCurrencySummary(1);

    // Open the menu for the "Quantity" column and choose the "Add Column Total" option
    /*
      Expected Result: The sum should be in a number format
     */
    assertFalse(reportBuilderPage.columnHasSummary(2), "Expected column " + 2 + " to not have a summary.");
    reportBuilderPage.addColumnTotal(2);
    assertTrue(reportBuilderPage.columnHasSummary(2), "Expected column " + 2 + " to have a summary.");
    validateNumberSummary(2);

    // Choose the small arrow from one of the columns with a total on it and choose the "Remove Column Total" option
    /*
      Expected Result
      -The total for that column is removed.
      -If another column has a total on it, that sum is still there.
     */
    assertTrue(reportBuilderPage.columnHasSummary(2), "Expected column " + 2 + " to have a summary.");
    reportBuilderPage.removeColumnTotal(2);
    assertFalse(reportBuilderPage.columnHasSummary(2), "Expected column " + 2 + " to not have a summary.");

    // Open the menu for the "Quantity" column and choose the "Duplicate Column" option
    /*
      Expected Result: The column is duplicated to the right of the selected column and it has a '(1)' after the original name
     */
    final String originalHeader = reportBuilderPage.getColumnHeaderText(2);
    reportBuilderPage.duplicateColumn(2);
    final String duplicateHeader = reportBuilderPage.getColumnHeaderText(3);
    assertEquals(duplicateHeader, originalHeader + " (1)", "Expected the duplicated-column text to equal \"" + originalHeader + " (1)\", was \"" + duplicateHeader + "\".");

    // Choose a column on the report and click on the small arrow in the column name; choose the "Remove Column" option
    /*
      Expected Result
      -The column will be deleted from the report and the column pill will be deleted.
      -The report will reload
     */
    reportBuilderPage.removeColumn(2, false);
  }

  private void validateCurrencySummary(final int colIndex)
  {
    final String summaryValue = getSummaryValue(colIndex);
    assertTrue(Pattern.compile("^[-]?[$]?(\\d{1,}(\\,\\d{3})*)(\\.\\d{2}){1}$").matcher(summaryValue).matches(), "Expected column-summary " + colIndex + " to be currency-formatted, was \"" + summaryValue + "\".");
  }

  private void validateNumberSummary(final int colIndex)
  {
    final String summaryValue = getSummaryValue(colIndex);
    assertTrue(NumberUtils.isParsable(summaryValue.replace(",", "")), "Expected column-summary " + colIndex + " to be number-formatted, was \"" + summaryValue + "\".");
  }

  private String getSummaryValue(final int colIndex)
  {
    final String summaryText = reportBuilderPage.getSummaryText(colIndex);
    return summaryText.split("\\n", 2)[1];
  }

  @AfterMethod
  public void returnToReportsList()
  {
    reportBuilderPage.navigateBackToReportsList();
    reportBuilderPage.continueWithoutSaving();
  }

  @AfterClass
  public void closeBrowser()
  {
    PageConfiguration.getPage().quit();
  }
}

