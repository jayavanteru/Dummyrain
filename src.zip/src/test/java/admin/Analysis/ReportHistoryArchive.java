package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.ReportActionsModal;
import apps.admin.adminPageObjects.analysis.ReportBuilderPage;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import apps.admin.adminPageObjects.analysis.reporting.ReportBuilderTemplates;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import logs.ReportingInfo;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ReportHistoryArchive {

    private final String ATTENDEE_TEMPLATE = "15381699461510010SC8";
    private final String ReportName = "automation" + new DataGenerator().generateString(5);
    private final String category = "Archived";

    private final ReportsListPage reportsListPage = ReportsListPage.getPage();
    private final ReportBuilderPage reportBuilderPage = ReportBuilderPage.getPage();
    private final ReportActionsModal reportActionsModal = ReportActionsModal.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }


    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-34547", chromeIssue = "RA-43373")
    public void reportHistory()
    {
        //Create report to work with
        reportsListPage.navigateToReportList();
        reportsListPage.openReportTypePickerModal();
        reportsListPage.openTemplatePickerModal();
        reportsListPage.selectTemplate(ATTENDEE_TEMPLATE);

        //Verify history shows
        reportBuilderPage.saveAsAndStay(ReportName);
        reportBuilderPage.viewHistory();
        Assert.assertTrue(reportBuilderPage.isHistoryShowing(),"History not showing");
        reportBuilderPage.cancelHistory();

        reportBuilderPage.removeColumn(0,false);
        reportActionsModal.save();

        reportBuilderPage.viewHistory();
        reportBuilderPage.restoreHistory();
        reportActionsModal.save();
        Utils.sleep(1000);

        //Edit Access
        reportBuilderPage.editAccess();
        reportActionsModal.gotoAccessTab();
        reportActionsModal.archiveReport();
        reportBuilderPage.navigateBackViaBreadcrumb();

        //Return to report list and verify changes
        reportsListPage.waitForReportsList();
        reportsListPage.goToArchiveDirectory();
        reportsListPage.setReportCategory(category);
        reportsListPage.search(ReportName);
        Assert.assertTrue(reportsListPage.isReportInList(ReportName),"Archive report is not showing, but it should");

    }
}
