package admin.Analysis.LiveTables;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditLiveTablesPage;
import apps.admin.adminPageObjects.libraries.LiveTablesSearchPage;
import apps.admin.adminPageObjects.onsite.NewBadgeBuilderPage;
import apps.workflows.workflowsPageObjects.WorkflowLiveTablePage;
import interaction.files.OpenFile;
import interaction.screenshots.ScreenShotImage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.io.File;
import java.io.IOException;

public class  LiveTableFileUpload {

    AdminApp adminApp = new AdminApp();

    private final LiveTablesSearchPage liveTables = LiveTablesSearchPage.getPage();
    private final EditLiveTablesPage editLiveTables = EditLiveTablesPage.getPage();
    private final WorkflowLiveTablePage wfLiveTable = WorkflowLiveTablePage.getPage();

    private final String attendeeEmail = ("Brian.Pulham@rainfocus.com");
    String file1 = "File1.mp4";
    String file2 = "File2.jpg";
    String file3 = "File3.pdf";

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-46781", chromeIssue = "RA-47965")
    public void LTFileUpload() throws IOException {
        adminApp.spoofIntoWorkflow(attendeeEmail, "chrisrattendee", 1);
        wfLiveTable.scrollToColumnRight("File Upload");
        Utils.sleep(3000);
        wfLiveTable.removeFileUpload();
        wfLiveTable.removeFileUploadOK();
        wfLiveTable.clickFileUpload();
        wfLiveTable.fileUpload(file1, file3, file2);
        wfLiveTable.confirmFileUpload();
        Utils.sleep(3000);
        wfLiveTable.clickFileUpload();
        Assert.assertEquals(wfLiveTable.getUploadedFiles(), 3, "Expected 3 files but did not see 3");
        wfLiveTable.verifyDownloadJPGFile();
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("File2.*\\.jpg");
        ScreenShotImage upLoadedImage = new ScreenShotImage(new File(file2));
        ScreenShotImage downLoadedImage = new ScreenShotImage(file.getFile());
        int diffAmount = upLoadedImage.getDiffAmount(downLoadedImage);
        Assert.assertTrue(diffAmount<500, "The images don't match " +diffAmount);
        //PageConfiguration.getPage().closeTabsToDefault();
        PageConfiguration.getPage().switchToTab(0);
    }

        @Test(groups = {ReportingInfo.DATATRON})
        @ReportingInfo(firefoxIssue = "RA-48935", chromeIssue = "RA-48934")
        public void LTPopupUpload()throws IOException{

            adminApp.spoofIntoWorkflow(attendeeEmail, "chrisrattendeepopup", 1);
            wfLiveTable.scrollToColumnRight("File Upload");
            Utils.sleep(3000);
            wfLiveTable.removeFileUpload();
            wfLiveTable.submitDetailsModal();
            wfLiveTable.clickFileUpload();
            wfLiveTable.fileUpload(file1, file3, file2);
            wfLiveTable.submitDetailsModal();
            wfLiveTable.clickFileUpload();
            Assert.assertEquals(wfLiveTable.getUploadedFiles(), 3, "Expected 3 files but did not see 3");
            wfLiveTable.verifyDownloadJPGFile();
            OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("File2.*\\.jpg");
            ScreenShotImage upLoadedImage = new ScreenShotImage(new File(file2));
            ScreenShotImage downLoadedImage = new ScreenShotImage(file.getFile());
            int diffAmount = upLoadedImage.getDiffAmount(downLoadedImage);
            Assert.assertTrue(diffAmount<500, "The images don't match " +diffAmount);
            PageConfiguration.getPage().switchToTab(0);
    }
}
