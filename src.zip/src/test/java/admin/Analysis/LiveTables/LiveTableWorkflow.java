package admin.Analysis.LiveTables;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditLiveTablesPage;
import apps.admin.adminPageObjects.libraries.LiveTablesSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowLiveTablePage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class LiveTableWorkflow {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    private final LiveTablesSearchPage liveTables = LiveTablesSearchPage.getPage();
    private final EditLiveTablesPage editLiveTables = EditLiveTablesPage.getPage();
    private final WorkflowLiveTablePage wfLiveTable = WorkflowLiveTablePage.getPage();

    private final String attendeeEmail = ("Brian.Pulham@rainfocus.com");

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-42512", chromeIssue = "RA-43498")
    public void LiveTableWorkflow() throws IOException, NoSuchAlgorithmException {
        adminApp.spoofIntoWorkflow(attendeeEmail, "chrisregressionattendee", 1);
        List<String> allHeaders = new ArrayList<>();

        //lastname
        WorkflowLiveTablePage.getPage().scrollToColumnLeft("Last Name");
        WorkflowLiveTablePage.getPage().editColumn("Last Name");
        WorkflowLiveTablePage.getPage().editColumnTextFilter("Underwood");

        List<String> column = WorkflowLiveTablePage.getPage().getColumns("Last Name");
        column.forEach(c -> Assert.assertEquals(c, "Underwood", "MAP WAS NOT FILTERED BY LAST NAME 'Underwood' THE VALUE WAS '"+c+"'"));

        PageConfiguration.getPage().refreshPage();

        //state
        WorkflowLiveTablePage.getPage().scrollToColumnRight("State");
        WorkflowLiveTablePage.getPage().editColumn("State");
        WorkflowLiveTablePage.getPage().editColumnSelectValue("State", "Utah");

        column = WorkflowLiveTablePage.getPage().getColumns("State");
        column.forEach(c -> Assert.assertEquals(c.toLowerCase(), "utah", "MAP WAS NOT FILTERED BY STATE 'Utah' THE VALUE WAS '"+c+"'"));

        PageConfiguration.getPage().refreshPage();

        //registration date
        WorkflowLiveTablePage.getPage().scrollToColumnRight("Radio Button");
        WorkflowLiveTablePage.getPage().editColumn("Registration Date");
        WorkflowLiveTablePage.getPage().editColumnDate("Registration Date", "2019-01-31");

        column = WorkflowLiveTablePage.getPage().getColumns("Registration Date");
        Assert.assertEquals(column.get(0),"2019-01-31", "MAP WAS NOT FILTERED BY REGISTRATION DATE '2019-01-31' THE VALUE WAS '"+column.get(0)+"'");

        PageConfiguration.getPage().refreshPage();

        //long answer
        WorkflowLiveTablePage.getPage().scrollToColumnRight("Company");
        WorkflowLiveTablePage.getPage().editColumn("Long Answer Question");
        Utils.sleep(3000);
        WorkflowLiveTablePage.getPage().editColumnTextFilter("This is long text");
        WorkflowLiveTablePage.getPage().scrollToColumnLeft("First Name");
        WorkflowLiveTablePage.getPage().scrollToColumnRight("Company");

        column = WorkflowLiveTablePage.getPage().getColumns("Long Answer Question");
        Assert.assertTrue(column.get(0).contains("This is long text"), "MAP WAS NOT FILTERED BY LONG ANSWER QUESTION THE VALUE WAS '"+column.get(0)+"'");

        PageConfiguration.getPage().refreshPage();

        //rolling comments
        WorkflowLiveTablePage.getPage().scrollToColumnRight("Company");
        WorkflowLiveTablePage.getPage().editColumn("Rolling Comments");
        WorkflowLiveTablePage.getPage().editColumnTextFilter("Todd Rhodes");
        PageConfiguration.getPage().justWait();

        column = WorkflowLiveTablePage.getPage().getColumns("Rolling Comments");
        Assert.assertTrue(column.get(0).contains("Todd Rhodes"), "MAP WAS NOT FILTERED BY ROLLING COMMENTS THE VALUE WAS '"+column.get(0)+"'");

        PageConfiguration.getPage().refreshPage();

        //filter by first name chris
        WorkflowLiveTablePage.getPage().scrollToColumnLeft("First Name");
        WorkflowLiveTablePage.getPage().editColumn("First Name");
        WorkflowLiveTablePage.getPage().editColumnTextFilter("Chris");

        //filter by last name ascending
        WorkflowLiveTablePage.getPage().editColumn("Last Name");
        WorkflowLiveTablePage.getPage().filterAscending();

        column = WorkflowLiveTablePage.getPage().getColumns("Last Name");
        List<String> filteredLastNames = new ArrayList<>();
        filteredLastNames.addAll(column);
        Collections.sort(filteredLastNames);

        for (int i = 0; i < 3; i++) {
            Assert.assertEquals(filteredLastNames.get(i),column.get(i), "LAST NAMES WERE NOT SORTED ASCENDING");
        }

        //change ascending to descending
        WorkflowLiveTablePage.getPage().filterDescending();

        column = WorkflowLiveTablePage.getPage().getColumns("Last Name");
        filteredLastNames = new ArrayList<>();
        filteredLastNames.addAll(column);
        Collections.sort(filteredLastNames, Collections.reverseOrder());

        for (int i = 0; i < 3; i++) {
            Assert.assertEquals(filteredLastNames.get(i),column.get(i), "LAST NAMES WERE NOT SORTED DESCENDING");
        }

        //attendee type 'employee'
        System.out.println();
        WorkflowLiveTablePage.getPage().scrollToColumnRight("Registration Date");
        WorkflowLiveTablePage.getPage().editColumn("Attendee Type");
        WorkflowLiveTablePage.getPage().editColumnSelectValue("Attendee Type", "Employee");

        //export excel
        int size = WorkflowLiveTablePage.getPage().getSize();
        WorkflowLiveTablePage.getPage().actions();
        WorkflowLiveTablePage.getPage().export();

        PageConfiguration.getPage().justWait();

        OpenFile openFile = OpenFile.OpenRecentDownloadedFile();

        List<Map<String, String>> xlsx = openFile.parseXLSX();
        Assert.assertTrue(xlsx.size() == size);
        xlsx.forEach((row)->{
            Assert.assertTrue(row.get("Attendee Type").contains("Employee"));
        });
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Disables the option to allow viewers to export as XLSX
        liveTables.navigateToLiveTables();
        liveTables.search("Chris Regression Session");
        liveTables.editItem();
        Utils.sleep(3000);
        editLiveTables.allowExport();
        adminApp.spoofIntoWorkflow(attendeeEmail, "chrisregressionsession", 1);
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("chrisregressionsession"));
        Assert.assertFalse(wfLiveTable.isActionButtonVisable(), "Actions button to export report is showing, and it shouldn't be");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Enable the option to allow viewers to export XLSX
        liveTables.navigateToLiveTables();
        liveTables.search("Chris Regression Session");
        liveTables.editItem();
        editLiveTables.allowExport();

        //spoof into pop up workflow
        adminApp.spoofIntoWorkflow(attendeeEmail, "chrisregressionattendeepopup", 1);

        //edit last name via modal
        String newName;
        allHeaders = WorkflowLiveTablePage.getPage().getAllHeaders();
        WorkflowLiveTablePage.getPage().scrollToColumnLeft("First Name");
        PageConfiguration.getPage().justWait();
        WorkflowLiveTablePage.getPage().editCell(1);
        WorkflowLiveTablePage.getPage().editDetailsModalTextBox("First Name", newName = dataGenerator.generateName());
        WorkflowLiveTablePage.getPage().submitDetailsModal();
        column = WorkflowLiveTablePage.getPage().getColumns("First Name");
        Assert.assertEquals(column.get(0), newName, "FIRST NAME WAS NOT CHANGED");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //spoof into session rb
        adminApp.spoofIntoWorkflow(attendeeEmail, "chrisregressionsessionrb", 1);
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("chrisregressionsessionrb"));

        PageConfiguration.getPage().justWait();
        WorkflowLiveTablePage.getPage().manageVolunteers(0);
        PageConfiguration.getPage().justWait();
        String otherRole = WorkflowLiveTablePage.getPage().getAnotherVolunteerRole("Perso Person");
        WorkflowLiveTablePage.getPage().editVolunteerRole("Perso Person", otherRole);
        WorkflowLiveTablePage.getPage().saveVolunteerModal();

        PageConfiguration.getPage().justWait();
        WorkflowLiveTablePage.getPage().manageVolunteers(0);
        Assert.assertTrue(WorkflowLiveTablePage.getPage().getRole("Perso Person").contains(otherRole));
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Test old old working reports to verify they have data
        adminApp.spoofIntoWorkflow(attendeeEmail, "CRLA", 1);
        Assert.assertTrue(WorkflowLiveTablePage.getPage().isReportContentVisable(), "The table is missing from this report");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        adminApp.spoofIntoWorkflow(attendeeEmail, "CRLAPU", 1);
        Assert.assertTrue(WorkflowLiveTablePage.getPage().isReportContentVisable(),"The table is missing from this report");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        adminApp.spoofIntoWorkflow(attendeeEmail, "CRLS", 1);
        Assert.assertTrue(WorkflowLiveTablePage.getPage().isReportContentVisable(),"The table is missing from this report");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        adminApp.spoofIntoWorkflow(attendeeEmail, "CRLSRB", 1);
        Assert.assertTrue(WorkflowLiveTablePage.getPage().isReportContentVisable(),"The table is missing from this report");
    }
}
