package admin.Analysis.LiveTables;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.LiveTablesEditPage;
import apps.admin.adminPageObjects.libraries.LiveTablesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class LTRestoreHistory {

    private final LiveTablesPage liveTablesCreate = LiveTablesPage.getPage();
    private final LiveTablesEditPage editLiveTable = LiveTablesEditPage.getPage();
    private final DataGenerator dataGenerator = new DataGenerator();
    String Message1 = (dataGenerator.generateString());
    String Message2 = (dataGenerator.generateString());
    String LiveTable = ("Chris Regression Session");

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-46784", chromeIssue = "RA-47184")
    public void LiveTableHistory(){

        //Open a live table to view history
        liveTablesCreate.navigateToLiveTables();
        Utils.sleep(3000);
        liveTablesCreate.search(LiveTable);
        liveTablesCreate.editItem();

        //Edit table then view history
        editLiveTable.addDisplayMsg(Message1);
        editLiveTable.save();
        Assert.assertTrue(editLiveTable.verifyDisplayMessage(Message1), "The display message should be " +Message1);
        editLiveTable.addDisplayMsg(Message2);
        editLiveTable.save();
        Assert.assertTrue(editLiveTable.verifyDisplayMessage(Message2),"The display message should be " +Message2);
        editLiveTable.viewHistory();
        editLiveTable.openHistory();
        Assert.assertTrue(editLiveTable.verifyDisplayMessage(Message1), "The display message should be " +Message1);
        editLiveTable.cancel();

        //Reopen the live table to go back to original state
        liveTablesCreate.search(LiveTable);
        Utils.sleep(3000);
        liveTablesCreate.editItem();
        Assert.assertTrue(editLiveTable.verifyDisplayMessage(Message2),"The display message should be " +Message2);
    }
}
