package admin.Analysis;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.NewReportNotificationPage;
import apps.admin.adminPageObjects.analysis.ReportNotificationSearchPage;
import configuration.PropertyReader;
import interaction.files.OpenFile;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportNotifications {

    String reportNotificationId;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NewReportNotificationPage.getPage().navigate();
    }

    @AfterClass
    public void cleanup() {
        if (reportNotificationId != null) {
            ReportNotificationSearchPage.getPage().deleteNotificationApi(reportNotificationId);
        }
        PageConfiguration.getPage().quit();
    }
//This test has been replaced with ReportNotificationV2  I will delete this test when I am sure noting in it is needed.
    //@Test(groups = ReportingInfo.DATATRON)
    //@ReportingInfo(firefoxIssue = "RA-18992", chromeIssue = "RA-43597")
    public void editReportNotification() throws IOException {
        DataGenerator generator = new DataGenerator();
        String reportName = "Attendee Summary";
        String time = "1:00";
        String timeZone = "GMT0";
        String emailSubject = "Report: "+reportName;
        String random = generator.generateString();
        String email1 = generator.generateEmail();
        String email2 = generator.generateValidEmail();

        NewReportNotificationPage newNotifications = NewReportNotificationPage.getPage();
        ReportNotificationSearchPage searchPage = ReportNotificationSearchPage.getPage();


        newNotifications.selectReport(reportName);
        Assert.assertEquals(newNotifications.getAttendeeSummaryReport(), reportName, "did not select the right report");

        newNotifications.addRecipients(random);
        Assert.assertEquals(newNotifications.getRecipientError(), random + " are not emails.", "Error message did not display correctly");

        newNotifications.addRecipients(email1, email2);
        List<String> recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 2, "not all recipient emails are there");
        Assert.assertTrue(recipients.contains(email1), "recipient email " + email1 + " was note added");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was note added");

        newNotifications.removeRecipient(email1);
        recipients = newNotifications.getRecipients();
        Assert.assertEquals(recipients.size(), 1, "not all recipient emails are there");
        Assert.assertFalse(recipients.contains(email1), "recipient email " + email1 + " was not removed");
        Assert.assertTrue(recipients.contains(email2), "recipient email " + email2 + " was removed");

        newNotifications.toggleNotificationFrequency("S", "M", "T");
        List<String> activeDays = newNotifications.getActiveDays();
        Assert.assertEquals(activeDays.size(), 3, "not all days were selected");
        Assert.assertTrue(activeDays.contains("S"), "S was not selected for notification frequency");
        Assert.assertTrue(activeDays.contains("M"), "M was not selected for notification frequency");
        Assert.assertTrue(activeDays.contains("T"), "T was not selected for notification frequency");

        newNotifications.toggleNotificationFrequency("M", "T");
        activeDays = newNotifications.getActiveDays();
        Assert.assertEquals(activeDays.size(), 1, "not all days were selected");
        Assert.assertTrue(activeDays.contains("S"), "S was not selected for notification frequency");
        Assert.assertFalse(activeDays.contains("M"), "M was not deselected for notification frequency");
        Assert.assertFalse(activeDays.contains("T"), "T was not deselected for notification frequency");

        newNotifications.selectTime(time);
        Assert.assertEquals(newNotifications.getSelectedTime(), time, "did not select the time");

        newNotifications.selectTimeZone(timeZone);
        Assert.assertEquals(newNotifications.getSelectedTimeZone(), timeZone, "did not select the right time zone");

        newNotifications.clickPM();

        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertTrue(newNotifications.isSendOnlyIfReportChangedChecked(), "did not check send only if report has changed");
        newNotifications.toggleSendOnlyIfReportChanged();
        Assert.assertFalse(newNotifications.isSendOnlyIfReportChangedChecked(), "did not uncheck send only if report has changed");

        DateTime startDate = DateTime.now().minusDays(2);
        DateTime endDate = DateTime.now().plusDays(2);
        newNotifications.setStartDate(startDate);
        newNotifications.setEndDate(endDate);
        Assert.assertEquals(newNotifications.getStartDate(), startDate.toString("yyyy-MM-dd"), "start date not set");
        Assert.assertEquals(newNotifications.getEndDate(), endDate.toString("yyyy-MM-dd"), "end date not set");

        newNotifications.save();

        HashMap<String, String> lastRow = searchPage.getLastRow();
        Assert.assertNotNull(lastRow.get("id"), "did not get the id");
        reportNotificationId = lastRow.get("id");
        Assert.assertEquals(lastRow.get("name"), reportName, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("days"), "S", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("times"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("timezone"), timeZone, "last row did not have the right info");

        //verify all the search
        searchPage.search(reportName);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), reportName, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("days"), "S", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("times"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("timezone"), timeZone, "last row did not have the right info");

        searchPage.search("");
        searchPage.search(email2);

        lastRow = searchPage.getLastRow();
        Assert.assertEquals(lastRow.get("name"), reportName, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("emails"), email2, "last row did not have the right info");
        Assert.assertEquals(lastRow.get("days"), "S", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("times"), time + " pm", "last row did not have the right info");
        Assert.assertEquals(lastRow.get("timezone"), timeZone, "last row did not have the right info");

        //send the notification and check the email
        final JSONObject response = searchPage.forceNotificationEmail(reportNotificationId);
        Assert.assertTrue(response.toString().contains("Success"), "did not fire the notification email");

        EmailApi.emailClient().waitForEmail(emailSubject);
        final EmailMessage mostRecentEmail = EmailApi.emailClient().getEmail(emailSubject);
        Assert.assertEquals(mostRecentEmail.getSubject(), emailSubject, "not the right email");
        Assert.assertEquals(mostRecentEmail.getRecipients()[0], email2, "not sent to the right email address");
        Assert.assertTrue(mostRecentEmail.getBody().contains(reportName), "does not have the report name in the body");
        Assert.assertTrue(mostRecentEmail.getBody().contains(PropertyReader.instance().getProperty("event")), "does not have the event name in the email");
        Assert.assertTrue(mostRecentEmail.hasAttachment(), "did not attach the report");
        String savedFile = mostRecentEmail.getAttachments().get(0);
        final List<Map<String, String>> fileContent = new OpenFile(savedFile).parseXLSX();
        Assert.assertTrue(fileContent.size() > 10, "there are less than 10 rows in the attached report file");
        Assert.assertTrue(fileContent.get(0).size() > 10, "there are less than 10 columns in the attached report file");

        searchPage.deleteNotification(reportNotificationId);

        searchPage.search("");
        lastRow = searchPage.getLastRow();
        Assert.assertNotEquals(lastRow.get("emails"), email2, "did not delete the last row");
        reportNotificationId = null;

    }
}
