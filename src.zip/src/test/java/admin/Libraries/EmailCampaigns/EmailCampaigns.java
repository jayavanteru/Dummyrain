package admin.Libraries.EmailCampaigns;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EmailCampaigns {
    String campaignName = new DataGenerator().generateName();

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().addItem();
        EmailCampaignSetUpTab.getPage().setName(campaignName);
        EmailCampaignSetUpTab.getPage().setInformational();
        EmailCampaign.getPage().nextTab();
        EmailCampaign.getPage().summaryTab();
        EmailCampaignSummaryTab.getPage().save();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-26622", firefoxIssue = "RA-26623")
    public void createEmailCampaign(){
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        Assert.assertTrue(EmailCampaignsSearchPage.getPage().campaignExists(campaignName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-26620", firefoxIssue = "RA-26621")
    public void deleteEmailCampaign(){
        String campaignName = new DataGenerator().generateName();
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().addItem();
        EmailCampaignSetUpTab.getPage().setName(campaignName);
        EmailCampaignSetUpTab.getPage().setInformational();
        EmailCampaign.getPage().nextTab();
        EmailCampaign.getPage().summaryTab();
        EmailCampaignSummaryTab.getPage().save();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        EmailCampaignsSearchPage.getPage().deleteFirstCampaign();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        Assert.assertFalse(EmailCampaignsSearchPage.getPage().campaignExists(campaignName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-26632", firefoxIssue = "RA-26633")
    public void editEmailCampaign(){
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        EmailCampaignsSearchPage.getPage().selectCampaign(campaignName);
        EmailCampaignSummaryTab.getPage().setUpTab();
        String newCampaignName = new DataGenerator().generateName();
        campaignName = newCampaignName;
        EmailCampaignSetUpTab.getPage().setName(campaignName);
        EmailCampaign.getPage().summaryTab();
        EmailCampaignSummaryTab.getPage().save();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        Assert.assertTrue(EmailCampaignsSearchPage.getPage().campaignExists(campaignName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-26641", firefoxIssue = "RA-26642")
    public void emailCampaignSafeGuards(){
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        EmailCampaignsSearchPage.getPage().selectCampaign(campaignName);
        EmailCampaign.getPage().recipientsTab();
        EmailCampaignEmailsTab.getPage().setRegisteredToNo();
        EmailCampaignEmailsTab.getPage().search();
        EmailCampaignEmailsTab.getPage().nextTab();
        Assert.assertTrue(EmailCampaign.getPage().errorExists("Warning, the recipients list is"));
    }

    @AfterClass
    public void tearDown(){
        EmailCampaignsSearchPage.getPage().navigate();
        EmailCampaignsSearchPage.getPage().search(campaignName);
        EmailCampaignsSearchPage.getPage().deleteFirstCampaign();
        PageConfiguration.getPage().quit();
    }
}