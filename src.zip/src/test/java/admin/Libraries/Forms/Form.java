package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import logs.Log;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import testHelp.DataGenerator;


public class Form {

    protected AdminApp app;

    protected DataGenerator dataGenerator;
    protected String parentAttributeid;
    protected String childAttributeid;
    protected String parentAttributeName;
    protected String childAttributeName;

    @BeforeClass
    public void setupBrowser() {
        app = new AdminApp();

        //login
        AdminLoginPage.getPage().login();
    }

    @BeforeMethod
    public void getFormReady() {
//        PageConfiguration.getPage().refreshPage();
//        Utils.sleep(2000);
        dataGenerator = new DataGenerator();

        //set some names
        parentAttributeName = dataGenerator.generateString(5) + "automation";
        childAttributeName = dataGenerator.generateString(5) + "automation";
    }

    @AfterMethod
    public void deleteAttributes() {
        //try to delete the created attributes at the end of the test
        //don't fail the test if this blows up for some reason
        try {
            if (childAttributeid != null) {
                app.deleteAttribute(childAttributeid);
            }
            if (parentAttributeid != null) {
                app.deleteAttribute(parentAttributeid);
            }
        } catch (Exception e) {
            Log.error(e, getClass());
        }
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }
}
