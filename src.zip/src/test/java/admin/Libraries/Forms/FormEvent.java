package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.libraries.NewFormPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class FormEvent {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String formName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event C");
        NavigationBar.getPage().collapse();

        //create form
        formName = dataGenerator.generateName();
        NewFormPage.getPage().navigate();
        NewFormPage.getPage().setFormName(formName);
        NewFormPage.getPage().setRenderAsSubmit();
        NewFormPage.getPage().setEntityTypeToAttendee();
        NewFormPage.getPage().submitForm();
    }

    @AfterClass
    public void afterClass() {
        //delete form
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);
        FormsSearchPage.getPage().deleteFormByName(formName);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-32276", firefoxIssue = "RA-35187")
    public void changeFormEvent() {
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "GLOBAL");
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);
        FormsSearchPage.getPage().edit(formName);
        EditFormPage.getPage().toggleExpandingSettings();
        EditFormPage.getPage().setEvent("Blue Event D");
        EditFormPage.getPage().submitForm();

        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);
        Assert.assertTrue(FormsSearchPage.getPage().formExists(formName));
    }
}
