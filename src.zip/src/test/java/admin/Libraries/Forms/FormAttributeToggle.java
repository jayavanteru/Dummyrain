package admin.Libraries.Forms;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class FormAttributeToggle {

  private DataGenerator dataGenerator;
  FormsSearchPage formsSearchPage;
  EditFormPage editFormPage;
  CreateAttendeePage createAttendeePage;
  EditAttendeePage editAttendeePage;
  AdminApp adminApp;
  String attributeId, attributeName, attendeeId, attendeeEmail;

  String[] options = new String[]{"Option 1", "Option 2", "Option 3", "Option 4", "Option 5"};
  String[] visibleOptions = new String[]{"Option 1", "Option 2", "Option 3"};
  String[] optionsToUnCheck = new String[]{"Option 4", "Option 5"};
  String formCode = "Attendee_Profile_Left_Nav_Form";

  @BeforeClass
  public void setup()
  {
    dataGenerator = new DataGenerator();
    adminApp = new AdminApp();
    formsSearchPage = FormsSearchPage.getPage();
    editFormPage = EditFormPage.getPage();
    createAttendeePage = CreateAttendeePage.getPage();
    editAttendeePage = EditAttendeePage.getPage();

    attendeeEmail = dataGenerator.generateValidEmail();
    attributeName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);
  }

  @AfterClass
  public void tearDown() {

    // Delete Attendee
    adminApp.deleteAttendee(attendeeId);

    // Delete Attribute from Form
    formsSearchPage.navigate();
    formsSearchPage.search(formCode);
    formsSearchPage.editItem();
    editFormPage.removeAttributeByName(attributeName);
    editFormPage.submitForm();

    // Delete Attribute
    adminApp.deleteAttribute(attributeId);

    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40305", chromeIssue = "RA-40215")
  public void testToggle()
  {
    // Create Attribute
    attributeId = adminApp.createSelectAttribute(attributeName, options, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

    // Update Form
    formsSearchPage.navigate();
    formsSearchPage.search(formCode);
    formsSearchPage.editItem();
    editFormPage.addExistingAttribute(attributeName);
    editFormPage.clickCheckOptionOnActiveForm(optionsToUnCheck);
    editFormPage.submitForm();

    // Create Attendee
    attendeeId = adminApp.createAttendee(attendeeEmail);

    editAttendeePage.openAttributeSelect(attributeName);
    for (int i = 0; i < visibleOptions.length; i++) {
      Assert.assertTrue(editAttendeePage.isAttributeValueVisible(visibleOptions[i]), "Attribute Value is not visible");
    }

    for (int i = 0; i < optionsToUnCheck.length; i++) {
      Assert.assertFalse(editAttendeePage.isAttributeValueVisible(optionsToUnCheck[i]), "Attribute Value should not be visible");
    }
  }
}
