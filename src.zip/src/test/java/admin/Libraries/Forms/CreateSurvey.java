package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.EditSurveyPage;
import apps.admin.adminPageObjects.libraries.NewSurveyPage;
import apps.admin.adminPageObjects.libraries.SurveysSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;
import java.util.HashSet;

public class CreateSurvey {

    private HashSet<String> attributeIds = new HashSet<>();
    private String formId;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
    }

    @AfterClass
    public void close() {
        final AdminApp adminApp = new AdminApp();
        if (formId != null) {
            adminApp.deleteForm(formId);
        }

        for (String id : attributeIds) {
            adminApp.deleteAttribute(id);
        }

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25941", chromeIssue = "RA-25940")
    public void createSurvey() {
        final DataGenerator dataGenerator = new DataGenerator();
        final SurveysSearchPage surveySearchPage = SurveysSearchPage.getPage();
        final NewSurveyPage createPage = NewSurveyPage.getPage();
        final EditSurveyPage editPage = EditSurveyPage.getPage();
        String surveyName = dataGenerator.generateName();

        createPage.navigate();
        createPage.setAttendeeSurveySettings(surveyName);

        //add a text box
        String textBoxName = dataGenerator.generateName();
        createPage.addNewAttribute(EditFormPage.ATTR_TYPE.TEXT_BOX, textBoxName);

        //add a scale
        String scaleName = dataGenerator.generateName();
        createPage.addNewAttribute(EditFormPage.ATTR_TYPE.SCALE, scaleName);

        //add a scale matrix
        String scaleMatrixName = dataGenerator.generateName();
        createPage.addNewAttribute(EditFormPage.ATTR_TYPE.SCALE_MATRIX, scaleMatrixName);

        //save new survey
        createPage.submitForm();

        //wait for results to show up
        Utils.waitForTrue(surveySearchPage::isLoaded);
        Utils.sleep(100);

        //find the survey on the search page
        surveySearchPage.search(surveyName);
        HashMap<String, String> result = surveySearchPage.getResults().get(0);

        Assert.assertEquals(result.get("name"), surveyName, "search did not bring back the right survey");
        formId = result.get("id");
        Assert.assertEquals(result.get("type"), "Attendee", "survey did not save the right type");
        Assert.assertEquals(result.get("published"), "Not Published", "survey was not marked as published");

        surveySearchPage.editItem();

        //expand the attributes, verifies they are there
        attributeIds.add(editPage.expandAttribute(textBoxName));
        Assert.assertEquals(attributeIds.size(), 1, "did not expand the right attribute in survey form");

        //no ids
        editPage.expandAttribute(scaleName);
        editPage.expandAttribute(scaleMatrixName);

        surveyName = dataGenerator.generateName();
        editPage.toggleExpandingSettings();
        editPage.setFormName(surveyName);

        editPage.submitForm();

        //wait for results to show up
        Utils.waitForTrue(surveySearchPage::isLoaded);
        Utils.sleep(100);

        //find the survey on the search page
        surveySearchPage.search(surveyName);
        result = surveySearchPage.getResults().get(0);

        Assert.assertEquals(result.get("name"), surveyName, "search did not bring back the right survey");
        Assert.assertEquals(result.get("type"), "Attendee", "survey did not save the right type");
        Assert.assertEquals(result.get("published"), "Not Published", "survey was not marked as published");

        surveySearchPage.deleteFirstRow();
        Utils.sleep(100);

        //find the survey on the search page
        surveySearchPage.search(surveyName);

        Assert.assertTrue(surveySearchPage.isNoResults(), "did not delete the survey");
        formId = null;
    }
}
