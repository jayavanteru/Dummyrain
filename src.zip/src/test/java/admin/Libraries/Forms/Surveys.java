package admin.Libraries.Forms;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.EditSurveyPage;
import apps.admin.adminPageObjects.libraries.NewSurveyPage;
import apps.admin.adminPageObjects.libraries.SurveysSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Surveys {

  private DataGenerator dataGenerator;
  private SurveysSearchPage surveySearchPage;
  private NewSurveyPage newSurveyPage;
  private EditSurveyPage editSurveyPage;
  String surveyName;

  @BeforeClass
  public void setup()
  {
    dataGenerator = new DataGenerator();
    surveySearchPage = SurveysSearchPage.getPage();
    newSurveyPage = NewSurveyPage.getPage();
    editSurveyPage = EditSurveyPage.getPage();
    surveyName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void close()
  {
    surveySearchPage.navigate();
    surveySearchPage.search(surveyName);
    surveySearchPage.deleteFirstRow();

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.BLUE})
  @ReportingInfo(firefoxIssue = "RA-40655", chromeIssue = "RA-40216")
  public void showAndHideAttributes()
  {
    newSurveyPage.navigate();
    newSurveyPage.setAttendeeSurveySettings(surveyName);

    // Add a select
    String textBoxName = dataGenerator.generateName();
    newSurveyPage.addNewAttribute(EditFormPage.ATTR_TYPE.SELECT, textBoxName);
    newSurveyPage.submitForm();

    surveySearchPage.search(surveyName);
    surveySearchPage.editItem();

    editSurveyPage.openFormByPos(1);

    Assert.assertTrue(editSurveyPage.validateTrashIcon(1), "Trash icon is not visible");
  }
}
