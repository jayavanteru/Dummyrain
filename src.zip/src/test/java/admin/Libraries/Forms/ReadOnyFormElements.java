package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class ReadOnyFormElements {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeId;
    String attributeValue;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event A");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createTextField(attributeName, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attributeId = AdminEventAttributesPage.getPage().getAttributeId(attributeName);

        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().editItem();
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();

        attributeValue = dataGenerator.generateName();
        PersistentProfileForm.getPage().setTextAttribute(attributeName, attributeValue);
        PersistentProfileForm.getPage().submit();

        //needs a refresh for form to be editable - it sometimes fails to open.....IDK Y
        PageConfiguration.getPage().refreshPage();
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().expandAttributeByName(attributeName);
        EditFormPage.getPage().makeAttributeReadOnly();
        EditFormPage.getPage().submitForm();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttribute(attributeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33836", firefoxIssue = "RA-35126")
    public void readOnlyFormTextBox() {
        Assert.assertTrue(PersistentProfileForm.getPage().isElementReadOnly(attributeName));
    }
}
