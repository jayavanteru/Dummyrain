package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class FormAttributeFeatureFlag {

  private DataGenerator dataGenerator;
  FormsSearchPage formsSearchPage;
  EditFormPage editFormPage;
  AdminApp adminApp;
  String attributeId, attributeName;

  String[] options = new String[]{"Option 1", "Option 2", "Option 3", "Option 4", "Option 5"};

  @BeforeClass
  public void setup()
  {
    dataGenerator = new DataGenerator();
    adminApp = new AdminApp();
    formsSearchPage = FormsSearchPage.getPage();
    editFormPage = EditFormPage.getPage();

    attributeName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40397", chromeIssue = "RA-40219")
  public void formFeatureFlag()
  {
    // Create Attribute
    attributeId = adminApp.createSelectAttribute(attributeName, options, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

    // Create Form
    String formName = dataGenerator.generateName();
    String formId = adminApp.createForm(formName, "Attendee", attributeName);
    formsSearchPage.editItem();
    editFormPage.expandAttributeByName(attributeName);
    Assert.assertTrue(editFormPage.validateTrashIcon(1), "Trash icon is not visible");

    // Delete
    String attributeId = editFormPage.getExpandedAttributeId();
    editFormPage.deleteExpandedAttribute();
    adminApp.deleteForm(formId);
    adminApp.deleteAttribute(attributeId);
  }
}
