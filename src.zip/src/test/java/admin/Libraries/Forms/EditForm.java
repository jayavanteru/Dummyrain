package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.libraries.NewFormPage;
import logs.ReportingInfo;
import org.openqa.selenium.TimeoutException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import static apps.admin.adminPageObjects.libraries.EditFormPage.ATTR_TYPE;

public class EditForm {

    String formId;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void delete() {
        try{FormsSearchPage.getPage().deleteForm(formId);}
        catch (TimeoutException e){
            EditFormPage editFormPage = EditFormPage.getPage();
            editFormPage.navigateTo(formId);
            editFormPage.toggleExpandingSettings();
            editFormPage.setFormCode("");
            editFormPage.submitForm();
            FormsSearchPage.getPage().deleteForm(formId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25939", chromeIssue = "RA-25937")
    public void editNewForm() {
        final HashSet<String> attributeIds = new HashSet<>();
        final ArrayList<String> attributeNames = new ArrayList<>();
        final NewFormPage newFormPage = NewFormPage.getPage();
        final EditFormPage editFormPage = EditFormPage.getPage();
        final FormsSearchPage searchPage = FormsSearchPage.getPage();
        final DataGenerator dataGenerator = new DataGenerator();
        String formName = dataGenerator.generateName();
        final String formCode = dataGenerator.generateString(5);


        searchPage.navigate();
        searchPage.addItem();

        newFormPage.setAttendeeFormSettings(formName, formCode);

        //add all attribute types
        for (ATTR_TYPE type : new ATTR_TYPE[]{ATTR_TYPE.TEXT_AREA, ATTR_TYPE.TEXT_BOX,
                ATTR_TYPE.SELECT, ATTR_TYPE.RADIO, ATTR_TYPE.CHECKBOX}) {
            String name = dataGenerator.generateName();
            attributeNames.add(name);
            newFormPage.addNewAttribute(type, name);
        }

        newFormPage.submitForm();

        //search for new form
        searchPage.search(formName);
        //top result should be the one we just created
        HashMap<String, String> searchRow = searchPage.getResults().get(0);

        formId = searchRow.get("id");
        Assert.assertEquals(searchRow.get("name"), formName, "created form info not in the search results");
        Assert.assertEquals(searchRow.get("code"), formCode, "created form info not in the search results");
        Assert.assertEquals(searchRow.get("type"), "Attendee", "created form info not in the search results");

        EditFormPage.getPage().navigateTo(formId);

        for (String attrName : attributeNames) {
            editFormPage.expandAttribute(attrName);

            int size = attributeIds.size();
            attributeIds.add(newFormPage.getExpandedAttributeId());
            Assert.assertTrue(attributeIds.size() > size, "did not add all the expected attributes to the form");
        }

        formName = dataGenerator.generateName();
        editFormPage.toggleExpandingSettings();
        editFormPage.setFormName(formName);
        editFormPage.submitForm();

        searchPage.search(formName);
        searchRow = searchPage.getResults().get(0);

        Assert.assertEquals(searchRow.get("name"), formName, "created form info not in the search results");
        Assert.assertEquals(searchRow.get("code"), formCode, "created form info not in the search results");
        Assert.assertEquals(searchRow.get("type"), "Attendee", "created form info not in the search results");
    }
}
