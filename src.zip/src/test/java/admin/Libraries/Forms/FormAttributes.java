package admin.Libraries.Forms;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class FormAttributes {

  private DataGenerator dataGenerator;
  FormsSearchPage formsSearchPage;
  EditFormPage editFormPage;
  CreateAttendeePage createAttendeePage;
  EditAttendeePage editAttendeePage;
  CreateGlobalAttributePage createGlobalAttributePage;
  AdminEventAttributesPage adminEventAttributesPage;
  AdminApp adminApp;
  String[] options = new String[]{"Option 1", "Option 2", "Option 3", "Option 4", "Option 5"};
  String attributeId, attributeName;
  String emailTest = "nic_test_rainfocus_email@gmail.com";
  String emailTestPass = "Rainclouds123$";

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    adminApp = new AdminApp();
    formsSearchPage = FormsSearchPage.getPage();
    editFormPage = EditFormPage.getPage();
    createAttendeePage = CreateAttendeePage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    createGlobalAttributePage = CreateGlobalAttributePage.getPage();
    adminEventAttributesPage = AdminEventAttributesPage.getPage();

    attributeName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40847", chromeIssue = "RA-40220")
  public void showFormAttributesGlobal()
  {
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");

    // Create Attribute
    String attributeName = dataGenerator.generateName();
    createGlobalAttributePage.navigate();
    createGlobalAttributePage.setType("multiple");
    createGlobalAttributePage.setType("single");
    createGlobalAttributePage.setInputType("radio");
    createGlobalAttributePage.setEntityType("attendee");
    createGlobalAttributePage.setName(attributeName);
    createGlobalAttributePage.setDisplayName(attributeName);
    createGlobalAttributePage.addAnswers(options);
    createGlobalAttributePage.clickSaveButton();

    // Create Form
    String formName = dataGenerator.generateName();
    String formId = adminApp.createForm(formName, "Attendee", attributeName);
    formsSearchPage.editItem();
    Utils.sleep(2000);
    editFormPage.expandAttributeByName(attributeName);
    Assert.assertTrue(editFormPage.validateTrashIcon(1), "Trash icon is not visible");

    // Delete
    String attributeId = editFormPage.getExpandedAttributeId();
    editFormPage.deleteExpandedAttribute();
    adminApp.deleteForm(formId);
    adminApp.deleteAttribute(attributeId);
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-41088", chromeIssue = "RA-32715")
  public void lockedAttributes()
  {
    String originalAutomationUser = PropertyReader.instance().getProperty("adminEmail");
    String originalAutomationPass = PropertyReader.instance().getProperty("adminPassword");

    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);

    // Create Attribute
    attributeId = adminApp.createSelectAttribute(attributeName, options, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

    // Create Form
    String formName = dataGenerator.generateName();
    String formId = adminApp.createForm(formName, "Attendee", attributeName);
    formsSearchPage.editItem();
    editFormPage.lockAttributeByAttributeName(attributeName);
    editFormPage.submitForm();

    AdminLoginPage.getPage().logout();
    PropertyReader.instance().setProperty("adminEmail", emailTest);
    PropertyReader.instance().setProperty("adminPassword", emailTestPass);
    AdminLoginPage.getPage().login();

    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);

    // Validate locked attribute
    formsSearchPage.navigate();
    formsSearchPage.search(formName);
    formsSearchPage.editItem();
    editFormPage.expandLockedAttributeByName(attributeName);
    Assert.assertTrue(editFormPage.isTypeSelectDisabled(), "Type select must not be clickable");
    Assert.assertFalse(editFormPage.isQuestionNameEditable(), "Question Name field must not be editable");
    Assert.assertFalse(editFormPage.isReadOnlyCheckEnabled(), "Read-only check must not be clickable");
    Assert.assertTrue(editFormPage.isTrashIconDisabled(), "Trash icon must not be clickable");
    Assert.assertTrue(editFormPage.isCopyIconDisabled(), "Copy icon must not be clickable");

    // Delete
    String attributeId = editFormPage.getExpandedAttributeIdLockedAttribute();
    adminApp.deleteAttribute(attributeId);
    adminApp.deleteForm(formId);

    PropertyReader.instance().setProperty("adminEmail", originalAutomationUser);
    PropertyReader.instance().setProperty("adminPassword", originalAutomationPass);
  }
}
