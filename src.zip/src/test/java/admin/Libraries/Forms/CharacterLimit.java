package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class CharacterLimit {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeValue;
    String attributeId;
    String attendeeEmail;
    String attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event F");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeId = adminApp.createTextFieldAttribute(attributeName, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

        //create attendee
        attendeeEmail = dataGenerator.generateEmail();
        attendeeEmail = adminApp.createAttendee(attendeeEmail);
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33838", firefoxIssue = "RA-35479")
    public void textBoxCharacterLimit() {
        attributeValue = dataGenerator.generateString(10);
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().setCharacterLimit(attributeName, "10");
        EditFormPage.getPage().submitForm();
        PersistentProfileForm.getPage().setTextAttribute(attributeName, attributeValue);
        PersistentProfileForm.getPage().submit();
        Assert.assertTrue(PersistentProfileForm.getPage().textValueExists(attributeName, attributeValue));
        attributeValue = dataGenerator.generateString(11);
        PersistentProfileForm.getPage().setTextAttribute(attributeName, attributeValue);
        PersistentProfileForm.getPage().submit();
        Assert.assertTrue(PersistentProfileForm.getPage().characterLimitExists(attributeName, "10"));
    }
}
