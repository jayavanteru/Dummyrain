package admin.Libraries.Forms;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class BasicsForm {

    DataGenerator dataGenerator = new DataGenerator();
    String formName = dataGenerator.generateName();

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");

        //create form with attribute on it
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().addItem();
        EditFormPage.getPage().setFormName(formName);
        EditFormPage.getPage().setRenderAsSubmit();
        EditFormPage.getPage().setEntityTypeToAttendee();
        EditFormPage.getPage().submitForm();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19168", firefoxIssue = "RA-25805")
    public void deleteForm(){
        //delete form
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);
        Assert.assertTrue(FormsSearchPage.getPage().formExists(formName), "FORM WAS NOT CREATED");
        FormsSearchPage.getPage().deleteFormByName(formName);
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);

        //assert that form does not exist
        Assert.assertFalse(FormsSearchPage.getPage().formExists(formName));
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }
}