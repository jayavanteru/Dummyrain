package admin.Libraries.Widgets;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetPage;
import apps.admin.adminPageObjects.libraries.WidgetSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class OldWidgetFramework {

    private String oldJson;
    private String apiToken;
    private String[] errors;
    private boolean cleanUp = false;
    private String NAME_ERROR = "Name is required";
    private String API_ERROR = "Api Token is required";
    private DataGenerator dataGenerator = new DataGenerator();
    private String WIDGET_NAME = dataGenerator.generateName() + " Widget";
    private String adminUrl = PageConfiguration.getPage().getData("adminUrl");
    private final String JSON = "{\"type\": \"collection\",\"jwtCookieName\": \"rfjwt\",\"headerTextMappings\": {\"sessions\": \"Sessions\"}}";
    private final String NEW_JSON = "\"sessions\": \"Test Widget Config\"";
    private final String REGEX_JSON = "\"sessions\":.*";

    private final EditWidgetPage config = EditWidgetPage.getPage();
    private final WidgetSearchPage search = WidgetSearchPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        search.navigate();
        search.addItem();
    }

    @AfterClass
    public void quit() {
        if(cleanUp) {
            search.navigate();
            search.searchWidgets(apiToken);
            search.deleteWidget();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-37092", chromeIssue = "RA-19884")
    public void addAndEditWidget() {
            config.saveWidgetConfig();
            errors = config.getErrors();
        Assert.assertEquals(errors[0], NAME_ERROR, "Incorrect error");
        Assert.assertEquals(errors[1], API_ERROR, "Incorrect error");

            config.setWidgetName(WIDGET_NAME);
            config.generateApiToken();
            config.setEventCopy(true);
            apiToken = config.getApiToken();

            config.setWidgetJson(JSON);
            config.saveWidgetConfig();
            cleanUp = true;

        Assert.assertEquals(PageConfiguration.getPage().getCurrentUrl(), adminUrl + "/rain.focus#widgets.do", "Widget was not saved");

            search.searchWidgets(WIDGET_NAME);
            search.editItem();

            oldJson = config.getWidgetJson();
        Assert.assertEquals(config.getWidgetName(), WIDGET_NAME, "Widget saved name does not match");
        Assert.assertEquals(config.getApiToken(), apiToken, "Api token saved does not match");
        Assert.assertEquals(config.getWidgetJson().replaceAll("\n", "").replaceAll(" ", ""), JSON.replaceAll(" ", ""), "Json saved does not match");
        Assert.assertTrue(config.isEventCopyChecked(), "Event copy should be checked");

            String newWidgetName = WIDGET_NAME + "123abc";
            config.setWidgetName(newWidgetName);
            config.setEventCopy(false);

            config.setWidgetJson(oldJson.replaceFirst(REGEX_JSON, NEW_JSON));
            String newWidgetJson = config.getWidgetJson();

            config.saveWidgetConfig();

            search.searchWidgets(apiToken);
            search.editItem();

        Assert.assertEquals(config.getWidgetName(), newWidgetName, "Modified widget name was not saved");
        Assert.assertEquals(config.getApiToken(), apiToken, "Api should not have changed");
        Assert.assertEquals(config.getWidgetJson().replaceAll("\n", "").replaceAll(" ", ""), newWidgetJson.replaceAll(" ", ""), "Json saved does not match");
        Assert.assertFalse(config.isEventCopyChecked(), "Event copy should NOT be checked");
    }
}
