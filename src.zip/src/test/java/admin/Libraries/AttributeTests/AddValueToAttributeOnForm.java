package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class AddValueToAttributeOnForm {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String []{"One"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttribute(attributeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-32270", firefoxIssue = "RA-35926")
    public void addValueToAttributeOnForm() {
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().editItem();

        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().addAttributeValues("Two", "Three", "Four", "Five");
        EditFormPage.getPage().submitForm();

        EditEventAttributePage.getPage().navigate(attributeId);
        Assert.assertTrue(EditEventAttributePage.getPage().valueExists("Two"), "VALUE 'TWO' DID NOT EXIST");
        Assert.assertTrue(EditEventAttributePage.getPage().valueExists("Three"), "VALUE 'THREE' DID NOT EXIST");
        Assert.assertTrue(EditEventAttributePage.getPage().valueExists("Four"), "VALUE 'FOUR' DID NOT EXIST");
        Assert.assertTrue(EditEventAttributePage.getPage().valueExists("Five"), "VALUE 'FIVE' DID NOT EXIST");//remove attribute

        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().editItem();

        PersistentProfileForm.getPage().edit();

        EditFormPage.getPage().expandAttributeByName(attributeName);
        EditFormPage.getPage().deleteExpandedAttribute();
        EditFormPage.getPage().submitForm();
    }
}
