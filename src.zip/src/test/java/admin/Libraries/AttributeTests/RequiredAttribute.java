package admin.Libraries.AttributeTests;


import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class RequiredAttribute {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName, attributeId, attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        NavigationBar.getPage().collapse();

        //create checkbox
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(),  new String[]{"One", "Two"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

        //add attribute to form
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        if(!AttendeeSearchPage.getPage().isAnySearchResults()){
            attendeeId = adminApp.createAttendee(dataGenerator.generateEmail());
        } else {
            AttendeeSearchPage.getPage().editItem();
        }
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().toggleRequiredSetting();
        EditFormPage.getPage().submitForm();
    }

    @AfterClass
    public void afterClass() {
        //remove attribute from form
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().expandAttributeByName(attributeName);
        EditFormPage.getPage().deleteExpandedAttribute();
        EditFormPage.getPage().submitForm();

        adminApp.deleteAttribute(attributeId);
        if(!(attendeeId == (null))){
            adminApp.deleteAttendee(attendeeId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33808", firefoxIssue = "RA-36914")
    public void requiredAttribute() {
        PersistentProfileForm.getPage().submit();
        Assert.assertTrue(PersistentProfileForm.getPage().attributeIsRequired(attributeName), "ATTRIBUTE WAS NOT REQUIRED");
    }
}
