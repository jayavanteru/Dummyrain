package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormModalPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import static apps.admin.adminPageObjects.libraries.CreateEventAttributePage.AUDIENCE_TYPES;

public class Attributes {

    private String attributeId;
    private String attendeeId;
    private AdminApp adminApp;

    @BeforeClass
    public void login() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");

        attendeeId = adminApp.createAttendee();
    }

    @AfterClass
    public void quit() {
        adminApp.deleteAttendee(attendeeId);
        if (attributeId != null) {
            adminApp.deleteAttribute(attributeId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = { ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25934", chromeIssue = "RA-25933")
    public void textBoxAttributeTest() {
        final CreateEventAttributePage createAttribute = CreateEventAttributePage.getPage();
        final EditEventAttributePage editAttribute = EditEventAttributePage.getPage();
        final AdminEventAttributesPage attributeSearchPage = AdminEventAttributesPage.getPage();
        final AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB7);
        final EditFormModalPage formModalPage = EditFormModalPage.getPage(EditFormModalPage.BASE_PAGE.TAB7);
        final DataGenerator generate = new DataGenerator();
        String name = generate.generateName();

        createAttribute.navigate();
        createAttribute.createTextField(name, AUDIENCE_TYPES.Exhibitor, AUDIENCE_TYPES.Attendee);
        createAttribute.saveAttribute();

        attributeSearchPage.searchAttribute(name);
        attributeId = attributeSearchPage.getAttributeId(name);
        attributeSearchPage.editItem();

        Utils.waitForTrue(()-> editAttribute.getName().equals(name));
        Assert.assertEquals(editAttribute.getName(), name, "search did not get the right attribute");

        //make sure you can add the attribute to a form
        customTab.navigate(attendeeId);
        customTab.editForm();
        formModalPage.addExistingAttribute(name);
        Assert.assertEquals(formModalPage.getExpandedAttributeId(), attributeId, "did not add the right attribute on the form");

        formModalPage.submitForm();
        Utils.sleep(200, "let the submit go through");
        PageConfiguration.getPage().refreshPage();

        Assert.assertTrue(customTab.isFieldVisible(name), "adding field to the form, not visible");

        //use the attribute on the form
        String text = generate.generateString();
        customTab.enterTextInField(attributeId, text);
        customTab.submit();
        Utils.sleep(200, "let the submit go through");
        PageConfiguration.getPage().refreshPage();

        Assert.assertEquals(customTab.getValueInField(attributeId), text, "did not save the right value in the text field");

        //clear value
        Utils.sleep(1000, "time to load before clearing");
        customTab.enterTextInField(attributeId, "");
        customTab.submit();
        Utils.sleep(200, "let the submit go through");

        //remove the attribute from the form
        customTab.editForm();
        formModalPage.expandAttribute(name);
        formModalPage.deleteExpandedAttribute();
        formModalPage.submitForm();

        //now delete the attribute
        attributeSearchPage.navigate();
        attributeSearchPage.deleteAttribute(attributeId);

        attributeSearchPage.searchAttribute(name);
        Assert.assertFalse(attributeSearchPage.anyResults(), "did not delete the attribute");
        attributeId = null;
    }
}
