package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class PVO {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName, attributeId, attendeeEmail, attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event B");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        //deletion
        adminApp.deleteAttribute(attributeId);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-32300", firefoxIssue = "RA-38068")
    public void PVO() {
        //create checkbox
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{"One", "Two", "Three"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

        //create PVO
        CreateEventAttributePage.getPage().navigate(attributeId);
        CreateEventAttributePage.getPage().usePrimaryValueOutput();
        CreateEventAttributePage.getPage().setHierarchy();
        CreateEventAttributePage.getPage().submitPVOModal();

        CreateEventAttributePage.getPage().saveAttribute();

        //create attendee
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());

        //add attribute to form
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();

        //set values
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "One");
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Two");
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Three");
        PersistentProfileForm.getPage().submit();

        Assert.assertTrue(PersistentProfileForm.getPage().valueIsPVO(attributeName, "One"), "PVO 'One' DID NOT RENDER");

        //set values for pvo 2
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "One");
        PersistentProfileForm.getPage().submit();

        Assert.assertTrue(PersistentProfileForm.getPage().valueIsPVO(attributeName, "Two"), "PVO 'Two' DID NOT RENDER");

        //set values for pvo 3
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Two");
        PersistentProfileForm.getPage().submit();

        Assert.assertTrue(PersistentProfileForm.getPage().valueIsPVO(attributeName, "Three"), "PVO 'Three' DID NOT RENDER");

        //remove attribute from form
        PageConfiguration.getPage().refreshPage();

        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().expandAttributeByName(attributeName);
        EditFormPage.getPage().deleteExpandedAttribute();
        EditFormPage.getPage().submitForm();
    }
}
