package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Encrypted {

  private final CreateEventAttributePage attributePage = CreateEventAttributePage.getPage();

  @BeforeClass
  public void beforeClass() {
    AdminLoginPage.getPage().login();
  }

  @AfterClass
  public void afterClass() {

    PageConfiguration.getPage().quit();
  }

  @Test(groups = ReportingInfo.DATATRON)
  @ReportingInfo(firefoxIssue = "RA-29618", chromeIssue = "RA-38829")
  public void checkEncrypted(){

    attributePage.navigate();

    attributePage.clickShowAdvanced();

    attributePage.assertEncryptedCheckboxDisabled();

    attributePage.selectRadio();

    attributePage.assertEncryptedCheckboxDisabled();

    attributePage.selectTextArea();

    attributePage.assertEncryptedCheckboxEnabled();

    attributePage.clickEncryptedCheckbox();

    attributePage.assertLimitedResponseTypes();

    attributePage.clickEncryptedCheckbox();

    attributePage.selectCheckBox();

    attributePage.assertEncryptedCheckboxDisabled();

    attributePage.clickEncryptedCheckboxInfoIcon();

    attributePage.assertInfoPopoverVisible();

    attributePage.clickShowAdvanced();

    attributePage.assertEncryptedCheckboxHidden();

  }
}
