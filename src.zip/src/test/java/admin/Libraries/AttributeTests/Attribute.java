package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Attribute {
    AdminApp adminApp = new AdminApp();
    String attributeName = new DataGenerator().generateName();
    String attributeID;

    @BeforeClass
    public void setUp() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event E");
        attributeID = adminApp.createTextArea(attributeName, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19159", firefoxIssue = "RA-25815")
    public void createAttribute(){
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        Assert.assertTrue(AdminEventAttributesPage.getPage().attributeExists(attributeID));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19161", firefoxIssue = "RA-25813")
    public void deleteAttribute(){
        String attributeName = new DataGenerator().generateName();
        String attributeID;
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().addItem();
        CreateEventAttributePage.getPage().createTextArea(attributeName, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        attributeID =  AdminEventAttributesPage.getPage().getAttributeId(attributeName);
        AdminEventAttributesPage.getPage().deleteFirstAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        Assert.assertFalse(AdminEventAttributesPage.getPage().attributeExists(attributeID));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19160", firefoxIssue = "RA-25814")
    public void editAttribute(){
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        AdminEventAttributesPage.getPage().editItem();
        String newAttributeName = new DataGenerator().generateName();
        attributeName = newAttributeName;
        EditEventAttributePage.getPage().setName(attributeName);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        Assert.assertTrue(AdminEventAttributesPage.getPage().attributeExists(attributeID));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24337", firefoxIssue = "RA-25818")
        public void addAttributeToAttendee(){
        //create attendee
        String attendeeEmail = new DataGenerator().generateEmail();
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().addItem();
        CreateAttendeePage.getPage().fillOutForm(attendeeEmail ,new DataGenerator().generateName(), new DataGenerator().generateName());

        //add attribute to attendee
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();
        Assert.assertTrue(PersistentProfileForm.getPage().attributeExists(attributeID));

        //delete attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        AttendeeSearchPage.getPage().deleteFirstRecord();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24337", firefoxIssue = "RA-25818")
    public void addAttributeToForm(){
        //add attribute to form
        String formName = new DataGenerator().generateName();
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().addItem();
        EditFormPage.getPage().setFormName(formName);
        EditFormPage.getPage().setRenderAsInline();
        EditFormPage.getPage().setEntityTypeToAttendee();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();
        FormsSearchPage.getPage().search(formName);
        FormsSearchPage.getPage().editItem();

        //Assert attribute exists on form
        Assert.assertTrue(EditFormPage.getPage().attributeExists(attributeID));

        //delete form
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formName);
        FormsSearchPage.getPage().deleteForm(FormsSearchPage.getPage().getId(formName));
    }

    @AfterClass
    public void tearDown(){
        adminApp.deleteAttribute(attributeID);
        PageConfiguration.getPage().quit();
    }
}
