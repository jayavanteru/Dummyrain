package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class AppliedValue {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeId;
    String ruleName;
    String ruleId;

    @BeforeClass
    public void beforeClass() {

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event C");
        NavigationBar.getPage().collapse();

        //create checkbox
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{"One", "Two"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);

        //create rule
        AdminRuleCreatePage.getPage().navigate();
        ruleId = adminApp.createRule(ruleName = dataGenerator.generateName(), "Attendees", attributeName +": Two", new Criteria[]{new Criteria(attributeName, "equal to", "One")}, "");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31588", firefoxIssue = "RA-36573")
    public void appliedValue() {
        //open attribute
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        AdminEventAttributesPage.getPage().editItem();

        //assert
        Assert.assertTrue(CreateEventAttributePage.getPage().attributeIsAppliedValue("Two", ruleName), "VALUE WAS NOT APPLIED");
    }
}
