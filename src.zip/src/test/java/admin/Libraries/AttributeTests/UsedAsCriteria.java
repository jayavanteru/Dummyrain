package admin.Libraries.AttributeTests;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class UsedAsCriteria {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeValue1;
    String attributeValue2;
    String attributeId;
    String ruleName;
    String ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event A");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue1 = dataGenerator.generateName();
        attributeValue2 = dataGenerator.generateName();
        CreateEventAttributePage.getPage().navigate();
        attributeId = adminApp.createCheckBoxAttribute(attributeName, new String[]{attributeValue1, attributeValue2}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);

        //create rule
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage();
        ruleName = dataGenerator.generateName();
        ruleId = adminApp.createRule(ruleName, "Attendees", attributeName+": "+ attributeValue2, new Criteria[]{new Criteria(attributeName, "equal to", attributeValue1)}, "");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31592", firefoxIssue = "RA-35151")
    public void usedAsCriteria() {
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        AdminEventAttributesPage.getPage().editItem();
        Assert.assertTrue(CreateEventAttributePage.getPage().valueUsedInCriteria(attributeValue1, ruleName));
        CreateEventAttributePage.getPage().clickUsedInCriteria(attributeValue1);
        CreateEventAttributePage.getPage().openUsedInCriteriaRule(attributeValue1, ruleName);
        PageConfiguration.getPage().switchToTab(1);

        PageConfiguration.getPage().justWait();
        PageConfiguration.getPage().waitForPageLoad();
        PageConfiguration.getPage().justWait();
        AdminRuleCreatePage.getPage().waitForPageRender();
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains(ruleId));
    }
}

