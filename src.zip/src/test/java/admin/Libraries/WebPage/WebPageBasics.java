package admin.Libraries.WebPage;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWebPagePage;
import apps.admin.adminPageObjects.libraries.NewWebPagePage;
import apps.admin.adminPageObjects.libraries.PreviewWebPagePage;
import apps.admin.adminPageObjects.libraries.WebPageSearchPage;
import interaction.pageObjects.rfBy;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class WebPageBasics {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String webPageName, webPageId,
            pageContent;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @BeforeMethod
    public void beforeMethod() {
        webPageName = dataGenerator.generateName();
        pageContent = dataGenerator.generateString(10);
        //create web page
        NewWebPagePage.getPage().navigate();
        NewWebPagePage.getPage().setName(webPageName);
        NewWebPagePage.getPage().setUrl(dataGenerator.generateString(10));
        NewWebPagePage.getPage().setType("Email Layout");
        NewWebPagePage.getPage().addTextToWYSIWYG(pageContent);
        NewWebPagePage.getPage().setKeyWords("First Name","Last Name","Email");
        NewWebPagePage.getPage().clickSaveAndPublish();
        WebPageSearchPage.getPage().searchFor(webPageName);
        webPageId = WebPageSearchPage.getPage().getId(webPageName);
    }

    @AfterMethod
    public void afterMethod() {
        WebPageSearchPage.getPage().navigate();
        WebPageSearchPage.getPage().searchFor(webPageName);
        if(WebPageSearchPage.getPage().webPageExists(webPageName)){
            adminApp.deleteCustomPage(webPageId);
        }
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31596", firefoxIssue = "RA-31908")
    public void createWebPage(){
        WebPageSearchPage.getPage().navigate();
        WebPageSearchPage.getPage().searchFor(webPageName);
        Assert.assertTrue(WebPageSearchPage.getPage().webPageExists(webPageName), "WEB PAGE DOES NOT EXIST");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31597", firefoxIssue = "RA-32028")
    public void deleteWebPage(){
        WebPageSearchPage.getPage().navigate();
        WebPageSearchPage.getPage().searchFor(webPageName);
        WebPageSearchPage.getPage().deleteWebPage(webPageName);
        WebPageSearchPage.getPage().searchFor(webPageName);
        Assert.assertFalse(WebPageSearchPage.getPage().webPageExists(webPageName), "WEB PAGE WAS NOT DELETED");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31598", firefoxIssue = "RA-32031")
    public void previewWebPage(){
        WebPageSearchPage.getPage().navigate();
        WebPageSearchPage.getPage().searchFor(webPageName);
        WebPageSearchPage.getPage().selectWebPage(webPageName);
        EditWebPagePage.getPage().clickPreview();
        PageConfiguration.getPage().switchToTab(1);
        Assert.assertTrue(PreviewWebPagePage.getPage().contentRendered(pageContent), "WEB PAGE DID NOT RENDER CORRECTLY");
        PageConfiguration.getPage().switchToTab(0);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31599", firefoxIssue = "RA-32041")
    public void webPageKeyWords(){
        WebPageSearchPage.getPage().navigate();
        WebPageSearchPage.getPage().searchFor(webPageName);
        WebPageSearchPage.getPage().selectWebPage(webPageName);
        EditWebPagePage.getPage().clickPreview();
        PageConfiguration.getPage().switchToTab(1);
        Assert.assertTrue(PreviewWebPagePage.getPage().contentRendered("[%attendee.firstname%]"), "WEB PAGE DID NOT RENDER CORRECTLY");
        Assert.assertTrue(PreviewWebPagePage.getPage().contentRendered("[%attendee.lastname%]"), "WEB PAGE DID NOT RENDER CORRECTLY");
        Assert.assertTrue(PreviewWebPagePage.getPage().contentRendered("[%attendee.email%]"), "WEB PAGE DID NOT RENDER CORRECTLY");
        PageConfiguration.getPage().switchToTab(0);
    }
}
