package admin.Libraries.WebPage;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewWebPagePage;
import apps.admin.events.EventSearchPage;
import apps.admin.events.NewEventPage;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

public class HideButton
{
  final String AM = "am";
  final String PM = "pm";

  @BeforeClass
  public void beforeClass() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", "Current Day Event - AUTOMATION");
  }

  @AfterClass
  public void afterClass() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(chromeIssue = "RA-40174", firefoxIssue = "RA-42824")
  public void testHideButton()
  {
    // code is hidejoinbutton for webpage
    EventSearchPage searchPage = EventSearchPage.getPage();
    searchPage.navigate();
    searchPage.getEventByNameOrCodeOldAdmin("Current Day Event - AUTOMATION");
    NewEventPage eventPage = NewEventPage.getPage();
    String eventId = eventPage.getEventIdFromUrl();
    eventPage.setStartDate();
    eventPage.setEndDateToCurrentDay();
    // note: for this to work, timezone needs to be mountain

    // make sure event start/end date are current date
    ZonedDateTime now = ZonedDateTime.now();
    String timezoneId = now.getZone().getId();
    // assuming that if we're not running this locally, the server will be in PST. Cross your fingers.
    if (StringUtils.equals(timezoneId,"America/Denver"))
      eventPage.setTimezone("US/Mountain");
    else
      eventPage.setTimezone("US/Pacific");

    // setting start/end time. Start time has to be after now()
    int hoursToAddOnStartTime = 1;
    List<String> startTime = getStartTime(now, hoursToAddOnStartTime);
    eventPage.setStartTime(startTime.get(0), startTime.get(1) == PM);

    List<String> endTime = getEndTime(now, hoursToAddOnStartTime);
    eventPage.setEndTime(endTime.get(0), endTime.get(1) == PM);
    eventPage.saveEvent();

    // making sure event webinar access window has time
    LegacyEventSettings eventSettings = LegacyEventSettings.getPage();
    eventSettings.navigate(eventId);
    eventSettings.setWebinarAccessWindow("61");
    eventSettings.clickSubmit();

    // looking at the webpage to see if button is there, should be
    NewWebPagePage webPagePage = NewWebPagePage.getPage();
    webPagePage.openUrlInNewTab("https://events.dev.rainfocus.com/pages/ibm/currentday/hidejoinbutton");
    webPagePage.refreshPage();
    Assert.assertTrue(webPagePage.isTextOnPage("Cool Button"), "Button is not on page");

    // going back to event settings to change minutes before you can access the button
    webPagePage.switchToTab(0);
    eventSettings.navigate(eventId);
    eventSettings.setWebinarAccessWindow("1");
    eventSettings.clickSubmit();

    // looking at webpage again, shouldn't be there
    webPagePage.switchToTab(1);
    webPagePage.refreshPage();
    Assert.assertTrue(webPagePage.isTextOnPage("Its not time yet foo!"), "Button is on page when its not supposed to be");
  }

  private List<String> getEndTime(ZonedDateTime now, int hoursToAddOnStartTime)
  {
    // returns -> [time, am/pm]
    // adding an additional hour from start time
    int hoursToAddOnEndTime = 1 + hoursToAddOnStartTime;

    List list = new ArrayList();
    String minsToAppend = ":00";
    int mins = now.getMinute();
    int twentyFourHour = now.getHour();
    int twelveHour = 0;
    if (twentyFourHour > 12)
      twelveHour = twentyFourHour - 12;

    // if twentyFourHour is 12 (noon/12pm), want time to be 2pm
    if (twentyFourHour == 12)
    {
      list.add("2:00");
      list.add(PM);
      return list;
    }
    // if twentyFourHour is 11am, want time to be 1pm
    if (twentyFourHour == 11)
    {
      list.add("1:00");
      list.add(PM);
      return list;
    }
    // if twentyFourHour is 10am, want time to be 12pm
    if (twentyFourHour == 10)
    {
      list.add("12:00");
      list.add(PM);
      return list;
    }
    // if twelveHour is 12 (midnight/12am), want time to be 2am
    if (twelveHour == 12)
    {
      list.add("2:00");
      list.add(AM);
      return list;
    }
    // if twelveHour is 11pm, want time to be 1am
    if (twelveHour == 11)
    {
      list.add("1:00");
      list.add(AM);
      return list;
    }
    // if twelveHour is 10pm, want time to be 12am
    if (twentyFourHour == 10)
    {
      list.add("12:00");
      list.add(AM);
      return list;
    }
    // if now is < 10 minutes from start time, add 30 mins to time
    if (mins >= 50)
      minsToAppend = ":30";

    if (twelveHour == 0)
    {
      // must be AM
      String startTime = (twentyFourHour + hoursToAddOnEndTime) + minsToAppend;
      list.add(startTime);
      list.add(AM);
      return list;
    }
    String startTime = (twelveHour + hoursToAddOnEndTime) + minsToAppend;
    list.add(startTime);
    list.add(PM);
    return list;
  }

  private List<String> getStartTime(ZonedDateTime now, int hoursToAddOnStartTime)
  {
    // returns -> [time, am/pm]

    List list = new ArrayList();
    String minsToAppend = ":00";
    int twentyFourHour = now.getHour();
    int mins = now.getMinute();
    int twelveHour = 0;
    if (twentyFourHour > 12)
      twelveHour = twentyFourHour - 12;

    // if twentyFourHour is 12 (noon/12pm) we want start time to be 1pm
    if (twentyFourHour == 12)
    {
      list.add("1:00");
      list.add(PM);
      return list;
    }
    // if twentyFourHour is 11am, want time to be 12pm
    if (twentyFourHour == 11)
    {
      list.add("12:00");
      list.add(PM);
      return list;
    }

    // if twelveHour is 12 (midnight/12am) we want start time to be 1am
    if (twelveHour == 12)
    {
      list.add("1:00");
      list.add(AM);
      return list;
    }
    // if twelveHour is 11pm, want time to be 12am
    if (twelveHour == 11)
    {
      list.add("12:00");
      list.add(AM);
      return list;
    }

    // if now is < 10 minutes from start time, add 30 mins to start time
    if (mins >= 50)
      minsToAppend = ":30";

    if (twelveHour == 0)
    {
      // must be AM
      String startTime = (twentyFourHour + hoursToAddOnStartTime) + minsToAppend;
      list.add(startTime);
      list.add(AM);
      return list;
    }
    String startTime = (twelveHour + hoursToAddOnStartTime) + minsToAppend;
    list.add(startTime);
    list.add(PM);
    return list;
  }

}
