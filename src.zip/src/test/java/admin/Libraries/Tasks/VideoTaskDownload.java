package admin.Libraries.Tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.FileTypesSearchPage;
import apps.admin.adminPageObjects.libraries.NewFileTypePage;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class VideoTaskDownload {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String taskName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Task Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-46808", firefoxIssue = "RA-46809")
    public void videoTaskDownload() {
        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search("Task Specific File Download");
        FileTypesSearchPage.getPage().editItem();
        NewFileTypePage.getPage().setAdminFileSize("1");
        NewFileTypePage.getPage().setAdminLimitType("KB");
        NewFileTypePage.getPage().submit();


        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setName(taskName = dataGenerator.generateName());
        NewTaskPage.getPage().setGroup("alpha");
        NewTaskPage.getPage().setEntityType("Exhibitor");
        NewTaskPage.getPage().setType("Download File");
        NewTaskPage.getPage().setFileType("Upload Now/Choose File");
        NewTaskPage.getPage().uploadAFile(Utils.getResourceAsFile("TestMov.mov").getAbsolutePath());
        NewTaskPage.getPage().submit();

        Assert.assertTrue(NewTaskPage.getPage().errorExists("The file cannot exceed 1 KB"), "ERROR DID NOT APPEAR");


        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search("Task Specific File Download");
        FileTypesSearchPage.getPage().editItem();
        NewFileTypePage.getPage().setAdminFileSize("100");
        NewFileTypePage.getPage().setAdminLimitType("MB");
        NewFileTypePage.getPage().submit();

        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setName(taskName = dataGenerator.generateName());
        NewTaskPage.getPage().setGroup("alpha");
        NewTaskPage.getPage().setEntityType("Exhibitor");
        NewTaskPage.getPage().setType("Download File");
        NewTaskPage.getPage().setFileType("Upload Now/Choose File");
        NewTaskPage.getPage().uploadAFile(Utils.getResourceAsFile("TestMov.mov").getAbsolutePath());
        NewTaskPage.getPage().submit();

        TasksSearchPage.getPage().searchFor(taskName);

        Assert.assertTrue(TasksSearchPage.getPage().taskExists(taskName), "TASK WAS NOT CREATED");
        TasksSearchPage.getPage().deleteFirstRecord();
    }
}
