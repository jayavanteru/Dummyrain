package admin.Libraries.Tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeTasksTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class CreateAttendeeTask {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String taskQualifierName, qualifierId,
            attendeeEmail,
            attendeeID,
            taskName, taskId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();

        //create attendee
        attendeeEmail = dataGenerator.generateEmail();
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create task qualifier
        taskQualifierName = dataGenerator.generateName();
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().setName(taskQualifierName);
        NewTaskQualifierPage.getPage().setCriterion(new Criteria("Email", "contains", attendeeEmail));
        NewTaskQualifierPage.getPage().save();
        TaskQualifierSearchPage.getPage().searchFor(taskQualifierName);
        qualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifierName);

        //create task
        taskName = dataGenerator.generateName();
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setName(taskName);
        NewTaskPage.getPage().setEntityType("Attendee");
        NewTaskPage.getPage().setGroup("alpha");
        NewTaskPage.getPage().setType("External URL");
        NewTaskPage.getPage().setDisplayValue(taskName);
        NewTaskPage.getPage().setQualifiers(taskQualifierName);
        NewTaskPage.getPage().setCode(dataGenerator.generateString());
        NewTaskPage.getPage().setExternalURL("google.com");
        NewTaskPage.getPage().submit();

        TasksSearchPage.getPage().search(taskName);
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
    }

    @AfterClass
    public void afterClass() {
        //remove task qualifier from task
        TasksSearchPage.getPage().navigate();
        TasksSearchPage.getPage().search(taskName);
        TasksSearchPage.getPage().select(taskName);
        NewTaskPage.getPage().removeQualifier();
        NewTaskPage.getPage().submit();

        //delete task
        adminApp.deleteTask(taskId);

        //delete task qualifier
        adminApp.deleteTaskQualifier(qualifierId);

        adminApp.deleteAttendee(attendeeID);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27361", firefoxIssue = "RA-27362")
    public void createAttendeeTask() {
        //assert task was assigned to attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().tasksTab();
        Assert.assertTrue(AttendeeTasksTab.getPage().taskExists(taskName));
    }
}
