package admin.Libraries.Tasks;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierModal;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class NetNewTaskQualifiers {
    DataGenerator dataGenerator = new DataGenerator();
    String qualifierName;

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        NavigationBar.getPage().collapse();
    }

    @BeforeMethod
    public void beforeMethod(){
        qualifierName = dataGenerator.generateName();

        //create task qualifier
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setEntityType("Exhibitor");
        NewTaskPage.getPage().createNewQualifier();
        NewTaskQualifierModal.getPage().setName(qualifierName);
        NewTaskQualifierModal.getPage().setCriteria("First Name","equal to",dataGenerator.generateString(10));
        NewTaskQualifierModal.getPage().save();
    }

    @AfterMethod
    public void afterMethod(){
        //delete qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().deleteFirstRecord();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-30389", firefoxIssue = "RA-31058")
    public void createNetNewTaskQualifier(){
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        Assert.assertTrue(TaskQualifierSearchPage.getPage().qualifierExists(qualifierName));
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }
}
