package admin.Libraries.Tasks;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.EditTaskPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.HashMap;

public class Tasks {

  private AdminApp adminApp = new AdminApp();
  private ReportingPage reportingPage = ReportingPage.getPage();

  private String taskName;
  private String taskQualifierName;
  private String formId;
  private String entityTypeName;
  private String typeName;
  private String taskId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

    taskName = new DataGenerator().generateName();
    String formName = "CFP - Session Participant";
    String groupName = "Session";
    entityTypeName = "Session";
    typeName = "Add Participants";
    taskQualifierName = "Accepted Sessions";
    String codeName = new DataGenerator().generateName();

    // Getting Id of the form CFP - Session Participant
    FormsSearchPage.getPage().navigate();
    FormsSearchPage.getPage().search(formName);
    HashMap<String, String> searchRow = FormsSearchPage.getPage().getResults().get(0);
    formId = searchRow.get("id");
    if(formId.contains("&formBuilder")) {
      formId = formId.replace("&formBuilder=true", "");
    }

    // create a task
    NewTaskPage.getPage().navigate();
    NewTaskPage.getPage().setName(taskName);
    NewTaskPage.getPage().setGroup(groupName);
    NewTaskPage.getPage().setEntityType(entityTypeName);
    NewTaskPage.getPage().setType(typeName);
    NewTaskPage.getPage().setQualifiers(taskQualifierName);
    NewTaskPage.getPage().setCode(codeName);
    NewTaskPage.getPage().setAddParticipantForm(formId);
    NewTaskPage.getPage().submit();
  }

  @AfterClass
  public void tearDown() {
    deleteTask();
    PageConfiguration.getPage().quit();
  }

  private void deleteTask() {
    if (taskId != null) {
      //remove the qualifier for deleting
      EditTaskPage.getPage().navigate(taskId);
      EditTaskPage.getPage().removeQualifiers();
      EditTaskPage.getPage().submit();
      //delete task
      adminApp.deleteTask(taskId);
      taskId = null;
    }
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-23245", firefoxIssue = "RA-20482")
  public void CreateNewTask() {
    //get the task qualifier id and task id
    TasksSearchPage.getPage().navigate();
    taskId = TasksSearchPage.getPage().getTaskId(taskName);
    TaskQualifierSearchPage.getPage().navigate();
    String taskQualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifierName);

    // Deleting current task
    deleteTask();

    // History Tracking: Tasks
    reportingPage.navigateTo();
    reportingPage.clickOnReport("History Tracking: Tasks");
    if (reportingPage.isPaginated()) {
      reportingPage.selectLastPage();
    }

    String expectedReportAction = "delete";
    String[] expectedReportProperties = { "config", "typeValue", "name", "type", "entityType", "qualifierId" };
    String[] expectedReportOldValue = { "{\"part-form-for-existing-attendees\":{}}", formId, taskName, typeName, entityTypeName, taskQualifierId};
    String expectedSubmitterName = "TROGDOR automation";
    String[] rows = {"0", "1", "2", "3", "5", "7"};

    String reportAction;
    String reportProperty;
    String reportOldValue;
    String reportSubmitterName;

    for (int index = 0; index < 6; index++) {
      reportAction = reportingPage.getCellValueFromNthFromBottomRow(Integer.parseInt(rows[index]), 2);
      reportProperty = reportingPage.getCellValueFromNthFromBottomRow(Integer.parseInt(rows[index]), 7);
      reportOldValue = reportingPage.getCellValueFromNthFromBottomRow(Integer.parseInt(rows[index]), 8);
      reportSubmitterName = reportingPage.getCellValueFromNthFromBottomRow(Integer.parseInt(rows[index]), 10);

      Assert.assertEquals(reportAction, expectedReportAction);
      Assert.assertEquals(reportProperty, expectedReportProperties[index]);
      Assert.assertEquals(reportOldValue, expectedReportOldValue[index]);
      Assert.assertEquals(reportSubmitterName, expectedSubmitterName);
    }
  }
}
