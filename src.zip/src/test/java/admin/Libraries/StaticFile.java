package admin.Libraries;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.StaticFilesSearchPage;
import interaction.files.OpenFile;
import interaction.screenshots.ScreenShotImage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class StaticFile {

    private String newUploadedName = new DataGenerator().generateName() + ".jpg";
    private boolean deletefile = false;
    private final String NAME = "pic1.jpg";

    private StaticFilesSearchPage fileSearchPage = StaticFilesSearchPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @BeforeMethod
    public void upload() {
        fileSearchPage.navigate();
        fileSearchPage.openUploadFileModal();
        Assert.assertTrue(fileSearchPage.isModalOpen(), "did not open upload modal");
        Utils.getResourceAsFile(NAME, newUploadedName);
        fileSearchPage.uploadFile(newUploadedName);
        fileSearchPage.submitUpload();
        Utils.waitForTrue(() -> fileSearchPage.getResult(1).get("name").equals(newUploadedName), 30);
        deletefile = true;
    }

    @AfterClass
    public void close() {
        if (deletefile) {
            fileSearchPage.navigate();
            new AdminApp().deleteFile(fileSearchPage.getTopFileId());
        }
        PageConfiguration.getPage().quit();
    }

    @Test (groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19033", firefoxIssue = "RA-30911")
    public void uploadFileDownload() {
        fileSearchPage.downloadRow(1);
        OpenFile downloadedFile = OpenFile.OpenRecentDownloadedFileMatchingPattern(newUploadedName.replace(".jpg", ".*\\.jpg"));
        OpenFile originalFile = new OpenFile(newUploadedName);
        boolean isFileTheSame = downloadedFile.equals(originalFile);
        Assert.assertTrue(isFileTheSame, "The file downloaded didn't match file upload");

    }

    @Test (groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19032", firefoxIssue = "RA-30910")
    public void uploadFileLinkAndCopy() {
        String name = "pic2.jpg";
        String link = fileSearchPage.getLink(1);

        PageConfiguration.getPage().navigateTo(link);
        final ScreenShotImage screenShotImage = PageConfiguration.getPage().takeScreenShot();
        fileSearchPage.navigate();
        PageConfiguration.getPage().justWait();
        fileSearchPage.swapFile(1);
        Utils.getResourceAsFile(name, newUploadedName);
        fileSearchPage.uploadFile(newUploadedName);
        fileSearchPage.submitUpload();
        Utils.sleep(5000);
        PageConfiguration.getPage().navigateTo(link);

        final ScreenShotImage screenShotImage1 = PageConfiguration.getPage().takeScreenShot();
        int pixelsDifferent = screenShotImage.getDiffAmount(screenShotImage1);
        Assert.assertTrue(pixelsDifferent > 100000, "Picture wasn't swapped diff amount " + pixelsDifferent);
    }

    @Test (groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19034", firefoxIssue = "RA-30912")
    public void uploadFileSearchAndDelete() {
        Assert.assertEquals(fileSearchPage.getResult(1).get("name"), newUploadedName, "File didn't upload");

        //search for it
        fileSearchPage.searchFor(newUploadedName);
        Assert.assertEquals(fileSearchPage.getResult(1).get("name"), newUploadedName, "File didn't upload");
        //delete
        fileSearchPage.deleteRow(1);

        //search again
        fileSearchPage.searchFor(newUploadedName);
        Assert.assertEquals(fileSearchPage.getResults().size(), 1, "File didn't delete");
        deletefile = false;
    }
}
