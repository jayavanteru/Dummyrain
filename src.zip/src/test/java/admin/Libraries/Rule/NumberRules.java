package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class NumberRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String numberAttributeName, numberAttributeID,
            checkboxAttributeName, checkboxAttributeID, checkboxAttributeValue1,
            ruleName1,
            attendeeEmail, attendeeID, ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event B");
        NavigationBar.getPage().collapse();
    }

    private void setUp() {
        //create number Attribute
        numberAttributeName = dataGenerator.generateName();
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createNumberAttribute(numberAttributeName, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
        CreateEventAttributePage.getPage().saveAttribute();

        //create check box attribute
        checkboxAttributeName = dataGenerator.generateName();
        checkboxAttributeValue1 = "One";
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(checkboxAttributeName, new String[]{checkboxAttributeValue1}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();

        //get attribute ids
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(numberAttributeName);
        numberAttributeID = AdminEventAttributesPage.getPage().getAttributeId(numberAttributeName);
        AdminEventAttributesPage.getPage().search(checkboxAttributeName);
        checkboxAttributeID = AdminEventAttributesPage.getPage().getAttributeId(checkboxAttributeName);

        //create rule

        AdminRuleCreatePage.getPage().navigate();
        ruleId = adminApp.createRule(ruleName1 = dataGenerator.generateName(),
                "Attendees",
                checkboxAttributeName + ": " + checkboxAttributeValue1,
                new Criteria[]{
                        new Criteria(numberAttributeName, "greater than", "1"),
                        new Criteria(numberAttributeName, "equal to", "2"),
                        new Criteria(numberAttributeName, "less than", "1")
                },
                "OR");

        attendeeEmail = dataGenerator.generateEmail();
        attendeeID = adminApp.createAttendee(attendeeEmail);
    }

    @AfterClass
    public void afterClass() {
        //deletion
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(numberAttributeID);
        adminApp.deleteAttribute(checkboxAttributeID);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-33199", firefoxIssue = "RA-35063")
    public void numberRule() {
        setUp();

        EditAttendeePage.getPage().navigate(attendeeID);
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(numberAttributeName);
        EditFormPage.getPage().submitForm();
        PersistentProfileForm.getPage().setNumberAttribute(numberAttributeName, "-1");
        PersistentProfileForm.getPage().submit();
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().toggleAdvancedSearchOn();
        AttendeeSearchPage.getPage().advSearchDropDown(checkboxAttributeName, "equal to", checkboxAttributeValue1);
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));

        EditAttendeePage.getPage().navigate(attendeeID);
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(numberAttributeName);
        EditFormPage.getPage().submitForm();
        PersistentProfileForm.getPage().setNumberAttribute(numberAttributeName, ".5");
        PersistentProfileForm.getPage().submit();
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));

        EditAttendeePage.getPage().navigate(attendeeID);
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(numberAttributeName);
        EditFormPage.getPage().submitForm();
        PersistentProfileForm.getPage().setNumberAttribute(numberAttributeName, "1.5");
        PersistentProfileForm.getPage().submit();
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));
    }
}
