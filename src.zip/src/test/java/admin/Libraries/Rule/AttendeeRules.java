package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class AttendeeRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendeeEmail;
    String attendeeID;
    String ruleName;
    String attributeName;
    String attributeID;
    String ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event B");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{"Option 1"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attendeeID = AdminEventAttributesPage.getPage().getAttributeId(attributeName);

        //create attendee
        attendeeEmail = dataGenerator.generateEmail();
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create rule
        ruleName = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().setRuleName(ruleName);
        AdminRuleCreatePage.getPage().setApplyValue(attributeName+": Option 1");
        AdminRuleCreatePage.getPage().setCriteria(0, new Criteria("Email","equal to",attendeeEmail));
        AdminRuleCreatePage.getPage().save();

        PageConfiguration.getPage().moveMouseToTopCorner();
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        ruleId = AdminRuleSearchPage.getPage().getRuleIdByName(ruleName);
    }

    @AfterClass
    public void afterClass() {
        //delete rule
        adminApp.deleteRule(ruleId);

        //delete attendee
        adminApp.deleteAttendee(attendeeID);

        //delete attribute
        adminApp.deleteAttribute(attributeID);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-31555", firefoxIssue = "RA-32415")
    public void createAttendeeRule(){
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        Assert.assertTrue(AdminRuleSearchPage.getPage().ruleExists(ruleName));

        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().toggleAdvancedSearchOn();
        AttendeeSearchPage.getPage().advSearchDropDown(attributeName, "equal", "Option 1");
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));
    }
}