package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class CustomExpressionRule {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendeeId;
    String attributeName;
    String attributeId;
    String ruleName;
    String ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event C");
        NavigationBar.getPage().collapse();


    }

    private void setUp() {
        //create attendee
        attendeeId = adminApp.createAttendee(dataGenerator.generateEmail());
        //create attribute
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{"One", "Two", "Three", "Four"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);

        //create rule
        AdminRuleCreatePage.getPage().navigate();
        ruleId = adminApp.createRuleCustomExpression(ruleName = dataGenerator.generateName(),
                "Attendees",
                attributeName + ": Four",
                new Criteria[]{
                        new Criteria(attributeName, "equal to", "One"),
                        new Criteria(attributeName, "equal to", "Two"),
                        new Criteria(attributeName, "equal to", "Three")
                },
                "1 AND (2 OR 3)");

        //adding attribute to form
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().editItem();
        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-33842", firefoxIssue = "RA-36575")
    public void oneAndTwoOrThree() {
        setUp();

        //setting checkbox values - 1 and 2
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "One");
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Two");
        PersistentProfileForm.getPage().submit();

        //assert 1 and 2
        Assert.assertTrue(PersistentProfileForm.getPage().checkBoxValueIsChecked(attributeName, "Four"), "RULE DID NOT FIRE");

        //setting checkbox values - 1 and 3
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Two"); // uncheck
        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "Three");
        PersistentProfileForm.getPage().submit();

        //assert 1 and 3
        Assert.assertTrue(PersistentProfileForm.getPage().checkBoxValueIsChecked(attributeName, "Four"), "RULE DID NOT FIRE");
    }
}
