package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

import java.util.Map;

public class MeetingRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String meetingTitle;
    String attributeName;
    String attributeId;
    String attributeValue;
    String ruleName;
    String ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();

        //get name of meeting
        MeetingsSearchPage.getPage().navigate();
        MeetingsSearchPage.getPage().search();
        meetingTitle = MeetingsSearchPage.getPage().getResults().get(1).get("title");

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue = attributeName;
        attributeId = adminApp.createCheckBoxAttribute(attributeName, new String[]{attributeValue}, CreateEventAttributePage.AUDIENCE_TYPES.Meeting, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);

        //create rule
        AdminRuleCreatePage.getPage().navigate();
        ruleName = dataGenerator.generateName();
        ruleId = adminApp.createRule(ruleName, "Meetings", attributeName+": "+attributeValue, new Criteria[]{new Criteria("Title", "equal to", meetingTitle)}, "");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-31557", firefoxIssue = "RA-35553")
    public void meetingNameRule() {
        MeetingsSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().advSearchDropDown(attributeName, "equal to", attributeValue);
        MeetingsSearchPage.getPage().search();
        boolean elementExists = false;
        for(Map<String,String> row: MeetingsSearchPage.getPage().getResults()) {
            if(row.get("title").contains(meetingTitle)){
                elementExists = true;
            }
        }
        Assert.assertTrue(elementExists, "RULE DID NOT FIRE");
    }
}
