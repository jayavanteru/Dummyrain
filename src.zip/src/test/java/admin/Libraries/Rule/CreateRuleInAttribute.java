package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.AttributeRuleModal;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

import static logs.ReportingInfo.BLUE;
import static logs.ReportingInfo.OPTIMUS;

public class CreateRuleInAttribute {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeValue;
    String attributeID;
    String ruleName;
    String ruleID;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event B");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue = dataGenerator.generateName();
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{attributeValue}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();

        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attributeID = AdminEventAttributesPage.getPage().getAttributeId(attributeName);
        AdminEventAttributesPage.getPage().editItem();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteRule(ruleID);
        adminApp.deleteAttribute(attributeID);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-32266", firefoxIssue = "RA-33564")
    public void createRuleInAttribute() {
        ruleName = dataGenerator.generateName();
        CreateEventAttributePage.getPage().createRule(attributeValue);
        AttributeRuleModal.getPage().setRuleName(ruleName);
        AttributeRuleModal.getPage().setCriteria(1, new Criteria("First Name", "contains", dataGenerator.generateString()));
        AttributeRuleModal.getPage().saveRule();

        //assert rule exists
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        ruleID = adminApp.getRuleId(ruleName);
        Assert.assertTrue(AdminRuleSearchPage.getPage().ruleExists(ruleName));
    }
}
