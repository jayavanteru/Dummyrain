package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import interaction.api.Api;
import interaction.api.ApiConfig;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class BasicRules {
    AdminApp adminApp = new AdminApp();
    DataGenerator dataGenerator = new DataGenerator();
    String attributeName, attributeId, attributeValue1, attributeValue2, ruleName, ruleId;

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");
        NavigationBar.getPage().collapse();

        //create attribute1
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{attributeValue1 = dataGenerator.generateName(), attributeValue2 = dataGenerator.generateName()}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
    }

    @BeforeMethod
    public void beforeMethod(){
        //create rule
        AdminRuleCreatePage.getPage().navigate();
        ruleId = adminApp.createRule(ruleName = dataGenerator.generateName(),
                "Attendees",
                attributeName +": " + attributeValue1, new Criteria[]{
                        new Criteria("First Name", "equal to", dataGenerator.generateString(10))
                },
                "");
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-19158", firefoxIssue = "RA-25642")
    public void deleteRule(){
        //delete test - assert test has been deleted
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        Assert.assertTrue(AdminRuleSearchPage.getPage().ruleExists(ruleName),"RULE WAS NOT CREATED");
        AdminRuleSearchPage.getPage().deleteFirstRecord();
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        Assert.assertFalse(AdminRuleSearchPage.getPage().ruleExists(ruleName),"RULE WAS NOT DELETED");
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-18761", firefoxIssue = "RA-25812")
    public void editRule(){
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        AdminRuleSearchPage.getPage().select(ruleName);
        ruleName = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().setRuleName(ruleName);
        AdminRuleCreatePage.getPage().setApplyValue(attributeValue2);
        AdminRuleCreatePage.getPage().save();
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        AdminRuleSearchPage.getPage().select(ruleName);
        Assert.assertTrue(AdminRuleCreatePage.getPage().ruleNameEquals(ruleName));
    }
    @AfterMethod
    public void afterMethod(){
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(ruleName);
        if(AdminRuleSearchPage.getPage().ruleExists(ruleName)){
            adminApp.deleteRule(ruleId);
        }
    }

    @AfterClass
    public void tearDown(){
        //deletion
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);
        PageConfiguration.getPage().quit();
    }
}
