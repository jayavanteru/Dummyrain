package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class DemoRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String demoName, attributeName, attributeValue, ruleName, ruleId, attributeID;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event E");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeID = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{attributeValue = attributeName}, CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);

        //create a demo
        adminApp.createDemo(demoName = dataGenerator.generateName(), "Blue Event E");

        //create rule
        AdminRuleCreatePage.getPage().navigate();
        adminApp.createRule(ruleName = dataGenerator.generateName(),
                "Demos",
                attributeValue,
                new Criteria[]{
                        new Criteria("Name" ,"equal to", demoName)
                },
                "");
    }

    @AfterClass
    public void afterClass() {
        //delete rule
        adminApp.deleteRule(ruleId);

        //delete demo
        adminApp.deleteExhibitor(demoName);

        //delete attribute
        adminApp.deleteAttribute(attributeID);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-31559", firefoxIssue = "RA-34077")
    public void createDemoRule() {
        //search for
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().clickAdvancedSearch();
        ExhibitorSearchPage.getPage().advancedSearchByCheckBox(attributeName, "equal to", attributeValue);
        DemosSearchPage.getPage().clickSearchButton();

        //assert that demo was applied attribute value
        Assert.assertTrue(DemosSearchPage.getPage().demoExists(demoName), "DEMO WAS NOT APPLIED ATTRIBUTE");
    }
}
