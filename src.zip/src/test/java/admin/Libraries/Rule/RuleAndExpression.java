package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class RuleAndExpression {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName, attributeID, attributeValue1,
            randomString,
            attendeeEmail, attendeeID,
            ruleName, ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");
        NavigationBar.getPage().collapse();
    }

    private void setUp() {
        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue1 = dataGenerator.generateString();
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{attributeValue1}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attributeID = AdminEventAttributesPage.getPage().getAttributeId(attributeName);

        //create attendee
        randomString = dataGenerator.generateString();
        attendeeEmail = "automation" + randomString + "@rainfocus.net";
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create rule
        ruleId = adminApp.createRule(ruleName = dataGenerator.generateName(),
                "Attendees",
                attributeName + ": " + attributeValue1,
                new Criteria[]{
                        new Criteria("Email", "contains", "automation"),
                        new Criteria("Email", "contains", randomString)
                },
                "");
    }

    @AfterClass
    public void afterClass() {
        //delete rule
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeID);
        adminApp.deleteAttendee(attendeeID);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-33840", firefoxIssue = "RA-34998")
    public void ruleAndExpression() {
        setUp();

        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().advSearchDropDown(attributeName, "equal to", attributeValue1);
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));
    }
}
