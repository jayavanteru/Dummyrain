package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class VerifyRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeID;
    String attributeName;
    String attributeValue1;
    String attributeValue2;
    String chainRuleName;
    String attendeeRule;
    String attendeeEmail;
    String attendeeID;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event A");
        NavigationBar.getPage().collapse();

        //create attendee
        attendeeEmail = dataGenerator.generateEmail();
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue1 = dataGenerator.generateString(10);
        attributeValue2 = dataGenerator.generateString(10);
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{attributeValue1, attributeValue2}, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
        CreateEventAttributePage.getPage().saveAttribute();
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attributeID = AdminEventAttributesPage.getPage().getAttributeId(attributeName);

        //create attendee rule
        attendeeRule = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().setRuleName(attendeeRule);
        AdminRuleCreatePage.getPage().setApplyValue(String.format("%s: %s", attributeName, attributeValue1));
        AdminRuleCreatePage.getPage().setCriteria(0, new Criteria("Email", "equal to", attendeeEmail));
        AdminRuleCreatePage.getPage().save();

        //create chain rule
        chainRuleName = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().setRuleName(chainRuleName);
        AdminRuleCreatePage.getPage().setApplyValue(String.format("%s: %s", attributeName, attributeValue2));
        AdminRuleCreatePage.getPage().setCriteria(0, new Criteria(attributeName, "equal to", attributeValue1));
        AdminRuleCreatePage.getPage().save();
    }

    @AfterClass
    public void afterClass() {
        //delete chain rule
        AdminRuleSearchPage.getPage().navigate();
        AdminRuleSearchPage.getPage().search(chainRuleName);
        AdminRuleSearchPage.getPage().deleteRuleByRuleDescription(chainRuleName);

        //delete attendee rule
        AdminRuleSearchPage.getPage().search(attendeeRule);
        AdminRuleSearchPage.getPage().deleteRuleByRuleDescription(attendeeRule);

        //delete attendee
        adminApp.deleteAttendee(attendeeID);

        adminApp.deleteAttribute(attributeID);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-19157", firefoxIssue = "RA-33432")
    public void verifyDaisyChainRuleRan(){
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().advSearchDropDown(attributeName, "equal to", attributeValue2);
        AttendeeSearchPage.getPage().search();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText(attendeeEmail));
    }
}
