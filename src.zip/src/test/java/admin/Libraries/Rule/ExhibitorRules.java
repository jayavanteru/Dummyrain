package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class ExhibitorRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName;
    String exhibitorId;
    String attributeName;
    String attributeId;
    String attributeValue;
    String ruleName;
    String ruleId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event F");
        NavigationBar.getPage().collapse();

        //create exhibitor
        exhibitorName = dataGenerator.generateName();
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName);

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue = attributeName;
        CreateEventAttributePage.getPage().navigate();
        attributeId = adminApp.createCheckBoxAttribute(attributeName, new String[]{attributeValue}, CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);


        //create rule
        ruleName = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().navigate();
        ruleId = adminApp.createRule(ruleName, "Exhibitors", attributeName + ": " + attributeValue, new Criteria[]{new Criteria("Name", "equal to", exhibitorName)}, "");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteRule(ruleId);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-31558", firefoxIssue = "RA-35471")
    public void exhibitorNameRule() {
        ExhibitorSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().toggleAdvancedSearch();
        ExhibitorSearchPage.getPage().advancedSearchByCheckBox(attributeName, "equal to", attributeValue);
        ExhibitorSearchPage.getPage().search();
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName), "RULE DID NOT FIRE");
    }
}
