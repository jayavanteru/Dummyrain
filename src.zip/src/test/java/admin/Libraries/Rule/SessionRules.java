package admin.Libraries.Rule;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class SessionRules {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String sessionID;
    String sessionTitle;
    String attributeName;
    String attributeValue;
    String ruleName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event B");
        NavigationBar.getPage().collapse();

        //create session attribute
        attributeName = dataGenerator.generateName();
        attributeValue = dataGenerator.generateString(10);
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{attributeValue}, CreateEventAttributePage.AUDIENCE_TYPES.Session, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();

        //create session
        sessionID = adminApp.createSession(sessionTitle = dataGenerator.generateEmail());

        //create rule
        ruleName = dataGenerator.generateName();
        AdminRuleCreatePage.getPage().navigate();
    }

    @AfterClass
    public void afterClass() {
        //delete session
        adminApp.deleteSession(sessionID);

        //delete rule
        final String ruleId = adminApp.getRuleId(ruleName);
        adminApp.deleteRule(ruleId);

        //delete session attribute
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().searchAttribute(attributeName);
        final String attributeId = AdminEventAttributesPage.getPage().getAttributeId(attributeName);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(chromeIssue = "RA-31556", firefoxIssue = "RA-32895")
    public void createSessionRule() {

       adminApp.createRule(ruleName,
               "Sessions",
               attributeName + ": " + attributeValue,
               new Criteria[]{
                       new Criteria("Title", "equal to", sessionTitle)
               }, "");

        SessionSearchPage.getPage().navigate();
        SessionSearchPage.getPage().advSearch(attributeName, "equal to", attributeValue);
        SessionSearchPage.getPage().search();
        Assert.assertTrue(SessionSearchPage.getPage().sessionExists(sessionTitle), "SESSION DID NOT APPEAR");
    }
}
