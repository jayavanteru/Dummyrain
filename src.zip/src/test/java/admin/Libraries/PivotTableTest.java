package admin.Libraries;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormModalPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import interaction.awsDatabase.DbQueryConfig;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;

public class PivotTableTest {

    private AdminApp adminApp;
    private DataGenerator generator;
    private String attendeeId;
    private String attributeName;
    private String ruleId;
    private String email;
    private String attributeId;

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        generator = new DataGenerator();

        AdminLoginPage.getPage().login();
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @BeforeMethod
    public void setupAttendee() {
        email = generator.generateValidEmail();
        OrgEventData.getPage().setOrgAndEvent();
        attendeeId = adminApp.createAttendee(email);
        Utils.sleep(2000);

        //create the new attribute that we wills be using ya know
        attributeName = generator.generateString(5) + "automation";
        Log.info("the new attribute name: " + attributeName, getClass().getName());
        CreateEventAttributePage createEventAttribute = CreateEventAttributePage.getPage();
        createEventAttribute.navigate();
        createEventAttribute.createRadioList(attributeName, new String[]{"test1", "test2", "test3"}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        createEventAttribute.saveAttribute();
        Utils.sleep(5000);
    }

    @AfterMethod
    public void deleteAttendee() {
        adminApp.deleteAttendee(attendeeId);
        if (ruleId != null) {
            adminApp.deleteRule(ruleId);
        }
        if (attributeId != null) {
            adminApp.deleteAttribute(attributeId);
        }
    }

//    @Test
    public void formSaveTest() {
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB1);
        EditFormModalPage editForm = EditFormModalPage.getPage(EditFormModalPage.BASE_PAGE.TAB1);

        customTab.navigate(attendeeId);
        customTab.editForm();

        editForm.addExistingAttribute(attributeName);
        attributeId = editForm.getExpandedAttributeId();
        editForm.submitForm();
        Utils.sleep(2000);
        Utils.waitForTrue(()->customTab.isFieldVisible(attributeName));

        //choose first
        customTab.checkCheckBoxField(attributeName, 0);

        customTab.submit();
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(500);

        //verify that it saved the checked fields
        Assert.assertTrue(customTab.isCheckBoxChecked(attributeName, 0), "did not save the third box checked");

        checkPivotTable(attributeId, "test1");
    }

//    @Test
    public void importTest() {

        //get the id, and add the attribute to form
        String attributeId;

        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB1);
        EditFormModalPage editForm = EditFormModalPage.getPage(EditFormModalPage.BASE_PAGE.TAB1);

        customTab.navigate(attendeeId);
        customTab.editForm();

        editForm.addExistingAttribute(attributeName);
        attributeId = editForm.getExpandedAttributeId();
        editForm.submitForm();
        Utils.sleep(1000);
        Utils.waitForTrue(()->customTab.isFieldVisible(attributeName));
        Assert.assertTrue(customTab.isFieldVisible(attributeName),"saved new attribute to the form");

        //setup the import
        ArrayList<HashMap<String, String>> contents = new ArrayList<>();
        HashMap<String, String> row = new HashMap<>();

        row.put("attendeeId", attendeeId);
        row.put(attributeId, "test3");
        contents.add(row);

        //do that import
        JSONObject importResponse = adminApp.importAttendeeFile("attendeeId", true, false, contents, attributeId);
        Log.info("importing attendees response " + importResponse.toString(), getClass().getName());

        //verify import worked
        PageConfiguration.getPage().refreshPage();
        Utils.waitForTrue(()->customTab.isFieldVisible(attributeName));
        Assert.assertTrue(customTab.isCheckBoxChecked(attributeName, 2), "did not save the third box checked");

        checkPivotTable(attributeId, "test3");
    }

//    @Test
    public void ruleTest() {

        //add attribute to form
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB1);
        EditFormModalPage editForm = EditFormModalPage.getPage(EditFormModalPage.BASE_PAGE.TAB1);

        customTab.navigate(attendeeId);
        customTab.editForm();

        editForm.addExistingAttribute(attributeName);
        attributeId = editForm.getExpandedAttributeId();
        editForm.submitForm();
        Utils.sleep(1000);
        Utils.waitForTrue(()->customTab.isFieldVisible(attributeName));
        Utils.sleep(1000);

        //create the new rule to populate the new attribute
        String ruleName = generator.generateString(5) + "automation";
        AdminRuleCreatePage createRulePage = AdminRuleCreatePage.getPage();
        createRulePage.navigate();
        Criteria criteria = createRulePage.createCriteria("Email", "contains", email);
        createRulePage.createRule(ruleName, attributeName + ": test2", AdminRuleCreatePage.ApplyTo.Attendees, criteria);
        ruleId = adminApp.getRuleId(ruleName);
        Utils.sleep(3000);

        //verify that it updated the attribute
        customTab.navigate(attendeeId);
        Utils.waitForTrue(()->customTab.isFieldVisible(attributeName));
        Assert.assertTrue(customTab.isCheckBoxChecked(attributeName, "test2"), "did not save the third box checked");

        checkPivotTable(attributeId, "test2");

    }

    private void checkPivotTable(String attributeId, String expectedValue) {
        int totalColumns = 50;

        Utils.sleep(10000, "wait for the pivot table to populate");

        //get the attribute info
        DbQueryConfig attributeConfig = DbQueryConfig.createConfig("attributes", "attribute_id = '"+attributeId+"'",
                "displayname", "input_type", "attendee_column");

        JSONArray attributeResult = adminApp.queryDb(attributeConfig);
        Assert.assertEquals(attributeResult.length(), 1, "should find the one attribute with that id");
        JSONObject myAttribute = MyJson.getJSONObject(attributeResult, 0);
        Assert.assertEquals(MyJson.getString(myAttribute, "displayname"), attributeName, "found attribute should match the name");

        //get the right column and table number
        int unParsedColumn = MyJson.getInt(myAttribute, "attendee_column");
        int column = unParsedColumn % totalColumns;
        int tableNum = column == 0 ? unParsedColumn / totalColumns : (unParsedColumn / totalColumns) + 1;
        if (column == 0) column = totalColumns;

        //run the pivot table query
        String tableColumn = "att" + column;
        DbQueryConfig pivotQuery = new DbQueryConfig();
        pivotQuery.setCustom("select attendee_id, MAX(tablenum) AS tablenum, MAX("+tableColumn+") AS "+tableColumn +
                " from attendeeattributes " +
                "where attendee_id='"+attendeeId+"' and tablenum='"+tableNum+"' " +
                "GROUP BY attendee_id;");
        pivotQuery.setSelect("attendee_id", "tablenum", tableColumn);

        Utils.waitForTrue(()->
        {
            JSONArray results = adminApp.queryDb(pivotQuery);
            return results.length() > 0 && MyJson.getJSONObject(results, 0).length() > 2;
        }, 40);

        JSONArray results = adminApp.queryDb(pivotQuery);

        Assert.assertTrue(results.length() > 0, "should have returned at least one attribute in results\n" + results);
        JSONObject attrRow = MyJson.getJSONObject(results, 0);
        Assert.assertEquals(MyJson.getString(attrRow, tableColumn), expectedValue, "did not save the saved attribute to the pivot table");
    }
}
