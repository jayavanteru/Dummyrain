package admin.Libraries.AttributeValues;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.RuleCreateAnswerModal;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class CreateAttributeValueInRule {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attributeName;
    String attributeValue;
    String newAttributeValue;
    String attributeID;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event F");
        NavigationBar.getPage().collapse();

        //create attribute
        attributeName = dataGenerator.generateName();
        attributeValue = dataGenerator.generateString(10);
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(attributeName, new String[]{attributeValue}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Rule_Based);
        CreateEventAttributePage.getPage().saveAttribute();

        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        attributeID = AdminEventAttributesPage.getPage().getAttributeId(attributeName);
    }

    @AfterClass
    public void afterClass() {
        //delete attribute
        adminApp.deleteAttribute(attributeID);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-32268", firefoxIssue = "RA-33531")
    public void createAttributeInRule() {
        //create attribute value in
        newAttributeValue = dataGenerator.generateString(10);
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().createAttributeValue(attributeName);
        RuleCreateAnswerModal.getPage().createNewAnswer(newAttributeValue, newAttributeValue, newAttributeValue);

        //assert value exists
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(attributeName);
        AdminEventAttributesPage.getPage().editItem();
        Assert.assertTrue(CreateEventAttributePage.getPage().valueExists(newAttributeValue));
    }
}
