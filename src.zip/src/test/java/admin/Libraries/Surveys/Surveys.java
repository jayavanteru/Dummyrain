package admin.Libraries.Surveys;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewSurveyPage;
import apps.admin.adminPageObjects.libraries.SurveysSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.*;

public class Surveys
{
  DataGenerator dataGenerator = new DataGenerator();
  String survey1Name;
  String survey2Name;
  boolean testSurveysCreated;
  
  private static final String ATTENDEE_SUMMARY_EXPORT_MD5 = "2CD9F3C9F96E7E37B102761F5A7CA4B8";
  private static final String ATTENDEE_RAW_DATA_EXPORT_MD5 = "374B45E0BF7B9D7B6EBC13ACA364729C";
  private static final String SESSION_SUMMARY_EXPORT_MD5 = "8CF7FA43683BF0A22710E3C124394012";
  private static final String SESSION_RAW_DATA_EXPORT_MD5 = "5B82234D8C26F3DCAA614C1BEEF2EDCD";
  private static final String SESSION_EVAL_EXPORT_MD5 = "8FFF09709A17F0120B10411A8514C25A";
  private static final String SESSION_SUMMARY_EXPORT_MD5_WIN = "01CCF8BA84AEC0A918177105D121FF94";
  private static final String SESSION_RAW_DATA_EXPORT_MD5_WIN = "83D9A58BC46C062C1B6FC3E5C5CD5F9B";

  @BeforeClass
  public void setUp()
  {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    survey1Name = dataGenerator.generateName();
    survey2Name = dataGenerator.generateName();
    testSurveysCreated = false;
  }

  @Test(groups = {ReportingInfo.BLUE})
  @ReportingInfo(chromeIssue = "RA-28597", firefoxIssue = "RA-28598")
  public void multiSelectCompletedSurveysCriteria()
  {
    OrgEventData.getPage().setOrgAndEvent();
    
    //create survey 1
    SurveysSearchPage.getPage().navigate();
    SurveysSearchPage.getPage().addItem();
    NewSurveyPage.getPage().setAttendeeSurveySettings(survey1Name);
    NewSurveyPage.getPage().submitForm();

    //create survey 2
    SurveysSearchPage.getPage().navigate();
    SurveysSearchPage.getPage().addItem();
    NewSurveyPage.getPage().setAttendeeSurveySettings(survey2Name);
    NewSurveyPage.getPage().submitForm();
    
    testSurveysCreated = true;
  
    AttendeeSearchPage.getPage().navigate();
    AttendeeSearchPage.getPage().toggleAdvancedSearch();
    AttendeeSearchPage.getPage().advancedSearchSurvey(survey1Name, survey2Name);
    assertTrue(AttendeeSearchPage.getPage().advancedSearchSurveysAreSelected(survey1Name, survey2Name));
  }

  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(chromeIssue = "RA-34613", firefoxIssue = "RA-20393")
  public void attendeeSurvey() throws IOException, NoSuchAlgorithmException
  {
    final List<String> failures = new ArrayList<>();
    OrgEventData.getPage().setOrgAndEvent("Cisco", "Cisco Live US 2019");
    
    final String surveyId = "1555910204198001Imry";
    final SurveysSearchPage surveysSearchPage = SurveysSearchPage.getPage();
    surveysSearchPage.navigate();
    surveysSearchPage.waitForPageLoad(5);
    surveysSearchPage.selectSurvey(surveyId);
    
    final SurveySummaryReportPage summaryReportPage = SurveySummaryReportPage.getPage();
    summaryReportPage.waitForPageLoad();
    
    final int numResponses = summaryReportPage.getResponsesCount();
    
    summaryReportPage.clickResponses();
    assertTrue(summaryReportPage.isResponsesModalVisible(), "Responses modal should be visible");
    summaryReportPage.closeResponsesModal();
    
    summaryReportPage.clickExport();
    summaryReportPage.exportSummary();
    Utils.sleep(500, "wait for export to finish");
    OpenFile summaryFile = OpenFile.OpenRecentDownloadedFileMatchingPattern("surveySummaryExport.*\\.xlsx", 30);
    assertNotNull(summaryFile, "Downloaded file should not be null");
    final String summaryExportMD5 = summaryFile.getXLSXContentsMD5();
    if (!StringUtils.equals(summaryExportMD5, ATTENDEE_SUMMARY_EXPORT_MD5))
      failures.add("Summary-export MD5 hash was incorrect: expected " + ATTENDEE_SUMMARY_EXPORT_MD5 + " but found " + summaryExportMD5);
    assertTrue(summaryFile.getFile().delete(), "Could not delete survey-summary file");

    summaryReportPage.clickExport();
    summaryReportPage.exportRawData();
    Utils.sleep(8000, "wait for export to finish");
    OpenFile rawDataFile = OpenFile.OpenRecentDownloadedFileMatchingPattern("surveyRawData.*\\.xlsx", 30);
    assertNotNull(rawDataFile, "Downloaded file should not be null");
    final String rawDataExportMD5 = rawDataFile.getXLSXContentsMD5();
    if (!StringUtils.equals(rawDataExportMD5, ATTENDEE_RAW_DATA_EXPORT_MD5))
      failures.add("Raw-data-export MD5 hash was incorrect: expected " + ATTENDEE_RAW_DATA_EXPORT_MD5 + " but found " + rawDataExportMD5);
    assertTrue(rawDataFile.getFile().delete(), "Could not delete raw-data file");
    
    if (CollectionUtils.isNotEmpty(failures))
      fail("Export MD5 mismatches: " + failures);
    
    summaryReportPage.toggleAdvancedFilters();
    assertTrue(summaryReportPage.areAdvancedFiltersOpen(), "Advanced criteria should be open");
    
    summaryReportPage.addAttendeeCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("First Name");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    assertTrue(summaryReportPage.isAdvancedSearchValueInputShowing(), "Advanced-search value input should be visible");
    summaryReportPage.selectAdvancedSearchOperator("contains", 0);
    summaryReportPage.enterAdvancedSearchValue("C", 0);
    summaryReportPage.applyAdvancedSearchCriteria();
    int searchResults = summaryReportPage.getResponsesCount();
    assertTrue(numResponses > searchResults, "Filtered results should be fewer than unfiltered");

    int previousSearchResults = searchResults;
    summaryReportPage.addAttendeeCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("Last Name");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    assertTrue(summaryReportPage.isAdvancedSearchValueInputShowing(), "Advanced-search value input should be visible");
    summaryReportPage.selectAdvancedSearchOperator("contains", 1);
    summaryReportPage.enterAdvancedSearchValue("r", 1);
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults > searchResults, "Further-filtered results should be fewer than previously filtered");

    previousSearchResults = searchResults;
    summaryReportPage.addAttendeeCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("Company Name");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    assertTrue(summaryReportPage.isAdvancedSearchValueInputShowing(), "Advanced-search value input should be visible");
    summaryReportPage.selectAdvancedSearchOperator("contains", 2);
    summaryReportPage.enterAdvancedSearchValue("a", 2);
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults > searchResults, "Further-filtered results should be fewer than previously filtered");
    
    previousSearchResults = searchResults;
    summaryReportPage.selectAttendeeAdvancedExpression("OR");
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults < searchResults, "OR-filtered results should be greater than AND-filtered");
    
    previousSearchResults = searchResults;
    summaryReportPage.selectAttendeeAdvancedExpression("Custom");
    summaryReportPage.enterCustomExpression("1 and (2 or 3)");
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults > searchResults, "Results filtered by AND and OR should be fewer than OR-filtered");
    
    summaryReportPage.selectAttendeeAdvancedExpression("Count");
    assertTrue(summaryReportPage.isAdvExprCountOperatorSelectVisible(), "Advanced-expression-count-operator select should be visible");
    assertTrue(summaryReportPage.isAdvExprInputVisible(), "Advanced-expression-count input should be visible");
    
    int previousNumCriteria = summaryReportPage.getCriteriaCount();
    summaryReportPage.deleteCriterion(0);
    int numCriteria = summaryReportPage.getCriteriaCount();
    assertEquals(previousNumCriteria - 1, numCriteria, "There should be one fewer criteria");
    
    summaryReportPage.clearCriteria();
    assertEquals(summaryReportPage.getCriteriaCount(), 0, "Clearing criteria should remove all");
    summaryReportPage.applyAdvancedSearchCriteria();
    assertEquals(summaryReportPage.getResponsesCount(), numResponses, "Responses count without criteria-filtering should equal original responses count");
    
    summaryReportPage.toggleAdvancedFilters();
    assertFalse(summaryReportPage.areAdvancedFiltersOpen(), "Clicking \"Close Advanced Filters\" should close advanced filters");
    
    summaryReportPage.clickSurveysBreadcrumb();
    assertTrue(StringUtils.contains(summaryReportPage.getCurrentUrl(), "surveys.do"));
  }

  @Test(groups = {ReportingInfo.DATATRON})
  @ReportingInfo(chromeIssue = "RA-34710", firefoxIssue = "RA-29909")
  public void sessionSurvey() throws IOException, NoSuchAlgorithmException
  {
    final List<String> failures = new ArrayList<>();
    
    OrgEventData.getPage().setOrgAndEvent("Cisco", "Cisco Live US 2019");

    final String surveyId = "1559192533038001i2RX";
    final SurveysSearchPage surveysSearchPage = SurveysSearchPage.getPage();
    surveysSearchPage.navigate();
    surveysSearchPage.waitForPageLoad(5);
    surveysSearchPage.selectSurvey(surveyId);

    final SurveySummaryReportPage summaryReportPage = SurveySummaryReportPage.getPage();
    summaryReportPage.waitForPageLoad();

    final int numResponses = summaryReportPage.getResponsesCount();
    
    summaryReportPage.clickResponses();
    assertTrue(summaryReportPage.isResponsesModalVisible(), "Responses modal should be visible");
    summaryReportPage.closeResponsesModal();

    summaryReportPage.clickExport();
    summaryReportPage.exportSummary();
    Utils.sleep(500, "wait for export to finish");
    OpenFile summaryFile = OpenFile.OpenRecentDownloadedFileMatchingPattern("surveySummaryExport.*\\.xlsx", 30);
    assertNotNull(summaryFile, "Downloaded file should not be null");
    final String summaryExportMD5 = summaryFile.getXLSXContentsMD5();
    if (!StringUtils.equals(summaryExportMD5, SESSION_SUMMARY_EXPORT_MD5) && !StringUtils.equals(summaryExportMD5, SESSION_SUMMARY_EXPORT_MD5_WIN))
      failures.add("Summary-export MD5 hash was incorrect: expected " + SESSION_SUMMARY_EXPORT_MD5 + " but found " + summaryExportMD5);
    assertTrue(summaryFile.getFile().delete(), "Could not delete survey-summary file");

    summaryReportPage.clickExport();
    summaryReportPage.exportRawData();
    Utils.sleep(8000, "wait for export to finish");
    OpenFile rawDataFile = OpenFile.OpenRecentDownloadedFileMatchingPattern("surveyRawData.*\\.xlsx", 30);
    assertNotNull(rawDataFile, "Downloaded file should not be null");
    final String rawDataExportMD5 = rawDataFile.getXLSXContentsMD5();
    if (!StringUtils.equals(rawDataExportMD5, SESSION_RAW_DATA_EXPORT_MD5) && !StringUtils.equals(rawDataExportMD5, SESSION_RAW_DATA_EXPORT_MD5_WIN))
      failures.add("Raw-data-export MD5 hash was incorrect: expected " + SESSION_RAW_DATA_EXPORT_MD5 + " but found " + rawDataExportMD5);
    assertTrue(rawDataFile.getFile().delete(), "Could not delete raw-data file");

    summaryReportPage.clickExport();
    summaryReportPage.exportSessionEval();
    Utils.sleep(8000, "wait for export to finish");
    OpenFile sessionEvalFile = OpenFile.OpenRecentDownloadedFileMatchingPattern("sessionSurveyReport.*\\.xlsx", 30);
    assertNotNull(sessionEvalFile, "Downloaded file should not be null");
    final String sessionEvalExportMD5 = sessionEvalFile.getXLSXContentsMD5();
    if (!StringUtils.equals(sessionEvalExportMD5, SESSION_EVAL_EXPORT_MD5))
      failures.add("Session-eval-export MD5 hash was incorrect: expected " + SESSION_EVAL_EXPORT_MD5 + " but found " + sessionEvalExportMD5);
    assertTrue(sessionEvalFile.getFile().delete(), "Could not delete session-eval file");

    if (CollectionUtils.isNotEmpty(failures))
      fail("Export MD5 mismatches: " + failures);
    
    summaryReportPage.openSessionSelectAndSelectASession();
    int searchResults = summaryReportPage.getResponsesCount();
    assertTrue(searchResults <= numResponses, "Session-filtered responses should be fewer than or equal to total responses");
    
    summaryReportPage.clearSelectedSession();
    searchResults = summaryReportPage.getResponsesCount();
    assertEquals(searchResults, numResponses, "Clearing selected session should return all responses");

    summaryReportPage.toggleAdvancedFilters();
    assertTrue(summaryReportPage.areAdvancedFiltersOpen(), "Advanced criteria should be open");

    summaryReportPage.addSessionCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("Title");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    summaryReportPage.selectAdvancedSearchOperator("contains", 0);
    assertTrue(summaryReportPage.isAdvancedSearchValueInputShowing(), "Advanced-search value input should be visible");
    summaryReportPage.enterAdvancedSearchValue("C", 0);
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(numResponses > searchResults, "Filtered results should be fewer than unfiltered");

    int previousSearchResults = searchResults;
    summaryReportPage.addSessionCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("Status");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    summaryReportPage.selectAdvancedSearchOperator("equal to", 1);
    assertTrue(summaryReportPage.isAdvancedSearchSelectValueItemShowing(), "Advanced-search value input should be visible");
    summaryReportPage.selectAdvancedSearchValueItem("Accepted", 0);
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults >= searchResults, "Further-filtered results should be fewer than or equal to previously filtered");

    previousSearchResults = searchResults;
    summaryReportPage.addSessionCriteria();
    summaryReportPage.selectAdvancedSearchCriteria("Day");
    assertTrue(summaryReportPage.isAdvancedSearchOperatorSelectShowing(), "Advanced-search operator select should be visible");
    assertTrue(summaryReportPage.isAdvancedSearchValueInputShowing(), "Advanced-search value input should be visible");
    summaryReportPage.selectAdvancedSearchOperator("equal to", 2);
    summaryReportPage.selectAdvancedSearchValueItem("Sunday, June 9", 1);
    summaryReportPage.selectAdvancedSearchValueItem("Monday, June 10", 2);
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults > searchResults, "Further-filtered results should be fewer than previously filtered");

    previousSearchResults = searchResults;
    summaryReportPage.selectSessionAdvancedExpression("OR");
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults < searchResults, "OR-filtered results should be greater than AND-filtered");

    previousSearchResults = searchResults;
    summaryReportPage.selectSessionAdvancedExpression("Custom");
    summaryReportPage.enterCustomExpression("1 and (2 or 3)");
    summaryReportPage.applyAdvancedSearchCriteria();
    searchResults = summaryReportPage.getResponsesCount();
    assertTrue(previousSearchResults > searchResults, "Results filtered by AND and OR should be fewer than OR-filtered");

    summaryReportPage.selectSessionAdvancedExpression("Count");
    assertTrue(summaryReportPage.isAdvExprCountOperatorSelectVisible(), "Advanced-expression-count-operator select should be visible");
    assertTrue(summaryReportPage.isAdvExprInputVisible(), "Advanced-expression-count input should be visible");

    int previousNumCriteria = summaryReportPage.getCriteriaCount();
    summaryReportPage.deleteCriterion(0);
    int numCriteria = summaryReportPage.getCriteriaCount();
    assertEquals(previousNumCriteria - 1, numCriteria, "There should be one fewer criteria");

    summaryReportPage.clearCriteria();
    assertEquals(summaryReportPage.getCriteriaCount(), 0, "Clearing criteria should remove all");
    summaryReportPage.applyAdvancedSearchCriteria();
    assertEquals(summaryReportPage.getResponsesCount(), numResponses, "Responses count without criteria-filtering should equal original responses count");

    summaryReportPage.toggleAdvancedFilters();
    assertFalse(summaryReportPage.areAdvancedFiltersOpen(), "Clicking \"Close Advanced Filters\" should close advanced filters");

    summaryReportPage.clickSurveysBreadcrumb();
    assertTrue(StringUtils.contains(summaryReportPage.getCurrentUrl(), "surveys.do"));
  }

  @AfterClass
  public void tearDown()
  {
    if (testSurveysCreated)
    {
      OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
      
      //delete survey 1
      SurveysSearchPage.getPage().navigate();
      SurveysSearchPage.getPage().search(survey1Name);
      if (SurveysSearchPage.getPage().getResultsNumber() > 0)
        SurveysSearchPage.getPage().deleteFirstRow();

      //delete survey 2
      SurveysSearchPage.getPage().navigate();
      SurveysSearchPage.getPage().search(survey2Name);
      if (SurveysSearchPage.getPage().getResultsNumber() > 0)
        SurveysSearchPage.getPage().deleteFirstRow();
    }

    PageConfiguration.getPage().quit();
  }
}