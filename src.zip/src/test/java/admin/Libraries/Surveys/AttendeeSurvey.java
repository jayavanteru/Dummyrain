package admin.Libraries.Surveys;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewSurveyPage;
import apps.admin.adminPageObjects.libraries.SurveysSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class AttendeeSurvey {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String attendeeEmail;
    String attendeeID;
    String surveyName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");

        //create attendee
        attendeeEmail = dataGenerator.generateEmail();
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create survey
        surveyName = dataGenerator.generateName();
        NewSurveyPage.getPage().navigate();
        NewSurveyPage.getPage().setSurveyType("Attendee");
        NewSurveyPage.getPage().setFormName(surveyName);
        NewSurveyPage.getPage().setPublishStatus("Published");
        NewSurveyPage.getPage().defineAttendees(new Criteria("Email", "equal to", attendeeEmail));
        NewSurveyPage.getPage().submitForm();
    }

    @AfterClass
    public void afterClass() {
        //delete survey
        SurveysSearchPage.getPage().navigate();
        SurveysSearchPage.getPage().search(surveyName);
        SurveysSearchPage.getPage().deleteFirstRow();

        //delete attendee
        adminApp.deleteAttendee(attendeeEmail);

        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-31561", firefoxIssue = "RA-32440")
    public void createAttendeeSurvey(){
        //search for attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        AttendeeSearchPage.getPage().clickResult(0);

        //assert survey was given to attendee
        EditAttendeePage.getPage().clickSurveysButton();
        EditAttendeePage.getPage().surveyExists(surveyName);
    }
}
