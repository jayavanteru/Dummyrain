package admin.Libraries.Surveys;

import interaction.pageObjects.WebPage;
import interaction.pageObjects.rfBy;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import testHelp.Utils;

public class SurveySummaryReportPage extends WebPage
{
  protected final By RESPONSES_COUNT = rfBy.datatest("qualifier-counts");
  protected final By RESPONSES_BUTTON = By.xpath("//button//span[text()='Responses']");
  protected final By RESPONSES_MODAL = rfBy.datatest("rf-modal-modal.body");
  protected final By RESPONSES_MODAL_DISMISS = rfBy.datatest("rf-modal-header-dismiss-button");
  protected final By EXPORT_BUTTON = rfBy.datatest("rf-button-trigger-menu");
  protected final By EXPORT_OPTION_SUMMARY = By.xpath("//li[text()='Export Summary']");
  protected final By EXPORT_OPTION_RAWDATA = By.xpath("//li[text()='Export Raw Data']");
  protected final By ADVANCED_FILTERS = By.className("adv-criteria-trigger");
  protected final By ADD_CRITERIA = By.className("add-criteria-button");
  protected final By ADD_CRITERIA_SELECT = By.xpath("//input[@placeholder='Select One']");
  protected final By ADVANCED_SEARCH_OPERATOR = By.className("adv-search-operator");
  protected final By ADVANCED_SEARCH_TYPE_VALUE = By.xpath("//input[@placeholder='Enter Text']");
  protected final By ADVANCED_SEARCH_SELECT_ITEM = By.xpath("//input[@placeholder='Select from list']");
  protected final By ADVANCED_SEARCH_APPLY = By.xpath("//span[text()='Apply']");
  protected final By ADVANCED_SEARCH_CLEAR = By.xpath("//span[text()='Clear']");
  protected final By ADV_EXPR_DROPDOWN = By.xpath("//div[@data-qa='expression']");
  protected final By ADV_EXPR_CUSTOM_INPUT = rfBy.xpath("//div[@class='advanced-expression-container']//input[@data-test='rf-text-input-node']");
  protected final By ADV_EXPR_CUSTOM_COUNT_OPERATOR = By.xpath("//div[@class='advanced-expression-container']//input[@data-test='rf-select-dropdown-trigger']");
  protected final By DELETE_CRITERION = By.xpath("//span[@title='Delete Criteria Item']");
  protected final By ADVANCED_SEARCH_CRITERIA = By.className("adv-search-list-item");
  protected final By SURVEYS_BREADCRUMB = By.xpath("//div[@class='top-breadcrumb']//span[text()='Surveys']");
  protected final By EXPORT_OPTION_SESSION_EVAL = By.xpath("//li[text()='Session Eval']");
  protected final By SELECT_SESSION_DROPDOWN = rfBy.datatest("rf-select-dropdown-trigger");
  protected final By SELECT_SESSION_ITEM = rfBy.datatest("select-dropdown-result-item-1554132467794001swBJ");
  protected final By REMOVE_SELECTED_SESSION = By.className("rf-selected-remove");

  //singleton constructor
  public static SurveySummaryReportPage getPage() {
    return initialize(SurveySummaryReportPage.class);
  }
  
  public int getResponsesCount()
  {
    waitForElementOnPage(RESPONSES_COUNT);
    final String responsesCountString = findElement(RESPONSES_COUNT).getText();
    return Integer.parseInt(StringUtils.split(responsesCountString, " ")[0]);
  }

  public void clickResponses()
  {
    superSafeClick(RESPONSES_BUTTON);
  }
  
  public boolean isResponsesModalVisible()
  {
    return isElementOnPage(RESPONSES_MODAL);
  }
  
  public void closeResponsesModal()
  {
    superSafeClick(RESPONSES_MODAL_DISMISS);
  }
  
  public void clickExport()
  {
    superSafeClick(EXPORT_BUTTON);
  }
  
  public void exportSummary()
  {
    superSafeClick(EXPORT_OPTION_SUMMARY);
  }
  
  public void exportRawData()
  {
    superSafeClick(EXPORT_OPTION_RAWDATA);
  }
  
  public void toggleAdvancedFilters()
  {
    scrollToTopOfPage();
    click(ADVANCED_FILTERS);
  }
  
  public boolean areAdvancedFiltersOpen()
  {
    return findElement(ADD_CRITERIA).isDisplayed();
  }
  
  public void addAttendeeCriteria()
  {
    scrollToTopOfPage();
    findElements(ADD_CRITERIA).get(0).click();
  }
  
  public void addSessionCriteria()
  {
    scrollToTopOfPage();
    findElements(ADD_CRITERIA).get(1).click();
  }
  
  public void selectAdvancedSearchCriteria(final String field)
  {
    scrollToTopOfPage();
    click(ADD_CRITERIA_SELECT);
    
    final By selectField = By.xpath("//span[text()='" + field + "']");
    click(selectField);
  }
  
  public boolean isAdvancedSearchOperatorSelectShowing()
  {
    return isElementOnPage(ADVANCED_SEARCH_OPERATOR);
  }
  
  public boolean isAdvancedSearchValueInputShowing()
  {
    return isElementOnPage(ADVANCED_SEARCH_TYPE_VALUE);
  }
  
  public boolean isAdvancedSearchSelectValueItemShowing()
  {
    return isElementOnPage(ADVANCED_SEARCH_SELECT_ITEM);
  }
  
  public void selectAdvancedSearchOperator(final String operator, final int criterionIndex)
  {
    scrollToTopOfPage();
    final WebElement webElement = findElements(ADVANCED_SEARCH_OPERATOR).get(criterionIndex);
    scrollToElement(webElement);
    webElement.click();
    
    final By operatorField = By.xpath("//span[text()='" + operator + "']");
    click(operatorField);
  }
  
  public void enterAdvancedSearchValue(final String searchValue, final int criterionIndex)
  {
    scrollToTopOfPage();
    findElements(ADVANCED_SEARCH_TYPE_VALUE).get(criterionIndex).click();
    findElements(ADVANCED_SEARCH_TYPE_VALUE).get(criterionIndex).sendKeys(searchValue);
  }
  
  public void selectAdvancedSearchValueItem(final String searchItem, final int criterionIndex)
  {
    scrollToTopOfPage();
    findElements(ADVANCED_SEARCH_SELECT_ITEM).get(criterionIndex).click();
    
    final By selectListItem = By.xpath("//span[text()='" + searchItem + "']");
    click(selectListItem);
  }
  
  public void applyAdvancedSearchCriteria()
  {
    scrollToTopOfPage();
    click(ADVANCED_SEARCH_APPLY);
  }
  
  public void selectAttendeeAdvancedExpression(final String expression)
  {
    click(ADV_EXPR_DROPDOWN);

    final By expressionOption = By.xpath("//span[text()='" + expression + "']");
    click(expressionOption);
  }
  public void selectSessionAdvancedExpression(final String expression)
  {
    final WebElement advancedExpression = findElements(ADV_EXPR_DROPDOWN).get(1);
    scrollToElement(advancedExpression);
    advancedExpression.click();

    final By expressionOption = rfBy.datatest("select-dropdown-result-item-" + expression);
    scrollToElement(expressionOption);
    click(expressionOption);
  }
  
  public void enterCustomExpression(final String customExpression)
  {
    click(ADV_EXPR_CUSTOM_INPUT);
    findElement(ADV_EXPR_CUSTOM_INPUT).sendKeys(customExpression);
  }
  
  public boolean isAdvExprCountOperatorSelectVisible()
  {
    return isElementOnPage(ADV_EXPR_CUSTOM_COUNT_OPERATOR);
  }
  
  public boolean isAdvExprInputVisible()
  {
    return isElementOnPage(ADV_EXPR_CUSTOM_INPUT);
  }
  
  public void deleteCriterion(final int criterionIndex)
  {
    scrollToTopOfPage();
    findElements(DELETE_CRITERION).get(criterionIndex).click();
  }
  
  public int getCriteriaCount()
  {
    return findElements(ADVANCED_SEARCH_CRITERIA).size();
  }
  
  public void clearCriteria()
  {
    scrollToTopOfPage();
    click(ADVANCED_SEARCH_CLEAR);
  }
  
  public void clickSurveysBreadcrumb()
  {
    scrollToTopOfPage();
    click(SURVEYS_BREADCRUMB);
    waitForPageLoad();
  }
  
  @Override
  public String getCurrentUrl()
  {
    return super.getCurrentUrl();
  }
  
  public void exportSessionEval()
  {
    moveTo(EXPORT_OPTION_SESSION_EVAL);
    moveByOffset(50, 50);
    Utils.sleep(1000);
    click(EXPORT_OPTION_SESSION_EVAL);
  }
  
  public void openSessionSelectAndSelectASession()
  {
    scrollToTopOfPage();
    click(SELECT_SESSION_DROPDOWN);
    waitForElementToBeClickable(SELECT_SESSION_ITEM);
    click(SELECT_SESSION_ITEM);
    waitForPageLoad();
  }
  
  public void clearSelectedSession()
  {
    click(REMOVE_SELECTED_SESSION);
    waitForPageLoad();
  }
}
