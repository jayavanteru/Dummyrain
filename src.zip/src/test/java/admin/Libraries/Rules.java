package admin.Libraries;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class Rules {
    protected DataGenerator generator;
    protected String ruleId;
    protected String ruleName;
    protected String email;
    protected String attendeeId;
    protected AdminApp app;

    @BeforeClass
    public void setupDriver() {
        app = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @BeforeMethod
    public void setupAttendee() {
        generator = new DataGenerator();

        ruleName = generator.generateString(5) + "automation";

        //create attendee
        email = generator.generateValidEmail();
        //make sure workflow uses that email
        PropertyReader.instance().setProperty("workflowUsername", email);
        Utils.sleep(500);
        attendeeId = app.createAttendee(email);
        Assert.assertNotNull(attendeeId, "did not create the attendee.");
        Utils.sleep(2000);
    }

    @AfterMethod
    public void delete() {
        PageConfiguration.getPage().navigateTo(app.getHost());
        //delete attendee
        app.deleteAttendee(attendeeId);
        //delete rule
        app.deleteRule(ruleId);
    }

    protected void checkRuleAppliedValue(AdminAttendeeCustomTab attendeeCustomTab, String appliedField, String appliedValue) {
        Utils.waitForTrue(()->attendeeCustomTab.isFieldVisible(appliedField));

        //assert rule checked the box
        Utils.waitForTrue(()->attendeeCustomTab.isCheckBoxChecked(appliedField, appliedValue));
        boolean boxChecked = attendeeCustomTab.isCheckBoxChecked(appliedField, appliedValue);
        Assert.assertTrue(boxChecked, "the newly created rule should have checked " + appliedField + " : " + appliedValue);
    }

    protected void checkRuleDidNotApplyValue(AdminAttendeeCustomTab attendeeCustomTab, String appliedField, String appliedValue) {
        Utils.waitForTrue(()->attendeeCustomTab.isFieldVisible(appliedField));

        //rule should not have changed any value, criteria does not match yet
        boolean boxChecked = attendeeCustomTab.isCheckBoxChecked(appliedField, appliedValue);
        Assert.assertFalse(boxChecked, "the newly created rule should have no affect on this attendee, " + appliedField + " : " + appliedValue + " is checked");
    }

    protected void checkFormSetupRight(AdminAttendeeCustomTab attendeeCustomTab, String appliedField) {
        attendeeCustomTab.navigate(attendeeId);
        Utils.sleep(500);
        Assert.assertTrue(attendeeCustomTab.isFieldVisible(appliedField), "the Attendee Type field is not visible on tab 3, may need to add that");
    }
    
    protected void createRule(AdminRuleCreatePage ruleCreatePage, String appliedField, String appliedValue, Criteria... ruleCriteria) {
        ruleCreatePage.createRule(ruleName, appliedField + ": " + appliedValue, AdminRuleCreatePage.ApplyTo.Attendees, ruleCriteria);
        Utils.waitForTrue(()->app.getRuleId(ruleName) != null);
        ruleId = app.getRuleId(ruleName);
        Assert.assertNotNull(ruleId, "the rule did not save,");
    }

    protected String createRuleReturnId(AdminRuleCreatePage ruleCreatePage, String appliedField, String appliedValue, Criteria... ruleCriteria) {
        ruleCreatePage.createRule(ruleName, appliedField + ": " + appliedValue, AdminRuleCreatePage.ApplyTo.Attendees, ruleCriteria);
        Utils.waitForTrue(()->app.getRuleId(ruleName) != null);
        ruleId = app.getRuleId(ruleName);
        Assert.assertNotNull(ruleId, "the rule did not save,");
        return ruleId;
    }
}
