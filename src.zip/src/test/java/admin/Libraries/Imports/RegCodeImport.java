package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.RegCodeSearchPage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegCodeImport
{
  final DataGenerator dataGenerator = new DataGenerator();

  String firstRegCode = dataGenerator.generateName();
  String secondRegCode = dataGenerator.generateName();

  @BeforeClass
  public void setupTest() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }

  @AfterClass
  public void quit() {
    // Deleting regCodes
    RegCodeSearchPage regCodeSearchPage = RegCodeSearchPage.getPage();
    regCodeSearchPage.GoTo();
    regCodeSearchPage.waitForPageLoad();

    try {
      regCodeSearchPage.deleteRegCode(0, firstRegCode);
      regCodeSearchPage.deleteRegCode(0, secondRegCode);
    } catch (Exception e) {
      Log.error(e, getClass());
    }

    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21286", firefoxIssue = "RA-25467")
  public void submitRegCodeImport() {

    NewImportTemplatePage newImportTemplatePage = NewImportTemplatePage.getPage();
    newImportTemplatePage.navigate();

    setTemplateBoilerPlate();

    //Importing file NoWorkflow
    final String csvFile = createImportCsvNoWorkflowFile(firstRegCode, secondRegCode);
    newImportTemplatePage.chooseFileInput(csvFile);

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as name, which is the key column");

    newImportTemplatePage.chooseImportColumn(0, "Category");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

    newImportTemplatePage.chooseImportColumn(1, "Quantity");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

    newImportTemplatePage.chooseImportColumn(2, "Code");
    newImportTemplatePage.chooseImportColumn(3, "Workflow URI");

    newImportTemplatePage.clickImport();
    Assert.assertTrue(newImportTemplatePage.uploadStatus("Reg Code", 2, 0, 2, 0));

    PageConfiguration.getPage().refreshPage();
    setTemplateBoilerPlate();

    //Importing file WorkflowURI
    final String csvFile2 = createImportCsvWorkflowURIFile(firstRegCode, secondRegCode);
    newImportTemplatePage.chooseFileInput(csvFile2);

    newImportTemplatePage.chooseImportColumn(0, "Category");
    newImportTemplatePage.chooseImportColumn(1, "Quantity");
    newImportTemplatePage.chooseImportColumn(2, "Code");
    newImportTemplatePage.chooseImportColumn(3, "Workflow");
    newImportTemplatePage.chooseImportColumn(4, "Workflow URI");

    newImportTemplatePage.clickImport();
    Assert.assertTrue(newImportTemplatePage.uploadStatus("Reg Code", 2, 2, 0, 0));

    RegCodeSearchPage.getPage().GoTo();
    List<String> regCodeResults = RegCodeSearchPage.getPage().searchForRegCode(firstRegCode);
    Assert.assertEquals(regCodeResults.size(), 1, "did not find the reg code that was imported");
    Assert.assertEquals(regCodeResults.get(0), firstRegCode, "did not find the right reg code");

    regCodeResults = RegCodeSearchPage.getPage().searchForRegCode(secondRegCode);
    Assert.assertEquals(regCodeResults.size(), 1, "did not find the reg code that was imported");
    Assert.assertEquals(regCodeResults.get(0), secondRegCode, "did not find the right reg code");
  }

  private void setTemplateBoilerPlate() {
    NewImportTemplatePage newImportTemplatePage = NewImportTemplatePage.getPage();

    newImportTemplatePage.setTemplateName(dataGenerator.generateName());

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Reg Code Import");

    newImportTemplatePage.clickKeyColumnDropdown();
    newImportTemplatePage.chooseKeyColumn("Code");
  }

  private String createImportCsvNoWorkflowFile(String firstRegCode, String secondRegCode)
  {
    //file with two rows to be uploaded (No Workflow)
    final ArrayList<Map<String, String>> fileNoWorkflow = new ArrayList<>();
    final HashMap<String, String> fileFirstRowNoWorkflow = new HashMap<>();
    fileFirstRowNoWorkflow.put("Reg Code", firstRegCode);
    fileFirstRowNoWorkflow.put("Category", "Test Codes");
    fileFirstRowNoWorkflow.put("Quantity", "1");
    fileFirstRowNoWorkflow.put("Workflow URI", firstRegCode);
    fileNoWorkflow.add(fileFirstRowNoWorkflow);

    final HashMap<String, String> fileSecondRowNoWorkflow = new HashMap<>();
    fileSecondRowNoWorkflow.put("Reg Code", secondRegCode);
    fileSecondRowNoWorkflow.put("Category", "Test Codes");
    fileSecondRowNoWorkflow.put("Quantity", "2");
    fileSecondRowNoWorkflow.put("Workflow URI", secondRegCode);
    fileNoWorkflow.add(fileSecondRowNoWorkflow);

    return CSVParser.createCsvFile(fileNoWorkflow, "regCodeNoWorkflow.csv");
  }

  private String createImportCsvWorkflowURIFile(String firstRegCode, String secondRegCode)
  {
    //file with two rows to be uploaded (Workflow URI)
    final ArrayList<Map<String, String>> fileWorkflowURI = new ArrayList<>();
    final HashMap<String, String> fileFirstRowWorkflowURI = new HashMap<>();
    fileFirstRowWorkflowURI.put("Reg Code", firstRegCode);
    fileFirstRowWorkflowURI.put("Category", "Test Codes");
    fileFirstRowWorkflowURI.put("Quantity", "1");
    fileFirstRowWorkflowURI.put("Workflow URI", firstRegCode);
    fileFirstRowWorkflowURI.put("Workflow", "Registration - General");
    fileWorkflowURI.add(fileFirstRowWorkflowURI);

    final HashMap<String, String> fileSecondRowWorkflowURI = new HashMap<>();
    fileSecondRowWorkflowURI.put("Reg Code", secondRegCode);
    fileSecondRowWorkflowURI.put("Category", "Test Codes");
    fileSecondRowWorkflowURI.put("Quantity", "2");
    fileSecondRowWorkflowURI.put("Workflow URI", secondRegCode);
    fileSecondRowWorkflowURI.put("Workflow", "Registration - General");
    fileWorkflowURI.add(fileSecondRowWorkflowURI);

    return CSVParser.createCsvFile(fileWorkflowURI, "regCodeWorkflowURI.csv");
  }
}
