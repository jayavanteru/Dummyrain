package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.marketing.AdminAccountsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AccountImport
{

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21615", firefoxIssue = "RA-24705")
    public void submitFiles() {
        final DataGenerator dataGenerator = new DataGenerator();

        String accountName = dataGenerator.generateName();

        //file with two rows to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("name", accountName);
        file.add(fileRow);


        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Account Import");

        String templateName = dataGenerator.generateName();
        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickAccountGroupDropdown();
        newImportTemplatePage.chooseAccountGroup("Default Account Group");

        newImportTemplatePage.clickKeyColumnDropdownOnAccountImport();
        newImportTemplatePage.chooseKeyColumn("Account Name");

        final String csvFile = CSVParser.createCsvFile(file, "accountImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as account name, which is the key column");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Account Name");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.uploadStatus("Account", 1, 1, 0, 0);

        //Verify account was created
        AdminAccountsSearchPage adminAccountsSearchPage = AdminAccountsSearchPage.getPage();
        adminAccountsSearchPage.navigate();
        adminAccountsSearchPage.searchFor(accountName);
        Assert.assertTrue(adminAccountsSearchPage.verifyAccountHasRow(accountName));
    }
}

