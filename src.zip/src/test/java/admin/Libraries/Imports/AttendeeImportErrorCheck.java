package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AttendeeImportErrorCheck {

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-24163", firefoxIssue = "RA-24164")
    public void importErrorCheck() {
        final DataGenerator dataGenerator = new DataGenerator();

        //file with over 8000 rows to test error modal
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        for (int i = 0; i < 8001; ++i) {
            HashMap<String, String> fileRow = new HashMap<>();
            fileRow.put("email", dataGenerator.generateEmail());
            fileRow.put("firstName", dataGenerator.generateName());
            fileRow.put("lastName", dataGenerator.generateName());

            file.add(fileRow);
        }

        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        String templateName = dataGenerator.generateName();

        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Attendee Import");

        newImportTemplatePage.clickKeyColumnDropdown();
        newImportTemplatePage.chooseKeyColumn("Email");

        final String csvFile1 = CSVParser.createCsvFile(file, "over8000.csv");
        newImportTemplatePage.chooseFileInput(csvFile1);

        //look for modal on page
        newImportTemplatePage.waitForModalError();

        Assert.assertTrue(newImportTemplatePage.hasErrorModalOnPage());

        //close modal and then continue test
        newImportTemplatePage.clickCloseButton();
    }
}
