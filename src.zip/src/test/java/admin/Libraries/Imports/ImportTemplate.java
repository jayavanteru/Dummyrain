package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditImportTemplatePage;
import apps.admin.adminPageObjects.libraries.ImportTemplatesSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class ImportTemplate
{
  protected DataGenerator dataGenerator;
  private String templateid;

  @BeforeClass
  public void setupTest() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    dataGenerator = new DataGenerator();
  }

  @AfterClass
  public void closeBrowser() {
    PageConfiguration.getPage().quit();
  }

  @AfterMethod
  public void delete() {
    if (templateid != null) {
      ImportTemplatesSearchPage.getPage().deleteImportTemplateById(templateid);
      templateid = null;
    }
  }

  @Test(dataProvider = "importtemplates", groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19877", firefoxIssue = "RA-20390")
  public void importTemplateTypes(String type, boolean skipInsertUpdateRecordCheckboxes) {
    createImportTemplate(type, skipInsertUpdateRecordCheckboxes);
  }

  @DataProvider(name = "importtemplates")
  public Object[][] templates() {

    return new Object[][]{{"Account Import", false}, {"Session Import", false},
            {"Reg Code Import", false}, {"Session Registration Import", false},
            {"Session Attendance Import", false}, {"Leads Import", false},
            {"Exhibitor Import", false}, {"Session Room Import", false},
            {"Meeting Room Import", false},
            {"File Import", true}
    };
  }

  private void createImportTemplate(String importTitle, boolean skipInsertUpdateRecordCheckboxes)
  {
    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();
    PageConfiguration.getPage().justWait();
    newImportTemplatePage.clickSaveButton();
    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted when no info was filled out");

    String templateName = dataGenerator.generateName();

    newImportTemplatePage.setTemplateName(templateName);
    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport(importTitle);
    if(importTitle.equals("Account Import")) {
      newImportTemplatePage.clickAccountGroupDropdown();
      newImportTemplatePage.chooseAccountGroup("Default Account Group");
    }
    newImportTemplatePage.clickSaveButton();

    ImportTemplatesSearchPage importTemplatesSearchPage = new ImportTemplatesSearchPage();
    importTemplatesSearchPage.navigate();
    PageConfiguration.getPage().justWait();
    importTemplatesSearchPage.searchFor(templateName);
    templateid = importTemplatesSearchPage.getTopResultId();
    importTemplatesSearchPage.clickResult(0);

    EditImportTemplatePage editImportTemplatePage = new EditImportTemplatePage();
    editImportTemplatePage.waitForPageLoad();
    if(importTitle.equals("Account Import")) {
      newImportTemplatePage.clickAccountGroupDropdown();
      newImportTemplatePage.chooseAccountGroup("Default Account Group");
    }
    Assert.assertEquals(editImportTemplatePage.getTemplateName(), templateName);
    Assert.assertEquals(editImportTemplatePage.getTemplateType(), importTitle);
    if (!skipInsertUpdateRecordCheckboxes)
    {
      Assert.assertTrue(editImportTemplatePage.isInsertRecords());
      Assert.assertTrue(editImportTemplatePage.isUpdateRecords());
    }

    newImportTemplatePage.setTemplateName("1");
    if (!skipInsertUpdateRecordCheckboxes)
      editImportTemplatePage.clickUpdateRecords();
    newImportTemplatePage.clickSaveButton();
    Assert.assertFalse(newImportTemplatePage.hasErrorsOnPage(), "Import template errors even when all info was filled out");

    importTemplatesSearchPage.navigate();
    importTemplatesSearchPage.waitForPageLoad();
    importTemplatesSearchPage.clickResult(0);
    Assert.assertEquals(editImportTemplatePage.getTemplateName(), templateName + "1");
    if (!skipInsertUpdateRecordCheckboxes)
    {
      Assert.assertTrue(editImportTemplatePage.isInsertRecords());
      Assert.assertFalse(editImportTemplatePage.isUpdateRecords());
    }

    importTemplatesSearchPage.navigate();
    importTemplatesSearchPage.waitForPageLoad();
    boolean deleted = importTemplatesSearchPage.deleteImportTemplateById(templateid);
    Assert.assertTrue(deleted, "Import template was not deleted properly");
    templateid = null;
  }
}
