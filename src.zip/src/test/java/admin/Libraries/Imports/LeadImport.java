package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class LeadImport
{
  private DataGenerator dataGenerator;

  @BeforeClass
  public void setupTest() {
    dataGenerator = new DataGenerator();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }

  @AfterClass
  public void quit() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21623", firefoxIssue = "RA-24749")
  public void submitLeads() {
    AdminApp adminApp = new AdminApp();
    PropertyReader.instance().setProperty("event", "Trogdor Automation");

    String exhibitorName = dataGenerator.generateName();
    String exhibitorId = adminApp.createExhibitor(exhibitorName);
    String attendeeId = adminApp.createAttendee();

    final String csvFile = createImportCsvFile(exhibitorId, attendeeId);

    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Leads Import");
    // NOTE: Important to input name after setting Dropdown or name will not input ¯\_(ツ)_/¯
    String templateName = new DataGenerator().generateName();
    newImportTemplatePage.setTemplateName(templateName);

    newImportTemplatePage.chooseFileInput(csvFile);

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as exhibitor, which is the key column");

    chooseImportColumn(newImportTemplatePage, 0, "attendee");
    chooseImportColumn(newImportTemplatePage, 1, "date/time");
    chooseImportColumn(newImportTemplatePage, 2, "exhibitor");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.uploadStatus("Leads", 1, 1, 0, 0);

    adminApp.deleteAttendee(attendeeId);
    adminApp.deleteExhibitor(exhibitorId);
  }

  private void chooseImportColumn(NewImportTemplatePage newImportTemplatePage, int index, String columnName)
  {
    newImportTemplatePage.clickColumnDropdown(index);
    newImportTemplatePage.setColumnDropdownSearch(columnName);
    newImportTemplatePage.clickFirstDropdownSearchResult();
  }

  private String createImportCsvFile(String exhibitorId, String attendeId)
  {
    //file with one row to be uploaded
    final ArrayList<Map<String, String>> file = new ArrayList<>();
    final HashMap<String, String> fileRow = new HashMap<>();
    fileRow.put("exhibitor", exhibitorId);
    fileRow.put("attendee", attendeId);
    fileRow.put("date/time", dataGenerator.generateDateStringAfterNow("yyyy-MM-dd HH:mm:ss"));
    file.add(fileRow);

    return CSVParser.createCsvFile(file, "meetingRoomImport.csv");
  }
}
