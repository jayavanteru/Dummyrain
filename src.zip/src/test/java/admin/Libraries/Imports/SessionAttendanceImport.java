package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionDaysSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SessionAttendanceImport
{

    private AdminApp adminApp = new AdminApp();
    private DataGenerator dataGenerator = new DataGenerator();

    private String attendeeId = "";
    private String attendeeEmail = dataGenerator.generateEmail();
    private String sessionId = "";
    private String sessionCode = "";
    private String sessionTimeId = "";
    private String dayId = "";
    private String room = "";

    EditSessionPage editSessionPage = new EditSessionPage();
    AdminSchedulingTab adminSchedulingTab = new AdminSchedulingTab();
    SessionDaysSearchPage sessionDaysSearchPage = new SessionDaysSearchPage();
    AttendeeScheduleTab attendeeScheduleTab = new AttendeeScheduleTab();

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        //Create attendee
        attendeeId = adminApp.createAttendee(attendeeEmail);

        //Create & schedule session
        String dayName = dataGenerator.generateName();
        dayId = adminApp.createDay(dayName, dataGenerator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY), dataGenerator.generateString());
        String time1 = "07:00 AM";
        room = adminApp.createSessionRoom(dataGenerator.generateName());

        sessionId = adminApp.createSessionWithLength(30);
        editSessionPage.waitForPageLoad();
        editSessionPage.setSessionStatus("Accepted");
        sessionCode = editSessionPage.getSessionCode();
        adminSchedulingTab.scheduleSessionTime(dayName, time1, room);
        sessionTimeId = adminSchedulingTab.getSessionTimeId();
    }

    @AfterClass
    public void closeBrowser() {
        //Delete attendee
        adminApp.deleteAttendee(attendeeId);

        //Delete Session
        adminSchedulingTab.navigate(sessionId);
        adminSchedulingTab.clickScheduleTab();
        adminSchedulingTab.deleteAllSessions();
        adminApp.deleteSession(sessionId);
        adminApp.deleteSessionRoom(room);
        sessionDaysSearchPage.deleteSessionDayById(dayId);

        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21620", firefoxIssue = "RA-24639")
    public void submitAttendance() {

        //file with one row to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("email", attendeeEmail);
        fileRow.put("sessionTime", sessionTimeId);
        file.add(fileRow);

        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Session Attendance Import");
        // NOTE: Important to input name after setting Dropdown or name will not input ¯\_(ツ)_/¯
        String templateName = dataGenerator.generateName();
        newImportTemplatePage.setTemplateName(templateName);

        final String csvFile = CSVParser.createCsvFile(file, "sessionAttendanceImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as attendee email, which is the key column");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Email");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as session Time, which is a mandatory column");

        newImportTemplatePage.clickColumnDropdown(1);
        newImportTemplatePage.setColumnDropdownSearch("Session Time");

        newImportTemplatePage.clickImport();

        Assert.assertTrue(newImportTemplatePage.uploadStatus("Session Attendance", 1, 1, 0, 0));

        //Verify attendee was created and marked as attended
        attendeeScheduleTab.navigate(attendeeId);
        attendeeScheduleTab.clickAttendedTab();

        Assert.assertTrue(attendeeScheduleTab.sessionExists(sessionCode), "Session not imported correctly");

        //Mark attendee as unattended
        attendeeScheduleTab.unscheduleSession();

        Utils.waitForTrue(() -> !attendeeScheduleTab.sessionExists(sessionCode));
        Assert.assertFalse(attendeeScheduleTab.sessionExists(sessionCode), "Session not unscheduled");
    }
}

