package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ExhibitorImport
{

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21621", firefoxIssue = "RA-24517")
    public void submitExhibitors() {
        final DataGenerator dataGenerator = new DataGenerator();

        //file with one row to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("name", dataGenerator.generateName());
        file.add(fileRow);

        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        String templateName = dataGenerator.generateName();

        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Exhibitor Import");

        newImportTemplatePage.clickKeyColumnDropdown();
        newImportTemplatePage.chooseKeyColumn("Name");

        final String csvFile = CSVParser.createCsvFile(file, "exhibitorImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as name, which is the key column");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Name");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.uploadStatus("Exhibitor", 1, 1, 0, 0);

        //Delete exhibitor
        ExhibitorSearchPage exhibitorSearchPage = new ExhibitorSearchPage();
        exhibitorSearchPage.navigate();
        exhibitorSearchPage.waitForPageLoad();

        exhibitorSearchPage.searchFor(fileRow.get("name"));
        Assert.assertTrue(exhibitorSearchPage.isAnySearchResults());
        Utils.sleep(200);
        boolean deleted = exhibitorSearchPage.deleteEntityById("exhibitorDelete.focus", exhibitorSearchPage.getTopResultId());
        Assert.assertTrue(deleted, "Exhibitor was not deleted properly");
    }
}
