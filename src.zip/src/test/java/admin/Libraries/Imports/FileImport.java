package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.AdminAttendeeFilesPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FileImport
{

    private AdminApp adminApp = new AdminApp();
    private DataGenerator dataGenerator = new DataGenerator();
    private AttendeeSearchPage attendeeSearchPage = new AttendeeSearchPage();

    private String attendeeId = "";
    private String attendeeEmail = dataGenerator.generateEmail();

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        //Create attendee
        attendeeId = adminApp.createAttendee(attendeeEmail);
    }

    @AfterClass
    public void closeBrowser() {
        //Delete attendee
        adminApp.deleteAttendee(attendeeId);

        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21625", firefoxIssue = "RA-24568")
    public void submitFiles() {

        //file with one row to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("email", attendeeEmail);
        fileRow.put("fileType", "Speaker Image");
        fileRow.put("linkURL", "https://cdn3-www.superherohype.com/assets/uploads/2016/01/batbarlego1.jpg");
        file.add(fileRow);

        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("File Import");
        // NOTE: Important to input name after setting Dropdown or name will not input ¯\_(ツ)_/¯
        String templateName = dataGenerator.generateName();
        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickKeyColumnDropdown();
        newImportTemplatePage.chooseKeyColumn("Attendee Email");

        final String csvFile = CSVParser.createCsvFile(file, "fileImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as attendee email, which is the key column");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Attendee Email");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

        newImportTemplatePage.clickColumnDropdown(1);
        newImportTemplatePage.setColumnDropdownSearch("File Type");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory column was not set");

        newImportTemplatePage.clickColumnDropdown(2);
        newImportTemplatePage.setColumnDropdownSearch("Link URL");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.uploadStatus("File", 1, 1, 0, 0);

        //Verify attendee was created and file was uploaded
        AdminAttendeeFilesPage attendeeFilesPage = new AdminAttendeeFilesPage();
        attendeeFilesPage.navigate(attendeeId);
        attendeeFilesPage.waitForPageLoad();

        Assert.assertTrue(attendeeFilesPage.isFileUploaded(), "File was not uploaded");

        //Delete file from attendee record
        attendeeFilesPage.deleteFirstFile();

        Assert.assertFalse(attendeeFilesPage.isFileUploaded(), "File was not deleted properly");
    }
}
