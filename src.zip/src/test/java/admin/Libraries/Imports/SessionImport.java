package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SessionImport
{
  @BeforeClass
  public void setupTest() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }

  @AfterClass
  public void quit() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21616", firefoxIssue = "RA-24751")
  public void submitSession() {
    final DataGenerator dataGenerator = new DataGenerator();

    //file with one row to be uploaded
    final ArrayList<Map<String, String>> file = new ArrayList<>();
    final HashMap<String, String> fileRow = new HashMap<>();
    fileRow.put("code", dataGenerator.generateString());
    fileRow.put("title", dataGenerator.generateString());
    fileRow.put("abstract", dataGenerator.generateString());
    fileRow.put("length", "15");
    fileRow.put("status", dataGenerator.generateString());
    file.add(fileRow);

    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();

    String templateName = dataGenerator.generateName();

    newImportTemplatePage.setTemplateName(templateName);

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Session Import");

    newImportTemplatePage.clickKeyColumnDropdown();
    newImportTemplatePage.chooseKeyColumn("Code");

    final String csvFile = CSVParser.createCsvFile(file, "sessionImport.csv");
    newImportTemplatePage.chooseFileInput(csvFile);

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as name, which is the key column");

    newImportTemplatePage.clickColumnDropdown(0);
    newImportTemplatePage.setColumnDropdownSearch("Abstract");

    newImportTemplatePage.clickColumnDropdown(1);
    newImportTemplatePage.setColumnDropdownSearch("Code");

    newImportTemplatePage.clickColumnDropdown(2);
    newImportTemplatePage.setColumnDropdownSearch("Length (in minutes)");

    newImportTemplatePage.clickColumnDropdown(3);
    newImportTemplatePage.setColumnDropdownSearch("Status");

    newImportTemplatePage.clickColumnDropdown(4);
    newImportTemplatePage.setColumnDropdownSearch("Title");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.uploadStatus("Session", 1, 1, 0, 0);

    SessionSearchPage sessionSearchPage = new SessionSearchPage();
    sessionSearchPage.navigate();
    sessionSearchPage.waitForPageLoad();

    sessionSearchPage.searchFor(fileRow.get("code"));
    Assert.assertTrue(sessionSearchPage.isAnySearchResults());
    Utils.sleep(200);
    Set<String> sessionIds = sessionSearchPage.getAllIds(fileRow.get("title"));
    AdminApp adminApp = new AdminApp();
    sessionIds.forEach(adminApp::deleteSession);
  }
}
