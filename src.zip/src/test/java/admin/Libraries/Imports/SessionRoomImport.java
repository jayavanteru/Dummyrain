package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.RoomsSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SessionRoomImport
{

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void quit() {
        PageConfiguration.getPage().quit();
    }

    @Test (groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21617", firefoxIssue = "RA-24547")
    public void submitSessionRooms() {
        final DataGenerator dataGenerator = new DataGenerator();

        //file with one row to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("name", dataGenerator.generateName());
        fileRow.put("capacity", "100");
        fileRow.put("notes", dataGenerator.generateString());
        file.add(fileRow);

        NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
        newImportTemplatePage.navigate();

        String templateName = dataGenerator.generateName();

        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Session Room Import");

        final String csvFile = CSVParser.createCsvFile(file, "sessionRoomImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as name, which is the key column");

        newImportTemplatePage.clickColumnDropdown(1);
        newImportTemplatePage.setColumnDropdownSearch("Name");

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Capacity");

        newImportTemplatePage.clickColumnDropdown(2);
        newImportTemplatePage.setColumnDropdownSearch("Notes");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.uploadStatus("Session Room", 1, 1, 0, 0);

        //Delete session room
        RoomsSearchPage roomsSearchPage = new RoomsSearchPage();
        roomsSearchPage.navigate();
        roomsSearchPage.waitForPageLoad();

        roomsSearchPage.searchFor(fileRow.get("name"));
        Assert.assertTrue(roomsSearchPage.isAnySearchResults());
        Utils.sleep(200);
        boolean deleted = roomsSearchPage.deleteEntityById("roomDelete.focus", roomsSearchPage.getTopResultId());
        Assert.assertTrue(deleted, "Session Room was not deleted properly");
    }
}
