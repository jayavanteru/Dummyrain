package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionDaysSearchPage;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SessionRegImport
{
  private AdminApp adminApp = new AdminApp();
  private DataGenerator dataGenerator = new DataGenerator();

  private String firstAttendeeId = "";
  private String firstAttendeeEmail = dataGenerator.generateEmail();
  private String secondAttendeeId = "";
  private String secondAttendeeEmail = dataGenerator.generateEmail();
  private String sessionId = "";
  private String sessionCode = "";
  private String sessionTimeId = "";
  private String dayId = "";
  private String room = "";

  EditSessionPage editSessionPage = new EditSessionPage();
  AdminSchedulingTab adminSchedulingTab = new AdminSchedulingTab();
  SessionDaysSearchPage sessionDaysSearchPage = new SessionDaysSearchPage();
  AttendeeScheduleTab attendeeScheduleTab = new AttendeeScheduleTab();

  @BeforeClass
  public void setupTest() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

    //Create first attendee
    firstAttendeeId = adminApp.createAttendee(firstAttendeeEmail);

    //Create second attendee
    secondAttendeeId = adminApp.createAttendee(secondAttendeeEmail);

    //Create and schedule session
    String dayName = dataGenerator.generateName();
    dayId = adminApp.createDay(dayName, dataGenerator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY), dataGenerator.generateString());
    String time1 = "07:00 AM";
    room = adminApp.createSessionRoom(dataGenerator.generateName());

    sessionId = adminApp.createSessionWithLength(30);
    editSessionPage.waitForPageLoad();
    editSessionPage.setSessionStatus("Accepted");
    editSessionPage.setSessionCapacity("1");
    sessionCode = editSessionPage.getSessionCode();
    adminSchedulingTab.scheduleSessionTime(dayName, time1, room);
    sessionTimeId = adminSchedulingTab.getSessionTimeId();
  }

  @AfterClass
  public void closeBrowser() {
    //Delete first Attendee
    adminApp.deleteAttendee(firstAttendeeId);

    //Delete second Attendee
    adminApp.deleteAttendee(secondAttendeeId);

    //Delete session
    adminSchedulingTab.navigate(sessionId);
    adminSchedulingTab.clickScheduleTab();
    adminSchedulingTab.deleteAllSessions();
    adminApp.deleteSession(sessionId);
    adminApp.deleteSessionRoom(room);
    sessionDaysSearchPage.deleteSessionDayById(dayId);

    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21619", firefoxIssue = "RA-25511")
  public void submitSessionReg() {
    //file with two rows to be uploaded
    final ArrayList<Map<String, String>> file = new ArrayList<>();
    final HashMap<String, String> firstFileRow = new HashMap<>();
    firstFileRow.put("email", firstAttendeeEmail);
    firstFileRow.put("sessionTime", sessionTimeId);
    file.add(firstFileRow);

    final HashMap<String, String> secondFileRow = new HashMap<>();
    secondFileRow.put("email", secondAttendeeEmail);
    secondFileRow.put("sessionTime", sessionTimeId);
    file.add(secondFileRow);

    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Session Registration Import");
    // NOTE: Important to input name after setting Dropdown or name will not input ¯\_(ツ)_/¯
    String templateName = dataGenerator.generateName();
    newImportTemplatePage.setTemplateName(templateName);

    final String csvFile = CSVParser.createCsvFile(file, "sessionRegImport.csv");
    newImportTemplatePage.chooseFileInput(csvFile);

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as attendee email, which is the key column");

    newImportTemplatePage.clickColumnDropdown(0);
    newImportTemplatePage.setColumnDropdownSearch("Email");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as session Time, which is a mandatory column");

    newImportTemplatePage.clickColumnDropdown(1);
    newImportTemplatePage.setColumnDropdownSearch("Session Time");

    newImportTemplatePage.clickImport();

    Assert.assertTrue(newImportTemplatePage.uploadStatus("Session Registration", 2, 2, 0, 0));

    //Verify first attendee was created and marked as attended
    attendeeScheduleTab.navigate(firstAttendeeId);
    attendeeScheduleTab.clickEnrolledTab();

    Assert.assertTrue(attendeeScheduleTab.sessionExists(sessionCode), "Session not imported correctly");

    //Mark attendee as unattended
    attendeeScheduleTab.unscheduleSession();

    Utils.waitForTrue(() -> !attendeeScheduleTab.sessionExists(sessionCode));
    Assert.assertFalse(attendeeScheduleTab.sessionExists(sessionCode), "Session not unscheduled");

    //Verify second attendee was created and marked as attended
    attendeeScheduleTab.navigate(secondAttendeeId);
    attendeeScheduleTab.clickEnrolledTab();

    Assert.assertTrue(attendeeScheduleTab.sessionExists(sessionCode), "Session not imported correctly");

    //Mark attendee as unattended
    attendeeScheduleTab.unscheduleSession();

    Utils.waitForTrue(() -> !attendeeScheduleTab.sessionExists(sessionCode));
    Assert.assertFalse(attendeeScheduleTab.sessionExists(sessionCode), "Session not unscheduled");
  }
}
