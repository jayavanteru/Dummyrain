package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.libraries.TranslationSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TranslationImport
{

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    //translation import is no longer a choice RA-41994
//    @Test (groups = {ReportingInfo.TROGDOR})
//    @ReportingInfo(chromeIssue = "RA-21624", firefoxIssue = "RA-24640")
    public void submitFiles() {
        final DataGenerator dataGenerator = new DataGenerator();

        // this key is one from the old widgets that no longer gets used, so it is safe to mess with
        // make sure it stays there!
        String translationPropertyKey = "catalog.daytimefilter.noselection";
        String translationLanguage = "Spanish";
        String translationLanguageCode = "es";
        String translationValue = dataGenerator.generateString();

        //file with one row to be uploaded
        final ArrayList<Map<String, String>> file = new ArrayList<>();
        final HashMap<String, String> fileRow = new HashMap<>();
        fileRow.put("key", translationPropertyKey);
        fileRow.put("language", translationLanguageCode);
        fileRow.put("translatedValue", translationValue);
        fileRow.put("type", "static");
        file.add(fileRow);


        NewImportTemplatePage newImportTemplatePage = NewImportTemplatePage.getPage();
        newImportTemplatePage.navigate();

        String templateName = dataGenerator.generateName();

        newImportTemplatePage.setTemplateName(templateName);

        newImportTemplatePage.clickTemplateTypeDropdown();
        newImportTemplatePage.chooseImport("Translation Import");

        final String csvFile = CSVParser.createCsvFile(file, "translationImport.csv");
        newImportTemplatePage.chooseFileInput(csvFile);

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as attendee email, which is the key column");

        newImportTemplatePage.clickColumnDropdown(0);
        newImportTemplatePage.setColumnDropdownSearch("Key Property");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

        newImportTemplatePage.clickColumnDropdown(1);
        newImportTemplatePage.setColumnDropdownSearch("Language");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory column was not set");

        newImportTemplatePage.clickColumnDropdown(2);
        newImportTemplatePage.setColumnDropdownSearch("Translated Value");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.waitForError();

        Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory column was not set");

        newImportTemplatePage.clickColumnDropdown(3);
        newImportTemplatePage.setColumnDropdownSearch("Type");

        newImportTemplatePage.clickImport();
        newImportTemplatePage.uploadStatus("Translation", 1, 1, 0, 0);

        //Verify translation value has been updated
        TranslationSearchPage translationSearchPage = TranslationSearchPage.getPage();
        translationSearchPage.navigate();
        translationSearchPage.waitForPageLoad();
        translationSearchPage.searchFor(translationPropertyKey);

        //filter by language
        translationSearchPage.filterByLanguage(translationLanguage);

        //Assert that translated value matches
        translationSearchPage.verifyTranslationByTranslatedValue(0, translationValue);
    }
}

