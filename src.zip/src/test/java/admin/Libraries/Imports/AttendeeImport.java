package admin.Libraries.Imports;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AttendeeImport
{

  @BeforeClass
  public void setupTest() {
    //PropertyReader.instance().setProperty("enableDesktopAutomation", true);
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }

  @AfterClass
  public void closeBrowser() {
    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-21070", firefoxIssue = "RA-24162")
  public void submitAttendees() {
    final DataGenerator dataGenerator = new DataGenerator();

    //file with one row to be uploaded
    final ArrayList<Map<String, String>> file = new ArrayList<>();
    final HashMap<String, String> fileRow = new HashMap<>();
    fileRow.put("email", dataGenerator.generateEmail());
    fileRow.put("firstname", dataGenerator.generateName());
    fileRow.put("lastname", dataGenerator.generateName());
    file.add(fileRow);


    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();

    String templateName = dataGenerator.generateName();

    newImportTemplatePage.setTemplateName(templateName);

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Attendee Import");

    newImportTemplatePage.clickKeyColumnDropdown();
    newImportTemplatePage.chooseKeyColumn("Email");

    final String csvFile2 = CSVParser.createCsvFile(file, "attendeeImport.csv");
    newImportTemplatePage.chooseFileInput(csvFile2);

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though no column was selected as email, which is the key column");

    newImportTemplatePage.clickColumnDropdown(0);
    newImportTemplatePage.setColumnDropdownSearch("Email");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though mandatory columns were not set");

    newImportTemplatePage.clickColumnDropdown(1);
    newImportTemplatePage.setColumnDropdownSearch("First Name");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.waitForError();

    Assert.assertTrue(newImportTemplatePage.hasErrorsOnPage(), "Import template submitted even though Last Name was not set");

    newImportTemplatePage.clickColumnDropdown(2);
    newImportTemplatePage.setColumnDropdownSearch("Last Name");

    newImportTemplatePage.clickImport();
    newImportTemplatePage.uploadStatus("Attendee", 1, 1, 0, 0);

    AttendeeSearchPage attendeeSearchPage = new AttendeeSearchPage();
    attendeeSearchPage.navigate();
    attendeeSearchPage.waitForPageLoad();

    attendeeSearchPage.searchFor(fileRow.get("email"));
    Assert.assertTrue(attendeeSearchPage.isAnySearchResults());
    Utils.sleep(200);
    boolean deleted = attendeeSearchPage.deleteEntityById("attendeeDelete.focus", attendeeSearchPage.getTopResultId());
    Assert.assertTrue(deleted, "Attendee was not deleted properly");
  }
}
