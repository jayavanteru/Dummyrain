package admin.Libraries.TaskQualifiers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class DemoTaskQualifier {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String qualifierName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event A");
        NavigationBar.getPage().collapse();

        //create task qualifier
        qualifierName = dataGenerator.generateName();
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().setEntityType("Demos");
        NewTaskQualifierPage.getPage().setCriterion(new Criteria("Name", "contains" ,dataGenerator.generateString()));
        NewTaskQualifierPage.getPage().save();
    }

    @AfterClass
    public void afterClass() {
        //delete qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().deleteFirstRecord();

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33855", firefoxIssue = "RA-35212")
    public void demoTaskQualifier() {
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setEntityType("Demo");
        NewTaskPage.getPage().setQualifiers(qualifierName);
        Assert.assertTrue(NewTaskPage.getPage().qualifierExists(qualifierName));
    }
}
