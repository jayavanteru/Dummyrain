package admin.Libraries.TaskQualifiers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class SessionTaskQualifier {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String taskQualifierName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        NavigationBar.getPage().collapse();

        //create session task qualifier
        taskQualifierName = dataGenerator.generateName();
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().setName(taskQualifierName);
        NewTaskQualifierPage.getPage().setEntityType("Sessions");
        NewTaskQualifierPage.getPage().setCriterion(new Criteria("Code", "contains", "test"));
        NewTaskQualifierPage.getPage().clickSubmit();
    }

    @AfterClass
    public void afterClass() {
        //delete session task qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(taskQualifierName);
        TaskQualifierSearchPage.getPage().deleteFirstRecord();

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33852", firefoxIssue = "RA-34673")
    public void createSessionTaskQualifier() {
        //assert task exists
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(taskQualifierName);
        Assert.assertTrue(TaskQualifierSearchPage.getPage().qualifierExists(taskQualifierName), "QUALIFIER WAS NOT CREATED");

        //assert task can be used
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setEntityType("Session");
        NewTaskPage.getPage().setQualifiers(taskQualifierName);
        Assert.assertTrue(NewTaskPage.getPage().qualifierExists(taskQualifierName), "QUALIFIER DOES NOT EXIST");
    }
}
