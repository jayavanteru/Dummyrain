package admin.Libraries.TaskQualifiers;

import apps.PageConfiguration;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class TaskQualifiers {
    String qualifierName = new DataGenerator().generateName();
    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().addItem();
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().setCriteriaByAttendeeLastName("Rene");
        NewTaskQualifierPage.getPage().save();
    }
    @AfterClass
    public void tearDown(){
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        if (TaskQualifierSearchPage.getPage().qualifierExists(qualifierName)) {
            TaskQualifierSearchPage.getPage().deleteFirstRecord();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27339", firefoxIssue = "RA-27340")
    public void createTaskQualifier(){
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        Assert.assertTrue(TaskQualifierSearchPage.getPage().qualifierExists(qualifierName));
    }

    @Test (groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-23244", firefoxIssue = "RA-20481")
    public void editTaskQualifierWithCriterion() {
        // search for created Task Qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().select(qualifierName);
        // edit and save changes to Task Qualifier
        String taskQualifierUpdatedName = qualifierName + "editing";
        Criteria taskQualifyForEditing = new Criteria("Email", "contains", "@rainfocus.com");
        NewTaskQualifierPage.getPage().setName(taskQualifierUpdatedName);
        NewTaskQualifierPage.getPage().setEntityType("Attendees");
        NewTaskQualifierPage.getPage().deleteCriteria(0);
        NewTaskQualifierPage.getPage().addCriteria();
        NewTaskQualifierPage.getPage().setCriterion(taskQualifyForEditing);
        NewTaskQualifierPage.getPage().save();

        TaskQualifierSearchPage.getPage().searchFor(taskQualifierUpdatedName);
        Assert.assertTrue(TaskQualifierSearchPage.getPage().qualifierExists(taskQualifierUpdatedName));
        TaskQualifierSearchPage.getPage().deleteFirstRecord();
        TaskQualifierSearchPage.getPage().searchFor(taskQualifierUpdatedName);
        Assert.assertFalse(TaskQualifierSearchPage.getPage().qualifierExists(taskQualifierUpdatedName));

        //History Tracking: Task Qualifiers
        ReportingPage.getPage().navigateTo();
        ReportingPage.getPage().clickOnReport("History Tracking: Task Qualifiers");
        if (ReportingPage.getPage().isPaginated()) {
            ReportingPage.getPage().selectLastPage();
        }
        String reportAction = ReportingPage.getPage().getCellValueFromNthFromBottomRow(0, 2);
        String reportProperty = ReportingPage.getPage().getCellValueFromNthFromBottomRow(0, 7);
        String reportOldValue = ReportingPage.getPage().getCellValueFromNthFromBottomRow(0, 8);
        String reportSubmitterName = ReportingPage.getPage().getCellValueFromNthFromBottomRow(0, 10);

        Assert.assertEquals(reportAction, "delete", "cannot locate the delete value");
        Assert.assertEquals(reportProperty, "name", "cannot locate the name value");
        Assert.assertEquals(reportOldValue, taskQualifierUpdatedName, "cannot locate the updated name");
        Assert.assertEquals(reportSubmitterName, "Test Automation", "cannot locate the Automation user's name");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27342", firefoxIssue = "RA-27343")
    public void deleteTaskQualifier(){
        String qualifierName = new DataGenerator().generateName();
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().addItem();
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().setCriteriaByAttendeeLastName("Rene");
        NewTaskQualifierPage.getPage().save();

        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().deleteFirstRecord();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        Assert.assertFalse(TaskQualifierSearchPage.getPage().qualifierExists(qualifierName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27355", firefoxIssue = "RA-27356")
    public void editTaskQualifier(){
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().select(qualifierName);
        String newQualifierName = new DataGenerator().generateName();
        qualifierName = newQualifierName;
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().save();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        Assert.assertTrue(TaskQualifierSearchPage.getPage().qualifierExists(qualifierName));
    }
}
