package admin.Libraries.TaskQualifiers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class MeetingTaskQualifiers {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String taskQualifierName, taskQualifierId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event F");
        NavigationBar.getPage().collapse();

        //create task qualifier
        taskQualifierId = adminApp.createTaskQualifier(taskQualifierName = dataGenerator.generateName(),
                "Meetings",
                new Criteria[]{
                        new Criteria("Code", "contains", dataGenerator.generateName())
                },
                "OR");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteTaskQualifier(taskQualifierId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(chromeIssue = "RA-33853", firefoxIssue = "RA-36910")
    public void createMeetingTaskQualifier() {
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setEntityType("Meeting");
        NewTaskPage.getPage().setQualifiers(taskQualifierName);
        Assert.assertTrue(NewTaskPage.getPage().qualifierExists(taskQualifierName));
    }
}
