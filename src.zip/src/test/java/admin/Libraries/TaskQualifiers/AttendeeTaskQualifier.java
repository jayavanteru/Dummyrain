package admin.Libraries.TaskQualifiers;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

         public class AttendeeTaskQualifier {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String qualifierName;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        NavigationBar.getPage().collapse();

        //create task qualifier
        qualifierName = dataGenerator.generateName();
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().setEntityType("Attendees");
        NewTaskQualifierPage.getPage().setCriterion(new Criteria("First Name", "contains", "123"));
        NewTaskQualifierPage.getPage().save();
    }

    @AfterClass
    public void afterClass() {
        //delete task qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        TaskQualifierSearchPage.getPage().deleteFirstRecord();

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33851", firefoxIssue = "RA-35026")
    public void attendeeTaskQualifier() {
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setEntityType("Attendee");
        NewTaskPage.getPage().setQualifiers(qualifierName);
        Assert.assertTrue(NewTaskPage.getPage().qualifierExists(qualifierName), "QUALIFIER DOES NOT EXIST");
    }
}
