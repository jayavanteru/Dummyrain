package admin.Libraries.FileTypes;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.FileTypesSearchPage;
import apps.admin.adminPageObjects.libraries.NewFileTypePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class FileTypes {
    DataGenerator dataGenerator = new DataGenerator();
    String fileType = dataGenerator.generateName();
    String abbreviation = dataGenerator.generateString(4);

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");

        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().addItem();
        NewFileTypePage.getPage().setName(fileType);
        NewFileTypePage.getPage().setAbbreviation(abbreviation);
        NewFileTypePage.getPage().setAdminFileSizeMB("50");
        NewFileTypePage.getPage().setWorkFlowFileSizeMB("50");
        NewFileTypePage.getPage().submit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27455", firefoxIssue = "RA-27456")
    public void createFileType(){
        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search(fileType);
        Assert.assertTrue(FileTypesSearchPage.getPage().recordExists(fileType), "File type with name '"+fileType+"' does not exist.");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27459", firefoxIssue = "RA-27460")
    public void deleteFileType(){
        String fileType = dataGenerator.generateName();
        String abbreviation = dataGenerator.generateString(4);
        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().addItem();
        NewFileTypePage.getPage().setName(fileType);
        NewFileTypePage.getPage().setAbbreviation(abbreviation);
        NewFileTypePage.getPage().setAdminFileSizeMB("50");
        NewFileTypePage.getPage().setWorkFlowFileSizeMB("50");
        NewFileTypePage.getPage().submit();

        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search(fileType);
        FileTypesSearchPage.getPage().deleteFirstRecord();
        FileTypesSearchPage.getPage().search(fileType);
        Assert.assertFalse(FileTypesSearchPage.getPage().recordExists(fileType), "File Type '" + fileType + "' was not deleted");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27597", firefoxIssue = "RA-27598")
    public void addContentType(){
        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search(fileType);
        FileTypesSearchPage.getPage().selectRecord(fileType);
        NewFileTypePage.getPage().addContentType();
        if(!NewFileTypePage.getPage().extensionExists("html")){
            NewFileTypePage.getPage().manageContentTypes();
            NewFileTypePage.getPage().addExtension("html");
            NewFileTypePage.getPage().addContentType();
            NewFileTypePage.getPage().selectContentType("html");
        } else {
            NewFileTypePage.getPage().selectContentType("html");
        } NewFileTypePage.getPage().submit();
        FileTypesSearchPage.getPage().search(fileType);
        FileTypesSearchPage.getPage().selectRecord(fileType);
        Assert.assertTrue(NewFileTypePage.getPage().contentTypeExists("html"));
    }

    @AfterClass
    public void tearDown(){
        FileTypesSearchPage.getPage().navigate();
        FileTypesSearchPage.getPage().search(fileType);
        FileTypesSearchPage.getPage().deleteFirstRecord();
        PageConfiguration.getPage().quit();
    }
}
