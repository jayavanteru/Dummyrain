package admin.Libraries;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
import apps.admin.adminPageObjects.libraries.AdminRuleSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.Log;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;

public class AdminRules extends Rules {

    public AdminApp adminApp;
    public String ruleId;

    @BeforeClass
    public void checkRuleDeleted() {
        adminApp = new AdminApp();
        AdminRuleSearchPage ruleSearchPage = AdminRuleSearchPage.getPage();
        ruleSearchPage.navigate();
        ruleSearchPage.deleteRuleByRuleDescription("Attendee Type: Press");
        ruleSearchPage.deleteRuleByRuleDescription("Attendee Type: Exhibitor");
        ruleSearchPage.deleteRuleByRuleDescription("Attendee Type: Vendor");
        ruleSearchPage.deleteRuleByRuleDescription("Attendee Type: Booth Staff");
    }

    @AfterMethod
    public void deleteRule(){
        adminApp.deleteRule(ruleId);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25893", chromeIssue = "RA-25892")
    public void rule_formSave() {
        String appliedField = "Attendee Type";
        String appliedValue = "Exhibitor";
        String criteriaField = "State";
        String criteriaFieldId = "formAttendee.stateId";
        String criteriaFieldValue = "Texas";
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);

        ruleCreatePage.navigate();

        //if state is Texas
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, "equal to", criteriaFieldValue);
        ruleId = createRuleReturnId(ruleCreatePage, appliedField, appliedValue, ruleCriteria);


        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);
        Assert.assertTrue(attendeeCustomTab.isFieldVisible(criteriaField), "the state field is not visible on tab 4, may need to add that");

        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //change state on an attendee form
        attendeeCustomTab.selectSelectField(criteriaFieldId, criteriaFieldValue);
        attendeeCustomTab.submit();
        Utils.sleep(2000);

        //verify rule took affect
        PageConfiguration.getPage().refreshPage();
        //assert the form saved the right stuff
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25903", chromeIssue = "RA-25899")
    public void rule_orderCreation() {
        String appliedField = "Attendee Type";
        String appliedValue = "Vendor";
        String criteriaField = "Paid in Full";
        String packageName = "Approval Package";
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);

        ruleCreatePage.navigate();

        //if an order is paid in full
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, true);
        ruleId = createRuleReturnId(ruleCreatePage, appliedField, appliedValue, ruleCriteria);

        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);

        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //order creation
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.selectPackage(packageName);
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.fillOutOrder();
        ordersTab.markAsPaid();
        ordersTab.submitOrder();
        Utils.sleep(2000);

        //verify rule took affect
        attendeeCustomTab.navigate(attendeeId);
        Utils.sleep(500);
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-25906", chromeIssue = "RA-25905")
    public void rule_import() {
        String appliedField = "Attendee Type";
        String appliedValue = "Press"; //formerly EI Press
        String criteriaField = "State";
        String criteriaFieldId = "formAttendee.stateId";
        String criteriaFieldValue = "Texas";
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);
        AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();

        ruleCreatePage.navigate();

        //if state is Texas
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, "equal to", criteriaFieldValue);
        ruleId = createRuleReturnId(ruleCreatePage, appliedField, appliedValue, ruleCriteria);

        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);

        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //======================================= IMPORT DATA SETUP =======================================
        ArrayList<HashMap<String, String>> importContent = new ArrayList<>();
        //change state on an attendee form
        HashMap<String, String> attendeeEdit = new HashMap<>();
        attendeeEdit.put("attendeeId", attendeeId);
        attendeeEdit.put("stateId", "Texas");
        attendeeEdit.put("firstname", "attendeeFirstName");
        attendeeEdit.put("lastname", "attendeeLastName");
        attendeeEdit.put("email", email);
        importContent.add(attendeeEdit);

        //add an attendee that should also get the rule
        String qualifiedEmail = generator.generateValidEmail();
        HashMap<String, String> attendeeQualified = new HashMap<>();
        attendeeQualified.put("attendeeId", "");
        attendeeQualified.put("stateId", "Texas");
        attendeeQualified.put("firstname", "autoFirstName");
        attendeeQualified.put("lastname", "autoLastName");
        attendeeQualified.put("email", qualifiedEmail);
        importContent.add(attendeeQualified);

        //add an attendee that will not get the rule
        String nonqualifiedEmail = generator.generateValidEmail();
        HashMap<String, String> attendeeNotQualified = new HashMap<>();
        attendeeNotQualified.put("attendeeId", "");
        attendeeNotQualified.put("stateId", "Arizona");
        attendeeNotQualified.put("firstname", "autoNotFirstName");
        attendeeNotQualified.put("lastname", "autoNotLastName");
        attendeeNotQualified.put("email", nonqualifiedEmail);
        importContent.add(attendeeNotQualified);
        //================================================================================================

        //post all them updates
        JSONObject importResponse = app.importAttendeeFile("attendeeId", importContent);
        Log.info("importing attendees response " + importResponse, getClass().getName());

        //get the attendee ids for the newly created attendees
        attendeeSearchPage.navigate();
        String qualifiedId = attendeeSearchPage.getIdByEmail(qualifiedEmail);
        String notqualifiedId = attendeeSearchPage.getIdByEmail(nonqualifiedEmail);

        //assert the form saved the right stuff
        attendeeCustomTab.navigate(attendeeId);
        Utils.sleep(500);
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);

        attendeeCustomTab.navigate(qualifiedId);
        Utils.sleep(500);
        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);

        attendeeCustomTab.navigate(notqualifiedId);
        Utils.sleep(500);
        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        //delete the extra attendees
        app.deleteAttendee(qualifiedId);
        app.deleteAttendee(notqualifiedId);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-26041", chromeIssue = "RA-26039")
    public void rule_updatesAttendee() {
        String appliedField = "Attendee Type";
        String appliedValue = "Booth Staff";
        String criteriaField = "State";
        String criteriaFieldId = "formAttendee.stateId";
        String criteriaFieldValue = "Texas";
        AdminRuleCreatePage ruleCreatePage = AdminRuleCreatePage.getPage();
        AdminAttendeeCustomTab attendeeCustomTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB4);

        //make sure form is setup right
        checkFormSetupRight(attendeeCustomTab, appliedField);
        Assert.assertTrue(attendeeCustomTab.isFieldVisible(criteriaField), "the state field is not visible on tab 4, may need to add that");

        //change attendee info to qualify
        //change state on an attendee form
        attendeeCustomTab.selectSelectField(criteriaFieldId, criteriaFieldValue);
        attendeeCustomTab.submit();
        Utils.sleep(2000);

        //create attendee that does not qualify
        Utils.sleep(500);
        String attendeeId2 = app.createAttendee(generator.generateValidEmail());
        Assert.assertNotNull(attendeeId, "did not create the attendee.");
        Utils.sleep(2000);

        //create rule, multiple criteria
        ruleCreatePage.navigate();

        //if state is Texas and if email contains automation@rainfocus.com
        Criteria ruleCriteria = ruleCreatePage.createCriteria(criteriaField, "equal to", criteriaFieldValue);
        Criteria ruleCriteria2 = ruleCreatePage.createCriteria("Email", "contains", "rainfocustestautomationuser");
        ruleId = createRuleReturnId(ruleCreatePage, appliedField, appliedValue, ruleCriteria, ruleCriteria2);

        //make sure attendee 1 is updated
        attendeeCustomTab.navigate(attendeeId);

        checkRuleAppliedValue(attendeeCustomTab, appliedField, appliedValue);

        //make sure attendee 2 is not updated
        //verify rule took affect
        attendeeCustomTab.navigate(attendeeId2);
        Utils.sleep(500);
        //assert the form saved the right stuff
        checkRuleDidNotApplyValue(attendeeCustomTab, appliedField, appliedValue);

        app.deleteAttendee(attendeeId2);
    }
}
