package admin.WidgetBuilder;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SimpleWidgetCreation {

  private AdminApp adminApp;
  private DataGenerator dataGenerator;
  private String pageId;

  private WidgetBuilderSearchPage widgetBuilderSearchPage = WidgetBuilderSearchPage.getPage();
  private WidgetBuilderCreateWidgetModal createWidgetModal = WidgetBuilderCreateWidgetModal.getPage();
  private EditWidgetCatalogSettings editWidgetCatalogSettings = EditWidgetCatalogSettings.getPage();

  @BeforeClass
  public void setup () {
    adminApp = new AdminApp();
    dataGenerator = new DataGenerator();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
  }

  @BeforeMethod
  public void beforeTest () {
    widgetBuilderSearchPage.navigate();
  }

  @AfterClass
  public void closeBrowser () {
    PageConfiguration.getPage().quit();
  }

  private void cleanupWidget(String widgetId) {
    widgetBuilderSearchPage.navigate();
    adminApp.deleteWidget(widgetId);
    adminApp.deleteCustomPage(pageId);
  }

  /**
   * Creates a widget and makes sure the settings page can be accessed
   */
  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-26689", chromeIssue = "RA-19881")
  public void createNewWidget() {
    widgetBuilderSearchPage.navigate();
    widgetBuilderSearchPage.addItem();
    createWidgetModal.clickCatalogType();
    createWidgetModal.clickWidgetTypeNextButton();

    String widgetUri = dataGenerator.generateString();
    createWidgetModal.setWidgetPageUri(widgetUri);

    String widgetName = dataGenerator.generateString();
    createWidgetModal.setWidgetName(widgetName);

    createWidgetModal.clickWidgetNameNextButton();

    // go into settings editor
    // did the page load, can i click to go back to widget list
    Assert.assertEquals(editWidgetCatalogSettings.elementsNotLoaded().size(), 0);
    EditWidgetBuilder widgetBuilder = EditWidgetBuilder.getPage();
    pageId = widgetBuilder.getPageLayoutId();
    String widgetId = editWidgetCatalogSettings.pullWidgetIdFromUrl();
    editWidgetCatalogSettings.clickSaveSettingsButton();

    cleanupWidget(widgetId);
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40009", chromeIssue = "RA-39984")
  public void testWidgetCopyCheckbox()
  {
    String widgetName = "cool widget for testing purposes that will get deleted";
    WidgetSearchPage widgetSearchPage = WidgetSearchPage.getPage();
    widgetSearchPage.navigate();
    widgetSearchPage.searchWidgets(widgetName);
    if (!widgetSearchPage.searchResultsEmpty())
      widgetSearchPage.deleteWidget();

    //create widget
    widgetBuilderSearchPage.navigate();
    widgetBuilderSearchPage.addItem();
    createWidgetModal.clickCatalogType();
    createWidgetModal.clickWidgetTypeNextButton();

    createWidgetModal.setWidgetName(widgetName);

    String widgetUri = dataGenerator.generateString();
    createWidgetModal.setWidgetPageUri(widgetUri);

    createWidgetModal.clickWidgetNameNextButton();

    String widgetId = editWidgetCatalogSettings.pullWidgetIdFromUrl();
    String componentType = editWidgetCatalogSettings.pullWidgetComponentFromUrl();

    // go to old widget page and set event copy to true
    EditWidgetPage oldWidgetPage = EditWidgetPage.getPage();
    oldWidgetPage.goToWidget(widgetId);
    oldWidgetPage.setEventCopy(true);
    oldWidgetPage.saveWidgetConfig();

    // go to new widget builder page, and just save it
    editWidgetCatalogSettings.goToWidgetSettings(widgetId, componentType);
    editWidgetCatalogSettings.clickSaveSettingsButton();

    // go back to old widget page to make sure event copy checkbox is still checked
    oldWidgetPage.goToWidget(widgetId);
    Assert.assertTrue(oldWidgetPage.isEventCopyChecked(), "Event copy is not checked on widget");

    cleanupWidget(widgetId);
  }
}