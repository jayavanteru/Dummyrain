package admin.WidgetBuilder;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.OrgEventSettings;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.events.eventsPageObjects.WidgetPage;
import configuration.PropertyReader;
import interaction.pageObjects.Page;
import interaction.pageObjects.WebPage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.springframework.beans.propertyeditors.TimeZoneEditor;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.*;

public class CreateV2SessionCatalog {
    public AdminApp adminApp = new AdminApp();
    public DataGenerator dataGenerator = new DataGenerator();
    public WidgetBuilderCreateWidgetModal widgetBuilderCreateWidgetModal;
    public WidgetBuilderSearchPage widgetBuilderSearchPage;
    public EditWidgetBuilder editWidgetBuilder;
    public BrandingCenterPage brandingCenterPage;
    public EditWidgetNavBarSettings editWidgetNavBarSettings;
    public EditFormPage editFormPage;
    public WidgetPage widgetPage = new WidgetPage();
    public OrgEventSettings orgEventSettings;
    public EditWidgetCatalogSettings editWidgetCatalogSettings = new EditWidgetCatalogSettings();

    public String attendeeId;
    public String widgetId;
    public String widgetName = dataGenerator.generateString(7) + "1Automation";
    public String navBarName = widgetName + "NavBar";
    public String eventsBrandingHeader = "Event Branding";
    public String globalBrandingHeader = "Global Branding";
    public String brandingProfile = "All Dashboard Branding";
    public String allDashboardBrandingId = "1501270758448001gNRX";
    public String sessionDataDumpId = "961c5688-1fbf-11e7-822e-06fe95280409";
    public String navBarId;
    public String attributeForm = "Session Data Dump";
    public String attendeeFirstName = dataGenerator.generateName();
    public String brandingHeader;
    public String brandingFooter;
    public String browserTimeZone = TimeZone.getDefault().getDisplayName(false, TimeZone.SHORT);
    public String eventTimeZone = "PST";
    public String WidgetUrl;

    public ArrayList<String> filters = new ArrayList<>();
    public ArrayList<String> filtersOnWidget = new ArrayList<>();
    public ArrayList<String> orderedAttributeFormList = new ArrayList<>();
    public ArrayList<String> htmlAttributeFormList = new ArrayList<>();
    public ArrayList<String> expectedTabs = new ArrayList<>();
    public ArrayList<String> actualTabs = new ArrayList<>();
    public ArrayList<DateTime> sessionDateTimes = new ArrayList<>();

    public boolean navBarCreation = false;
    public boolean finishedEdit = false;

    @BeforeClass
    public void setup() {
        widgetBuilderCreateWidgetModal = WidgetBuilderCreateWidgetModal.getPage();
        widgetBuilderSearchPage = WidgetBuilderSearchPage.getPage();
        editWidgetBuilder = EditWidgetBuilder.getPage();
        brandingCenterPage = BrandingCenterPage.getPage();
        editWidgetNavBarSettings = EditWidgetNavBarSettings.getPage();
        editFormPage = EditFormPage.getPage();
        orgEventSettings = OrgEventSettings.getPage();

        if (browserTimeZone.equals("UTC"))
            browserTimeZone = "GMT";

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
        attendeeId = adminApp.createAttendee(dataGenerator.generateEmail(), attendeeFirstName, dataGenerator.generateName());
    }

    @AfterClass
    public void teardown() {
        //PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        if (navBarCreation) //delete navbar if it got created
            adminApp.deleteWidget(navBarId);
        if (!finishedEdit) //close widget page to delete widget if widget page is still open
            editWidgetCatalogSettings.saveAndClose();
        adminApp.deleteWidget(widgetId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-48049", firefoxIssue = "RA-52137")
    public void CreateV2SessionCatalog() {
        //URI INVALID CHARACTER CHECK WILL BECOME UNIT TESTED
        //Create the Widget
        widgetBuilderSearchPage.navigate();
        widgetBuilderSearchPage.addItem();
        widgetBuilderCreateWidgetModal.clickCatalogType();
        widgetBuilderCreateWidgetModal.clickWidgetTypeNextButton();

        //Set uri and name
        widgetBuilderCreateWidgetModal.setWidgetPageUri(widgetName);
        PageConfiguration.getPage().justWait();
        widgetBuilderCreateWidgetModal.setWidgetName(widgetName);
        widgetBuilderCreateWidgetModal.clickWidgetNameNextButton();
        widgetId = editWidgetCatalogSettings.getWidgetId();

        //Customize widget
        //Check branding
        Assert.assertTrue(editWidgetCatalogSettings.verifyBrandingProfileHeaders(eventsBrandingHeader));
        Assert.assertTrue(editWidgetCatalogSettings.verifyBrandingProfileHeaders(globalBrandingHeader));
        editWidgetCatalogSettings.addBrandingProfile(brandingProfile);
        editWidgetCatalogSettings.clickManageBrandingProfile();
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        Assert.assertEquals(brandingCenterPage.getBrandingId(), allDashboardBrandingId, "Button did not open branding center");
        brandingHeader = brandingCenterPage.getWidgetBrandingHeaderURL();
        PageConfiguration.getPage().navigateBack();
        brandingFooter = brandingCenterPage.getWidgetBrandingFooterURL();
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Check Nav bar
        editWidgetCatalogSettings.addNewNavBar(navBarName);
        NewWebPagePage.getPage().openUrlInNewTab(PropertyReader.instance().getProperty("adminUrl"));
        PageConfiguration.getPage().switchToTab(1);
        widgetBuilderSearchPage.navigate();
        widgetBuilderSearchPage.searchFor(navBarName);
        widgetBuilderSearchPage.clickTopSearchResult();
        navBarId = editWidgetNavBarSettings.getNavBarId();
        navBarCreation = true;
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        editWidgetCatalogSettings.clickManageNavBar();
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        Assert.assertEquals(editWidgetNavBarSettings.getNavBarId(),navBarId, "Button did not open Nav Bar Widget");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        //Check Attribute form
        Assert.assertTrue(editWidgetCatalogSettings.verifyAttributeForm(attributeForm), "Session Dump was not selected");
        orderedAttributeFormList = editWidgetCatalogSettings.getAttributeFormList();
        Collections.sort(orderedAttributeFormList, String.CASE_INSENSITIVE_ORDER);
        htmlAttributeFormList = editWidgetCatalogSettings.getAttributeFormList();
        Assert.assertEquals(htmlAttributeFormList,orderedAttributeFormList, "The attribute form list isn't alphabetized");
        editWidgetCatalogSettings.clickManageAttributeForm();
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        Assert.assertEquals(editFormPage.getId(), sessionDataDumpId, "Button did not open form library");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        editWidgetCatalogSettings.selectLayoutFilters("right");
        editWidgetCatalogSettings.chooseSortSessionBy("Day and Time");
        editWidgetCatalogSettings.chooseTimeZone("Display times in event and browser time zones");
        editWidgetCatalogSettings.addAttribute("Session track");
        editWidgetCatalogSettings.addAttribute("Session Type");
        filters.add("Session track");
        filters.add("Session Type");
        editWidgetCatalogSettings.saveAndClose();

        finishedEdit = true;
        adminApp.spoofIntoCatalog(attendeeFirstName, widgetName, 1);

        String[] brandingHeaderHtml = brandingHeader.replaceAll(" /", "").split("\\n");
        String[] brandingFooterHtml = brandingFooter.split("<body>")[1].split("</body>")[0].split("\\n");
        String pageSource = widgetPage.getHtmlPageSource();
        for (String headerCode : brandingHeaderHtml) {
            Assert.assertTrue(pageSource.contains(headerCode.trim()), "The branding header is not present: " + headerCode);
        }

        for (String footerCode : brandingFooterHtml) {
            Assert.assertTrue(pageSource.contains(footerCode.trim()), "The branding footer is not present: " + footerCode);
        }

        Assert.assertTrue(widgetPage.assertFilterLocations("right"), "Filters not on right side");
        Assert.assertTrue(widgetPage.checkTimeZone(eventTimeZone), "Not PST time zone");
        Assert.assertTrue(widgetPage.checkTimeZone(browserTimeZone), "Not browser time zone");
        filtersOnWidget = widgetPage.getfilterNames();
        Assert.assertEquals(filtersOnWidget, filters, "The filters on the widget are not equal to the expected filters");
        Assert.assertTrue(widgetPage.isExpandCollapsed(), "Widget is not expand/collpase");
        Assert.assertTrue(widgetPage.isNavBarOnPage(), "The nav bar is not applied");
        WidgetUrl = PageConfiguration.getPage().getCurrentUrl();
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

        widgetBuilderSearchPage.navigate();
        widgetBuilderSearchPage.searchFor(widgetName);
        widgetBuilderSearchPage.clickTopSearchResult();
        finishedEdit = false;

        editWidgetCatalogSettings.removeBranding();
        editWidgetCatalogSettings.selectLayoutFilters("left");
        editWidgetCatalogSettings.chooseTabLayout();
        editWidgetCatalogSettings.addTabs("Session Type - Birds of a feather");
        editWidgetCatalogSettings.addTabs("Session Type - Breakout session");
        editWidgetCatalogSettings.addTabs("Day - Mon, Mar 01");
        editWidgetCatalogSettings.addTabs("Day - Wed, May 12");
        expectedTabs.add("Birds of a feather");
        expectedTabs.add("Breakout session");
        expectedTabs.add("Mon, Mar 01");
        expectedTabs.add("Wed, May 12");
        editWidgetCatalogSettings.clickFirstTabOption();
        editWidgetCatalogSettings.tabSortBy("Day and Time");
        editWidgetCatalogSettings.chooseTimeZone("Display times in browser time zone only");
        editWidgetCatalogSettings.addAttribute("Industry");
        editWidgetCatalogSettings.addAttribute("Session technology");
        filters.add("Industry");
        filters.add("Session technology");
        editWidgetCatalogSettings.chooseNewPageSessionDetails();
        editWidgetCatalogSettings.setNewPageSessionDetails(WidgetUrl);
        editWidgetCatalogSettings.saveAndClose();

        finishedEdit = true;
        adminApp.spoofIntoCatalog(attendeeFirstName, widgetName, 1);

        Assert.assertTrue(widgetPage.assertFilterLocations("left"), "Filters not on left side");
        Assert.assertTrue(widgetPage.checkTimeZone(browserTimeZone), "Not browser time zone");
        filtersOnWidget.clear();
        filtersOnWidget = widgetPage.getfilterNames();
        Assert.assertEquals(filtersOnWidget, filters, "The filters on the widget are not equal to the expected filters");
        Assert.assertTrue(widgetPage.isNavBarOnPage(), "The nav bar is not applied");
        actualTabs = widgetPage.getCatalogTabNames();
        Assert.assertEquals(actualTabs, expectedTabs, "The catalog tabs are different");
        Assert.assertTrue(widgetPage.isSessionDetailsWithUrl(WidgetUrl.split("com")[1]), "Session details does not open on a new page");
        String newPageSource = widgetPage.getHtmlPageSource();
        Assert.assertFalse(newPageSource.contains("<header "), "A branding opening header tag is present");
        Assert.assertFalse(newPageSource.contains("</header>"), "A branding closing header tag is present");
        Assert.assertFalse(newPageSource.contains("<footer "), "A branding opening footer tag is present");
        Assert.assertFalse(newPageSource.contains("</footer>"), "A branding closing footer tag is present");
        sessionDateTimes = widgetPage.getTabbedSessionDates();
        ArrayList<DateTime> actualSessionDateTimes = new ArrayList<>(sessionDateTimes);
        Collections.sort(sessionDateTimes);
        Assert.assertEquals(actualSessionDateTimes,sessionDateTimes, "The sessions are not ordered by date and time");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
    }
}
