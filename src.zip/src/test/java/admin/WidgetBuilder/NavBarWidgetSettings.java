package admin.WidgetBuilder;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetBuilder;
import apps.admin.adminPageObjects.libraries.EditWidgetNavBarSettings;
import apps.admin.adminPageObjects.libraries.WidgetBuilderCreateWidgetModal;
import apps.admin.adminPageObjects.libraries.WidgetBuilderSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.ConstellationsWidgetPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

import java.util.HashMap;
import java.util.Map;

public class NavBarWidgetSettings
{
  private AdminApp adminApp;
  private PropertyReader propertyReader;
  private DataGenerator dataGenerator;
  private EditWidgetBuilder editWidgetBuilder;
  private WidgetBuilderSearchPage widgetBuilderSearchPage;
  private WidgetBuilderCreateWidgetModal createWidgetModal = WidgetBuilderCreateWidgetModal.getPage();
  private EditWidgetNavBarSettings editWidgetNavBarSettings;
  private ConstellationsWidgetPage constellationsWidgetPage;
  private PageConfiguration pageConfiguration;
  private EditAttendeePage editAttendeePage;
  private String pageId;
  private String widgetId;
  private String email;
  private String password;
  private String attendeeId;

  @BeforeClass
  public void setup () {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    propertyReader = PropertyReader.instance();
    dataGenerator = new DataGenerator();
    editWidgetBuilder = EditWidgetBuilder.getPage();
    widgetBuilderSearchPage = WidgetBuilderSearchPage.getPage();
    editWidgetNavBarSettings = EditWidgetNavBarSettings.getPage();
    constellationsWidgetPage = ConstellationsWidgetPage.getPage();
    pageConfiguration = PageConfiguration.getPage();
    editAttendeePage = EditAttendeePage.getPage();

    email = dataGenerator.generateValidEmail();
    password = dataGenerator.generatePassword();
    attendeeId = adminApp.createAttendee(email, password);
  }

  @BeforeMethod
  public void beforeTest () {
    widgetBuilderSearchPage.navigate();
    pageConfiguration.refreshPage();
  }

  @AfterMethod
  public void afterTest () {
    cleanupWidget(widgetId);
  }

  @AfterClass
  public void closeBrowser () {
    pageConfiguration.navigateTo(adminApp.getHost());
    adminApp.deleteAttendee(attendeeId);
    pageConfiguration.quit();
  }

  // there's no QA id on the search page, so doing this by widgetId
  private void cleanupWidget(String widgetId) {
    // search for widget in search page
    widgetBuilderSearchPage.navigate();

    adminApp.deleteWidget(widgetId);

    adminApp.deleteCustomPage(pageId);
  }

  /**
   * Creates a widget and makes sure the settings page can be accessed
   */
  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19906", firefoxIssue = "RA-23075")
  public void ensureNavBarLinkSetup () {
    // create navbar widget
    widgetBuilderSearchPage.addItem();
    createWidgetModal.clickNavBarType();
    createWidgetModal.clickWidgetTypeNextButton();
    String widgetName = dataGenerator.generateString();
    createWidgetModal.setWidgetName(widgetName);
    String widgetUri = dataGenerator.generateString();
    createWidgetModal.setWidgetPageUri(widgetUri);
    createWidgetModal.clickWidgetNameNextButton();

    pageId = editWidgetBuilder.getPageLayoutId();
    widgetId = editWidgetNavBarSettings.pullWidgetIdFromUrl();
    // go into settings editor
    editWidgetBuilder.clickNavBarSettingsButton();

    // did the page load, can i click to go back to settings
    Assert.assertEquals(editWidgetNavBarSettings.elementsNotLoaded().size(), 0);

    // by default has a dummy link, update it
    String linkIndex = "0";
    String linkDisplayOrder = "1";
    String linkLabel = dataGenerator.generateString();
    String linkValue = "https://www.google.com";
    boolean linkActiveState = true;
    boolean linkIsNewPageRedirectState = true;
    boolean linkRequiresLoginState = false;
    boolean linkRequiresSchedulerAccessState = false;
    editWidgetNavBarSettings.updateNavItemLink(linkIndex, linkDisplayOrder, linkLabel, linkValue, linkActiveState, linkIsNewPageRedirectState, linkRequiresLoginState, linkRequiresSchedulerAccessState);

    // create a new workflow nav item
    String workflowIndex = "1";
    String workflowDisplayOrder = "2";
    String workflowLabel = dataGenerator.generateString();
    String workflowUri = "autoreg";
    boolean workflowActiveState = true;
    boolean workflowIsNewPageRedirectState = false;
    boolean workflowRequiresLoginState = true;
    boolean workflowRequiresSchedulerAccessState = false;
    editWidgetNavBarSettings.createNavItemWorkflow(workflowDisplayOrder, workflowLabel, workflowUri, workflowActiveState, workflowIsNewPageRedirectState, workflowRequiresLoginState, workflowRequiresSchedulerAccessState);

    // create a new workflow nav item
    String linkIndex2 = "2";
    String linkDisplayOrder2 = "3";
    String linkLabel2 = dataGenerator.generateString();
    String linkValue2 = "https://www.rainfocus.com";
    boolean linkActiveState2 = false;
    boolean linkIsNewPageRedirectState2 = false;
    boolean linkRequiresLoginState2 = false;
    boolean linkRequiresSchedulerAccessState2 = false;
    editWidgetNavBarSettings.createNavItemLink(linkDisplayOrder2, linkLabel2, linkValue2, linkActiveState2, linkIsNewPageRedirectState2, linkRequiresLoginState2, linkRequiresSchedulerAccessState2);

    editWidgetNavBarSettings.clickSaveSettingsButton();

    editWidgetBuilder.clickSaveWidget();

    widgetBuilderSearchPage.searchFor(widgetName);
    widgetBuilderSearchPage.clickTopSearchResult();
    editWidgetBuilder.clickNavBarSettingsButton();

    Assert.assertEquals(editWidgetNavBarSettings.getNavItemCount(), 3);

    // ensure that the nav items added are still good
    validateNavItemLinkSetup(linkIndex, linkDisplayOrder, linkLabel, linkValue, linkActiveState, linkIsNewPageRedirectState, linkRequiresLoginState, linkRequiresSchedulerAccessState);
    validateNavItemWorkflowSetup(workflowIndex, workflowDisplayOrder, workflowLabel, workflowUri, workflowActiveState, workflowIsNewPageRedirectState, workflowRequiresLoginState, workflowRequiresSchedulerAccessState);
    validateNavItemLinkSetup(linkIndex2, linkDisplayOrder2, linkLabel2, linkValue2, linkActiveState2, linkIsNewPageRedirectState2, linkRequiresLoginState2, linkRequiresSchedulerAccessState2);

    String eventsUrl = propertyReader.getProperty("eventsUrlWidget").toLowerCase();
    String widgetUrl = eventsUrl + widgetUri;

    // check links for unauthenticated user
    pageConfiguration.navigateTo(widgetUrl);
    HashMap<String, Boolean> unauthenticatedNavBarItemsMap = new HashMap<>();
    unauthenticatedNavBarItemsMap.put(linkLabel, true);
    unauthenticatedNavBarItemsMap.put(workflowLabel, false);
    unauthenticatedNavBarItemsMap.put(linkLabel2, false);
    validateVisibilityOfNavBarItemsInWidget(unauthenticatedNavBarItemsMap, false);


    // check links for authenticated user
    editAttendeePage.navigate(attendeeId);
    editAttendeePage.spoofToWidget(widgetName);
    HashMap<String, Boolean> authenticatedNavBarItemsMap = new HashMap<>();
    unauthenticatedNavBarItemsMap.put(linkLabel, true);
    unauthenticatedNavBarItemsMap.put(workflowLabel, true);
    unauthenticatedNavBarItemsMap.put(linkLabel2, false);
    validateVisibilityOfNavBarItemsInWidget(authenticatedNavBarItemsMap, true);

    // check that the links that show work
    constellationsWidgetPage.clickNavBarItemOnPageByLabel(linkLabel);
    pageConfiguration.switchToTab(2);
    pageConfiguration.waitForPageLoad();
    Assert.assertTrue(pageConfiguration.getCurrentUrl().startsWith(linkValue), "Link with label " + linkLabel + " didn't navigate to " + linkValue);

    String workflowUrlProperty = propertyReader.getProperty("workflowsUrlWithOrgAndEvent").toLowerCase();
    String workflowUrl = workflowUrlProperty + workflowUri;

    pageConfiguration.switchToTab(1);
    constellationsWidgetPage.clickNavBarItemOnPageByLabel(workflowLabel);
    pageConfiguration.waitForPageLoad();
    Assert.assertTrue(pageConfiguration.getCurrentUrl().startsWith(workflowUrl), "Link with label " + workflowLabel + " didn't navigate to " + workflowLabel);
  }

  private void validateNavItemLinkSetup(String index, String displayOrder, String linkLabel, String linkValue, boolean linkActiveState, boolean linkIsNewPageRedirectState, boolean linkRequiresLoginState, boolean linkRequiresSchedulerAccessState) {
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemType(index), "link", "Nav Item at index " + index + " did not have type of link");
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemDisplayOrder(index), displayOrder, "Nav Item at index " + index + " did not have display order " + displayOrder);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemLabel(index), linkLabel, "Nav Item at index " + index + " did not have label " + linkLabel);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemValue(index), linkValue, "Nav Item at index " + index + " did not have value " + linkValue);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemIsActive(index), linkActiveState, "Nav Item at index " + index + " checkbox Active was not " + (linkActiveState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemIsNewPageRedirect(index), linkIsNewPageRedirectState, "Nav Item at index " + index + " checkbox Is New Page Redirect was not " + (linkIsNewPageRedirectState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemRequiresLogin(index), linkRequiresLoginState, "Nav Item at index " + index + " checkbox Requires Login was not " + (linkRequiresLoginState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemRequiresSchedulerAccess(index), linkRequiresSchedulerAccessState, "Nav Item at index " + index + " checkbox Requires Scheduler Access was not " + (linkRequiresSchedulerAccessState ? "checked" : "unchecked"));
  }

  private void validateNavItemWorkflowSetup(String index, String displayOrder, String workflowLabel, String workflowUri, boolean workflowActiveState, boolean workflowIsNewPageRedirectState, boolean workflowRequiresLoginState, boolean workflowRequiresSchedulerAccessState) {
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemType(index), "workflow", "Nav Item at index " + index + " did not have type of workflow");
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemDisplayOrder(index), displayOrder, "Nav Item at index " + index + " did not have display order " + displayOrder);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemLabel(index), workflowLabel, "Nav Item at index " + index + " did not have label " + workflowLabel);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemWorkflowUrl(index), workflowUri, "Nav Item at index " + index + " did not have value " + workflowUri);
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemIsActive(index), workflowActiveState, "Nav Item at index " + index + " checkbox Active was not " + (workflowActiveState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemIsNewPageRedirect(index), workflowIsNewPageRedirectState, "Nav Item at index " + index + " checkbox Is New Page Redirect was not " + (workflowIsNewPageRedirectState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemRequiresLogin(index), workflowRequiresLoginState, "Nav Item at index " + index + " checkbox Requires Login was not " + (workflowRequiresLoginState ? "checked" : "unchecked"));
    Assert.assertEquals(editWidgetNavBarSettings.getNavItemRequiresSchedulerAccess(index), workflowRequiresSchedulerAccessState, "Nav Item at index " + index + " checkbox Requires Scheduler Access was not " + (workflowRequiresSchedulerAccessState ? "checked" : "unchecked"));
  }

  private void validateVisibilityOfNavBarItemsInWidget(Map<String, Boolean> navBarItemLabelToWhetherShouldShowOrNot, boolean isUserAuthenticated) {
    String userStateString = isUserAuthenticated ? "authenticated" : "unauthenticated";
    for(String label : navBarItemLabelToWhetherShouldShowOrNot.keySet()) {
      if (navBarItemLabelToWhetherShouldShowOrNot.get(label)) {
        Assert.assertTrue(constellationsWidgetPage.isNavBarItemVisibleOnPageByLabel(label), "Link with label " + label + " didn't show on the NavBar in the widget for " + userStateString + " user");
      }
      else {
        Assert.assertFalse(constellationsWidgetPage.isNavBarItemVisibleOnPageByLabel(label), "Link with label " + label + " did show on the NavBar in the widget for " + userStateString + " user");
      }
    }
  }
}
