package admin.WidgetBuilder;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetBuilder;
import apps.admin.adminPageObjects.libraries.EditWidgetCatalogSettings;
import apps.admin.adminPageObjects.libraries.WidgetBuilderCreateWidgetModal;
import apps.admin.adminPageObjects.libraries.WidgetBuilderSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.DigitalSignageWidgetPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class DigitalSignage {

    private AdminApp adminApp;
    private String attendeeId;
    private boolean cleanUp = false;
    private final String TITLE = "Reach In-memory data fabric unlike PIG";
    private final DataGenerator dataGenerator = new DataGenerator();
    private final String URI = "uri" + dataGenerator.generateString(8);
    private final String WIDGET_NAME = "Automated Signage " + dataGenerator.generateString(6);
    private final WidgetBuilderSearchPage builderSearch = WidgetBuilderSearchPage.getPage();
    private final WidgetBuilderCreateWidgetModal createWidgetModal = WidgetBuilderCreateWidgetModal.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
    }

    @AfterClass
    public void closeBrowser () {
        if(attendeeId != null) {
            PageConfiguration.getPage().navigateTo(adminApp.getHost());
            adminApp.deleteAttendee(attendeeId);
        }
        if(cleanUp) {
            builderSearch.navigate();
            builderSearch.searchFor(WIDGET_NAME);
            builderSearch.deleteWidget();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-25598", firefoxIssue = "RA-39789")
    public void createNewDigitalSignage() {
         builderSearch.navigate();
         builderSearch.addItem();
         createWidgetModal.clickDigitalSignageType();
         createWidgetModal.clickWidgetTypeNextButton();
         createWidgetModal.setWidgetName(WIDGET_NAME);
         createWidgetModal.setWidgetPageUri(URI);
         createWidgetModal.clickWidgetNameNextButton();
         cleanUp = true;

        EditWidgetBuilder editBuilder = EditWidgetBuilder.getPage();
        editBuilder.clickSignageSettingsButton();
        EditWidgetCatalogSettings settings = EditWidgetCatalogSettings.getPage();
        settings.toggleTestMode(true);
        settings.clickSaveSettingsButton();

        editBuilder.clickSaveWidget();
        attendeeId = adminApp.createAttendee();

        EditAttendeePage.getPage().spoofToWidget(WIDGET_NAME);
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains(URI), "Digital signage URI was incorrect");

            String room = "Lando";
            String year = "2022";
            String month = "12";
            String day = "03";
            String hour = "09";
            String minute = "00";

        DigitalSignageWidgetPage signage = DigitalSignageWidgetPage.getPage();

        signage.searchRoom(room, year, month, day, hour, minute);
        Assert.assertEquals(TITLE, signage.getSessionTitle(), TITLE + " session was not displayed after the search");
    }
}
