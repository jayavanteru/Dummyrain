package admin.SecurityRoles;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.SecurityRolePage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.manageUsers.SecurityRolesPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ScheduleEmailSecurityRole {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Chat Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-43486", firefoxIssue = "RA-43487")
    public void scheduleEmailSecurityRole() {
        //turn on security role
        SecurityRolesPage.getPage().navigate();
        SecurityRolesPage.getPage().search("Rene Email Role");
        SecurityRolesPage.getPage().editRoleByText("Rene Email Role");
        if(!SecurityRolePage.getPage().hasPermission("Send Scheduled Bulk Emails")){
            SecurityRolePage.getPage().togglePermission("Send Scheduled Bulk Emails");
            SecurityRolePage.getPage().save();
        }

        SecurityRolesPage.getPage().navigate();
        SecurityRolesPage.getPage().editRoleByText("Rene Email Role");

        if(!SecurityRolePage.getPage().hasPermission("Send Bulk Emails")){
            SecurityRolePage.getPage().togglePermission("Send Bulk Emails");
            SecurityRolePage.getPage().save();
        }
        PropertyReader.instance().setProperty("adminEmail", "renevdwatt@icloud.com");
        PropertyReader.instance().setProperty("adminPassword", "Rainfocus1!Email");

        PageConfiguration.getPage().deleteAllCookies();
        PageConfiguration.getPage().refreshPage();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Chat Event");

        //attendee email
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().clickActions();
        Assert.assertTrue(AttendeeSearchPage.getPage().scheduledBulkEmailsActionExists());
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().clickBulkEmailDropdown();
        AttendeeSearchPage.getPage().clickEmailType();
        AttendeeSearchPage.getPage().clickScheduleRadio();
        Assert.assertTrue(AttendeeSearchPage.getPage().bulkEmailModalHasScheduleElements());

        //exhibitor email
        ExhibitorSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().clickActions();
        Assert.assertTrue(AttendeeSearchPage.getPage().scheduledBulkEmailsActionExists());
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().clickBulkEmailDropdown();
        AttendeeSearchPage.getPage().clickEmailType();
        AttendeeSearchPage.getPage().clickScheduleRadio();
        Assert.assertTrue(AttendeeSearchPage.getPage().bulkEmailModalHasScheduleElements());

        //turn off security role
        PropertyReader.instance().setProperty("adminEmail", "automation@rainfocus.com");
        PropertyReader.instance().setProperty("adminPassword", "R@infocus123");

        PageConfiguration.getPage().deleteAllCookies();
        PageConfiguration.getPage().refreshPage();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Chat Event");

        SecurityRolesPage.getPage().navigate();
        SecurityRolesPage.getPage().search("Rene Email Role");
        SecurityRolesPage.getPage().editRoleByText("Rene Email Role");

        SecurityRolePage.getPage().togglePermission("Send Scheduled Bulk Emails");
        SecurityRolePage.getPage().save();

        PropertyReader.instance().setProperty("adminEmail", "renevdwatt@icloud.com");
        PropertyReader.instance().setProperty("adminPassword", "Rainfocus1!Email");

        PageConfiguration.getPage().deleteAllCookies();
        PageConfiguration.getPage().refreshPage();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Chat Event");

        //attendee email
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().clickActions();
        Assert.assertFalse(AttendeeSearchPage.getPage().scheduledBulkEmailsActionExists());
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().clickBulkEmailDropdown();
        AttendeeSearchPage.getPage().clickEmailType();
        Assert.assertFalse(AttendeeSearchPage.getPage().bulkEmailModalHasScheduleElements());

        //exhibitor email
        ExhibitorSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().clickActions();
        Assert.assertFalse(AttendeeSearchPage.getPage().scheduledBulkEmailsActionExists());
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().clickBulkEmailDropdown();
        AttendeeSearchPage.getPage().clickEmailType();
        Assert.assertFalse(AttendeeSearchPage.getPage().bulkEmailModalHasScheduleElements());
    }
}
