package admin.email;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.libraries.NewEmailPage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EmailBasics {
    DataGenerator dataGenerator = new DataGenerator();
    String emailName;

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event C");
        //create email
        emailName = dataGenerator.generateName();
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().addItem();
        NewEmailPage.getPage().fillOutBasicInfo(emailName);
        NewEmailPage.getPage().save();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19170", firefoxIssue = "RA-25800")
    public void createEmail(){
        //assert email exists
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        Assert.assertTrue(EmailsSearchPage.getPage().emailExists(emailName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19171", firefoxIssue = "RA-25796")
    public void copyEmail(){
        //copy email
        String newName = dataGenerator.generateName();
        String code = dataGenerator.generateString(8);
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        EmailsSearchPage.getPage().copyFirstEmail();
        NewEmailPage.getPage().setName(newName);
        NewEmailPage.getPage().setCode(code);
        NewEmailPage.getPage().save();

        //assert copy exists
        EmailsSearchPage.getPage().searchFor(newName);
        Assert.assertTrue(EmailsSearchPage.getPage().emailExists(newName));
        EmailsSearchPage.getPage().deleteEmail(newName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19177", firefoxIssue = "RA-25000")
    public void deleteEmail(){
        String emailName = dataGenerator.generateName();
        //create email
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().addItem();
        NewEmailPage.getPage().fillOutBasicInfo(emailName);
        NewEmailPage.getPage().save();

        //assert email exists
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        Assert.assertTrue(EmailsSearchPage.getPage().emailExists(emailName), "EMAIL WAS NOT CREATED");

        //delete email
        EmailsSearchPage.getPage().deleteEmail(emailName);
        EmailsSearchPage.getPage().searchFor(emailName);
        Assert.assertFalse(EmailsSearchPage.getPage().emailExists(emailName) ,"EMAIL WAS NOT DELETED");
    }

    @AfterClass
    public void tearDown(){
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        EmailsSearchPage.getPage().deleteEmail(emailName);
        PageConfiguration.getPage().quit();
    }
}
