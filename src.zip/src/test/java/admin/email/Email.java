package admin.email;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditEmailPage;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.libraries.NewEmailPage;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.UsersPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

public class Email {

  protected EmailsSearchPage emailsSearchPage;
  protected NewEmailPage newEmailPage;
  protected EditEmailPage editEmailPage;
  protected AttendeeSearchPage attendeeSearchPage;
  protected CreateAttendeePage createAttendeePage;
  protected EditAttendeePage editAttendeePage;
  protected AdminLoginPage adminLoginPage;
  protected DataGenerator dataGenerator = new DataGenerator();
  protected SoftAssert softAssert;
  protected UsersPage usersPage;
  protected EditUserPage editUserPage;
  String attendeeEmail;
  String attendeeFirstName;
  String emailCode;
  String emailCode2;
  String emailCode3;
  String emailName;
  String copiedEmailName;
  String globalEmailName;
  String originalAutomationUser;
  String originalAutomationPass;

  @BeforeClass
  public void setup() {
    newEmailPage = NewEmailPage.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    createAttendeePage = CreateAttendeePage.getPage();
    adminLoginPage = AdminLoginPage.getPage();
    editEmailPage = EditEmailPage.getPage();
    emailsSearchPage = EmailsSearchPage.getPage();
    usersPage = UsersPage.getPage();
    editUserPage = EditUserPage.getPage();
    softAssert = new SoftAssert();
    attendeeEmail = dataGenerator.generateValidEmail();
    attendeeFirstName = dataGenerator.generateName();
    emailCode = dataGenerator.generateString(6);
    emailCode2 = dataGenerator.generateString(6);
    emailCode3 = dataGenerator.generateString(6);
    originalAutomationUser = PropertyReader.instance().getProperty("adminEmail");
    originalAutomationPass = PropertyReader.instance().getProperty("adminPassword");
    adminLoginPage.login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void cleanup() {
    PageConfiguration.getPage().quit();
  }


  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-39296", chromeIssue = "RA-32717")
  public void securityRoles() {
    emailName = dataGenerator.generateName();
    String subject = dataGenerator.generateString();
    String fromAddress = dataGenerator.generateEmail();

    globalEmailName = "global" + dataGenerator.generateName();

    copiedEmailName = "copied" + dataGenerator.generateName();
    String securityRole = "Event Owner";

    String attendeeLastName = dataGenerator.generateName();

    String testUserEmail = "emailrole@test.com";
    String testUserPass = "Rainclouds!23";

    // Uncheck unnecessary permissions to testUserEmail
    usersPage.navigate();
    usersPage.selectUserByEmail(testUserEmail);
    editUserPage.unselectAllRoles();
    editUserPage.submit();

    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Create email with 'Event Owner' security role
    createEmail(emailName, subject, fromAddress, emailCode, securityRole);

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can't see created email in Attendee's email tab
    createAttendeePage.navigate();
    createAttendeePage.fillOutForm(attendeeEmail, attendeeFirstName, attendeeLastName);
    editAttendeePage.goToEmailsTab();
    editAttendeePage.emailsTabSearchEmail(emailName);
    softAssert.assertFalse(editAttendeePage.emailTabExistEmail(emailName), "Email should not be accessible");


    logoutAndLogin(originalAutomationUser, originalAutomationPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Delete 'Event Owner' security Role
    manageEmailSecurityRole(emailCode, securityRole);

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can see created email in Attendee's email tab
    validateEmailInEmailTab(attendeeEmail, emailName, true);

    logoutAndLogin(originalAutomationUser, originalAutomationPass, "GLOBAL");

    // Create global email with 'Event Owner' security Role
    createEmail(globalEmailName, subject, fromAddress, emailCode2, securityRole);

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can't see created email in Attendee's email tab
    validateEmailInEmailTab(attendeeEmail, globalEmailName, false);

    logoutAndLogin(originalAutomationUser, originalAutomationPass, "GLOBAL");

    // Delete 'Event Owner' security Role
    manageEmailSecurityRole(emailCode2, securityRole);

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can see created email in Attendee's email tab
    validateEmailInEmailTab(attendeeEmail, globalEmailName, true);

    logoutAndLogin(originalAutomationUser, originalAutomationPass, "GLOBAL");

    // Make a copy of the email from Global to "Eventgers Test Event" event
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(emailCode2);
    emailsSearchPage.copyFirstEmail();
    editEmailPage.emailCopySelectEvent(RFConstants.EVENT_NAME_EVENTGERS_TEST);
    editEmailPage.setName(copiedEmailName);
    editEmailPage.setCode(emailCode3);
    editEmailPage.clickSecurityRole(securityRole);
    editEmailPage.save();

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can't see created email in Attendee's email tab
    validateEmailInEmailTab(attendeeEmail, copiedEmailName, false);

    logoutAndLogin(originalAutomationUser, originalAutomationPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Delete 'Event Owner' security Role
    manageEmailSecurityRole(emailCode3, securityRole);

    logoutAndLogin(testUserEmail, testUserPass, RFConstants.EVENT_NAME_EVENTGERS_TEST);

    // Validate that can see created email in Attendee's email tab
    validateEmailInEmailTab(attendeeEmail, copiedEmailName, true);

    softAssert.assertAll();
  }

  @AfterMethod
  public void delete() {
    //Delete Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.deleteAttendeeByName(attendeeFirstName);

    //Delete Emails
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(emailCode);
    emailsSearchPage.deleteEmail(emailName);
    emailsSearchPage.searchFor(emailCode3);
    emailsSearchPage.deleteEmail(copiedEmailName);
    OrgEventData.getPage().setOrgAndEvent("IBM", "GLOBAL");
    emailsSearchPage.searchFor(emailCode2);
    emailsSearchPage.deleteEmail(globalEmailName);

    // Return to default values
    PropertyReader.instance().setProperty("adminEmail", originalAutomationUser);
    PropertyReader.instance().setProperty("adminPassword", originalAutomationPass);
  }

  // Logout and Login with given parameters
  private void logoutAndLogin(String useEmail, String userPass, String event) {
    adminLoginPage.logout();
    adminLoginPage.navigate();
    PropertyReader.instance().setProperty("adminEmail", useEmail);
    PropertyReader.instance().setProperty("adminPassword", userPass);
    adminLoginPage.login();
    OrgEventData.getPage().setOrgAndEvent("IBM", event);
  }

  private void manageEmailSecurityRole(String emailCode, String securityRole) {
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(emailCode);
    emailsSearchPage.clickResult(0);
    editEmailPage.clickSecurityRole(securityRole);
    editEmailPage.save();
  }

  // Try to find email in Attendee's Email tab
  private void validateEmailInEmailTab(String attendeeEmail, String emailName, boolean isEmailAccessible) {
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.clickResult(0);
    editAttendeePage.goToEmailsTab();
    editAttendeePage.emailsTabSearchEmail(emailName);

    if (isEmailAccessible) {
      softAssert.assertTrue(editAttendeePage.emailTabExistEmail(emailName), "Email should be accessible");
      editAttendeePage.emailTabSelectEmail(emailName);
      editAttendeePage.emailTabSendEmail();
    } else {
      softAssert.assertFalse(editAttendeePage.emailTabExistEmail(emailName), "Email should not be accessible");
    }
  }

  private void createEmail(String emailName, String subject, String fromAddress, String emailCode, String securityRole) {
    emailsSearchPage.navigate();
    emailsSearchPage.addItem();
    newEmailPage.setName(emailName);
    newEmailPage.setSubject(subject);
    newEmailPage.setFromAddress(fromAddress);
    newEmailPage.setCode(emailCode);
    newEmailPage.clickSecurityRole(securityRole);
    newEmailPage.save();
  }
}
