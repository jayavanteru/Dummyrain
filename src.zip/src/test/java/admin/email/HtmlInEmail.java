package admin.email;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditEmailPage;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.gmail.EmailApi;
import logs.ReportingInfo;
import net.bytebuddy.implementation.bytecode.Throw;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class HtmlInEmail {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    String emailName, emailSubject, attendeeEmail, attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();

        //create attendee
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateValidEmail());

        //create email
        EditEmailPage.getPage().createEmail(emailName = dataGenerator.generateName(), emailSubject = emailName, dataGenerator.generateEmail(), dataGenerator.generateName(), true, EditEmailPage.getPage().GENERIC_PAGE_CONTENT);
    }

    @AfterClass
    public void afterClass() {
        //delete email
        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        EmailsSearchPage.getPage().deleteEmail(emailName);

        adminApp.deleteAttendee(attendeeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-33821", firefoxIssue = "RA-36903")
    public void htmlRenders() {
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        Assert.assertEquals(AttendeeSearchPage.getPage().getResults().size(), 1, "didn't get just one result");
        AttendeeSearchPage.getPage().clickActions();
        AttendeeSearchPage.getPage().openBulkEmailModal();
        AttendeeSearchPage.getPage().bulkEmail(emailName);
        EmailApi.emailClient().waitForEmail(emailSubject);
        Assert.assertTrue((EmailApi.emailClient().getEmail(emailSubject).bodyContains("Hello World") && EmailApi.emailClient().getEmail(emailSubject).bodyContains("This is some html")), "EMAIL DID NOT RENDER THE HTML CORRECTLY");
    }
}
