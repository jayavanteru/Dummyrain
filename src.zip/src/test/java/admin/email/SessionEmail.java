package admin.email;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.meetings.EditMeetingPage;
import apps.admin.adminPageObjects.meetings.MeetingParticipants;
import emails.Email;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class SessionEmail extends Email {

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-26655", chromeIssue = "RA-26653")
    public void swappingSessionTimeEmail() {
        String emailSubject = "Session Changed";
        String sessionName = new DataGenerator().generateString(5) + "automation";
        loginAndCreateAttendee();
        sessionId = adminApp.createSession(sessionName);

        //assign the attendee to the session
        AdminSessionParticipantsTab sessionParticipantsTab = AdminSessionParticipantsTab.getPage();
        SessionAddParticipant addParticipant = SessionAddParticipant.getPage();
        sessionParticipantsTab.navigate(sessionId);
        sessionParticipantsTab.clickAddParticipantButton();
        Utils.sleep(500);
        addParticipant.addParticipant(emailAddress);

        AdminSchedulingTab schedulingTab = AdminSchedulingTab.getPage();
        schedulingTab.navigate(sessionId);
        schedulingTab.scheduleSession(1);

        PageConfiguration.getPage().refreshPage();

        //swap the session time to a different one
        schedulingTab.editSession();
        schedulingTab.setTimeByOrder(2);
        schedulingTab.setRoomByOrder(6);
        Utils.sleep(500);
        EmailApi checkEmail = EmailApi.emailClient();
        schedulingTab.clickSaveSessionButtonExpectModal();

        Assert.assertTrue(checkEmail.waitForEmail(emailSubject, emailAddress), "waiting for email");
        EmailMessage message = checkEmail.getEmail(emailSubject);
        String emailText = message.getBody();

        Log.info(emailText, getClass().getName());
        Assert.assertTrue(emailText.contains(sessionName), "email did not contains the session name: " + sessionName);
    }

    //    @Test
    public void meetingStatusChangeEmail() {
        String emailSubject = "Test Email: You have a pending meeting";
        String sessionName = "automation" + new DataGenerator().generateString(5);
        loginAndCreateAttendee();
        sessionId = adminApp.createMeeting(sessionName);

        //assign the attendee to the meeting
        MeetingParticipants meetingParticipants = MeetingParticipants.getPage();
        SessionAddParticipant addParticipant = SessionAddParticipant.getPage();
        meetingParticipants.navigate(sessionId);
        Utils.sleep(500);
        meetingParticipants.addParticipant();
        Utils.sleep(500);
        addParticipant.addParticipant(emailAddress, "Analysts");
        Utils.sleep(2000); //some time to save

        //change the status
        EditMeetingPage.getPage().setStatus("Pending");

        Assert.assertTrue(checkEmail.waitForEmail(emailSubject), "waiting for email");
        EmailMessage message = checkEmail.getEmail(emailSubject);
        String emailText = message.getBody();

        Log.info(emailText, getClass().getName());
        Assert.assertTrue(emailText.contains(sessionName), "email did not contains the session name: " + sessionName);
        Assert.assertTrue(emailText.contains("Pending"), "email did not contains the status: " + sessionName);
    }
}
