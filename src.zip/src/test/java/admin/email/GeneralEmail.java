package admin.email;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import emails.Email;
import interaction.gmail.EmailMessage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GeneralEmail extends Email {

    @Test(groups = {ReportingInfo.OPTIMUS})
    @ReportingInfo(firefoxIssue = "RA-27064", chromeIssue = "RA-27057")
    public void forgotPassword() {
        properties.setProperty("adminEmail", properties.getProperty("adminRealEmail"));
        String passwordResetEmail = "RainFocus Password Reset";

        AdminLoginPage loginPage = AdminLoginPage.getPage();
        loginPage.navigate();
        loginPage.sendForgotPassword();

        Assert.assertTrue(checkEmail.waitForEmail(passwordResetEmail), "waiting for email");
        EmailMessage message = checkEmail.getEmail(passwordResetEmail);
        String emailText = message.getBody();

        Matcher matches = Pattern
                .compile(".*?To reset your password click here (.*?) .*")
                .matcher(emailText.replace("\n", ""));
        if (matches.find()) {
            Log.info("found the new password in the email :)", getClass().getName()); }
        else {Log.error("did not find the new password in the email :(", getClass().getName());}
        String newPassword = matches.group(1);

        Assert.assertNotNull(newPassword, "did not get a valid new password");
        Log.info("password reset link: " + newPassword, getClass().getName());
        PageConfiguration.getPage().navigateTo(newPassword);

        //set the new password
        loginPage.setNewPassword(properties.getProperty("adminPassword"));
        PageConfiguration.getPage().navigateTo("http://google.com");

        //login with password
        loginPage.login();

        //set org and event to make sure it is logging in
        OrgEventData.getPage().setOrgAndEvent();
    }
}
