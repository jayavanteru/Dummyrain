package admin.email;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AdminEmailTab;
import apps.admin.adminPageObjects.registration.AdminEmailTabHistory;
import configuration.PropertyReader;
import emails.Email;
import interaction.gmail.EmailMessage;
import logs.Log;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

public class AttendeeEmail extends Email {

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19173", firefoxIssue = "RA-20802")
    public void regConfirmationAdmin() {
        String firstName = properties.getProperty("attendeeFirstName");
        String lastName = properties.getProperty("attendeeLastName");
        String date = DateTime.now().toString("MM/dd/yyyy");
        String order = "Approval Package";
        loginAndCreateAttendee();

        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        ordersTab.selectPackage(order);
        ordersTab.clickNextOnAddOrderModal();
        ordersTab.placeOrder();
        PageConfiguration.getPage().waitForPageLoad();

        findTheEmail(confirmEmail, true, order, firstName, lastName, date, eventname, "INVOICE");

        //cancel the order
        ordersTab.selectOrder(order);
        ordersTab.deleteOrders();
        Assert.assertTrue(ordersTab.isSendCancellationEmail(), "default to send cancellation email is not checked");
        ordersTab.cancelOrder();

        findTheEmail(cancelEmail, true, order, firstName, lastName, date, eventname, "CANCELLATION");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19176", firefoxIssue = "RA-20801")
    public void sendEmailForAttendee() {
        String emailName = "Test Email";
        String emailSubject = "Admin Test Email";
        loginAndCreateAttendee();

        AdminEmailTab emailTab = AdminEmailTab.getPage();
        emailTab.navigate(attendeeId);
        emailTab.sendEmail(emailName);

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //check all the things about the email
        Assert.assertTrue(checkEmail.waitForEmail(emailSubject), "waiting for email");
        EmailMessage message = checkEmail.getEmail(emailSubject);
        String emailBody = message.getBody();

        //assert some things in the body here
        Log.info("email looks like: " + emailBody, getClass().getName());
        Assert.assertEquals(message.getFrom()[0], "automation@rainfocus.com", "email did not have the right from address");
        Assert.assertTrue(emailBody.contains("My Test Email"), "email did not have the expected body");
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        PageConfiguration.getPage().refreshPage();
        AdminEmailTabHistory historyTab = AdminEmailTabHistory.getPage();
        historyTab.navigate(attendeeId);
        Utils.sleep(1000);
        historyTab.resendEmail(emailName);


        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //check all the things about the email
        Assert.assertTrue(checkEmail.waitForEmail(emailSubject), "waiting for email");
        message = checkEmail.getEmail(emailSubject);
        emailBody = message.getBody();

        //assert some things in the body here
        Log.info("email looks like: " + emailBody, getClass().getName());
        Assert.assertEquals(message.getFrom()[0], "automation@rainfocus.com", "email did not have the right from address");
        Assert.assertTrue(emailBody.contains("My Test Email - Love The Robots"), "email did not have the expected body");
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19172", firefoxIssue = "RA-20804")
    public void sendEmailKeywordsForAttendee() {
        String emailName = "Test Email Keywords";
        String emailSubject = "Admin Keywords Test Email";
        String managersNameAttributeId = "1501085490532001X67z";
        String managerName = "automater";
        loginAndCreateAttendee();

        //set the job title
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB2);
        customTab.navigate(attendeeId);
        customTab.enterTextInField(managersNameAttributeId, managerName);
        customTab.submit();
        Utils.sleep(1000);

        AdminEmailTab emailTab = AdminEmailTab.getPage();
        emailTab.navigate(attendeeId);
        emailTab.sendEmail(emailName);


        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //check all the things about the email
        Assert.assertTrue(checkEmail.waitForEmail(emailSubject), "waiting for email");
        EmailMessage message = checkEmail.getEmail(emailSubject);
        String emailBody = message.getBody();

        //assert some things in the body here
        Log.info("email looks like: " + emailBody, getClass().getName());
        String firstName = PropertyReader.instance().getProperty("attendeeFirstName");
        String lastName = PropertyReader.instance().getProperty("attendeeLastName");
        Assert.assertEquals(message.getFrom()[0], "automation@rainfocus.com", "email did not have the right from address");
        Assert.assertTrue(emailBody.contains("first name " + firstName), "email did not add in the keywords for first name. " + firstName);
        Assert.assertTrue(emailBody.contains("last name " + lastName), "email did not add in the keywords for last name. " + lastName);
        Assert.assertTrue(emailBody.contains("email " + this.emailAddress), "email did not add in the keywords for email. " + emailAddress);
        Assert.assertTrue(emailBody.contains("what is your managers name " + managerName), "email did not add in the keywords for job title. " + managerName);
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19175", firefoxIssue = "RA-25628")
    public void previewEmailForAttendee() {
        String emailName = "Test Email Keywords";
        String managersNameAttributeId = "1501085490532001X67z";
        String managerName = "automater";
        loginAndCreateAttendee();

        //set the job title
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB2);
        customTab.navigate(attendeeId);
        customTab.enterTextInField(managersNameAttributeId, managerName);
        customTab.submit();
        Utils.sleep(1000);

        AdminEmailTab emailTab = AdminEmailTab.getPage();
        emailTab.navigate(attendeeId);
        Utils.sleep(500);
        String emailBody = emailTab.previewEmail(emailName);

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //check all the things about the email preview

        //assert some things in the body here
        Log.info("email preivew looks like: " + emailBody, getClass().getName());
        String firstName = PropertyReader.instance().getProperty("attendeeFirstName");
        String lastName = PropertyReader.instance().getProperty("attendeeLastName");
        Assert.assertTrue(emailBody.contains("first name " + firstName), "email did not add in the keywords for first name. " + firstName);
        Assert.assertTrue(emailBody.contains("last name " + lastName), "email did not add in the keywords for last name. " + lastName);
        Assert.assertTrue(emailBody.contains("email " + this.emailAddress), "email did not add in the keywords for email. " + emailAddress);
        Assert.assertTrue(emailBody.contains("what is your managers name " + managerName), "email did not add in the keywords for job title. " + managerName);
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    }
}
