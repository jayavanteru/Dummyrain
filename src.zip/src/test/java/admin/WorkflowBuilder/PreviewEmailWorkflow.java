package admin.WorkflowBuilder;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditEmailPage;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.Utils;

public class PreviewEmailWorkflow
{
    private OrgEventData orgEventData;
    private String orgName = "RainFocus";
    private String eventName = "Constellations";

    @BeforeClass
    public void setupTest()
    {
        AdminLoginPage.getPage().login();
        orgEventData.setOrgAndEvent(orgName, eventName);
    }

    @AfterClass
    public void teardownTest() {
        PageConfiguration.getPage().quit();
    }

    //TODO: Uncomment Test when finished implementing.
    //@Test
    public void previewEmailInWorkflowBuilder()
    {
        NavigationBar navigationBar = new NavigationBar();
        EmailsSearchPage emailSearch = new EmailsSearchPage();
        WorkflowsSearchPage workflowSearch = new WorkflowsSearchPage();
        EditEmailPage emailEdit = new EditEmailPage();


        navigationBar.gotoPage(navigationBar.EMAILS); //Navigates to the emails page.
        //If the template email exists then navigate to the workflows page.
        if (emailSearch.emailExists("automationPreviewWorkflowBuilderEmail"))
        {
            navigationBar.gotoPage(navigationBar.WORKFLOWS);
        }
        else
        {
            //If the template email does not exist then create the email and navigate to the workflows page.
            //createPreviewEmailTemplate(); //TODO: Create the email template if it does not exist.

            navigationBar.gotoPage(navigationBar.WORKFLOWS);
        }
        //If the template workflow exists then open it
        if (workflowSearch.workflowExists("automationPreviewWorkflowBuilderWorkflow"))
        {
            workflowSearch.clickResult(0); //Click the first result
        }
        //If the workflow template does not exist, then create it.
        else {
            workflowSearch.clickAddButton(); //Click FAB
            NewWorkflowPage workflowPage = new NewWorkflowPage();
            workflowPage.verifyPageUrl(); //Verify the page loaded.
            workflowPage.selectTemplateByName("Registration"); //Select the Registration template (as it already has an email node pre-placed.)
            workflowPage.setTemplateName("automationPreviewWorkflowBuilderWorkflow");
            workflowPage.setTemplateURI("automationPreviewWorkflowBuilderWorkflow");
            workflowPage.clickModalSave();
        }
        WorkflowEditBuilderPage.getPage().openNodeByName("Confirmation Email");
        //workflowEditPage.previewEmail();
        Utils.sleep(20000);
    }
}
