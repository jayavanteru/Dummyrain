package admin.WorkflowBuilder;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.workflows.CFPWorkflowStepEditPage;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class CFPWorkflow {

    private final String TemplateName = new DataGenerator().generateName();
    private final String HomeFormName = "CFP - Home Trogdor";
    private final String SessionFormName = "CFP - Session Submit";
    private final String DisplayRole = "Speaker";
    private final String SessionRole = "Speaker";
    private final String SessionType = "Breakout";
    private final String Limit = "5";
    private final String NewParticipantFrom = "CFP - Session Participant";
    private final String ExistingAttendeeFrom = "CFP - Session Participant Existing";
    private final String EditParticipantForm = "CFP - Session Participant Modify";
    private final String ConfirmationPageForm = "CFP - Confirm Trogdor";
    private final String attendeeEmail = ("Brian.Pulham@rainfocus.com");

    private final WorkflowsSearchPage WFSearch = WorkflowsSearchPage.getPage();
    private final NewWorkflowPage NewWFPage = NewWorkflowPage.getPage();
    private final CFPWorkflowStepEditPage CFPEdit = CFPWorkflowStepEditPage.getPage();

    protected AdminApp adminApp;

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-19895", chromeIssue = "RA-50695")
    public void CreateCFPWorkflow(){

        WFSearch.navigate();
        WFSearch.clickAddButton();
        WFSearch.clickNewTemplate("Call For Papers");
        NewWFPage.setTemplateName(TemplateName);
        NewWFPage.setTemplateURI(TemplateName);
        NewWFPage.clickModalSave();
        CFPEdit.homeForm(HomeFormName);
        CFPEdit.save();
        CFPEdit.sessionForm(SessionFormName);
        CFPEdit.save();
        CFPEdit.participantRoles(DisplayRole, SessionRole);
        CFPEdit.sessionLimits(SessionType, Limit);
        CFPEdit.setNewAttendeeForm(NewParticipantFrom);
        CFPEdit.setExistingAttendeeForm(ExistingAttendeeFrom);
        CFPEdit.setEditParticipantForm(EditParticipantForm);
        CFPEdit.save();
        CFPEdit.setConfirmationPageForm(ConfirmationPageForm);
        CFPEdit.save();
        CFPEdit.publish();
        WFSearch.navigate();
        WFSearch.searchFor(TemplateName);
        WFSearch.clickResult(0);
        Assert.assertTrue(CFPEdit.isHomePageFormSet(), "The home page form is not set to " + HomeFormName);
        CFPEdit.save();
        Assert.assertTrue(CFPEdit.isSessionPageFormSet(), "The session page form is not set to " + SessionFormName);
        CFPEdit.save();
        Assert.assertTrue(CFPEdit.isNewAttendeeFormSet(), "The home page form is not set to " + NewParticipantFrom );
        Assert.assertTrue(CFPEdit.isExistingAttendeeSet(), "The home page form is not set to " + ExistingAttendeeFrom);
        Assert.assertTrue(CFPEdit.isEditAttendeeSet(), "The home page form is not set to " + EditParticipantForm);
        CFPEdit.save();
        Assert.assertTrue(CFPEdit.isConfirmationFormSet(), "The home page form is not set to " + ConfirmationPageForm);
        CFPEdit.save();
        adminApp.spoofIntoWorkflow(attendeeEmail, TemplateName, 1);
        Assert.assertTrue(CFPEdit.canWorkflowBeSpoofedInTo(), "It seems like the user can't spoof into the CFP workflow");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        WFSearch.navigate();
        WFSearch.deleteWorkFlowByName(TemplateName);
    }
}
