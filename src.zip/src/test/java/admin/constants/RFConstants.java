package admin.constants;

public class RFConstants
{
  public static final String EVENT_NAME_EVENTGERS_TEST = "Eventgers Test Event";
  public static final String EVENT_NAME_TVA = "TVA AUTOMATION *DO NOT TOUCH*";
  public static final String EVENT_CODE_EVENTGERS_TEST = "eventgers";
  public static final String EVENT_NAME_ONE_DAY = "One Day Event TEST - DO NOT EDIT";
  public static final String EVENT_CODE_ONE_DAY = "onedayevent";
  public static final String EVENT_NAME_ACCOUNTS = "Accounts TEST - DO NOT EDIT";
  public static final String EVENT_CODE_ACCOUNTS = "accountstest";
  public static final String DO_NOT_EDIT_STRING = " - Automation test - do not edit";
  public static final String ORG_IBM = "IBM";
  public static final String ORG_RF_AUTOMATION = "RF Automation";
}
