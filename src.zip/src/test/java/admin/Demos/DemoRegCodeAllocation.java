package admin.Demos;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.Demos.Demos.DemoRegCodesTab;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.Demos.Demos.EditDemoPage;
import apps.admin.adminPageObjects.Demos.RegCodeAllocations.CreateDemoRegCodeAllocationPage;
import apps.admin.adminPageObjects.Demos.RegCodeAllocations.SearchDemoRegCodeAllocationsPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class DemoRegCodeAllocation {
    AdminLoginPage adminLoginPage = AdminLoginPage.getPage();
    DataGenerator dataGenerator = new DataGenerator();
    SearchDemoRegCodeAllocationsPage searchDemoRegCodeAllocationsPage = SearchDemoRegCodeAllocationsPage.getPage();
    CreateDemoRegCodeAllocationPage createDemoRegCodeAllocationPage = CreateDemoRegCodeAllocationPage.getPage();

    private AdminApp adminApp;
    String allocationId;
    String regCodeName;

    @BeforeTest
    public void setUp(){
        adminApp = new AdminApp();
        adminLoginPage.login();
        OrgEventData.getPage().setOrgAndEvent();
        adminLoginPage.navigate();
        NavigationBar.getPage().collapse();
        searchDemoRegCodeAllocationsPage.navigate();
    }

    @BeforeMethod
    public void createNewRegCode(){
        regCodeName = dataGenerator.generateName();
        searchDemoRegCodeAllocationsPage.navigate();
        searchDemoRegCodeAllocationsPage.clickAddButton();
        createDemoRegCodeAllocationPage.createDemoRegCodeAllocation(regCodeName);
    }

    @AfterMethod
    public void deleteRegCode(){
        adminApp.deleteDemoRegCodeAllocation(allocationId);
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24356", firefoxIssue = "RA-24819")
    public void createDemoRegCodeAllocation(){
        searchDemoRegCodeAllocationsPage.navigate();
        searchDemoRegCodeAllocationsPage.searchByString(regCodeName);
        Assert.assertTrue(searchDemoRegCodeAllocationsPage.elementExists(regCodeName), "Demo Reg Code was not created successfully");
        allocationId = searchDemoRegCodeAllocationsPage.getId(regCodeName);
       }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24358", firefoxIssue = "RA-25829")
    public void verifyAllocation(){
        //create demo
        String demoName = new DataGenerator().generateName();
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().clickAddButton();
        CreateDemoPage.getPage().createDemo(demoName);
        adminApp.safeSetSelectListValue("Exhibitor Status", "Approved");
        EditDemoPage.getPage().clickSubmit();

        //create reg code
        regCodeName = dataGenerator.generateName();
        searchDemoRegCodeAllocationsPage.navigate();
        searchDemoRegCodeAllocationsPage.clickAddButton();
        createDemoRegCodeAllocationPage.createDemoRegCodeAllocation(regCodeName);

        //assert demo got allocation
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().select(demoName);
        EditDemoPage.getPage().clickRegCodeTab();
        Assert.assertTrue(DemoRegCodesTab.getPage().regCodeExists(regCodeName));

        // delete demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().deleteFirstDemo();

        // delete reg code
        searchDemoRegCodeAllocationsPage.navigate();
        searchDemoRegCodeAllocationsPage.searchByString(regCodeName);
        searchDemoRegCodeAllocationsPage.deleteFirstRegCode();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24357", firefoxIssue = "RA-24820")
    public void deleteFirstRegCodeAllocation(){
        //delete new reg code
        searchDemoRegCodeAllocationsPage.navigate();
        searchDemoRegCodeAllocationsPage.searchByString(regCodeName);
        searchDemoRegCodeAllocationsPage.deleteFirstRegCode();
        searchDemoRegCodeAllocationsPage.searchByString(regCodeName);
        Assert.assertFalse(searchDemoRegCodeAllocationsPage.elementExists(regCodeName), "Demo Reg Code was not deleted successfully");
    }

}
