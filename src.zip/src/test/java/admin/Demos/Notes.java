package admin.Demos;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.Demos.Demos.DemoNotesTabPage;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.Demos.Demos.EditDemoPage;
import apps.admin.adminPageObjects.OrgEventData;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Notes {
    DataGenerator dataGenerator = new DataGenerator();
    String demoName = dataGenerator.generateName();
    String noteText = dataGenerator.generateString(10);

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event D");

        //create demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().clickAddButton();
        CreateDemoPage.getPage().createDemo(demoName);

        //create note
        EditDemoPage.getPage().noteTab();
        DemoNotesTabPage.getPage().setNoteTextField(noteText);
        DemoNotesTabPage.getPage().clickSaveNote();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27959", firefoxIssue = "RA-27960")
    public void createNote(){
        //assert note exists
        Assert.assertTrue(DemoNotesTabPage.getPage().noteExists(noteText));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27961", firefoxIssue = "RA-27962")
    public void editNote(){
        String newNoteText = dataGenerator.generateString(10);

        //edit note
        DemoNotesTabPage.getPage().editNote(noteText, newNoteText);
        noteText = newNoteText;

        //assert note is edited
        Assert.assertTrue(DemoNotesTabPage.getPage().noteExists(noteText));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27963", firefoxIssue = "RA-27964")
    public void deleteNote(){
        String noteText = dataGenerator.generateString(10);

        //create note
        DemoNotesTabPage.getPage().setNoteTextField(noteText);
        DemoNotesTabPage.getPage().clickSaveNote();

        //delete note
        DemoNotesTabPage.getPage().deleteNote(noteText);

        //assert note does not exist
        Assert.assertFalse(DemoNotesTabPage.getPage().noteExists(noteText));
    }

    @AfterClass
    public void tearDown(){
        //delete demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().deleteFirstDemo();

        PageConfiguration.getPage().quit();
    }
}