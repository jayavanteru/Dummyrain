package admin.Demos;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.Demos.Demos.EditDemoPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.BoothsSearchPage;
import apps.admin.adminPageObjects.exhibits.EditBoothPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorBoothsTab;
import apps.admin.adminPageObjects.exhibits.NewBoothPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Booths {

    private AdminApp adminApp;
    protected String boothName, boothId, demoName, demoId;
    DataGenerator dataGenerator = new DataGenerator();

    @BeforeClass
    public void setUp(){
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event E");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24348", firefoxIssue = "RA-24817")
    public void assignDemoToBooth(){
        //create Booth
        boothName = dataGenerator.generateName();
        boothId = adminApp.createBooth(boothName = dataGenerator.generateName(), "");

        //create Demo
        demoId = adminApp.createDemoInCurrentEvent(demoName = dataGenerator.generateName());

        //add Demo to Booth
        BoothsSearchPage.getPage().navigate();
        BoothsSearchPage.getPage().searchBooth(boothName);
        BoothsSearchPage.getPage().clickResult(0);
        EditBoothPage.getPage().assignExhibitor(demoName);
        EditBoothPage.getPage().submit();

        //assert Demo has been added to Booth
        BoothsSearchPage.getPage().searchBooth(boothName);
        BoothsSearchPage.getPage().clickResult(0);
        Assert.assertTrue(EditBoothPage.getPage().exhibitorIsAssigned(demoName));

        //un-assign booth from demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().select(demoName);
        EditDemoPage.getPage().clickBoothsTab();
        ExhibitorBoothsTab.getPage().unassignBooth(boothName);
        ExhibitorBoothsTab.getPage().clickSubmitButton();
    }

    @AfterClass
    public void tearDown(){
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().deleteFirstDemo();

        adminApp.deleteBooth(boothId);

        PageConfiguration.getPage().quit();
    }
}
