package admin.Demos;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.Demos.Demos.DemosSearchPage;
import apps.admin.adminPageObjects.Demos.Demos.EditDemoPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class DemoExhibitor {
    AdminApp adminAp = new AdminApp();
    protected final DataGenerator dataGenerator = new DataGenerator();
    String demoName, demoId;
    String event =  "Constellations";

    @BeforeClass
    public void setUpTest(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Event D");
        adminAp.createDemoInCurrentEvent(demoName = dataGenerator.generateName());
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24341", firefoxIssue = "RA-25650")
    public void createDemo(){
        DemosSearchPage demosSearchPage = DemosSearchPage.getPage();
        demosSearchPage.navigate();
        demosSearchPage.searchBy(demoName);
        Assert.assertEquals(demosSearchPage.getName(demosSearchPage.getName(demoName)), demoName, "Demo was not created correctly");
    }


    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24339", firefoxIssue = "RA-25649")
    public void searchByString(){
        DemosSearchPage demosSearchPage = DemosSearchPage.getPage();
        demosSearchPage.navigate();
        demosSearchPage.searchBy(demoName);
        Assert.assertTrue(demosSearchPage.elementExists(demoName), "Demo was not found by searching by demo name");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24340", firefoxIssue = "RA-25819")
    public void editDemo(){
        //edit demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().selectFirstDemo();

        adminAp.safeSetTextBox("Name", demoName = dataGenerator.generateName());

        //assert demo was edited;
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        Assert.assertTrue(DemosSearchPage.getPage().demoExists(demoName), "Demo name was not changed");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24342", firefoxIssue = "RA-25820")
    public void deleteDemo(){
        //create demo
        String demo = dataGenerator.generateName();
        adminAp.createDemoInCurrentEvent(demoName);

        //delete demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demo);
        DemosSearchPage.getPage().deleteFirstDemo();

        //assert demo has been deleted
        DemosSearchPage.getPage().searchBy(demo);
        Assert.assertFalse(DemosSearchPage.getPage().elementExists(demo));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-24343", firefoxIssue = "RA-25821")
    public void cantDuplicateDemo(){

        //try and create another demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().clickAddButton();
        CreateDemoPage.getPage().setDemoName(demoName);

        //assert cant create duplicate demo
        Assert.assertTrue(CreateDemoPage.getPage().errorExists(demoName));
    }

    @AfterClass
    public void tearDown(){
        adminAp.deleteExhibitor(demoId);
        PageConfiguration.getPage().quit();
    }
}
