package admin.Demos;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.Demos.Demos.*;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.NewTaskQualifierPage;
import apps.admin.adminPageObjects.libraries.TaskQualifierSearchPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class DemoTasks {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String demoName =  dataGenerator.generateName(),
            qualifierName = dataGenerator.generateName(),
            taskName = dataGenerator.generateName(),
            attendeeEmail = dataGenerator.generateEmail(),
            attendeeID,
            taskId,
            qualifierId;

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event F");
        NavigationBar.getPage().collapse();

        //create attendee
        attendeeID = adminApp.createAttendee(attendeeEmail);

        //create demo
        //for some reason the navigate() method in the create demo page does not work.....even though it does :that:
        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("adminUrl") + "/rain.focus#demo/load.do");
        CreateDemoPage.getPage().createDemo(demoName);

        //add primary owner to demo
        EditDemoPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendeeEmail, "Primary Owner");

        //create demo task qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().addItem();
        NewTaskQualifierPage.getPage().setName(qualifierName);
        NewTaskQualifierPage.getPage().setEntityType("Demo");
        NewTaskQualifierPage.getPage().setCriteriaByDemoName(demoName);
        NewTaskQualifierPage.getPage().clickSubmit();

        //create demo task with qualifier
        TasksSearchPage.getPage().navigate();
        TasksSearchPage.getPage().addItem();
        NewTaskPage.getPage().setName(taskName);
        NewTaskPage.getPage().setGroup("Test Test");
        NewTaskPage.getPage().setEntityType("Demo");
        NewTaskPage.getPage().setType("External URL");
        NewTaskPage.getPage().setDisplayValue(taskName);
        NewTaskPage.getPage().setDemoRole("Primary Owner");
        NewTaskPage.getPage().setExternalURL("app.dev.rainfocus.com");
        NewTaskPage.getPage().setQualifiers(qualifierName);
        NewTaskPage.getPage().submit();

        TasksSearchPage.getPage().search(taskName);
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20186", firefoxIssue = "RA-25035")
    public void adminDemoTask(){
        //assert that demo has task
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().select(demoName);
        EditDemoPage.getPage().clickTaskTab();
        Assert.assertTrue(DemoTasksTab.getPage().taskExists(taskName));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27370", firefoxIssue = "RA-27371")
    public void createDemoTask(){
        TasksSearchPage.getPage().navigate();
        TasksSearchPage.getPage().search(taskName);
        Assert.assertTrue(TasksSearchPage.getPage().taskExists(taskName));
    }

    @AfterClass
    public void tearDown(){
        //delete Demo
        DemosSearchPage.getPage().navigate();
        DemosSearchPage.getPage().searchBy(demoName);
        DemosSearchPage.getPage().deleteFirstDemo();

        //delete attendee
        adminApp.deleteAttendee(attendeeID);

        //Delete Task
        adminApp.deleteTask(taskId);

        //Delete Task Qualifier
        TaskQualifierSearchPage.getPage().navigate();
        TaskQualifierSearchPage.getPage().searchFor(qualifierName);
        qualifierId = TaskQualifierSearchPage.getPage().getId(qualifierName);
        adminApp.deleteTaskQualifier(qualifierId);

        PageConfiguration.getPage().quit();
    }
}
