package admin.searches.Meeting;

import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import testHelp.Utils;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class Export extends Meeting {

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-26679", chromeIssue = "RA-26678")
    public void exportmeetingSearchCSV() {
        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(meetingName);
        Utils.sleep(1000);
        search.exportcsv();
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("meetings.+csv\\z");
        List<Map<String, String>> CSVList = file.getCsvMap();
        List<Map<String, String>> meetingList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, CSVList.size(), "The number of results are not the same. Expected " + results + " but instead got " + CSVList.size());

        OpenFile.assertSameUK(meetingList, CSVList);

    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-26682", chromeIssue = "RA-26680")
    public void exportmeetingSearchXML() throws IOException, SAXException, ParserConfigurationException {
        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(meetingName);
        Utils.sleep(500, "wait for the search");
        search.exportXML();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xmlResults = file.parseXML("session");
        List<Map<String, String>> meetingList;
        meetingList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xmlResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xmlResults.size());

        OpenFile.assertSameLK(meetingList, xmlResults);

    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-26684", chromeIssue = "RA-26683")
    public void exportmeetingSearchXLSX() throws IOException, SAXException, ParserConfigurationException {
        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(meetingName);
        Utils.sleep(500, "wait for the search");
        search.exportXLSX();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xlsxResults = file.parseXLSX();
        List<Map<String, String>> meetingList;
        meetingList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xlsxResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xlsxResults.size());

        OpenFile.assertSameUK(meetingList, xlsxResults);

    }

}
