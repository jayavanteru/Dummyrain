package admin.searches.Meeting;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import logs.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Meeting {
    DataGenerator gen = new DataGenerator();

    protected AdminApp adminApp;
    protected String meetingName = "automation" + gen.generateString(8);
    protected List<String> meetingIds;
    protected List<String> meetingNames = new ArrayList<>();
    protected int meetingCount = 5;

    //load test setup
    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        meetingIds = new ArrayList<>();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
        for (int i = 0; i < meetingCount; ++i) {
            String newMeetingName = this.meetingName + gen.generateString();
            meetingIds.add(adminApp.createMeeting(newMeetingName));
            meetingNames.add(newMeetingName);
        }
    }

    @AfterClass
    public void endTest() {
        for (String meetingId : meetingIds) {
            adminApp.deleteMeeting(meetingId);
        }
        PageConfiguration.getPage().quit();
    }

    public void assertAllMeetingsShowUp() {
        Log.info("waiting for the search, when the search is done there should be less than 50", getClass());
        Utils.waitForTrue(()->MeetingsSearchPage.getPage().getAllIds(".*").size() < 50);

        Set<String> allIds = MeetingsSearchPage.getPage().getAllIds(".*");
        Assert.assertEquals(allIds.size(), meetingIds.size(), "search results did not find just the expected meetings");
        meetingIds.forEach(id -> Assert.assertTrue(allIds.contains(id), "id '" + id + "' was not found in searched list " + allIds.stream().reduce((a,b)-> a + " "+b+" ").get()));
    }

}
