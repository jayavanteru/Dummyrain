package admin.searches.Meeting;

import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.List;
import java.util.Map;

public class Search extends Meeting {

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-26677", chromeIssue = "RA-26676")
    //(description = "creates 5 meetings, bulk updates the status, asserts it updated on all of them")
    public void bulkMeetingUpdateTest() {
        String status = "Referred";

        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        search.navigate();
        Utils.sleep(500);
        search.searchFor(meetingName);
        assertAllMeetingsShowUp();

        Utils.sleep(1000);
        search.bulkedit();
        AdminAttendeeBulkEditPage.getPage().bulkUpdateStatus(status);
        search.navigate();

        search.searchFor(meetingName);
        assertAllMeetingsShowUp();

        Utils.waitForTrue(()->search.getStatuses().get(0).equals(status));
        List<String> statuses = search.getStatuses();
        statuses.forEach(name -> Assert.assertEquals(name, status, "Could not find the status"));
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-26675", chromeIssue = "RA-19566")
    public void AdvancedMeetingSearchTests() {
        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        search.navigate();
        Utils.sleep(500);

        search.clickSearch();
        Assert.assertTrue(search.getAllIds(".*").size() > meetingCount, "there should be more results with no search parameter");

        search.toggleAdvancedSearch();

        for(String meeting: meetingNames){
            AttendeeSearchPage.getPage().advSearch("Title", "contains", meeting);
            MeetingsSearchPage.getPage().search();
            List<Map<String, String>> results = MeetingsSearchPage.getPage().getResults();
            Assert.assertTrue(results.get(0).get("title").contains(meeting));
            MeetingsSearchPage.getPage().clickClear();
        }
    }
}
