package admin.searches;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.*;
import logs.Log;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class QuickSearchTest {

    private AdminApp adminApp;
    private DataGenerator dataGenerator;
    private QuickSearchPage searchPage;
    private String attendeeId;
    private String sessionId;
    private String exhibitorId;

    @BeforeClass
    public void setup() {
        dataGenerator = new DataGenerator();
        adminApp = new AdminApp();
        searchPage = QuickSearchPage.getPage();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void delete() {
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
        }
        if (sessionId != null) {
            adminApp.deleteSession(sessionId);
        }
        if (exhibitorId != null) {
            adminApp.deleteExhibitor(exhibitorId);
        }

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TRIAGE})
    @ReportingInfo(chromeIssue = "RA-25950", firefoxIssue = "RA-25949")
    public void searchForAttendee() {
        String email = dataGenerator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);

        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        AdminDashboardPage.getPage().waitTillLoaded();

        searchPage.openSearch();
        searchPage.searchFor(email);

        assertResultsForText(searchPage.top5(), email);

        Assert.assertTrue(searchPage.isAnyAttendee(), "is not showing any attendee results");

        Log.info("switching to only attendee results", getClass());
        assertResultsForText(searchPage.top5Attendees(), email);

        PageConfiguration.getPage().setImplicitWait(1, TimeUnit.SECONDS);
        Assert.assertFalse(searchPage.isAnyExhibitor(), "showing exhibitors when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnySession(), "showing sessions when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnyMeeting(), "showing meetings when there shouldn't be any");
        PageConfiguration.getPage().setImplicitWait(5, TimeUnit.SECONDS);

        assertClickingOnSearchResult(email, attendeeId);

        checkRecents(email);
    }

    @Test(groups = {ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-25952", chromeIssue = "RA-25951")
    public void searchForSession() {
        String name = dataGenerator.generateString();
        sessionId = adminApp.createSession(name);

        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        AdminDashboardPage.getPage().waitTillLoaded();

        searchPage.openSearch();
        searchPage.searchFor(name);

        assertResultsForText(searchPage.top5(), name);

        Assert.assertTrue(searchPage.isAnySession(), "is not showing any session results");

        Log.info("switching to only session results", getClass());
        assertResultsForText(searchPage.top5Sessions(), name);

        PageConfiguration.getPage().setImplicitWait(1, TimeUnit.SECONDS);
        Assert.assertFalse(searchPage.isAnyExhibitor(), "showing exhibitors when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnyAttendee(), "showing attendees when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnyMeeting(), "showing meetings when there shouldn't be any");
        PageConfiguration.getPage().setImplicitWait(5, TimeUnit.SECONDS);

        assertClickingOnSearchResult(name, sessionId);

        checkRecents(name);
    }

    @Test(groups = {ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-32304", chromeIssue = "RA-25947")
    public void searchForExhibitor() {
        String name = dataGenerator.generateString(6) + "automation";
        exhibitorId = adminApp.createExhibitor(name);

        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        AdminDashboardPage.getPage().waitTillLoaded();

        searchPage.openSearch();
        searchPage.searchFor(name);

        assertResultsForText(searchPage.top5(), name);

        Assert.assertTrue(searchPage.isAnyExhibitor(), "is not showing any exhibitor results");

        Log.info("switching to only exhibitor results", getClass());
        assertResultsForText(searchPage.top5Exhibitors(), name);

        PageConfiguration.getPage().setImplicitWait(1, TimeUnit.SECONDS);
        Assert.assertFalse(searchPage.isAnySession(), "showing exhibitors when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnyAttendee(), "showing attendees when there shouldn't be any");
        Assert.assertFalse(searchPage.isAnyMeeting(), "showing meetings when there shouldn't be any");
        PageConfiguration.getPage().setImplicitWait(5, TimeUnit.SECONDS);

        assertClickingOnSearchResult(name, exhibitorId);

        checkRecents(name);
    }

    private void assertResultsForText(String[] results, String text) {
        Assert.assertEquals(results.length, 1, "the search returned more than just the one result");
        String result = results[0];
        Assert.assertTrue(result.contains(text), "search did not return the correct text: " + text + " search result: " + result);
    }

    private void assertClickingOnSearchResult(String result, String expectedId) {
        searchPage.clickSearchResult(result);
        PageConfiguration.getPage().waitForPageLoad();

        String currentUrl = PageConfiguration.getPage().getCurrentUrl();
        Assert.assertTrue(currentUrl.contains(expectedId), "clicking on the search result did not take us to the correct record: " + attendeeId +
                " instead navigated to " + currentUrl);
    }

    private void checkRecents(String record) {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        AdminDashboardPage.getPage().waitTillLoaded();

        RecentsPage.getPage().openRecents();
        ArrayList<String> recents = RecentsPage.getPage().getRecentsForDate(DateTime.now());

        Log.info("removing found recent records from list if they don't have " + record, getClass());
        recents.removeIf(t -> !t.contains(record));

        Assert.assertTrue(recents.size() > 0, "none of the records contained " + record);
    }
}
