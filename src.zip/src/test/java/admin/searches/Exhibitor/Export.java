package admin.searches.Exhibitor;

import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import testHelp.Utils;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class Export extends Exhibitor {

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-26659", chromeIssue = "RA-26658")
    public void exportExhibitorSearchCSV() {
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        search.navigate();
        search.resetColumns();
        search.searchFor(exhibitorName);
        search.exportcsv();
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("exhibitors.+csv\\z");
        List<Map<String, String>> CSVList = file.getCsvMap();
        List<Map<String, String>> exhibitorList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, CSVList.size(), "The number of results are not the same. Expected " + results + " but instead got " + CSVList.size());

        OpenFile.assertSameUK(exhibitorList, CSVList);

    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-26661", chromeIssue = "RA-26660")
    public void exportExhibitorSearchXML() throws IOException, SAXException, ParserConfigurationException {
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        search.navigate();
        search.resetColumns();
        search.clickClear();
        search.searchFor(exhibitorName);
        Utils.sleep(500, "wait for the search");
        search.exportXML();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xmlResults = file.parseXML("exhibitor");
        List<Map<String, String>> exhibitorList;
        exhibitorList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xmlResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xmlResults.size());

        OpenFile.assertSameLK(exhibitorList, xmlResults);

    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-26664", chromeIssue = "RA-26663")
    public void exportExhibitorSearchXLSX() throws IOException, SAXException, ParserConfigurationException {
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        search.navigate();
        search.resetColumns();
        search.clickClear();
        search.searchFor(exhibitorName);
        Utils.sleep(500, "wait for the search");
        search.exportXLSX();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xlsxResults = file.parseXLSX();
        List<Map<String, String>> exhibitorList;
        exhibitorList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xlsxResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xlsxResults.size());

        OpenFile.assertSameUK(exhibitorList, xlsxResults);

    }

}
