package admin.searches.Exhibitor;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Exhibitor {
    DataGenerator gen = new DataGenerator();

    protected AdminApp adminApp;
    protected String exhibitorName = gen.generateString(3) + "automation";
    protected List<String> exhibitorIds;
    List<String> exhibitorNames = new ArrayList<>();
    protected int exhibitorCount = 5;

    //load test setup
    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        exhibitorIds = new ArrayList<>();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
        for (int i = 0; i < exhibitorCount; ++i) {
            String tempExhibitorName = gen.generateString(3) + this.exhibitorName;
            exhibitorIds.add(adminApp.createExhibitorInCurrentEvent(tempExhibitorName));
            exhibitorNames.add(tempExhibitorName);
        }

    }

    @AfterClass
    public void endTest() {
        for (String exhibitor : exhibitorIds) {
            adminApp.deleteExhibitor(exhibitor);
        }
        PageConfiguration.getPage().quit();
    }

    public void assertAllExhibitorsShowUp() {
        Set<String> allIds = ExhibitorSearchPage.getPage().getAllIds(".*");
        Assert.assertEquals(allIds.size(), exhibitorIds.size(), "search results did not find the expected exhibitors" + allIds);
        exhibitorIds.forEach(id -> Assert.assertTrue(allIds.contains(id), "id '" + id + "' was not found in searched list " + allIds.stream().reduce((a,b)-> a + " "+b+" ").get()));
    }


}
