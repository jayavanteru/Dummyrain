package admin.searches.Exhibitor;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class AdvancedSearch {
    String exhibitorName = new DataGenerator().generateName();
    String participantFirstName = new DataGenerator().generateName();
    String participantLastName = new DataGenerator().generateName();
    String participantEmail = new DataGenerator().generateEmail();


    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event E");

        //create Exhibitor
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().addItem();
        CreateExhibitorPage.getPage().filloutForm("Blue Event E", exhibitorName);

        //add participant to exhibitor
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().clickAddParticipantButton();
        AdminExhibitorNewContactPage.getPage().fillOutForm(participantFirstName, participantLastName, participantEmail,"Primary Owner");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27979", firefoxIssue = "RA-27980")
    public void exhibitorParticipantValues(){
        ExhibitorSearchPage.getPage().navigate();

        //participant firstName
        ExhibitorSearchPage.getPage().toggleAdvancedSearch();
        ExhibitorSearchPage.getPage().advancedSearchByText("Participant First Name", participantFirstName);
        ExhibitorSearchPage.getPage().search();
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName));

        //participant last name
        ExhibitorSearchPage.getPage().removeAdvancedSearchCriteria();
        ExhibitorSearchPage.getPage().addAdvancedSearchCriteria();
        ExhibitorSearchPage.getPage().advancedSearchByText("Participant Last Name", participantLastName);
        ExhibitorSearchPage.getPage().search();
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName));

        //participant email
        ExhibitorSearchPage.getPage().removeAdvancedSearchCriteria();
        ExhibitorSearchPage.getPage().addAdvancedSearchCriteria();
        ExhibitorSearchPage.getPage().advancedSearchByText("Participant Email", participantEmail);
        ExhibitorSearchPage.getPage().search();
        Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(exhibitorName));

    }

    @AfterClass
    public void tearDown(){
        //delete exhibitor
        ExhibitorSearchPage.getPage().navigate();
        ExhibitorSearchPage.getPage().searchFor(exhibitorName);
        ExhibitorSearchPage.getPage().deleteFirstExhibitor();
        PageConfiguration.getPage().quit();
    }
}