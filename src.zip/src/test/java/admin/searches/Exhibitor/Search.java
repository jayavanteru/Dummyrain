package admin.searches.Exhibitor;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.List;

public class Search extends Exhibitor{

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-26657", chromeIssue = "RA-26656")
    //(description = "creates 5 exhibitors, bulk updates the status, asserts it updated on all of them")
    public void bulkExhibitorUpdateTest() {
        String status = "1524857625Maf8184d52";
        String statusText = "Pending";

        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        search.navigate();
        Utils.sleep(500);
        search.clickClear();
        search.searchFor(exhibitorName);
        assertAllExhibitorsShowUp();

        Utils.sleep(1000);
        search.bulkedit();
        AdminAttendeeBulkEditPage.getPage().bulkUpdateStatus(statusText);
        search.navigate();
        Utils.sleep(500, "search page to load");
        search.searchFor(exhibitorName);
        assertAllExhibitorsShowUp();

        Utils.waitForTrue(()->search.getStatuses().get(0).equals(status));
        List<String> statuses = search.getStatuses();
        statuses.forEach(name -> Assert.assertEquals(name, statusText, "Could not find the status"));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-20180", firefoxIssue = "RA-20798")
    public void AdvancedExhibitorSearchTests() {
        NavigationBar.getPage().collapse();
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        search.navigate();
        Utils.sleep(500);

        search.search();
        Assert.assertTrue(search.getAllIds(".*").size() > exhibitorCount, "there should be more results with no search parameter");

        for(String name: exhibitorNames){
            AttendeeSearchPage.getPage().advSearchDropDown("Name", "equal to", name);
            ExhibitorSearchPage.getPage().search();
            Assert.assertTrue(ExhibitorSearchPage.getPage().exhibitorExists(name), "EXHIBITOR '"+name+"' DID NOT APPEAR");
            ExhibitorSearchPage.getPage().clickClear();
        }
    }
}
