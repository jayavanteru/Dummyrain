package admin.searches;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.PaginationHelper;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PaginationTests {

    private AdminApp adminApp;

    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27013", chromeIssue = "RA-27012")
    public void attendeeSearchPagination() {
        AttendeeSearchPage search = AttendeeSearchPage.getPage();
        PaginationHelper pagination = PaginationHelper.getPage();
        search.navigate();
        search.clickSearchButton();
        pagination.waitForResults();
        Assert.assertTrue(pagination.paginationExists(), "The pagination does not exist");
        String activePage = pagination.getActivePage();
        pagination.goToNextPage();
        String newPage = pagination.getActivePage();
        Assert.assertFalse(activePage.contains(newPage), "The page did not change");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-27005", chromeIssue = "RA-27004")
    public void meetingSearchPagination() {
        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        PaginationHelper pagination = PaginationHelper.getPage();
        search.navigate();
        search.clickSearch();
        pagination.waitForResults();
        Assert.assertTrue(pagination.paginationExists(), "The pagination does not exist");
        String activePage = pagination.getActivePage();
        pagination.goToNextPage();
        String newPage = pagination.getActivePage();
        Assert.assertFalse(activePage.contains(newPage), "The page did not change");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27009", chromeIssue = "RA-27008")
    public void sessionSearchPagination() {
        SessionSearchPage search = SessionSearchPage.getPage();
        PaginationHelper pagination = PaginationHelper.getPage();
        search.navigate();
        search.search();
        pagination.waitForResults();
        Assert.assertTrue(pagination.paginationExists(), "The pagination does not exist");
        String activePage = pagination.getActivePage();
        pagination.goToNextPage();
        String newPage = pagination.getActivePage();
        Assert.assertFalse(activePage.contains(newPage), "The page did not change");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-27011", chromeIssue = "RA-27010")
    public void exhibitorSearchPagination() {
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        PaginationHelper pagination = PaginationHelper.getPage();
        search.navigate();
        search.search();
        pagination.waitForResults();
        Assert.assertTrue(pagination.paginationExists(), "The pagination does not exist");
        String activePage = pagination.getActivePage();
        pagination.goToNextPage();
        String newPage = pagination.getActivePage();
        Assert.assertFalse(activePage.contains(newPage), "The page did not change");
    }



}
