package admin.searches.Account;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.marketing.AdminAccountsSearchPage;
import apps.admin.adminPageObjects.marketing.AdminEditAccountPage;
import apps.admin.adminPageObjects.marketing.AdminNewAccountPage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertTrue;

public class AccountSearch {

  private List<String> accountNamesToDelete;
  private DataGenerator dataGenerator;

  private AdminAccountsSearchPage accountsSearchPage;
  private AdminNewAccountPage newAccountPage;
  private AdminEditAccountPage accountPage;

  @BeforeClass
  public void setupTest() {
    accountNamesToDelete = new ArrayList<>();
    dataGenerator = new DataGenerator();
    accountsSearchPage = new AdminAccountsSearchPage();
    newAccountPage = new AdminNewAccountPage();
    accountPage = new AdminEditAccountPage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void tearDown() {
    // delete accounts that were created
    try {
      accountsSearchPage.navigate();
      for(String accountName : accountNamesToDelete) {
        accountsSearchPage.searchFor(accountName);
        accountsSearchPage.deleteAccount(0);
      }
    }
    catch (Exception e) {
      Log.error("Error cleaning up accounts from the AccountSearch tests", AccountSearch.class);
    }

    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-39619", chromeIssue = "RA-39543")
  public void testAccountSearchByEmailDomain() {
    accountsSearchPage.navigate();
    accountsSearchPage.addItem();

    // create account
    String accountName = dataGenerator.generateName();
    newAccountPage.fillInformation(accountName);
    newAccountPage.saveAccount();

    accountNamesToDelete.add(accountName);

    // add domain to account
    String domain = dataGenerator.generateString().concat(".com");
    accountPage.findAvailableMapping(domain);
    accountPage.selectNewMapping(domain);

    // search account by domain
    accountsSearchPage.navigate();
    accountsSearchPage.searchFor(domain);

    boolean accountResult = accountsSearchPage.verifyAccountHasRow(accountName);
    assertTrue(accountResult, "Account was not found after searching for it by new domain mapping");
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-39618", chromeIssue = "RA-39617")
  public void testAccountSearchByAccountNameMapping() {
    accountsSearchPage.navigate();
    accountsSearchPage.addItem();

    // create account
    String accountName = dataGenerator.generateName();
    newAccountPage.fillInformation(accountName);
    newAccountPage.saveAccount();

    accountNamesToDelete.add(accountName);

    // add account name
    String name = dataGenerator.generateString();
    accountPage.gotoCompanyNames();
    accountPage.findAvailableMapping(name);
    accountPage.selectNewMapping(name);

    // search for account by new name
    accountsSearchPage.navigate();
    accountsSearchPage.searchFor(name);

    boolean accountResult = accountsSearchPage.verifyAccountHasRow(accountName);
    assertTrue(accountResult, "Account was not found after searching for it by new name mapping");
  }

}
