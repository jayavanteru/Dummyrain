package admin.searches.Session;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import logs.Log;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Session {

    DataGenerator gen = new DataGenerator();

    protected String sessionBaseName = "automationbulk" + gen.generateString(3);
    protected AdminApp adminApp;
    protected String sessionName = sessionBaseName + gen.generateString(5);
    protected List<String> sessionIds;
    protected int sessionCount = 5;

    //load test setup
    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        sessionIds = new ArrayList<>();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        for (int i = 0; i < sessionCount; ++i) {
            sessionIds.add(adminApp.createSession(sessionName));
            Utils.sleep(1500);
        }

    }

    @AfterClass
    public void endTest() {
        for (String session : sessionIds) {
            adminApp.deleteSession(session);
        }
        PageConfiguration.getPage().quit();
    }

    public void assertAllSessionsShowUp() {
        Log.info("waiting for the search, when the search is done there should be less than 50", getClass());
        Utils.waitForTrue(()->SessionSearchPage.getPage().getAllIds(".*").size() < 50);

        Set<String> allIds = SessionSearchPage.getPage().getAllIds(".*");
        Assert.assertEquals(allIds.size(), sessionIds.size(), "search results did not find the expected sessions");
        sessionIds.forEach(id -> Assert.assertTrue(allIds.contains(id), "id '" + id + "' was not found in searched list " + allIds.stream().reduce((a,b)-> a + " "+b+" ").get()));
    }

}
