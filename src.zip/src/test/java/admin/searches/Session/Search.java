package admin.searches.Session;

import apps.admin.adminHelpers.AdvancedSearch;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.List;

public class Search extends Session {
    private SessionSearchPage search = SessionSearchPage.getPage();
    
    @AfterMethod
    public void tearDown() {
        search.clickClear();
        search.search();
        search.waitForResults();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19850", firefoxIssue = "RA-20847")
    public void bulkSessionUpdateTest() {
        String status = "On Hold";

        search.navigate();
        Utils.sleep(500);
        search.searchFor(sessionName);
        assertAllSessionsShowUp();

        Utils.sleep(1000);
        search.bulkedit();
        AdminAttendeeBulkEditPage.getPage().bulkUpdateStatus(status);
        search.navigate();

        search.searchFor(sessionName);
        assertAllSessionsShowUp();

        Utils.waitForTrue(()->search.getStatuses().get(0).equals(status));
        List<String> statuses = search.getStatuses();
        statuses.forEach(name -> Assert.assertEquals(name, status, "Could not find the status"));
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-19565", chromeIssue = "RA-24109")
    public void basicSearch() {
        search.navigate();

        search.searchFor("");
        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");

        // Enter a value into the 'Search' field and press the 'Enter' key or the 'Search' button
        search.searchFor(sessionName);

        // Expected Result: A list of results are returned containing the value you searched for.
        Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when searching by session title");
        Assert.assertTrue(search.getResults().stream().allMatch(result -> StringUtils.containsIgnoreCase(result.get("title"), sessionName)), "results should be filtered by the given criteria");
    }
    
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-24110", chromeIssue = "RA-24111")
    public void filterByStatus() {
        search.navigate();
        search.waitForPageLoad();
        
        search.clickClear();
        Utils.sleep(500);
        search.search();
        search.waitForResults();
        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");
        
        // Select a value from the 'Session Status' drop down (Accepted) and press the 'Enter' key or the 'Search' button
        search.filterByStatus("Accepted");

        // Expected Result: A list of results are returned filtered by the status
        Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when filtering by status");
        Assert.assertTrue(search.getResults().stream().allMatch(result -> StringUtils.containsIgnoreCase(result.get("status"), "Accepted")), "results should be filtered by the given status");
    }
    
    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-24112", chromeIssue = "RA-24113")
    public void clearFilters() {
        search.navigate();
        
        // Add search filters
        search.searchFor(sessionName);
        search.filterByStatus("Accepted");
        
        // Click the "Clear" button.
        search.clickClear();
        
        // Expected Result: All of the values you have entered are erased.
        Assert.assertTrue(search.isSearchFieldCleared(), "search field should have been cleared");
        Assert.assertTrue(search.isStatusFilterCleared(), "status selector should have been cleared");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-24114", chromeIssue = "RA-24115")
    public void AdvancedSessionSearchTests() {
        search.navigate();
        Utils.sleep(500);

        search.search();
        Assert.assertTrue(search.getAllIds(".*").size() > sessionCount, "there should be more results with no search parameter");

        search.toggleAdvancedSearch();
        //have to search for the same title 5 times to get all 5 created
        search.advSearch("Title","equal to", sessionName);
        for (int i = 1; i < sessionCount; ++i) {
            search.addValueAdvSearch(sessionName);
        }
        search.search();
        assertAllSessionsShowUp();
        search.toggleAdvancedSearch();
        search.search();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-24116", chromeIssue = "RA-24117")
    public void compoundAdvancedSearchTest() {
        search.navigate();

        search.searchFor("");
        int resultsCount = search.getResultsNumber();

        // Click on the 'Advanced Search' link
        search.toggleAdvancedSearch();
        // Expected Result: A sub menu opens that allows for more search criteria.
        Assert.assertFalse(search.isAdvancedSearchCollapsed());
        
        final String code = "2";

        // Click on the '+ ADD MORE CRITERIA' link. Enter a value in the last field (Chris) and press the 'Enter' key or the 'Search' button
        search.advSearch("Code", "contains", code);
        search.search();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the value you searched for.
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Click on the '+ ADD MORE CRITERIA' link. Choose the value 'Day' from the column drop down box.
        /*
          Expected Result:
            -The value is selected and two more fields appear.
            -The operator drop down is set to 'equal to'
            -The last field is a drop down because of the value selected in the first field.
         */
        // Choose a value from the list drop down field and press the 'Enter' key or the 'Search' button
        search.advSearch(new AdvancedSearch().withIndex(1).withFieldText("Day"));
        search.search();
        search.waitForResults();
        /*
          Expected Result:
            -The selected value is displayed below the drop down.
            -A list of results are returned containing the searched for values for 1 AND 2
         */
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' operator to "OR" and press the "Search" button
        search.selectAdvancedExpression("OR");
        search.search();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 OR 2
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        resultsCount = search.getResultsNumber();

        // Click on the '+ ADD MORE CRITERIA' link. Choose 'Length' for the field. Select the first option from the value list. Press "Search"
        search.advSearch(new AdvancedSearch().withIndex(2).withFieldText("Length"));
        search.search();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 OR 2 OR 3
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' drop down field to "Custom"
        search.selectAdvancedExpression("Custom");
        // Change the word "And" to "1 and (2 or 3)". Press the "Search" button
        search.inputCustomExpression("1 and (2 or 3)");
        search.search();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 and 2 OR 3.
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' drop down field to "Count"
        search.selectAdvancedExpression("Count");
        /*
            Expected Result
            - A new drop down with '=', "<", ">", '<=', and ">=" appears.
            - A new field for entering numeric values appears.
         */
        Assert.assertTrue(search.areCountOperatorsPresent());
        Assert.assertTrue(search.isCountInputFieldPresent());

        // Click the 'X' to the right hand side of one of the added criteria
        int criteriaCount = search.getAdvancedSearchCriteriaCount();
        search.removeAdvancedSearchCriteria(1);
        Assert.assertEquals(search.getAdvancedSearchCriteriaCount(), criteriaCount - 1);

        // Click the "Clear" button. Click the "Search" button
        search.clickClear();
        search.search();
        search.waitForResults();
        // Expected Result: All of the values you have entered are erased and a list of all sessions are returned.
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        Assert.assertEquals(search.getAdvancedSearchCriteriaCount(), 0);
    }
}
