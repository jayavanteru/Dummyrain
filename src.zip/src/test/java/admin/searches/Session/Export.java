package admin.searches.Session;

import apps.admin.adminPageObjects.content.SessionSearchPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import testHelp.Utils;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class Export extends Session {

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-26668", chromeIssue = "RA-19976")
    public void exportSessionSearchCSV() {
        SessionSearchPage search = SessionSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(sessionBaseName);
        Utils.sleep(500, "wait for the search");
        search.exportCSV();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("sessions.+csv\\z");
        List<Map<String, String>> CsvSessionList;
        CsvSessionList = file.getCsvMap();
        List<Map<String, String>> SessionList;
        SessionList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, CsvSessionList.size(), "The number of results are not the same. Expected " + results + " but instead got " + CsvSessionList.size());

        OpenFile.assertSameUK(SessionList, CsvSessionList);

    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-26670", chromeIssue = "RA-26669")
    public void exportSessionSearchXML() throws IOException, SAXException, ParserConfigurationException {
        SessionSearchPage search = SessionSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(sessionBaseName);
        Utils.sleep(500, "wait for the search");
        search.exportXML();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xmlResults = file.parseXML("session");
        List<Map<String, String>> SessionList;
        SessionList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xmlResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xmlResults.size());

        OpenFile.assertSameLK(SessionList, xmlResults);

    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-26672", chromeIssue = "RA-26671")
    public void exportSessionSearchXLSX() throws IOException, SAXException, ParserConfigurationException {
        SessionSearchPage search = SessionSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(sessionBaseName);
        Utils.sleep(500, "wait for the search");
        search.exportXLSX();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xlsxResults = file.parseXLSX();
        List<Map<String, String>> SessionList;
        SessionList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xlsxResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xlsxResults.size());

        OpenFile.assertSameUK(SessionList, xlsxResults);

    }

}
