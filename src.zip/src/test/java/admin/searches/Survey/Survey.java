package admin.searches.Survey;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import configuration.PropertyReader;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.List;

public class Survey
{
  DataGenerator gen = new DataGenerator();
  
  protected AdminApp adminApp;
  protected String surveyName = gen.generateName();
  protected List<String> surveyIds;
  
  @BeforeClass
  public void setupTest() throws Exception
  {
    PropertyReader.instance().setProperty("enableNetworkLogging", true);
    
    adminApp = new AdminApp();
    surveyIds = new ArrayList<>();
    AdminLoginPage.getPage().login();

    OrgEventData.getPage().setOrgAndEvent();
    
    surveyIds.add(adminApp.createSurvey(surveyName));
  }
  
  @AfterClass
  public void endTest()
  {
    for (String surveyId : surveyIds)
    {
      adminApp.deleteSurvey(surveyId);
    }
    PageConfiguration.getPage().quit();
  }
}
