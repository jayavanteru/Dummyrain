package admin.searches.Survey;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.libraries.CreateSurveyPage;
import apps.admin.adminPageObjects.libraries.SurveysSearchPage;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class Search extends Survey
{
  private SurveysSearchPage search = SurveysSearchPage.getPage();
  
  @AfterMethod
  public  void tearDown()
  {
    search.search(StringUtils.EMPTY);
    search.waitForResults();
  }
  
  @Test(groups = ReportingInfo.DATATRON)
  @ReportingInfo(chromeIssue = "RA-19568", firefoxIssue = "RA-33953")
  public void basicSearch()
  {
    search.navigate();
    
    search.search(StringUtils.EMPTY);
    search.waitForResults();
    int count = search.getResultsNumber();
    Assert.assertTrue(count > 0, "there should be results with no search parameter");
    
    // Enter a value into the 'Search' field and press the 'Enter' key or the 'Search' button
    search.search(surveyName);
    search.waitForResults();
    
    Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when searching by survey name");
    Assert.assertTrue(search.getResults().stream().allMatch(result -> StringUtils.containsIgnoreCase(result.get("name"), surveyName)), "results should be filtered by the given criteria");
    
    search.editItem();
    CreateSurveyPage.getPage().waitForPageLoad();
    Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("survey.do?id=" + surveyIds.get(0)));
    CreateSurveyPage.getPage().cancel();
    
    search.waitForPageLoad();
    
    search.copyItem();
    CreateSurveyPage.getPage().waitForPageLoad();
    Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("survey.do?id=" + surveyIds.get(0)));
    CreateSurveyPage.getPage().cancel();
    
    search.waitForPageLoad();
    
    search.deleteFirstRow();
    
    search.search(StringUtils.EMPTY);
    search.waitForResults();
    count = search.getResultsNumber();
    
    search.setPublished("No");
    Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when limiting results to published/not published");
  }
}
