package admin.searches.SaveSearch;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.EditColumnsModal;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.SaveSearchPage;
import apps.admin.adminPageObjects.analysis.reporting.ReportingPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.pageObjects.BaseSearchPage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;


public class SaveSearch {

    private DataGenerator generator = new DataGenerator();
    private SaveSearchPage saveSearch = SaveSearchPage.getPage();
    private EditColumnsModal editcolumns = EditColumnsModal.getPage();

    @BeforeClass
    public void login() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-29453", chromeIssue = "RA-29454")
    //description = "creates, uses and deletes attendee saved search record")
    public void attendeeSavedSearch() {
        AttendeeSearchPage search = AttendeeSearchPage.getPage();

        String NEW_SAVED_SEARCH_NAME = generator.generateName();
        saveSearch.navigateToAttendeeSearch();

        search.searchFor("");
        int initialResultCount = search.getResultsNumber();
        Log.info("Unfiltered result count: " + initialResultCount, getClass());

        search.toggleAdvancedSearch();
        search.advSearch("First Name", "Christopher");
        search.clickSearchButton();

        int filteredSearchCount = search.getResultsNumber();

        Log.info("Filtered search result count: " + filteredSearchCount, getClass());

        saveSearch.openSaveSearchModal();
        saveSearch.enterSaveSearchName(NEW_SAVED_SEARCH_NAME);
        saveSearch.togglePrivateSearchCheckbox();
        saveSearch.assertPrivateSearchCheckboxIsUnchecked();
        saveSearch.togglePrivateSearchCheckbox();
        saveSearch.assertPrivateSearchCheckboxIsChecked();
        saveSearch.confirmModal();

        search.clickClear();
        search.searchFor("");
        Assert.assertNotEquals(filteredSearchCount, search.getResultsNumber(), "Back to unfiltered results");

        // run the new saved search
        saveSearch.openMySavedSearchList();
        saveSearch.selectMyRecentSavedSearch(NEW_SAVED_SEARCH_NAME);

        Assert.assertEquals(filteredSearchCount,  search.getResultsNumber(), "Filtered results displayed: " + filteredSearchCount);

        // delete the saved search
        saveSearch.openMySavedSearchList();
        saveSearch.clickOnMySavedSearchRowDeleteIcon(NEW_SAVED_SEARCH_NAME);
        saveSearch.deleteMyRecentSavedSearch();
        saveSearch.assertSavedSearchDeleted(NEW_SAVED_SEARCH_NAME);
        saveSearch.closeSaveSearchModal();

    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-29459", chromeIssue = "RA-29460")
    //description = "creates, uses and deletes exhibitor saved search record")
    public void exhibotorSavedSearch() {
        ExhibitorSearchPage search = ExhibitorSearchPage.getPage();
        String NEW_SAVED_SEARCH_NAME = generator.generateName();

        saveSearch.navigateToExhibitorSearch();
        editcolumns.resetColumns();
        search.search();
        Utils.sleep(3000);
        String searchString = search.getResults().get(1).get("name");
        runSaveSearchTests(search, NEW_SAVED_SEARCH_NAME, searchString);

    }


    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-29457", chromeIssue = "RA-29458")
    //description = "creates, uses and deletes meetings saved search record")
    public void meetingsSavedSearch() {
        String NEW_SAVED_SEARCH_NAME = generator.generateName();

        saveSearch.navigateToMeetingsSearch();

        MeetingsSearchPage search = MeetingsSearchPage.getPage();
        Utils.sleep(3000);
        String searchString = search.getResults().get(1).get("code");
        runSaveSearchTests(search, NEW_SAVED_SEARCH_NAME, searchString);

    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-29455", chromeIssue = "RA-29456")
    //description = "creates, uses and deletes sessions saved search record")
    public void sessionsSavedSearch() {

        SessionSearchPage search = SessionSearchPage.getPage();

        String NEW_SAVED_SEARCH_NAME = generator.generateName();

        saveSearch.navigateToSessionsSearch();
        Utils.sleep(3000);
        String searchString = search.getResults().get(1).get("code");
        runSaveSearchTests(search, NEW_SAVED_SEARCH_NAME, searchString);

    }

    private void runSaveSearchTests(BaseSearchPage search, String savedSearchName, String searchString ) {

        search.searchFor("");

        int initialResultCount = search.getResultsNumber();

        Log.info("Unfiltered result count: " + initialResultCount, getClass());

        search.searchFor(searchString);

        int filteredSearchCount = search.getResultsNumber();

        Log.info("Filtered search result count: " + filteredSearchCount, getClass());

        saveSearch.openSaveSearchModal();
        saveSearch.enterSaveSearchName(savedSearchName);
        saveSearch.togglePrivateSearchCheckbox();
        saveSearch.assertPrivateSearchCheckboxIsUnchecked();
        saveSearch.togglePrivateSearchCheckbox();
        saveSearch.assertPrivateSearchCheckboxIsChecked();
        saveSearch.confirmModal();

        search.searchFor("");
        Assert.assertNotEquals(search.getResultsNumber(), filteredSearchCount, "Back to unfiltered results");

        // run the new saved search
        saveSearch.openMySavedSearchList();
        saveSearch.selectMyRecentSavedSearch(savedSearchName);

        Assert.assertEquals(search.getResultsNumber(), filteredSearchCount, "Filtered results displayed: " + filteredSearchCount);

        // delete the saved search
        saveSearch.openMySavedSearchList();
        saveSearch.clickOnMySavedSearchRowDeleteIcon(savedSearchName);
        saveSearch.deleteMyRecentSavedSearch();
        saveSearch.assertSavedSearchDeleted(savedSearchName);
        saveSearch.closeSaveSearchModal();
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

}
