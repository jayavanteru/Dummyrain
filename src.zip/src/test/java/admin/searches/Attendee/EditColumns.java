package admin.searches.Attendee;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.EditColumnsModal;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class EditColumns {
    private AttendeeSearchPage search = AttendeeSearchPage.getPage();
    private PropertyReader data = PropertyReader.instance();
    private EditColumnsModal columnsModal = EditColumnsModal.getPage();

    @BeforeClass
    public void Setup(){
        AdminLoginPage.getPage().login();
    }
    @BeforeMethod
     public void SetOrg(){
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "christestr");
    }


    @AfterClass
    public void endTest() {
    PageConfiguration.getPage().quit();
    }

    @Test(dataProvider = "AddSearchPages",groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-20170", chromeIssue = "RA-33524")
    public void addColumn(String URL, String columnname) {
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);

        search.search();
        columnsModal.resetColumns();
        List<String> keysBeforeAddingColumn = search.getColumns();
        Assert.assertFalse(keysBeforeAddingColumn.contains(columnname.toLowerCase()),columnname +" already exists");

        columnsModal.addColumn(columnname);

        List<String> keysAfterAddingColumn = search.getColumns();
        keysAfterAddingColumn.forEach((k)-> Log.info("Found column "+k+" (keysAfterAddingColumn)",getClass()));
        Assert.assertTrue(keysAfterAddingColumn.size() > keysBeforeAddingColumn.size(),"Additional column was not added");
        Assert.assertTrue(keysAfterAddingColumn.contains(columnname.toLowerCase()),columnname +" does not exist");

        AdminLoginPage.getPage().logout();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "christestr");
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);
        search.search();
        List<String> keysAfterLogoutLogin = search.getColumns();
        keysAfterLogoutLogin.forEach((k)-> Log.info("Found column "+k+" (keysAfterLogoutLogin)",getClass()));
        Assert.assertTrue(keysAfterLogoutLogin.size() > keysBeforeAddingColumn.size(),"Additional column was not added");
        Assert.assertTrue(keysAfterLogoutLogin.contains(columnname.toLowerCase()),columnname +" does not exist");
        checkReset(keysBeforeAddingColumn);
       }

    @Test(dataProvider = "MoveSearchPages",groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-20173", chromeIssue = "RA-45685")
    public void moveColumn(String URL, String columnname)
    {
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);

        search.search();
        columnsModal.resetColumns();
        List<String> keys = search.getColumns();
        Assert.assertTrue(keys.contains(columnname.toLowerCase()),columnname +" not found. Cannot move column.");

        List<String> columnNames = columnsModal.getColumnNames();
        int currentPosition = columnNames.indexOf(columnname);
        columnsModal.moveColumnDownOne(currentPosition);

        List<String> keys2 = search.getColumns();
        keys2.forEach((k)-> Log.info("Found column "+k,getClass()));
        Assert.assertEquals(keys2.size(), keys.size());//verify that we still have the same # of columns
        Assert.assertEquals(keys.get(0),keys2.get(1));//verify that the first column has been moved to the 2nd position
        columnsModal.resetColumns();
       }

    @Test(dataProvider = "DeleteSearchPages",groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-20171", chromeIssue = "RA-20172")
    public void deleteColumn(String URL, String columnname) {
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);

        //1) Test deleting the column in Event 1
        search.search();
        columnsModal.resetColumns();
        List<String> keysBeforeDeleteOnEvent1 = search.getColumns();
        Assert.assertTrue(keysBeforeDeleteOnEvent1.contains(columnname.toLowerCase()),columnname +" is not on the page");
        columnsModal.deleteColumn(columnname);
        List<String> keysAfterDeleteOnEvent1 = search.getColumns();
        keysAfterDeleteOnEvent1.forEach((k)-> Log.info("Found column "+k+" (keysAfterDeleteOnEvent1)",getClass()));
        Assert.assertTrue(keysAfterDeleteOnEvent1.size() < keysBeforeDeleteOnEvent1.size(),"column was not removed");
        Assert.assertFalse(keysAfterDeleteOnEvent1.contains(columnname.toLowerCase()),columnname +" column was not removed");

        //2) Test deleting the column in Event 2
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);
        search.search();
        columnsModal.resetColumns();
        List<String> keysBeforeDeleteOnEvent2 = search.getColumns();
        Assert.assertTrue(keysBeforeDeleteOnEvent2.contains(columnname.toLowerCase()),columnname +" is not on the page");
        columnsModal.deleteColumn(columnname);
        List<String> keysAfterDeleteOnEvent2 = search.getColumns();
        keysAfterDeleteOnEvent2.forEach((k)-> Log.info("Found column "+k+" (keysAfterDeleteOnEvent2)",getClass()));
        Assert.assertTrue(keysAfterDeleteOnEvent2.size() < keysBeforeDeleteOnEvent2.size(),"column was not removed");
        Assert.assertFalse(keysAfterDeleteOnEvent2.contains(columnname.toLowerCase()),columnname +" column was not removed");

        //3) Verify that columns stored for the user in each event are stored independently
        columnsModal.resetColumns();//reset the columns on Event 2
        List<String> keysAfterResetOnEvent2 = search.getColumns();
        keysAfterResetOnEvent2.forEach((k)-> Log.info("Found column "+k+" (keysAfterResetOnEvent2)",getClass()));
        Assert.assertTrue(keysAfterResetOnEvent2.contains(columnname.toLowerCase()),columnname +" is not on the page");

        OrgEventData.getPage().setOrgAndEvent("RainFocus", "christestr");//switch back to Event 1
        PageConfiguration.getPage().navigateTo(data.getProperty("adminUrl")+URL);
        search.search();
        List<String> keysAfterSwitchingBackToEvent1 = search.getColumns();
        keysAfterSwitchingBackToEvent1.forEach((k)-> Log.info("Found column "+k+" (keysAfterSwitchingBackToEvent1)",getClass()));
        Assert.assertEquals(keysAfterSwitchingBackToEvent1.size(), keysAfterDeleteOnEvent1.size(),"resetting the columns on event2 should not have affected the columns on event1");
        Assert.assertFalse(keysAfterSwitchingBackToEvent1.contains(columnname.toLowerCase()),columnname +"resetting the columns on event2 should not have affected the columns on event1");
        checkReset(keysBeforeDeleteOnEvent1);//Reset the columns on Event 1
    }
    private void checkReset(Collection<String> originalColumns){
        columnsModal.resetColumns();
        Assert.assertEquals(search.getColumns(),originalColumns,"columns did not reset correctly");
    }

    @DataProvider(name = "DeleteSearchPages")
    public Object[][] EditColumnSearchPages () {
        return new Object[][]{{AttendeeSearchPage.ATTENDEE_SEARCH_URL, "First Name"}, {"/rain.focus#sessions.do", "Code"}, {"/rain.focus#meetings.do", "Code"}, {"/rain.focus#exhibitors.do", "Status"}};
    }

    @DataProvider(name = "MoveSearchPages")
    public Object[][] MoveColumnSearchPages () {
        return new Object[][]{{AttendeeSearchPage.ATTENDEE_SEARCH_URL,"First Name"},{"/rain.focus#sessions.do","Code"},{"/rain.focus#meetings.do","Code"},{"/rain.focus#exhibitors.do","Name"}};
    }
    
    @DataProvider(name = "AddSearchPages")
    public Object[][] addColumnSearchPages () {
        return new Object[][]{{AttendeeSearchPage.ATTENDEE_SEARCH_URL,"Phone"},{"/rain.focus#sessions.do","Speakers"},{"/rain.focus#meetings.do","Length"},{"/rain.focus#exhibitors.do","City"}};
    }
}
