package admin.searches.Attendee;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.NewWorkflowPage;
import apps.admin.adminPageObjects.workflows.WorkflowEditBuilderPage;
import apps.admin.adminPageObjects.workflows.WorkflowStepEditor;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.workflows.workflowsPageObjects.WorkflowContactInfoPage;
import apps.workflows.workflowsPageObjects.WorkflowPurchasePage;
import logs.Log;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertTrue;

public class AttendeeStatus {

  private DataGenerator dataGenerator;

  private List<String> packageNamesToDelete;
  private List<String> attendeeNamesToDelete;
  private List<String> workflowNamesToDelete;

  @BeforeClass
  public void setupTest() {
    dataGenerator = new DataGenerator();
    packageNamesToDelete = new ArrayList<>();
    attendeeNamesToDelete = new ArrayList<>();
    workflowNamesToDelete = new ArrayList<>();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void tearDown() {
    // delete attendees
    try {
      AttendeeSearchPage.getPage().navigate();

      for(String attendeeName : attendeeNamesToDelete) {
        AttendeeSearchPage.getPage().searchFor(attendeeName);
        AttendeeSearchPage.getPage().deleteAttendeeByName(attendeeName);
      }
    }
    catch (Exception e) {
      Log.error("Error cleaning up attendees from the AttendeeStatus tests", AttendeeStatus.class);
    }

    // delete packages
    try {
      PackageSearchPage.getPage().navigate();

      for(String packageName : packageNamesToDelete) {
        PackageSearchPage.getPage().searchPackage(packageName);
        PackageSearchPage.getPage().deletePackage(0);
      }
    }
    catch (Exception e) {
      Log.error("Error cleaning up packages from the AttendeeStatus tests", AttendeeStatus.class);
    }

    // delete workflows
    try {
      WorkflowsSearchPage.getPage().navigate();

      for(String workflowName : workflowNamesToDelete) {
        WorkflowsSearchPage.getPage().searchFor(workflowName);
        WorkflowsSearchPage.getPage().deleteWorkFlowByName(workflowName);
      }
    }
    catch (Exception e) {
      Log.error("Error cleaning up workflows from the AttendeeStatus tests", AttendeeStatus.class);
    }

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-39719", chromeIssue = "RA-39720")
  public void testAttendeeWaitlistStatusBubble() {
    // create waitlist package
    NewPackagePage.getPage().navigate();
    String packageName = dataGenerator.generateName();
    String code = dataGenerator.generateName();
    NewPackagePage.getPage().createWaitlistPackage(packageName, code, "Regression waitlist package", 0, 1, 1, 0, true, false, 0, true);
    packageNamesToDelete.add(packageName);

    // create attendee
    String firstName = dataGenerator.generateName();
    String lastName = dataGenerator.generateName();
    String email = dataGenerator.generateEmail();

    AdminApp adminApp = new AdminApp();
    String attendeeId = adminApp.createAttendee(email, firstName, lastName);

    String fullName = firstName + " " + lastName;
    attendeeNamesToDelete.add(fullName);

    // create registration workflow
    String workflowName = dataGenerator.generateName();
    String workflowUri = dataGenerator.generateString();
    workflowNamesToDelete.add(workflowName);

    WorkflowsSearchPage.getPage().navigate();
    WorkflowsSearchPage.getPage().clickAddButton();
    WorkflowsSearchPage.getPage().clickNewTemplate("Registration");
    NewWorkflowPage.getPage().setTemplateName(workflowName);
    NewWorkflowPage.getPage().setTemplateURI(workflowUri);
    NewWorkflowPage.getPage().clickModalSave();

    // contact info page
    WorkflowEditBuilderPage.getPage().openStepEditor("Contact Info Page");
    WorkflowStepEditor.getPage().openTab("form");
    WorkflowStepEditor.getPage().selectForm("Attendee Profile Form");
    WorkflowStepEditor.getPage().saveStep();

    // order page
    WorkflowEditBuilderPage.getPage().openStepEditor("Orders and Payment Page");
    WorkflowStepEditor.getPage().openTab("packages");
    WorkflowStepEditor.getPage().addPackage(packageName);
    WorkflowStepEditor.getPage().saveStep();

    // publish workflow
    WorkflowEditBuilderPage.getPage().publishWorkflow();

    // spoof into workflow
    EditAttendeePage.getPage().navigate(attendeeId);
    EditAttendeePage.getPage().spoofTo(workflowUri);

    // navigate past contact info form
    WorkflowContactInfoPage.getPage().cookiesButtonHandle();
    WorkflowContactInfoPage.getPage().click_continue();

    // add to waitlist
    WorkflowPurchasePage.getPage().joinWaitlist(packageName);

    // switch back to original tab
    PageConfiguration.getPage().switchToTab(0);

    // check attendee status
    AttendeeSearchPage.getPage().navigate();
    AttendeeSearchPage.getPage().searchFor(firstName);

    assertTrue(AttendeeSearchPage.getPage().attendeeStatusIs(firstName, "Waitlisted"), "Attendee's status was not 'Waitlisted'");
  }

}
