package admin.searches.Attendee;

import apps.admin.adminHelpers.AdvancedSearch;
import apps.admin.adminPageObjects.EditColumnsModal;
import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Search extends Attendee {
    private AttendeeSearchPage search = AttendeeSearchPage.getPage();

    @AfterMethod
    public void tearDown() {
        search.clickClear();
        search.clickSearchButton();
        search.waitForResults();
    }

    @Test(groups = {"prodTest", ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26685", chromeIssue = "RA-21295")
    //description = "creates 5 attendees, bulk updates the company name, asserts it updated on all of them")
    public void bulkAttendeeUpdateTest() {
        search.navigate();

        Utils.sleep(500);
        search.searchFor(attendeeName);
        assertAllAttendeesShowUp();

        Utils.sleep(1000);
        search.bulkedit();
        AdminAttendeeBulkEditPage.getPage().bulkUpdateCompanyName(companyName);
        search.navigate();
        Utils.sleep(500);
        search.searchFor(attendeeName);
        assertAllAttendeesShowUp();

        Utils.waitForTrue(()->search.getCompanyNames().get(0).equals(companyName));
        List<String> companyNames = search.getCompanyNames();
        companyNames.forEach(name -> Assert.assertEquals(name, companyName, "Could not find the company name"));
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24048", chromeIssue = "RA-24049")
    public void basicSearch() {
        search.navigate();

        search.searchFor("");
        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");

        // Enter a value (Chris) into the 'Search' field and press the 'Enter' key or the 'Search' button
        search.searchFor(attendeeName);

        // Expected Result: A list of results are returned containing the value you searched for.
        Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when searching by attendee name");
        Assert.assertTrue(search.getResults().stream().allMatch(result -> StringUtils.containsIgnoreCase(result.get("first name"), attendeeName) || StringUtils.containsIgnoreCase(result.get("last name"), attendeeName)), "results should be filtered by the given criteria");
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24050", chromeIssue = "RA-24051")
    public void filterByRegCode() {
        search.navigate();

        search.searchFor("");
        Assert.assertTrue(search.getSearchCount() > 0, "there should be results with no search parameter");

        // Enter a value into the 'Reg Code' field (105) and press the 'Enter' key or the 'Search' button
        search.filterByRegCode("105");

        // Expected Result: A list of results (none) are returned that contain both the original value you searched for and the Reg Code value.
        Assert.assertFalse(search.isAnySearchResults());
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24052", chromeIssue = "RA-24053")
    public void filterByPackage() {
        search.navigate();

        EditColumnsModal.getPage().resetColumns();
        EditColumnsModal.getPage().addColumn("Package Name");
        
        search.waitForResults();

        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");
        Assert.assertTrue(count > 1, "there should be more than 1 result with no search parameters");

        // Select a value from the 'Package' drop down and press the 'Search' button
        final String packageName = "2 Day Conference Pass";
        search.selectPackageDropdownItem(packageName);

        // Expected Result: A list of results are returned that contain the Package value.
        Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when searching by package");

        List<String> packages = search.getResults().stream().map(result -> result.get("package name")).collect(Collectors.toList());
        Assert.assertTrue(packages.stream().allMatch(result -> StringUtils.containsIgnoreCase(result, packageName)), "results should be filtered by the given criteria");

        EditColumnsModal.getPage().resetColumns();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24054", chromeIssue = "RA-24055")
    public void filterByRegistered() {
        search.navigate();

        search.searchFor("");
        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");

        // Select a value from the 'Registered?' drop down and press the 'Search' button
        search.selectRegistered(false);

        // Expected Result: A list of results are returned that contain the 'Registered?' value.
        Assert.assertTrue(search.getResultsNumber() < count, "there should be fewer results when searching by registered");

        List<String> statuses = search.getResults().stream().map(result -> result.get("status").toLowerCase()).collect(Collectors.toList());
        Assert.assertTrue(statuses.stream().noneMatch(status -> Arrays.asList("registered").contains(status)), "results should be filtered by the given criteria");
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24056", chromeIssue = "RA-24057")
    public void filterByPaidInFull() {
        search.navigate();

        search.searchFor("");
        int count = search.getResultsNumber();
        Assert.assertTrue(count > 0, "there should be results with no search parameter");

        // Select a value from the 'Paid in Full?' drop down and press the 'Search' button
        search.selectPaidInFull(true);

        // Expected Result: A list of results are returned that contain the 'Paid in Full?' value.
        int paid = search.getResultsNumber();
        Assert.assertTrue(paid < count, "there should be fewer results when searching by paid-in-full");

        search.selectPaidInFull(false);
        int notPaid = search.getResultsNumber();
        Assert.assertTrue(notPaid < count, "there should be fewer results when searching by paid-in-full");
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-24058", chromeIssue = "RA-24059")
    public void testClearingFilters() {
        search.navigate();

        search.filterByRegCode("105");
        search.selectPackageDropdownItem("2 Day Conference Pass");
        search.selectRegistered(true);
        search.selectPaidInFull(true);
        // Click the "Clear" button.
        search.clickClear();

        // Expected Result: All of the values you have entered are erased.
        Assert.assertFalse(search.isSearchFieldFiltered());
        Assert.assertFalse(search.isRegCodeFiltered());
        Assert.assertFalse(search.isPackageSelected());
        Assert.assertFalse(search.isRegisteredSelected());
        Assert.assertFalse(search.isPaidInFullSelected());
    }

    @Test(groups = {"prodTest", ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-26687", chromeIssue = "RA-26686")
    public void AdvancedAttendeeSearchTests() {
        search.navigate();

        //check before the filter
        search.searchFor("");
        Assert.assertTrue(search.getSearchCount() > attendeeCount, "there should be more results with no search parameter");

        search.toggleAdvancedSearch();
        search.advSearch("First Name", attendeeName);
        search.clickSearchButton();
        Utils.sleep(500, "wait for the search");
        assertAllAttendeesShowUp();
        search.toggleAdvancedSearch();
        //click search to save the toggled search
        search.clickSearchButton();
    }

    @Test(groups = {ReportingInfo.DATATRON})
    @ReportingInfo(firefoxIssue = "RA-19564", chromeIssue = "RA-24020")
    public void compoundAdvancedSearchTest() {
        search.navigate();

        search.searchFor("");
        int resultsCount = search.getResultsNumber();

        // Click on the 'Advanced Search' link
        search.toggleAdvancedSearch();
        // Expected Result: A sub menu opens that allows for more search criteria.
        Assert.assertFalse(search.isAdvancedSearchCollapsed());

        // Click on the '+ ADD MORE CRITERIA' link. Enter a value in the last field (Chris) and press the 'Enter' key or the 'Search' button
        search.advSearch("First Name", attendeeName);
        search.clickSearchButton();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the value you searched for.
        Assert.assertTrue(search.getResults().stream().allMatch(result -> StringUtils.equalsIgnoreCase(result.get("first name"), attendeeName)));
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Click on the '+ ADD MORE CRITERIA' link. Choose the value 'Reg Code Category' from the column drop down box.
        search.advSearch(new AdvancedSearch().withIndex(1).withFieldText("Regcode Category").withSearchFor("Exhibitors"));
        /*
          Expected Result:
            -The value is selected and two more fields appear.
            -The operator drop down is set to 'equal to'
            -The last field is a drop down because of the value selected in the first field.
         */
        search.clickSearchButton();
        search.waitForResults();
        /*
          Expected Result:
            -The selected value is displayed below the drop down.
            -A list of results are returned containing the searched for values for 1 AND 2
         */
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' operator to "OR" and press the "Search" button
        search.selectAdvancedExpression("OR");
        search.clickSearchButton();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 OR 2
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        resultsCount = search.getResultsNumber();

        // Click on the '+ ADD MORE CRITERIA' link. Choose 'Last Name' contains 'r'. Press "Search"
        search.advSearch(new AdvancedSearch().withIndex(2).withFieldText("Last Name").withOperator("contains").withSearchFor("Test"));
        search.clickSearchButton();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 OR 2 OR 3
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' drop down field to "Custom"
        search.selectAdvancedExpression("Custom");
        // Change the word "And" to "1 and (2 or 3)". Press the "Search" button
        search.inputCustomExpression("1 and (2 or 3)");
        search.clickSearchButton();
        search.waitForResults();
        // Expected Result: A list of results are returned containing the searched for values for 1 and 2 OR 3.
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() < resultsCount);
        resultsCount = search.getResultsNumber();

        // Change the 'Advanced Expression' drop down field to "Count"
        search.selectAdvancedExpression("Count");
        /*
            Expected Result
            - A new drop down with '=', "<", ">", '<=', and ">=" appears.
            - A new field for entering numeric values appears.
         */
        Assert.assertTrue(search.areCountOperatorsPresent());
        Assert.assertTrue(search.isCountInputFieldPresent());

        // Click the 'X' to the right hand side of one of the added criteria
        int criteriaCount = search.getAdvancedSearchCriteriaCount();
        search.removeAdvancedSearchCriteria(1);
        Assert.assertEquals(search.getAdvancedSearchCriteriaCount(), criteriaCount - 1);

        // Click the "Clear" button. Click the "Search" button
        search.clickClear();
        search.clickSearchButton();
        search.waitForResults();
        // Expected Result: All of the values you have entered are erased and a list of all attendees are returned.
        Assert.assertTrue(!search.isAnySearchResults() || search.getResultsNumber() > resultsCount);
        Assert.assertEquals(search.getAdvancedSearchCriteriaCount(), 0);
    }
}
