package admin.searches.Attendee;


import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class PaidUnpaidEvents {

    private SoftAssert softAssert;



    @BeforeClass
    public void setUp(){

        softAssert = new SoftAssert();
        AdminLoginPage.getPage().login();
        AttendeeSearchPage.getPage().navigate();
    }

    @Test(groups = {ReportingInfo.TVA})
    @ReportingInfo(firefoxIssue = "RA-37213", chromeIssue = "RA-37212")
    public void unPaidEvent(){

        OrgEventData.getPage().setOrgAndEvent("IBM", "Tiers Template 1");
        AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
        softAssert.assertTrue(attendeeSearchPage.isRegisteredVisible());
        softAssert.assertFalse(attendeeSearchPage.isPaidInFullVisible());
        softAssert.assertAll();

    }


    @Test(groups = {ReportingInfo.TVA})
    @ReportingInfo(firefoxIssue = "RA-37216", chromeIssue = "RA-37215")
    public void paidEvent(){
        OrgEventData.getPage().setOrgAndEvent("IBM", "Think 2019");
        AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
        softAssert.assertTrue(attendeeSearchPage.isRegisteredVisible());
        softAssert.assertTrue(attendeeSearchPage.isPaidInFullVisible());
        softAssert.assertTrue(attendeeSearchPage.isPackagesVisible());
        softAssert.assertTrue(attendeeSearchPage.isRegCodeVisible());
        softAssert.assertAll();

    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

}




