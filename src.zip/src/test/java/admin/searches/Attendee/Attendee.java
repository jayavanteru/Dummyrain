package admin.searches.Attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public class Attendee {
    DataGenerator gen = new DataGenerator();

    protected AdminApp adminApp;
    protected String companyName = gen.generateString(5);
    protected String attendeeName = gen.generateString();
    protected List<String> attendeeIds;
    protected int attendeeCount = 5;
    protected Pattern pattern;

    //load test setup
    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();
        attendeeIds = new ArrayList<>();
        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();
        for (int i = 0; i < attendeeCount; ++i) {
            attendeeIds.add(adminApp.createAttendeeWithName(attendeeName));
            Utils.sleep(1500);
        }

    }

    @AfterClass
    public void endTest() {
        for (String attendee : attendeeIds) {
            adminApp.deleteAttendee(attendee);
        }
        PageConfiguration.getPage().quit();
    }

    public void assertAllAttendeesShowUp() {
        Set<String> allIds = AttendeeSearchPage.getPage().getAllIds();
        Assert.assertEquals(allIds.size(), attendeeIds.size(), "search results did not find the expected attendees");
        attendeeIds.forEach(id -> Assert.assertTrue(allIds.contains(id), "id '" + id + "' was not found in searched list " + allIds.stream().reduce((a,b)-> a + " "+b+" ").get()));
    }

}
