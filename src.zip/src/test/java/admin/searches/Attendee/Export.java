package admin.searches.Attendee;

import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.files.OpenFile;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import testHelp.Utils;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Export extends Attendee {

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26665", chromeIssue = "RA-21297")
    public void exportAttendeeSearchCSV() {
        AttendeeSearchPage search = AttendeeSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(attendeeName);
        search.exportcsv();
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("attendees.+csv\\z");
        List<Map<String, String>> CSVList = file.getCsvMap();
        List<Map<String, String>> attendeeList = search.getResults();
        search.clickActions();
        int results = search.getResultsNumber();
        int csvSize = CSVList.size();
        Assert.assertEquals(results, csvSize, "The number of results are not the same. Expected " + results + " but instead got " + CSVList.size());

        OpenFile.assertSameUK(attendeeList, CSVList);

    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26666", chromeIssue = "RA-21299")
    public void exportAttendeeSearchXML() throws IOException, SAXException, ParserConfigurationException {
        AttendeeSearchPage search = AttendeeSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(attendeeName);
        Utils.sleep(500, "wait for the search");
        search.exportXML();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFileMatchingPattern("attendees_.*\\.xml");
        List<Map<String, String>> xmlResults = file.parseXML("attendee");
        List<Map<String, String>> AttendeeList;
        AttendeeList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xmlResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xmlResults.size());

        OpenFile.assertSameLK(AttendeeList, xmlResults);

    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26667", chromeIssue = "RA-21298")
    public void exportAttendeeSearchXLSX() throws IOException, SAXException, ParserConfigurationException {
        AttendeeSearchPage search = AttendeeSearchPage.getPage();
        search.navigate();
        search.clickClear();
        search.searchFor(attendeeName);
        Utils.sleep(500, "wait for the search");
        search.exportXLSX();
        Utils.sleep(500, "wait for export to finish");
        OpenFile file = OpenFile.OpenRecentDownloadedFile();
        List<Map<String, String>> xlsxResults = file.parseXLSX();
        List<Map<String, String>> AttendeeList;
        AttendeeList = search.getResults();
        int results = search.getResultsNumber();
        Assert.assertEquals(results, xlsxResults.size(), "The number of results are not the same. Expected " + results + " but instead got " + xlsxResults.size());

        OpenFile.assertSameUK(AttendeeList, xlsxResults);

    }

    private void assertLists(List<HashMap<String, String>> l1, List<HashMap<String, String>> l2) {
        Assert.assertEquals(l1.size(), l2.size(), "not the same number of records");
        Assert.assertEquals(l1.get(0).size(), l2.get(0).size(), "not the same number of columns");

        for (int i = 0; i < l1.size(); ++i) {
            for (String key : l1.get(i).keySet()) {
                Assert.assertEquals(l1.get(i).get(key), l2.get(i).get(key), "record did not match");
            }
        }
    }
}
