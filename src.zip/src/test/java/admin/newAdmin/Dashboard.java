package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.newAdmin.DashboardPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Dashboard
{
  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.loginAsAdminUser();
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39039", chromeIssue = "RA-32711")
  public void makeSurePageWorks()
  {
    DashboardPage dashboardPage = DashboardPage.getPage();
    dashboardPage.navigate();

    Assert.assertTrue(dashboardPage.makeSurePageWorks(), "Dashboard page in new admin is broke");
  }

}
