package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.analysis.ReportsListPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ReportingTab
{
  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.loginAsAdminUserAutoOrg();
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39194", chromeIssue = "RA-32713")
  public void testMakeSureReportingNavItemAndChildrenOnNewAdmin()
  {
    ReportsListPage reportsListPage = ReportsListPage.getPage();
    reportsListPage.navigateToReportList();
    reportsListPage.waitForPageLoad();

    Assert.assertTrue(reportsListPage.makeSureReportingNavItemAndChildrenOnNewAdmin(), "Reporting tab in new admin not working");
  }
}
