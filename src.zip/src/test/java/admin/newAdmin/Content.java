package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.newAdmin.content.SessionsPage;
import apps.admin.newAdmin.guide.ContentPage;
import apps.admin.newAdmin.guide.GeneralTabPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Content
{
  private SessionsPage sessionsPage;
  private NavigationBar navigationBar;

  @BeforeClass
  public void setup()
  {
    AdminApp adminApp = new AdminApp();
    adminApp.loginAsAdminUser();
    navigationBar = new NavigationBar();
    sessionsPage = SessionsPage.getPage();
    sessionsPage.navigate();
    if(!sessionsPage.hasResults()) {
      navigationBar.switchToOldAdmin();
      adminApp.createSession();
      navigationBar.switchToNewAdmin();
      Assert.assertTrue(EditUserPage.getPage().isSpoofedIn(), "did not spoof into the admin user");
    }
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-32710", chromeIssue = "RA-38510")
  public void goToContentTab() throws Exception
  {
    //this test has to have to the content nav item but that is controlled by the event status so we want to
    //make sure that it is always set to live
    GeneralTabPage generalTabPage = GeneralTabPage.getPage();
    generalTabPage.navigate();
    generalTabPage.changeRFEventStatus(GeneralTabPage.RF_SITE_LIVE_TEXT);

    ContentPage contentPage = ContentPage.getPage();
    contentPage.clickContentTab();
    contentPage.clickContentModuleLink();

    Assert.assertTrue(sessionsPage.existsSearchBox(), "Should have been able to get to sessions page");

    contentPage.navigate();
    contentPage.editSessionAttribute();

    DataGenerator generator = new DataGenerator();
    String optionName = "value option " + generator.generateString(7);
    contentPage.addNewOption(optionName);

    contentPage.editSessionAttribute();
    Assert.assertTrue(contentPage.doesNewOptionExist(optionName), "After adding a new session attribute value, value was NOT created");

    sessionsPage.navigate();
    sessionsPage.clickFirstSession();
    sessionsPage.submitSessionType(optionName);

    contentPage.navigate();
    contentPage.editSessionAttribute();
    Assert.assertTrue(contentPage.isOptionDisabled(optionName), "The created session attribute value should be disabled since it was applied to an existing session");

    //Now, lets go remove the option from the session so we can delete it
    sessionsPage.navigate();
    sessionsPage.clickFirstSession();
    sessionsPage.removeSessionType();

    contentPage.navigate();
    contentPage.editSessionAttribute();
    Assert.assertFalse(contentPage.isOptionDisabled(optionName), "After session attribute value was removed from session, the value should be ENABLED for deletion to occur");

    //Remove the option created during this test
    contentPage.removeOption(optionName);
    contentPage.editSessionAttribute();
    Assert.assertFalse(contentPage.doesNewOptionExist(optionName), "The initially created session attribute value was NOT deleted");
  }
}
