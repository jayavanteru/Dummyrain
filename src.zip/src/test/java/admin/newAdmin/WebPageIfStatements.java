package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.newAdmin.guide.GeneralTabPage;
import apps.admin.newAdmin.guide.LandingPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class WebPageIfStatements
{
  protected final String VENUE_NAME_TEXT = "Venue name";

  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.setupNewAdminUserAndSpoofTo(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST, AdminApp.orgIBMCode);
  }

  @AfterClass
  public void cleanUp() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38982", chromeIssue = "RA-32719")
  public void toggleIfStatements()
  {
    GeneralTabPage generalTabPage = GeneralTabPage.getPage();
    generalTabPage.navigate();
    // this is a little confusing, but both the field and value are named the same thing
    generalTabPage.editEventInformationInput(VENUE_NAME_TEXT, VENUE_NAME_TEXT);

    LandingPage landingPage = LandingPage.getPage();
    landingPage.navigate();
    Assert.assertTrue(landingPage.toggleIfStatements(), "If statements on web pages not working");
  }
}
