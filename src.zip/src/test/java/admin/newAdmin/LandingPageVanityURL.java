package admin.newAdmin;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.*;
import apps.admin.events.EventSearchPage;
import apps.admin.events.NewEventPage;
import apps.admin.newAdmin.guide.LandingPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

public class LandingPageVanityURL {

  OrgEventData orgEventData;
  EventSearchPage eventSearchPage;
  LandingPage landingPage;
  LegacyEventSettings legacyEventSettings;
  OrgEventSettings orgEventSettings;
  AdminApp adminApp;
  NavigationBar navigationBar;
  CreateNewOrgPage createNewOrgPage;
//  final String org = "NicVanityURLTest";
  final String org = "RF Automation";
  final String orgCode = "nicvanityurltest";
  final String event = "Eventgers Manual Test Event";
  final String eventCode = "manualtestevent";
  boolean reset = false;
  boolean reset2 = false;

  @BeforeClass
  public void setup()
  {
    adminApp = new AdminApp();
    eventSearchPage = new EventSearchPage();
    navigationBar = new NavigationBar();
    landingPage = LandingPage.getPage();
    legacyEventSettings = LegacyEventSettings.getPage();
    orgEventSettings = OrgEventSettings.getPage();
    orgEventData = OrgEventData.getPage();
    createNewOrgPage = CreateNewOrgPage.getPage();
    AdminLoginPage.getPage().login();
    try {
      orgEventData.setOrgAndEvent(org, event);
    } catch (Exception exception) {
      orgEventData.clickViewAllOrgs();
      orgEventData.clickCreateNewOrg();
      CreateNewOrgPage.getPage().createNewOrg(org, orgCode);
      orgEventData.switchToOrg(org);
      orgEventData.clickEventSelect();
      orgEventData.clickViewAllEvents();
      orgEventData.clickCreateNewEvent();
      NewEventPage.getPage().fillEventInformation(event, eventCode);
      orgEventData.switchToEvent(event);
    }
  }

  @AfterMethod
  public void tearDown()
  {
    if(reset){goToEventSettings("");}
    if(reset2){goToOrgSettings("");}
    navigationBar.switchToOldAdmin();
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-44011", chromeIssue = "RA-42911")
  public void vanityURL()
  {
    String eventVanityURL = "www.eventtestautomation.com";
    String orgVanityURL = "www.orgtestautomation.com";

    // Event Vanity Url with value
    goToEventSettings(eventVanityURL);
    reset = true;
    Assert.assertTrue(landingPage.getLandingPageURL().contains(eventVanityURL));
    navigationBar.switchToOldAdmin();

    // Event Vanity Url and Org Vanity Url with values
    goToOrgSettings(orgVanityURL);
    reset2 = true;
    Assert.assertTrue(landingPage.getLandingPageURL().contains(eventVanityURL));
    navigationBar.switchToOldAdmin();

    // Org Vanity Url with value
    goToEventSettings("");
    reset = false;
    Assert.assertTrue(landingPage.getLandingPageURL().contains(orgVanityURL));
    navigationBar.switchToOldAdmin();

    // Event Vanity Url and Org Vanity Url without values
    goToOrgSettings("");
    reset2 = false;
    Assert.assertTrue(landingPage.getLandingPageURL().contains("events-stg.rainfocus.com"));
    navigationBar.switchToOldAdmin();
  }

  private void goToOrgSettings(String orgVanityURL)
  {
    orgEventSettings.navigate();
    orgEventSettings.setOrgVanityURL(orgVanityURL);
    navigationBar.switchToNewAdmin();
    landingPage.navigate();
  }

  private void goToEventSettings(String eventVanityURL)
  {
    orgEventData.goToEventSettings();
    legacyEventSettings.setEventsVanityURL(eventVanityURL);
    navigationBar.switchToNewAdmin();
    landingPage.navigate();
  }
}
