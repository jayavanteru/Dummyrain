package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.events.EventSearchPage;
import apps.admin.events.NewEventPage;
import apps.admin.newAdmin.LeftNavActions;
import apps.admin.newAdmin.guide.AgendaItemEditPage;
import apps.admin.newAdmin.guide.AgendaPage;
import apps.admin.newAdmin.guide.LandingPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

public class Agenda {

  private SoftAssert softAssert;
  private String brandingUserEmail = "automation+brandinguser@rainfocus.com";
  DataGenerator dataGenerator;
  EventSearchPage eventSearchPage;
  NewEventPage newEventPage;
  AgendaPage agendaPage;
  LandingPage landingPage;
  AgendaItemEditPage agendaItemEditPage;
  NavigationBar navigationBar;
  AdminApp adminApp;
  private String userId;

  @BeforeClass
  public void setup() {
    eventSearchPage = EventSearchPage.getPage();
    newEventPage = NewEventPage.getPage();
    agendaPage = AgendaPage.getPage();
    landingPage = LandingPage.getPage();
    agendaItemEditPage = AgendaItemEditPage.getPage();
    dataGenerator = new DataGenerator();
    softAssert = new SoftAssert();
    adminApp = new AdminApp();
    navigationBar = new NavigationBar();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

    adminApp.loginAsAdminUser();

    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_NAME_EVENTGERS_TEST, false);
  }

  @AfterClass
  public void cleanUp() {
    // Delete Agendas which contain this text
    agendaPage.navigate();
    agendaPage.deleteAgendas("automation");
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-37834", chromeIssue = "RA-37833")
  public void newAgendaItemAndLandingPage() {

    String agenda1Title = dataGenerator.generateName();
    int agenda1Day = 10;
    String agenda1Location = dataGenerator.generateName();
    String agenda1StartTime = "7:00";
    String agenda1EndTime = "11:00";
    String agenda1EndTime24format = "23:00";
    String agenda1URL = "www." + dataGenerator.generateString() + ".com";

    String agenda2Title = dataGenerator.generateName();
    int agenda2Day = 10;
    String agenda2Location = dataGenerator.generateName();
    String agenda2StartTime = "10:00";
    String agenda2EndTime = "10:00";
    String agenda2EndTime24format = "22:00";
    String agenda2URL = "www." + dataGenerator.generateString() + ".com";

    String agenda3Title = dataGenerator.generateName();
    int agenda3Day = 15;
    String agenda3Location = dataGenerator.generateName();
    String agenda3StartTime = "5:00";
    String agenda3EndTime = "7:00";
    String agenda3EndTime24format = "19:00";
    String agenda3URL = "www." + dataGenerator.generateString() + ".com";

    String agenda4Title = dataGenerator.generateName();
    int agenda4Day = 15;
    String agenda4Location = dataGenerator.generateName();
    String agenda4StartTime = "10:00";
    String agenda4EndTime = "10:00";
    String agenda4EndTime24format = "22:00";
    String agenda4URL = "www." + dataGenerator.generateString() + ".com";

    agendaPage.navigate();

   //create two Agendas
    createAgenda(agenda1Title, agenda1Day, agenda1Location, agenda1StartTime, agenda1EndTime, agenda1URL);
    createAgenda(agenda2Title, agenda2Day, agenda2Location, agenda2StartTime, agenda2EndTime, agenda2URL);

    // Go Landing Page, and validate those agendas
    landingPage.navigate();
    landingPage.openLandingPage();
    validateAgendaInLandingPage(agenda1Title, agenda1Location, "0" + agenda1StartTime, agenda1EndTime24format, agenda1Day);
    validateAgendaInLandingPage(agenda2Title, agenda2Location, agenda2StartTime, agenda2EndTime24format, agenda2Day);

    // Create 2 new agendas with a different date
    landingPage.closeLandingPageTab();
    agendaPage.navigate();
    createAgenda(agenda3Title, agenda3Day, agenda3Location, agenda3StartTime, agenda3EndTime, agenda3URL);
    createAgenda(agenda4Title, agenda4Day, agenda4Location, agenda4StartTime, agenda4EndTime, agenda4URL);

    // Validate new agendas
    landingPage.navigate();
    landingPage.openLandingPage();
    validateAgendaInLandingPage(agenda3Title, agenda3Location, "0" + agenda3StartTime, agenda3EndTime24format, agenda3Day);
    validateAgendaInLandingPage(agenda4Title, agenda4Location, agenda4StartTime, agenda4EndTime24format, agenda4Day);

    //Edit an Agenda and validate changes in landing page
    landingPage.closeLandingPageTab();
    agendaPage.navigate();
    agendaPage.goToEditAgenda(agenda2Title);
    agenda2Location = dataGenerator.generateString();
    agenda2Title = dataGenerator.generateName();
    agenda2StartTime = "11:00";
    agendaItemEditPage.setLocation(agenda2Location);
    agendaItemEditPage.setTitle(agenda2Title);
    agendaItemEditPage.setStartTime(agenda2StartTime);
    agendaItemEditPage.saveAgenda();
    landingPage.navigate();
    landingPage.openLandingPage();
    validateAgendaInLandingPage(agenda2Title, agenda2Location, agenda2StartTime, agenda2EndTime24format, agenda2Day);

    // Delete and Agenda and validate in landing page
    landingPage.closeLandingPageTab();
    agendaPage.navigate();
    agendaPage.deleteAgenda(agenda3Title);
    landingPage.navigate();
    landingPage.openLandingPage();
    landingPage.changeAgendaTab(agenda3Day);
    softAssert.assertFalse(landingPage.existAgenda(agenda3Title, "0" + agenda3StartTime + " - " + agenda3EndTime), "Agenda should not exist any more");

    landingPage.closeLandingPageTab();
    agendaPage.navigate();

    softAssert.assertAll();
  }


  public void validateAgendaInLandingPage(String agendaTitle, String agendaLocation, String agendaStartTime, String agendaEndTime, int agendaDay) {
    landingPage.changeAgendaTab(agendaDay);
    landingPage.openAgendaDetail(agendaTitle);
    softAssert.assertTrue(landingPage.existAgenda(agendaTitle, agendaStartTime + " - " + agendaEndTime), "Agenda does not exist " + agendaTitle);
    softAssert.assertTrue(landingPage.existLocation(agendaLocation));
  }

  private void createAgenda(String agendaTitle, int day, String agendaLocation, String startTime, String endTime, String agendaURL) {
    agendaPage.addAgendaItem();
    agendaItemEditPage.fillInformation(agendaTitle, day, agendaLocation, startTime, endTime, agendaURL);
    agendaItemEditPage.saveAgenda();
  }

  private void addNewBrandingRole()
  {
    EditUserPage editUserPage = EditUserPage.getPage();
    AdminApp adminApp = new AdminApp();
    LeftNavActions.getPage().setGlobal();
    String userId = adminApp.getAdminUser(brandingUserEmail, "{'WDhrQi36D8KWFBBhGxp8B8xUsOIlqD3hnLQGkiZO':['role.system.admin']}");
    editUserPage.navigate(userId);
    editUserPage.setSecurityRole("New Branding - Option", "System Administrator");
    editUserPage.submit();
  }

}
