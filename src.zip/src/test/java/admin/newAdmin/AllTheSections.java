package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.newAdmin.guide.AllTheSectionsPage;
import apps.admin.newAdmin.guide.GeneralTabPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class AllTheSections {

  private AllTheSectionsPage allTheSectionsPage;
  private String testDescription = " - Automation test - do not edit";
  DataGenerator dataGenerator;
  AdminApp adminApp;
  GeneralTabPage generalTabPage;

  private String userId;

  @BeforeClass
  public void setup()
  {
    adminApp = new AdminApp();
    dataGenerator = new DataGenerator();
    allTheSectionsPage = AllTheSectionsPage.getPage();
    generalTabPage = GeneralTabPage.getPage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

    userId = adminApp.createUserByEmailIfNotExists("branding+superuser1234@rainfocus.com", AdminApp.orgIBMCode);
    EditUserPage.getPage().assignRole(userId, "New Branding - Locked", "Event Owner");
    EditUserPage.getPage().spoofUser(userId);
  }

  @AfterClass
  public void tearDown()
  {
    // todo this is a temporary way to unspoof from a user while the "Return to User" button is not visible in the new admin branding
    PageConfiguration.getPage().post(PropertyReader.instance().getProperty("adminUrl") + "/unspoofUser.focus");
    PageConfiguration.getPage().refreshPage();

    EditUserPage.getPage().assignRole(userId);

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38773", chromeIssue = "RA-38269")
  public void linkSection()
  {
    String sectionName = "Link Section" + testDescription;
    allTheSectionsPage.navigate();
    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Link Section does not exist");
    Assert.assertTrue(allTheSectionsPage.getUrlSection(sectionName).contains("/rain.focus#waitlistManagement.do"), "The Link of this section is wrong");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38813", chromeIssue = "RA-38268")
  public void registrationLimit()
  {
    String sectionName = "Registration Limit" + testDescription;
    String quantity = String.valueOf(dataGenerator.getNumber(0, 100));

    allTheSectionsPage.navigate();

    boolean isWaitlistEnabled = allTheSectionsPage.existTextInSection(sectionName,"Waitlist enabled");
    allTheSectionsPage.editSection(sectionName);
    allTheSectionsPage.editPackage(quantity);

    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Registration Limit section does not exist");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName,"Choose how many attendees will be able to register for the event."), "Registration Limit description is wrong");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, quantity), "Package quantity has not been saved correctly");
    Assert.assertNotEquals(allTheSectionsPage.existTextInSection(sectionName, "Waitlist enabled"), isWaitlistEnabled, "Package quantity has not been saved correctly");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42035", chromeIssue = "RA-42036")
  public void webinarHostLink()
  {
    String sectionName = "Webinar Host Links" + testDescription;

    allTheSectionsPage.navigate();
    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Webinar Host Links section (All tbe Sections) does not exit");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, "These are the unique URLs for the hosts to join the webinar"), "Webinar Host Links description is wrong (All tbe Sections)");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, "Jake Test"), "Webinar Host Links - wrong link name (All tbe Sections)");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, "jake.stowell+2299@rainfocus.com"), "Webinar Host Links - wrong email (All tbe Sections)");
    Assert.assertTrue(allTheSectionsPage.existUrl(sectionName, PropertyReader.instance().getProperty("eventsUrl") + "/eventWebinar/ibm/eventgers?userId=1614227984014001z0Yk"), "Webinar Host Links - wrong link (All tbe Sections)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38811", chromeIssue = "RA-38265")
  public void webinarGuestLink()
  {
    String sectionName = "Webinar Guest Link" + testDescription;
    allTheSectionsPage.navigate();
    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Webinar Guest Link section (All tbe Sections) does not exist");
    Assert.assertTrue(allTheSectionsPage.getUrlSection(sectionName).contains("www.cnn.com"), "Webinar Guest Link - the Link of this section is wrong (All tbe Sections)");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, "Password:"), "Webinar Guest Link - password has not been shown (All tbe Sections)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42033", chromeIssue = "RA-42034")
  public void landingPage()
  {
    String sectionName = "Landing Page" + testDescription;
    allTheSectionsPage.navigate();
    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Landing Page section (All the sections) does not exist");
    Assert.assertTrue(allTheSectionsPage.existSection("This link will direct the user to the event landing page to register"), "Landing Page description is wrong (All the sections)");
    Assert.assertEquals(allTheSectionsPage.getUrlSection(sectionName), PropertyReader.instance().getProperty("workflowsUrl") + "/ibm/eventgers/attendeedashboard", "The Link of this section is wrong (All the sections)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42030", chromeIssue = "RA-42032")
  public void formRender()
  {
    String sectionName = "Form Render" + testDescription;
    String text = dataGenerator.generateString();
    String attributeOption = "Option " + dataGenerator.getNumber(1, 10);

    allTheSectionsPage.navigate();
    Assert.assertTrue(allTheSectionsPage.existSection(sectionName), "Form Render section (All tbe Sections) does not exist");

    allTheSectionsPage.editSection(sectionName);
    allTheSectionsPage.formRenderEditSelectAttribute(attributeOption);
    allTheSectionsPage.formRenderEditTextAttribute(text);
    allTheSectionsPage.saveForm();

    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, text), "Attribute has not been saved correctly (All tbe Sections)");
    Assert.assertTrue(allTheSectionsPage.existTextInSection(sectionName, attributeOption), "Attribute has not been saved correctly (All tbe Sections)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42027", chromeIssue = "RA-42028")
  public void formBuilder()
  {
    allTheSectionsPage.navigate();
    allTheSectionsPage.editForm();
    allTheSectionsPage.saveForm();

    Assert.assertTrue(allTheSectionsPage.existSection("Form Builder" + testDescription), "Form Builder section (All tbe Sections) does not exist");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-41258", chromeIssue = "RA-41257")
  public void countryOrder()
  {
    generalTabPage.navigate();
    boolean generalPageGood = generalTabPage.countryOrderWorks();
    Assert.assertTrue(generalPageGood, "Country order not working on General Tab");
    allTheSectionsPage.navigate();
    // using the generalTabPage cause its the exact same stuff
    boolean allTheSectionsGood = generalTabPage.countryOrderWorks();
    Assert.assertTrue(allTheSectionsGood, "Country order not working in All The Sections tab");
  }
}
