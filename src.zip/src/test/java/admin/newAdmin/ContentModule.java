package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.newAdmin.guide.ContentSettingsPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ContentModule
{
  private long length;
  private String roomName;
  private String sessionTitle;
  private String dayName;
  @BeforeClass
  public void setup()
  {
    AdminApp adminApp = new AdminApp();
    adminApp.loginAsAdminUser();
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42003", chromeIssue = "RA-41845")
  public void content1Day()
  {
    ContentSettingsPage contentSettingsPage = ContentSettingsPage.getPage();
    contentSettingsPage.navigate("days");

    contentSettingsPage.removeUnusedDays();

    //create a new day
    dayName = contentSettingsPage.addDay();
    Assert.assertTrue(contentSettingsPage.verifyDay(dayName), "Failed to create date: " + dayName);

    contentSettingsPage.deleteByName(dayName);
    Assert.assertFalse(contentSettingsPage.verifyDay(dayName), "Day should have been deleted");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42004", chromeIssue = "RA-42000")
  public void content2Length()
  {
    ContentSettingsPage contentSettingsPage = ContentSettingsPage.getPage();
    contentSettingsPage.navigate("lengths");

    //remove unused length
    contentSettingsPage.removeUnusedLengths();

    //create a new length
    length = contentSettingsPage.pickUniqueLength();
    Assert.assertTrue(length > 0, "Please remove sessions tied to any of these session lengths 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180. We want to create and delete lengths");

    contentSettingsPage.addLength(length);
    Assert.assertTrue(contentSettingsPage.verifyLength(length), "Failed to create length: " + length);

    contentSettingsPage.deleteByName(String.valueOf(length));
    Assert.assertFalse(contentSettingsPage.verifyLength(length), "Length should have been deleted");
  }

 @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42005", chromeIssue = "RA-42001")
  public void content3Room()
  {
    ContentSettingsPage contentSettingsPage = ContentSettingsPage.getPage();
    contentSettingsPage.navigate("rooms");

    contentSettingsPage.deleteUnusedRooms();

    //create a room
    roomName = contentSettingsPage.addRoom();
    Assert.assertTrue(contentSettingsPage.verifyRoom(roomName), "Failed to create date: " + roomName);

    contentSettingsPage.deleteByName(roomName);
    Assert.assertFalse(contentSettingsPage.verifyRoom(roomName), "Room should have been deleted");
  }


  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-35910", chromeIssue = "RA-38939")
  public void contentModule()
  {
    SessionSearchPage sessionSearchPage = SessionSearchPage.getPage();
    sessionSearchPage.navigate();

    sessionSearchPage.removeSessionsByTitle("session automation");

    ContentSettingsPage contentSettingsPage = ContentSettingsPage.getPage();
    contentSettingsPage.navigate("days");

    //create a new day
    dayName = contentSettingsPage.addDay();
    Assert.assertTrue(contentSettingsPage.verifyDay(dayName), "Failed to create date: " + dayName);

    contentSettingsPage.navigate("lengths");

    //create a new length
    length = contentSettingsPage.pickUniqueLength();
    Assert.assertTrue(length > 0, "Please remove sessions tied to any of these session lengths 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180. We want to create and delete lengths");

    contentSettingsPage.addLength(length);
    Assert.assertTrue(contentSettingsPage.verifyLength(length), "Failed to create length: " + length);

    contentSettingsPage.navigate("rooms");

    //create a room
    roomName = contentSettingsPage.addRoom();
    Assert.assertTrue(contentSettingsPage.verifyRoom(roomName), "Failed to create room: " + roomName);

    //Create new session
    sessionSearchPage.navigate();

    DataGenerator dataGenerator = new DataGenerator();
    sessionTitle = "session automation" + dataGenerator.generateString(5);
    sessionSearchPage.createSessionAndMakeSchedulable(sessionTitle, "test", length);

    contentSettingsPage.goToScheduleGrid();

    //Now, let's schedule the session
    contentSettingsPage.scheduleSession(sessionTitle, roomName);

    Assert.assertTrue(contentSettingsPage.wasSessionScheduled(sessionTitle), "Session " + sessionTitle +  " was not scheduled at room: " + roomName);

    //Unschedule session
    contentSettingsPage.unScheduleSession(sessionTitle);

    Assert.assertFalse(contentSettingsPage.wasSessionScheduled(sessionTitle), "Session " + sessionTitle + " should have been unscheduled at room: " + roomName);

    sessionSearchPage.navigate();

    sessionSearchPage.search(sessionTitle);
    sessionSearchPage.deleteFirstRecord();

    contentSettingsPage.navigate("days");
    contentSettingsPage.deleteByName(dayName);

    Assert.assertFalse(contentSettingsPage.verifyDay(dayName), "Day should have been deleted");

    contentSettingsPage.navigate("lengths");
    contentSettingsPage.deleteByName(String.valueOf(length));

    Assert.assertFalse(contentSettingsPage.verifyLength(length), "Length should have been deleted");

    contentSettingsPage.navigate("rooms");
    contentSettingsPage.deleteByName(roomName);

    Assert.assertFalse(contentSettingsPage.verifyRoom(roomName), "Room should have been deleted");
  }
}
