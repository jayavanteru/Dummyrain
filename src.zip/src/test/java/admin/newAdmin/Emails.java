package admin.newAdmin;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.events.EventSearchPage;
import apps.admin.newAdmin.guide.EditEmailNewAdminPage;
import apps.admin.newAdmin.guide.EmailsNewAdminPage;
import apps.admin.newAdmin.guide.PreviewEmailNewAdminPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

public class Emails {

  DataGenerator dataGenerator = new DataGenerator();
  String orgIBMCode = "nGHYGAOXirpk2EuFF1rMzwEXr2KQMqiw4g2ImBOf";
  String userId;
  AdminApp adminApp;
  EditUserPage editUserPage;
  EmailsNewAdminPage emailsNewAdminPage;
  EventSearchPage eventSearchPage;
  EditEmailNewAdminPage editEmailNewAdminPage;
  PreviewEmailNewAdminPage previewEmailNewAdminPage;
  SoftAssert softAssert;

  @BeforeClass
  public void setup()
  {
    adminApp = new AdminApp();
    editUserPage = new EditUserPage();
    emailsNewAdminPage = new EmailsNewAdminPage();
    editEmailNewAdminPage = new EditEmailNewAdminPage();
    eventSearchPage = new EventSearchPage();
    previewEmailNewAdminPage = new PreviewEmailNewAdminPage();
    softAssert = new SoftAssert();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", "GLOBAL");
    userId = adminApp.getAdminUser(PropertyReader.instance().getProperty("ibmNewAdminUserEmail"), "{'" + orgIBMCode + "':['role.system.admin']}");
    editUserPage.assignRole(userId, "New Branding - Option", "System Administrator");
  }

  @AfterClass
  public void quit()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38100", chromeIssue = "RA-38099")
  public void editEmail()
  {
    editUserPage.spoofUser(userId);
    String emailSubject = dataGenerator.generateName();
    String emailCCList = dataGenerator.generateValidEmail();
    String emailBCCList = dataGenerator.generateValidEmail();
    String emailFromName = dataGenerator.generateName();
    String emailFromAddress = dataGenerator.generateValidEmail();
    String emailHTML = dataGenerator.generateString();

    String email2Subject = dataGenerator.generateName();
    String email2CCList = dataGenerator.generateValidEmail();
    String email2BCCList = dataGenerator.generateValidEmail();
    String email2FromName = dataGenerator.generateName();
    String email2FromAddress = dataGenerator.generateValidEmail();
    String email2HTML = dataGenerator.generateString();


    emailsNewAdminPage.navigate();

    //Edit email
    emailsNewAdminPage.editEmailByPosition(0);
    editEmail(emailSubject, emailCCList, emailBCCList, emailFromName, emailFromAddress, emailHTML);

    //Validate changes
    emailsNewAdminPage.editEmailByPosition(0);
    validateEmail(emailSubject, emailCCList, emailBCCList, emailFromName, emailFromAddress, emailHTML);
    String selectedLanguage = editEmailNewAdminPage.getSelectedLanguage();
    editEmailNewAdminPage.canceEmail();

    //Validate Preview
    emailsNewAdminPage.previewEmailByPosition(0);
    previewEmailNewAdminPage.selectLanguage(selectedLanguage);
    softAssert.assertTrue(previewEmailNewAdminPage.getEmailContent().contains("<p>" + emailHTML + "</p>"), "'Email Content' must be the same");
    softAssert.assertEquals(previewEmailNewAdminPage.getSelectedLanguage(), selectedLanguage, "'Language' must be the same");
    previewEmailNewAdminPage.cancelPreview();

    // Change language, save and validate changes
    emailsNewAdminPage.editEmailByPosition(0);
    String languageToSelect = editEmailNewAdminPage.getLanguageToSelect();
    editEmailNewAdminPage.selectLanguage(languageToSelect);
    editEmail(email2Subject, email2CCList, email2BCCList, email2FromName, email2FromAddress, email2HTML);

    emailsNewAdminPage.editEmailByPosition(0);
    validateEmail(email2Subject, email2CCList, email2BCCList, email2FromName, email2FromAddress, email2HTML);
    softAssert.assertEquals(editEmailNewAdminPage.getSelectedLanguage(), languageToSelect, "'Language' must be the same");
    editEmailNewAdminPage.canceEmail();

    //Validate Preview
    emailsNewAdminPage.previewEmailByPosition(0);
    previewEmailNewAdminPage.selectLanguage(languageToSelect);
    softAssert.assertTrue(previewEmailNewAdminPage.getEmailContent().contains("<p>" + email2HTML + "</p>"), "'Email Content' must be the same");
    softAssert.assertEquals(previewEmailNewAdminPage.getSelectedLanguage(), languageToSelect, "'Language' must be the same");
    previewEmailNewAdminPage.cancelPreview();

    softAssert.assertAll();
  }

  private void validateEmail(String emailSubject, String emailCCList, String emailBCCList, String emailFromName, String emailFromAddress,  String emailHTML)
  {
    softAssert.assertEquals(editEmailNewAdminPage.getSubject(), emailSubject, "'Subject' must be the same");
    softAssert.assertEquals(editEmailNewAdminPage.getCCList(), emailCCList, "'CC List' must be the same");
    softAssert.assertEquals(editEmailNewAdminPage.getBCCList(), emailBCCList, "'BCC List' must be the same");
    softAssert.assertEquals(editEmailNewAdminPage.getFromName(), emailFromName, "'From Name' must be the same");
    softAssert.assertEquals(editEmailNewAdminPage.getFromAddress(), emailFromAddress, "'From Address' must be the same");
    softAssert.assertTrue(editEmailNewAdminPage.getEmailContent().contains("<p>" + emailHTML + "</p>"), "'Email Content' must be the same");
  }

  private void editEmail(String emailSubject, String emailCCList, String emailBCCList, String emailFromName, String emailFromAddress, String emailHTML)
  {
    editEmailNewAdminPage.setSubject(emailSubject);
    editEmailNewAdminPage.setCCList(emailCCList);
    editEmailNewAdminPage.setBCCList(emailBCCList);
    editEmailNewAdminPage.setFromName(emailFromName);
    editEmailNewAdminPage.setFromAddress(emailFromAddress);
    editEmailNewAdminPage.setEmailContent(emailHTML);
    editEmailNewAdminPage.saveEmail();
  }
}
