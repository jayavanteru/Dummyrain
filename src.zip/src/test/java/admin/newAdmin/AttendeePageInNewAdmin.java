package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AttendeePageInNewAdmin
{
  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.loginAsAdminUser();
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39052", chromeIssue = "RA-32712")
  public void isWorkingInNewAdmin()
  {
    AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
    attendeeSearchPage.navigateToNewAdminPage();
    attendeeSearchPage.search();
    attendeeSearchPage.clickResult(1);
    Assert.assertTrue(attendeeSearchPage.summaryTabLoaded(), "Summary tab not working");
    Assert.assertTrue(attendeeSearchPage.clickOrdersTabConfirmLoad(), "Orders tab not working");
    Assert.assertTrue(attendeeSearchPage.clickDemographicTabConfirmLoad(), "Demographics tab not working");
    Assert.assertTrue(attendeeSearchPage.clickEmailsTabConfirmLoad(), "Emails tab not working");
    Assert.assertTrue(attendeeSearchPage.clickScheduleTabConfirmLoad(), "Schedule tab not working");
    Assert.assertTrue(attendeeSearchPage.clickTasksTabConfirmLoad(), "Tasks tab not working");
    Assert.assertTrue(attendeeSearchPage.clickTab1ConfirmLoad(), "Form tab 1 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab2ConfirmLoad(), "Form tab 2 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab3ConfirmLoad(), "Form tab 3 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab4ConfirmLoad(), "Form tab 4 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab5ConfirmLoad(), "Form tab 5 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab6ConfirmLoad(), "Form tab 6 not working");
    Assert.assertTrue(attendeeSearchPage.clickTab7ConfirmLoad(), "Form tab 7 not working");
    Assert.assertTrue(attendeeSearchPage.clickComplianceTabConfirmLoad(), "Compliance tab not working");
    Assert.assertTrue(attendeeSearchPage.clickOnsiteTabConfirmLoad(), "Onsite tab not working");
    Assert.assertTrue(attendeeSearchPage.clickHistoryTabConfirmLoad(), "History tab not working");
    Assert.assertTrue(attendeeSearchPage.clickFilesTabConfirmLoad(), "Files tab not working");
  }
}
