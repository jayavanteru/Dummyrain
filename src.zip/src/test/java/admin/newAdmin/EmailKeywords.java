package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditEmailPage;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.events.EventSearchPage;
import apps.admin.newAdmin.guide.EmailsNewAdminPage;
import apps.admin.newAdmin.guide.PreviewEmailNewAdminPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EmailKeywords {

  DataGenerator dataGenerator = new DataGenerator();
  String orgIBMCode = "nGHYGAOXirpk2EuFF1rMzwEXr2KQMqiw4g2ImBOf";
  String userId;
  AdminApp adminApp;
  EditUserPage editUserPage;
  EmailsNewAdminPage emailsNewAdminPage;
  EventSearchPage eventSearchPage;
  PreviewEmailNewAdminPage previewEmailNewAdminPage;
  EmailsSearchPage emailsSearchPage;
  EditEmailPage editEmailPage;
  NavigationBar navigationBar;
  OrgEventData orgEventData;
  LegacyEventSettings legacyEventSettings;
  AttendeeSearchPage attendeeSearchPage;
  EditAttendeePage editAttendeePage;
  String emailName = "global Email - Automation test do not edit";
  String emailCode = "automationEmailDoNotEditKeywords";
  String eventGuide = "AUTOMATION EVENT GUIDE - DO NOT EDIT";

  @BeforeClass
  public void setup()
  {
    adminApp = new AdminApp();
    editUserPage = new EditUserPage();
    emailsNewAdminPage = new EmailsNewAdminPage();
    eventSearchPage = new EventSearchPage();
    previewEmailNewAdminPage = new PreviewEmailNewAdminPage();
    emailsSearchPage = new EmailsSearchPage();
    editEmailPage = new EditEmailPage();
    navigationBar = new NavigationBar();
    orgEventData = new OrgEventData();
    legacyEventSettings = new LegacyEventSettings();
    attendeeSearchPage = new AttendeeSearchPage();
    editAttendeePage = new EditAttendeePage();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", "GLOBAL");
    userId = adminApp.getAdminUser(PropertyReader.instance().getProperty("ibmNewAdminUserEmail"), "{'" + orgIBMCode + "':['role.system.admin']}");
    editUserPage.assignRole(userId, "New Branding - Option", "System Administrator");
  }

  @AfterClass
  public void quit()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-41272", chromeIssue = "RA-38989")
  public void showKeywords()
  {
    String emailSubject = dataGenerator.generateName();
    String emailFromAddress = dataGenerator.generateValidEmail();

    emailsSearchPage.navigate();
    if(!emailsSearchPage.emailExists(emailCode))
    {
      emailsSearchPage.addItem();
      editEmailPage.setName(emailName);
      editEmailPage.setSubject(emailSubject);
      editEmailPage.setFromAddress(emailFromAddress);
      editEmailPage.setCode(emailCode);
      editEmailPage.setKeyWord("First Name");
      editEmailPage.save();
    }
    orgEventData.setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

//    orgEventData.goToEventSettings();
//    legacyEventSettings.setEventGuide(eventGuide);

    editUserPage.spoofUser(userId);
    Assert.assertTrue(EditUserPage.getPage().isSpoofedIn(), "did not spoof in to admin with the new user");
    navigationBar.switchToNewAdmin();
    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_NAME_EVENTGERS_TEST, navigationBar.isOldAdminNavVisible());
    emailsNewAdminPage.navigate();
    emailsNewAdminPage.previewEmailByPosition(1);
    Assert.assertTrue(previewEmailNewAdminPage.existTextInEmailPreviewer("[%attendee.firstname%]"), "'Firstname' keyword must be shown");
    previewEmailNewAdminPage.cancelPreview();

    navigationBar.switchToOldAdmin();
    editUserPage.navigate(userId);
    editUserPage.returnToUser();

    orgEventData.setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
    attendeeSearchPage.navigate();
    attendeeSearchPage.search();
    attendeeSearchPage.clickResult(0);
    String attendeeFirstName = editAttendeePage.getFirstName();
    editAttendeePage.goToEmailsTab();
    editAttendeePage.emailsTabSearchEmail(emailName);
    editAttendeePage.emailTabSelectEmail(emailName);
    editAttendeePage.emailTabPreviewEmail();
    String emailText = editAttendeePage.getEmailPreviewText();

    Assert.assertTrue(emailText.contains(attendeeFirstName), "Attendee 'Firstname' keyword do not match");

    orgEventData.goToEventSettings();
    legacyEventSettings.setEventGuide(RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }
}
