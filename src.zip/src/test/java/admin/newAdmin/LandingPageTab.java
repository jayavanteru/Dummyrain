package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.newAdmin.guide.LandingPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class LandingPageTab
{

  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.setupNewAdminUserAndSpoofTo(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST, AdminApp.orgIBMCode);
  }

  @AfterClass
  public void cleanUp() {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38860", chromeIssue = "RA-32705")
  public void editLandingPage()
  {
    LandingPage landingPage = LandingPage.getPage();
    landingPage.navigate();

    Assert.assertTrue(landingPage.editLandingPage());
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39081", chromeIssue = "RA-35570")
  public void testKeywordsOnWorkflow()
  {
    LandingPage landingPage = LandingPage.getPage();
    landingPage.navigate();

    Assert.assertTrue(landingPage.validateKeywordsOnCreateAccountPage(), "Keywords aren't working on workflows");
  }
}
