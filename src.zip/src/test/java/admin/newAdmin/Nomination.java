package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.newAdmin.guide.NominationPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Nomination
{
  @BeforeClass
  public void setup()
  {
    AdminApp adminApp = new AdminApp();
    adminApp.setupNewAdminUserAndSpoofTo(RFConstants.ORG_IBM, "Nominations Test", AdminApp.orgIBMCode);
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-32709", chromeIssue = "RA-38742")
  public void goToNomination()
  {
    NominationPage nominationPage = NominationPage.getPage();
    nominationPage.navigate();
    nominationPage.clickNominationTab();

    Assert.assertTrue(nominationPage.isNavLinkActive(), "Link isn't highlighted by css='active'");
    Assert.assertTrue(nominationPage.hasSections(), "Should have sections to show");
  }
}
