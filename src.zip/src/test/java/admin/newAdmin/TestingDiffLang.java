package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.newAdmin.guide.AgendaPage;
import apps.admin.newAdmin.guide.GeneralTabPage;
import apps.admin.newAdmin.guide.LandingPage;
import apps.admin.newAdmin.guide.RegistrationTabPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

public class TestingDiffLang
{
  private GeneralTabPage generalTabPage;
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private AgendaPage agendaPage;
  private LandingPage landingPage;
  private RegistrationTabPage registrationTabPage;

  @BeforeClass
  public void setup() {
    PropertyReader.instance().setProperty("lang", "spanish");
    generalTabPage = GeneralTabPage.getPage();
    landingPage = LandingPage.getPage();
    registrationTabPage = RegistrationTabPage.getPage();
    agendaPage = AgendaPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();

    AdminApp adminApp = new AdminApp();
   adminApp.setupNewAdminUserAndSpoofTo(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST, AdminApp.orgIBMCode);
    //adminApp.loginAsAdminUser();

  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  // https://rainfocus.atlassian.net/browse/RA-38313
  // https://rainfocus.atlassian.net/browse/RA-41710
  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-41710", chromeIssue = "RA-38313")
  public void translateGlobalFormSavesToEvent()
  {
    String workflowCode = "translateglobalformtoevent";
    generalTabPage.navigate();
    generalTabPage.translateFormBuilder();

    // spoof into workflow
    attendeeSearchPage.navigate();
    attendeeSearchPage.selectRegistered(false);
    attendeeSearchPage.clickResult(1);
    editAttendeePage.spoofTo(workflowCode);
    editAttendeePage.acceptCookiesIfExistInSpoofPackage();
    List<String> spanishColorNames = Arrays.asList("Naranja", "Azul", "Verde", "Rojo", "Morado", "Amarillo");
    for (String colorName : spanishColorNames)
      Assert.assertTrue(editAttendeePage.isTextOnPage(colorName));
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42459", chromeIssue = "RA-35908")
  public void testNewAdminTranslationsGeneralTab()
  {
    String EVENTGERS_IN_ESPANOL = "Eventgers in espanol";

    // translate event information in general tab
    generalTabPage.navigate();
    generalTabPage.clickManageTranslationsButton();
    generalTabPage.selectSpanishLanguageForTranslationModal();
    generalTabPage.fillOutInputInTranslationModal("Eventgers", EVENTGERS_IN_ESPANOL);
    generalTabPage.saveTranslationModal();

    // open landing page
    landingPage.navigate();
    landingPage.openLandingPage();
    Assert.assertTrue(landingPage.isTextOnPage(EVENTGERS_IN_ESPANOL), "Translations from event information not working");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-44062", chromeIssue = "RA-44066")
  public void testNewAdminTranslationsAgendaTab()
  {
    String COOL_SPANISH_WORD = "palabra en español genial";

    // translate agenda item
    agendaPage.navigate();
    agendaPage.clickManageTranslationsButton();
    // this is the same functionality, so reusing
    generalTabPage.selectSpanishLanguageForTranslationModal();
    generalTabPage.fillOutInputInTranslationModal("Agenda Item for Translations - DO NOT DELETE", COOL_SPANISH_WORD);
    generalTabPage.saveTranslationModal();

    // open landing page
    landingPage.navigate();
    landingPage.openLandingPage();
    Assert.assertTrue(landingPage.isTextOnPage(COOL_SPANISH_WORD), "Translations from agenda not working");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-44060", chromeIssue = "RA-44061")
  public void testNewAdminTranslationsRegTab()
  {
    String FIRST_NAME_IN_SPANISH = "Nombre de Pila";
    String LAST_NAME_IN_SPANISH = "Apellido";

    // translate stuff on reg tab
    registrationTabPage.navigate();
    registrationTabPage.clickOnTranslateButtonOfFirstForm();
    generalTabPage.selectSpanishLanguageForTranslationModal();
    generalTabPage.fillOutInputInTranslationModal("First Name", FIRST_NAME_IN_SPANISH);
    generalTabPage.fillOutInputInTranslationModal("Last Name", LAST_NAME_IN_SPANISH);
    generalTabPage.saveTranslationModal();

    // spoof into workflow
    attendeeSearchPage.navigate();
    attendeeSearchPage.selectRegistered(false);
    attendeeSearchPage.clickResult(1);
    editAttendeePage.spoofTo("regcteba4");
    Assert.assertTrue(landingPage.isTextOnPage(FIRST_NAME_IN_SPANISH), "Translations from reg form not working");
    Assert.assertTrue(landingPage.isTextOnPage(LAST_NAME_IN_SPANISH), "Translations from reg form not working");
  }
}
