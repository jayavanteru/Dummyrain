package admin.newAdmin;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.events.EventSearchPage;
import apps.admin.newAdmin.guide.GeneralTabPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class GeneralTab {

  private GeneralTabPage generalTabPage;
  private String testDescription = " - Automation test - do not edit";
  private DataGenerator dataGenerator = new DataGenerator();
  EventSearchPage eventSearchPage;
  private String userId;

  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    generalTabPage = GeneralTabPage.getPage();
    eventSearchPage = new EventSearchPage();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);

    userId = adminApp.createUserByEmailIfNotExists("branding+superuser1234@rainfocus.com", AdminApp.orgIBMCode);
    adminApp.loginAsAdminUser();

    eventSearchPage.navigate();
    eventSearchPage.accessEventByCode(RFConstants.EVENT_NAME_EVENTGERS_TEST, false);
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38855", chromeIssue = "RA-32704")
  public void editEvent()
  {
    generalTabPage.navigate();

    Assert.assertTrue(generalTabPage.editEventInformation());
    Assert.assertTrue(generalTabPage.editMoreInformationForm());
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39103", chromeIssue = "RA-38588")
  public void webinarProfile()
  {
    String sectionName = "Webinar Profile" + testDescription;
    generalTabPage.navigate();

    Assert.assertTrue(generalTabPage.existSection(sectionName), "Webinar Profile section (General Tab) does not exist");
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, "The description of the webinar profile shindig"), "Webinar Profile description is wrong (General Tab)");

    String selectedOption = generalTabPage.editWebinarProfileSection(sectionName, dataGenerator.getNumber(1, 4));
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, selectedOption), "Webinar Profile description is wrong (General Tab)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38810", chromeIssue = "RA-38262")
  public void formBuilder()
  {
    generalTabPage.navigate();
    generalTabPage.editForm();
    generalTabPage.saveForm();

    Assert.assertTrue(generalTabPage.existSection("Form Builder" + testDescription), "Form Builder section (General Tab) does not exist");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38808", chromeIssue = "RA-38261")
  public void formRender()
  {
    String sectionName = "Form Render" + testDescription;
    String text = dataGenerator.generateString();
    String attributeOption = "Option " + dataGenerator.getNumber(1, 10);

    generalTabPage.navigate();
    Assert.assertTrue(generalTabPage.existSection(sectionName), "Form Render section (General Tab) does not exist");

    generalTabPage.editSection(sectionName);
    generalTabPage.formRenderEditSelectAttribute(attributeOption);
    generalTabPage.formRenderEditTextAttribute(text);
    generalTabPage.saveForm();

    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, text), "Attribute has not been saved correctly. Form Render (General Tab)");
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, attributeOption), "Attribute has not been saved correctly. Form Render (General Tab)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38814", chromeIssue = "RA-38263")
  public void landingPage()
  {
    String sectionName = "Landing Page" + testDescription;
    generalTabPage.navigate();
    Assert.assertTrue(generalTabPage.existSection(sectionName), "Landing Page section (General Tab) does not exist");
    Assert.assertTrue(generalTabPage.existSection("This link will direct the user to the event landing page to register"), "Landing Page description is wrong (General Tab)");
    Assert.assertEquals(generalTabPage.getUrlSection(sectionName), PropertyReader.instance().getProperty("workflowsUrl") + "/ibm/eventgers/attendeedashboard", "Landing Page - the Link of this section is wrong (General Tab)");
  }

  @Test(groups = {ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-38812", chromeIssue = "RA-38264")
  public void webinarHostLink()
  {
    String sectionName = "Webinar Host Links" + testDescription;

    generalTabPage.navigate();
    Assert.assertTrue(generalTabPage.existSection(sectionName), "Webinar Host Links section (General Tab) does not exit");
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, "These are the unique URLs for the hosts to join the webinar"), "Webinar Host Links description is wrong (General Tab)");
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, "Jake Test"), "Webinar Host Links - Wrong link name (General Tab)");
    Assert.assertTrue(generalTabPage.existTextInSection(sectionName, "jake.stowell+2299@rainfocus.com"), "Webinar Host Links - Wrong email (General Tab) ");
    Assert.assertTrue(generalTabPage.existUrl(sectionName, PropertyReader.instance().getProperty("eventsUrl") + "/eventWebinar/ibm/eventgers?userId=1614227984014001z0Yk"), "Webinar Host Links - Wrong link (General Tab)");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-39173", chromeIssue = "RA-32716")
  public void testEventKeywordsOnForm()
  {
    /*
      this assumes the setup of actually putting the keywords on the form
    */
    GeneralTabPage generalTabPage = GeneralTabPage.getPage();
    generalTabPage.navigate();

    Assert.assertTrue(generalTabPage.eventKeywordsOnForm(), "Event keywords not working on form in new admin");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-42188", chromeIssue = "RA-42163")
  public void testSimpleAdvancedCkEditor()
  {
    GeneralTabPage generalTabPage = GeneralTabPage.getPage();
    generalTabPage.navigate();

    Assert.assertTrue(generalTabPage.testTogglingCkEditor(), "Toggling between advanced/basic ck editor not working");
  }

  @Test(groups = { ReportingInfo.PLANNERTEERS})
  @ReportingInfo(firefoxIssue = "RA-45641", chromeIssue = "RA-43779")
  public void showContentTab()
  {
    String sectionName = "Set Registration Status, Branding, and Attendee Tracking (Required Action): ";
    GeneralTabPage generalTabPage = GeneralTabPage.getPage();
    generalTabPage.navigate();

    // Validate sections exists
    Assert.assertTrue(generalTabPage.existSection(sectionName));

    // Validate Content Tab exists
    generalTabPage.changeRFEventStatus("RF Site Live (Publish)");
    Assert.assertTrue(generalTabPage.isTabOnPage("Content"), "Content must exist");

    // Validate Content Tab does not exists
    generalTabPage.changeRFEventStatus("RF Ready to Build");
    Assert.assertFalse(generalTabPage.isTabOnPage("Content"), "Content must not exist");
  }
}
