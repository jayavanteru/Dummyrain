package admin.Accounts;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.CreateNewOrgPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.marketing.AdminAccountsSearchPage;
import apps.admin.adminPageObjects.marketing.AdminEditAccountPage;
import apps.admin.adminPageObjects.marketing.*;
import apps.admin.adminPageObjects.registration.AdminAccountBulkEditPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.admin.events.NewEventPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Accounts {

  private final DataGenerator dataGenerator = new DataGenerator();
  private SoftAssert softAssert;
  private AdminAccountsSearchPage adminAccountsSearchPage;
  private AdminNewAccountPage adminNewAccountPage;
  private AdminEditAccountPage adminEditAccountPage;
  private AttendeeSearchPage attendeeSearchPage;
  private EditAttendeePage editAttendeePage;
  private AdminAccountBulkEditPage adminAccountBulkEditPage;
  private OrgEventData orgEventData;
  private String testDesc = "Automation test - do not edit";
  private String testAccountName1 = "account1 - " + testDesc;
  private String testAccountName2 = "account2 - " + testDesc;
  private String testEmailDomain1 = "testDomainNotedit1.com";
  private String testAttendeeEmail1 = "attendeeTestDoNotEdit1@" + testEmailDomain1;
  private String testEmailDomain2 = "testDomainNotedit2.com";
  private String testAttendeeEmail2 = "attendeeTestDoNotEdit2@" + testEmailDomain2;
  private List<String> attributes = new ArrayList<>(Arrays.asList("ACCOUNTS: PEP_FLAG", "ACCOUNTS: ACCOUNT_CATEGORY", "ACCOUNTS: GBL_BUY_GRP"));
  private List<String> attributeValuesAccountCategory = new ArrayList<>(Arrays.asList("General Accounts", "Integrated Accounts", "Think Priority Accounts"));
  private List<String> attributeValuesPEP_FLAG = new ArrayList<>(Arrays.asList("Y", "N"));

  private List<String> accountNamesToDelete = new ArrayList<>();
  private List<String> attendeeNamesToDelete = new ArrayList<>();

  @BeforeClass
  public void setupTest() {
    softAssert = new SoftAssert();
    adminAccountsSearchPage = AdminAccountsSearchPage.getPage();
    adminNewAccountPage = AdminNewAccountPage.getPage();
    adminEditAccountPage = AdminEditAccountPage.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    adminAccountBulkEditPage = AdminAccountBulkEditPage.getPage();
    orgEventData = OrgEventData.getPage();

    AdminLoginPage.getPage().login();
    orgEventData.switchToOrg(RFConstants.ORG_IBM);
    try {
      orgEventData.switchToEvent(RFConstants.EVENT_NAME_ACCOUNTS);
    } catch (Exception exception) {
      String templateName = "Eventgers Test Event";
      orgEventData.clickViewAllEvents();
      orgEventData.clickCreateNewEvent();
      orgEventData.createEventWithTemplate(templateName);
      NewEventPage.getPage().createOneDayEvent(RFConstants.EVENT_NAME_ACCOUNTS, RFConstants.EVENT_CODE_ACCOUNTS);
      orgEventData.switchToEvent(RFConstants.EVENT_NAME_ACCOUNTS);
    }
  }

  @AfterClass
  public void closeBrowser() {
    // delete accounts
    if(accountNamesToDelete.size() > 0)
    {
      AdminAccountsSearchPage.getPage().navigate();
      for (String accountName : accountNamesToDelete)
      {
        AdminAccountsSearchPage.getPage().searchFor(accountName);
        if (AdminAccountsSearchPage.getPage().existAccount(accountName))
        {
          AdminAccountsSearchPage.getPage().deleteAccount(0);
        }

      }
    }

    // delete attendees
    if(attendeeNamesToDelete.size() > 0)
    {
      AttendeeSearchPage.getPage().navigate();
      for (String attendeeName : attendeeNamesToDelete)
      {
        AttendeeSearchPage.getPage().searchFor(attendeeName);
        AttendeeSearchPage.getPage().deleteAttendeeByName(attendeeName);
      }
    }

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-38732", chromeIssue = "RA-19022")
  public void addNewEmailDomainMapping() {
    String accountName = dataGenerator.generateName();

    String emailDomain = dataGenerator.generateString(4).concat(".com");
    String attendeeFirstName = dataGenerator.generateName();
    String attendeeLastName = dataGenerator.generateString();
    String attendeeEmail = dataGenerator.generateName() + "@" + emailDomain;

    // Create an Account
    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.addItem();
    adminNewAccountPage.fillInformation(accountName);
    adminNewAccountPage.saveAccount();

    // Add an Email Domain to new Account
    adminEditAccountPage.findAvailableMapping(emailDomain);
    adminEditAccountPage.selectNewMapping(emailDomain);

    // Create new Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.add();
    editAttendeePage.fillInformationNewAttendee(attendeeFirstName, attendeeLastName, attendeeEmail);
    editAttendeePage.saveNewAttendee();

    // Go to created Account -> Attendees tab
    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.searchFor(accountName);
    adminAccountsSearchPage.clickResult(0);
    adminEditAccountPage.goToAttendeesTab();

    // Validate that the attendee appears in the account's attendees list
    Assert.assertTrue(adminEditAccountPage.existAttendee(attendeeEmail), "Attendee has not been assigned to an account");

    // Delete Account
    adminEditAccountPage.cancel();
    adminAccountsSearchPage.deleteAccount(0);
    adminAccountsSearchPage.searchFor(accountName);
    Assert.assertFalse(adminAccountsSearchPage.existAccount(accountName), "Account has not been deleted");

    // Delete Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.deleteAttendeeByName(attendeeFirstName);
    attendeeSearchPage.searchFor(attendeeEmail);
    Assert.assertFalse(attendeeSearchPage.findAttendeeByText(attendeeEmail), "Attendee has not been deleted");
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-37841", chromeIssue = "RA-37840")
  public void addCompanyName() {
    String accountName = dataGenerator.generateName();
    String companyName = dataGenerator.generateName();
    String attendeeFirstName = dataGenerator.generateName();
    String attendeeLastName = dataGenerator.generateString();
    String attendeeEmail = dataGenerator.generateValidEmail();

    // Create an Account
    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.addItem();
    adminNewAccountPage.fillInformation(accountName);
    adminNewAccountPage.saveAccount();

    // Add a Company Name to new Account
    adminEditAccountPage.gotoCompanyNames();
    adminEditAccountPage.findAvailableMapping(companyName);
    adminEditAccountPage.selectNewMapping(companyName);

    // Create new Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.add();
    editAttendeePage.fillInformationNewAttendee(attendeeFirstName, attendeeLastName, attendeeEmail);
    editAttendeePage.saveNewAttendee();
    editAttendeePage.setCompany(companyName);
    editAttendeePage.saveNewAttendee();

    // Go to created Account -> Attendees tab
    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.searchFor(accountName);
    adminAccountsSearchPage.clickResult(0);
    adminEditAccountPage.goToAttendeesTab();

    // Validate that the attendee appears in the account's attendees list
    Assert.assertTrue(adminEditAccountPage.existAttendee(attendeeEmail), "Attendee has not been assigned to an account");

    // Delete Account
    adminEditAccountPage.cancel();
    adminAccountsSearchPage.deleteAccount(0);
    adminAccountsSearchPage.searchFor(accountName);
    Assert.assertFalse(adminAccountsSearchPage.existAccount(accountName), "Account has not been deleted");

    // Delete Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.deleteAttendeeByName(attendeeFirstName);
    attendeeSearchPage.searchFor(attendeeEmail);
    Assert.assertFalse(attendeeSearchPage.findAttendeeByText(attendeeEmail), "Attendee has not been deleted");
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-37870", chromeIssue = "RA-37869")
  public void accountGroupAssociation() {
    String accountName = dataGenerator.generateName();

    // Create an Account
    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.addItem();
    adminNewAccountPage.fillInformation(accountName);
    adminNewAccountPage.saveAccount();

    // Go Form1 tab
    adminEditAccountPage.goToForm1Tab();
    adminEditAccountPage.form1TabSave();
    adminEditAccountPage.cancel();

    // Validate that the account already exists for the account group
    adminAccountsSearchPage.searchFor(accountName);
    Assert.assertTrue(adminAccountsSearchPage.existAccount(accountName), "Account does not exist");
  }


  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40413", chromeIssue = "RA-40344")
  public void bulkEditAccounts() {

    // If doesn't exit, create accounts
    createAccount(testAccountName1, testEmailDomain1);
    createAccount(testAccountName2, testEmailDomain2);

    // If doesn't exit, create attendees
    createAttendee(testAttendeeEmail1);
    createAttendee(testAttendeeEmail2);

    // If some attributes hasn't been shown in Attendee's left bar, show them
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(testAttendeeEmail1);
    attendeeSearchPage.clickResult(0);

    List<String> unseenAttributes = new ArrayList<>();
    for(String attribute: attributes){
      if(!editAttendeePage.isAttributeVisible(attribute))
        unseenAttributes.add(attribute);
    }

    if(!unseenAttributes.isEmpty()){
      editAttendeePage.openAttendeeFormModal();
      for(String unseenAttribute: unseenAttributes){
        editAttendeePage.addAttribute(unseenAttribute);
      }
      editAttendeePage.submitModalAttributes();
      editAttendeePage.saveAttendeeProfile();
    }

    adminAccountsSearchPage.navigate();
    adminAccountsSearchPage.searchFor(testDesc);
    adminAccountsSearchPage.openMoreActions();
    adminAccountsSearchPage.clickBulkEditAction();

    // Adding Attributes to Bulk Edit options
    String attributeValueName1 = attributeValuesPEP_FLAG.get(dataGenerator.getNumber(0, 1));
    String attributeValueName2 = attributeValuesAccountCategory.get(dataGenerator.getNumber(0, 2));
    String attributeValueName3 = dataGenerator.generateName();


    adminAccountBulkEditPage.chooseAttribute(attributes.get(0));
    adminAccountBulkEditPage.selectAttributeValue(attributeValueName1, "Add", 1);
    adminAccountBulkEditPage.addNewAttribute();

    adminAccountBulkEditPage.chooseAttribute(attributes.get(1));
    adminAccountBulkEditPage.selectAttributeValue(attributeValueName2, "Add", 2);
    adminAccountBulkEditPage.addNewAttribute();

    adminAccountBulkEditPage.chooseAttribute(attributes.get(2));
    adminAccountBulkEditPage.writeAttributeValue(attributeValueName3, "Add", 3);
    adminAccountBulkEditPage.change();

    // Validate in Attendees profile that attribute values has changed
    validateAttributeValues(testAttendeeEmail1, attributeValueName1, attributeValueName2, attributeValueName3);
    validateAttributeValues(testAttendeeEmail2, attributeValueName1, attributeValueName2, attributeValueName3);
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-43822", chromeIssue = "RA-37941")
  public void attendeeHasExistingCompanyNameWhenAccountIsCreated() {
    String accountName = dataGenerator.generateName();

    String firstName = dataGenerator.generateName();
    String lastName = dataGenerator.generateName();
    String email = firstName + "." + lastName + dataGenerator.generateString(5) + "@" + accountName + ".com";

    CreateAttendeePage.getPage().navigate();
    CreateAttendeePage.getPage().fillOutForm(email, firstName, lastName);

    attendeeNamesToDelete.add(firstName);

    AdminNewAccountPage.getPage().navigate();
    AdminNewAccountPage.getPage().fillInformation(accountName);
    AdminNewAccountPage.getPage().saveAccount();

    accountNamesToDelete.add(accountName);

    String emailMapping = accountName + ".com";

    AdminEditAccountPage.getPage().findAvailableMapping(emailMapping);
    AdminEditAccountPage.getPage().selectNewMapping(emailMapping);

    AdminEditAccountPage.getPage().goToAttendeesTab();
    softAssert.assertTrue(AdminEditAccountPage.getPage().existAttendee(email), "Attendee should exist on the account");

    softAssert.assertAll();
  }

  private void validateAttributeValues(String attendeeEmail, String attributeValueName1, String attributeValueName2, String attributeValueName3){

    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.clickResult(0);
    Assert.assertTrue(editAttendeePage.existAttributeValue(attributes.get(0), attributeValueName1));
    Assert.assertTrue(editAttendeePage.existAttributeValue(attributes.get(1), attributeValueName2));
    Assert.assertTrue(editAttendeePage.existAttributeValue(attributes.get(2), attributeValueName3));
  }

  private void createAttendee(String attendeeEmail){

    String attendeeFirstName = dataGenerator.generateName();
    String attendeeLastName = dataGenerator.generateString();

    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    if(!attendeeSearchPage.isAnySearchResults()){
      attendeeSearchPage.navigate();
      attendeeSearchPage.add();
      editAttendeePage.fillInformationNewAttendee(attendeeFirstName, attendeeLastName, attendeeEmail);
      editAttendeePage.saveNewAttendee();
    }
  }

  private void createAccount(String accountName, String emailDomain){

    adminAccountsSearchPage.navigate();

    adminAccountsSearchPage.searchFor(accountName);
    if(!adminAccountsSearchPage.existAccount(accountName))
    {
      adminAccountsSearchPage.addItem();
      adminNewAccountPage.fillInformation(accountName);
      adminNewAccountPage.saveAccount();

      adminEditAccountPage.findAvailableMapping(emailDomain);
      adminEditAccountPage.selectNewMapping(emailDomain);
    }
  }
}

