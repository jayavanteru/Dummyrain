package admin.Content.Pigeonhole;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.events.virtual.PigeonHoleEditSession;
import apps.events.virtual.PigeonHoleLiveDashboardPage;
import apps.events.virtual.PigeonHoleLogin;
import apps.events.virtual.PigeonHoleSessionPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

public class PigeonHoleEventSettings {
    AdminApp admin = new AdminApp();
    String sessionId;
    String sessionName;
    DataGenerator dg = new DataGenerator();
    String scheduledRoom;
    DateTime scheduledSessionStartDateTime;
    DateTime scheduledSessionEndDateTime;
    PersistentProfileForm leftForm;
    final AdminSchedulingTab schedulingTab = AdminSchedulingTab.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        //make sure we have all pigeonhole Q&A enabled
        final LegacyEventSettings eventSettings = LegacyEventSettings.getPage();
        eventSettings.navigate(PropertyReader.instance().getProperty("eventId"));
        eventSettings.enableAllPigeonholeQA();
        eventSettings.clickSubmit();

        sessionId = admin.createSession(sessionName = dg.generateName());
        EditSessionPage.getPage().navigate(sessionId);

        leftForm = PersistentProfileForm.getPage();
        leftForm.setTextAttribute("Times Offered", "1");
        leftForm.setSelectAttribute("Status", "Accepted");
        leftForm.setSelectAttribute("Webinar Profile", "Brightcove");
        leftForm.clickCheckBoxValue("Session Published?", "Yes");
        EditSessionPage.getPage().setSessionLength("30 minutes");

        schedulingTab.navigate(sessionId);

        schedulingTab.clickAddSessionButton();
        schedulingTab.enablePigeonHole();
        schedulingTab.enableQA();
        final ArrayList<String> days = schedulingTab.getDays();
        schedulingTab.scheduleSessionNamedDay("PigeonHole Event Day");

        scheduledRoom = schedulingTab.getScheduledRoom();
        scheduledSessionStartDateTime = schedulingTab.getScheduledDateTimeStart();
        scheduledSessionEndDateTime = schedulingTab.getScheduledDateTimeEnd();

    }

    @AfterClass
    public void cleanup() {
        //reset the event settings
        final LegacyEventSettings eventSettings = LegacyEventSettings.getPage();
        eventSettings.navigate(PropertyReader.instance().getProperty("eventId"));
        eventSettings.enableAllPigeonholeQA();
        eventSettings.clickSubmit();

        PigeonHoleLiveDashboardPage.getPage().navigateToPigeonholeAgendaConstellations();
        PigeonHoleLiveDashboardPage.getPage().deleteSession(sessionName);

        PageConfiguration.getPage().navigateTo(admin.getHost());

        AdminSchedulingTab.getPage().navigate(sessionId);
        AdminSchedulingTab.getPage().deleteAllSessions();

        //change settings
        leftForm.setSelectAttribute("Status", "New");
        leftForm.clickCheckBoxValue("Session Published?", "Yes");
        leftForm.submit();

        Utils.sleep(1000, "let the session changes save");

        admin.deleteSession(sessionId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-39616", firefoxIssue = "RA-52100")
    public void pigeonHoleSessionSettings() {
        final PigeonHoleLiveDashboardPage pigeondash = PigeonHoleLiveDashboardPage.getPage();
        final PigeonHoleEditSession pigeonEdit = PigeonHoleEditSession.getPage();

        PigeonHoleLogin.getPage().loginToPigeonhole();
        pigeondash.navigateToPigeonholeAgendaConstellations();
        pigeondash.editAgendaSession(sessionName);

        final String purl = PageConfiguration.getPage().getCurrentUrl();
        final HashMap<String, String> sessionInfo = pigeonEdit.getSessionInfo();
        Assert.assertEquals(sessionInfo.get("name").split("\\[")[0].trim(), sessionName, "pigeonhole wrong session");
        Assert.assertEquals(sessionInfo.get("location"), scheduledRoom, "pigeon hole has the wrong location");
        Assert.assertEquals(sessionInfo.get("start"), scheduledSessionStartDateTime.toString(), "different start time");
        Assert.assertEquals(sessionInfo.get("end"), scheduledSessionEndDateTime.toString(), "different end time");

        final List<String> checkedQA = pigeonEdit.getCheckedQA();
        pigeonEdit.save();

        //disabling Q&A options on the event
        final LegacyEventSettings eventSettings = LegacyEventSettings.getPage();
        eventSettings.navigate(PropertyReader.instance().getProperty("eventId"));
        eventSettings.disableAllPigeonholeQA();
        eventSettings.clickSubmit();

        //rescheduling session
        schedulingTab.navigate(sessionId);
        schedulingTab.editSession();
        schedulingTab.setTimeByOrder(5);
        schedulingTab.setRoomByOrder(5);
        schedulingTab.clickSaveSessionButton();
        schedulingTab.clickRescheduleButton();
        Utils.sleep(2000, "changing session time can take a second to populate");

        scheduledRoom = schedulingTab.getScheduledRoom();
        scheduledSessionStartDateTime = schedulingTab.getScheduledDateTimeStart();
        scheduledSessionEndDateTime = schedulingTab.getScheduledDateTimeEnd();

        PageConfiguration.getPage().navigateTo(purl);

        final List<String> checkedQA1 = pigeonEdit.getCheckedQA();
        Assert.assertNotEquals(checkedQA1, checkedQA, "did not update the Q&A event setting change");
        //the one is question votes, is always an option
        Assert.assertEquals(checkedQA1.size(), 1, "disabled all Q&A but some are still showing in pigeonhole");

        final HashMap<String, String> sessionInfoEdot = pigeonEdit.getSessionInfo();
        Assert.assertEquals(sessionInfoEdot.get("name").split("\\[")[0].trim(), sessionName, "pigeonhole wrong session");
        Assert.assertEquals(sessionInfoEdot.get("location"), scheduledRoom, "pigeon hole has the wrong location");
        Assert.assertEquals(sessionInfoEdot.get("start"), scheduledSessionStartDateTime.toString(), "different start time");
        Assert.assertEquals(sessionInfoEdot.get("end"), scheduledSessionEndDateTime.toString(), "different end time");
        Assert.assertNotEquals(sessionInfoEdot, sessionInfo, "after rescheduling pigeonhole did not update");
    }
}
