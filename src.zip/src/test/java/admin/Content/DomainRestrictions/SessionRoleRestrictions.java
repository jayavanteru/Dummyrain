package admin.Content.DomainRestrictions;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.NewSessionRolesPage;
import apps.admin.adminPageObjects.content.SessionRolesSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;

public class SessionRoleRestrictions
{
  private static final String NO_EMAIL_DOMAINS_ERROR_PRESENT = "Expected to find an error on the email domains text input";
  private static final String UNEXPECTED_EMAIL_DOMAINS_ERROR = "Did not expect to find an error on the email domains text input";
  private AdminApp adminApp;
  private NewSessionRolesPage sessionRolePage;
  private SessionRolesSearchPage sessionRolesSearchPage;
  private DataGenerator dataGenerator;
  private String roleid = null;

  @BeforeClass
  public void adminSetup()
  {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus","Trogdor Automation");

    // create a session role
    sessionRolePage = NewSessionRolesPage.getPage();
    sessionRolesSearchPage = SessionRolesSearchPage.getPage();
    dataGenerator = new DataGenerator();
  }

  @AfterClass
  public void tearDown() {
    PageConfiguration.getPage().quit();
  }

  @BeforeMethod
  private  void pageSetup () {
    // ensure we're on the sessionRolePage with a fresh state for every test
    sessionRolePage.navigate();
    PageConfiguration.getPage().waitForPageLoad();
    PageConfiguration.getPage().refreshPage();
  }

  @AfterMethod
  public void cleanup() {
    if (roleid != null) {
      sessionRolesSearchPage.deleteRoleById(roleid);
    }
  }

  private void fillOutRequiredSessionRoleFields()
  {
    String roleName = dataGenerator.generateName();
    String description = dataGenerator.generateString();

    Utils.sleep(500);
    sessionRolePage.setRoleName(roleName);
    sessionRolePage.setRoleDescription(description);
  }

  private void handleCleaningUpCreatedSessionRole (String roleName) {
    // wait to get to the search page
    sessionRolesSearchPage.waitForPageLoad();
    sessionRolesSearchPage.searchFor(roleName);
    Utils.waitForTrue(()->sessionRolesSearchPage.getResults().get(0).equals(roleName));
    Assert.assertEquals(sessionRolesSearchPage.getResults().get(0), roleName, "search result did not find the right role");
    boolean isDeleted = sessionRolesSearchPage.deleteRoleById(sessionRolesSearchPage.getTopResultId());
    Assert.assertTrue(isDeleted);
    roleid = null;
  }

  private void handleSelectingSearchPageRole (String roleName) {
    // wait to get to the search page
    sessionRolesSearchPage.waitForPageLoad();
    sessionRolesSearchPage.searchFor(roleName);
    Utils.waitForTrue(()->sessionRolesSearchPage.getResults().get(0).equals(roleName));
    Assert.assertEquals(sessionRolesSearchPage.getResults().get(0), roleName, "search result did not find the right role");
    roleid = sessionRolesSearchPage.getTopResultId();
    sessionRolesSearchPage.clickResult(0);
    // wait for the sessionRole page to load
    PageConfiguration.getPage().waitForPageLoad();
  }

  /**
   * A simple role can be created upon visiting the page
   */
  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19640", firefoxIssue = "RA-20965")
  public void sessionRole_simpleRoleCreation () {
    String roleName = dataGenerator.generateName();
    String description = dataGenerator.generateString();

    sessionRolePage.setRoleName(roleName);
    sessionRolePage.setRoleDescription(description);
    sessionRolePage.clickSaveButton();
    handleCleaningUpCreatedSessionRole(roleName);
  }

  /**
   * A simple role can be edited
   */
  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19642", firefoxIssue = "RA-20964")
  public void sessionRole_simpleRoleEdit () {
    SessionRolesSearchPage searchPage = SessionRolesSearchPage.getPage();
    String roleName = dataGenerator.generateName();
    String roleName2 = dataGenerator.generateName();
    String description = dataGenerator.generateString();

    sessionRolePage.setRoleName(roleName);
    sessionRolePage.setRoleDescription(description);
    sessionRolePage.clickSaveButton();

    searchPage.searchFor(roleName);
    Utils.waitForTrue(()->searchPage.getResults().size() <= 1);
    Assert.assertEquals(searchPage.getResults().get(0), roleName, "search result did not find the right role");
    roleid = sessionRolesSearchPage.getTopResultId();
    searchPage.clickResult(0);

    sessionRolePage.setRoleName(roleName2);
    sessionRolePage.clickSaveButton();

    searchPage.searchFor(roleName);
    Utils.waitForTrue(()->searchPage.getResults().size() <= 1);
    List<String> results = searchPage.getResults();
    Assert.assertEquals(results.size(), 0, "if it changed the name then there should be no results");

    searchPage.searchFor(roleName2);
    Utils.waitForTrue(()->sessionRolesSearchPage.getResults().get(0).equals(roleName));
    results = searchPage.getResults();
    Assert.assertEquals(results.get(0), roleName2, "search result did not find the right role");

    handleCleaningUpCreatedSessionRole(roleName2);
  }

  /**
   * Verifying the email field only accepts valid emails and throws appropriate errors
   */
  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-26793", firefoxIssue = "RA-26794")
  public void sessionRoles_EmailDomainVerification () {
    sessionRolePage.clickEmailDomainsCheckbox();
    sessionRolePage.setEmailDomains("@cisco.com, @rainfocus.com");

    Assert.assertEquals(sessionRolePage.getEmailDomains(), "@cisco.com,@rainfocus.com");


    // Singular Bad Email Domain
    sessionRolePage.setEmailDomains("cisco");
    sessionRolePage.clickSaveButton();

    String expectedError = "Domain 1 is not a valid domain.";
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageIs(expectedError));

    // Email Domain Error Clears When Text Box Changes
    sessionRolePage.setEmailDomains("@cisco");
    sessionRolePage.clickSaveButton();

    // expect problem
    Assert.assertFalse(sessionRolePage.assertEmailDomainsErrorMessageNotShowing());
    // expect problem fixed
    sessionRolePage.setEmailDomains(".com");
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageNotShowing());

    // Multiple Bad Email Domains
    sessionRolePage.setEmailDomains("@cisco,@hello");
    sessionRolePage.clickSaveButton();

    String MultipleBadDomainsError = "Domain 1 is not a valid domain. Domain 2 is not a valid domain.";
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageIs(MultipleBadDomainsError));

    // Second Domain Good
    sessionRolePage.setEmailDomains("@cisco,@hello.com");
    sessionRolePage.clickSaveButton();
    Assert.assertFalse(sessionRolePage.assertEmailDomainsErrorMessageNotShowing(), NO_EMAIL_DOMAINS_ERROR_PRESENT);

    String BadDomainOneError = "Domain 1 is not a valid domain.";
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageIs(BadDomainOneError));

    // First Domain Good
    sessionRolePage.setEmailDomains("@cisco.com,@hello");
    sessionRolePage.clickSaveButton();
    Assert.assertFalse(sessionRolePage.assertEmailDomainsErrorMessageNotShowing(), NO_EMAIL_DOMAINS_ERROR_PRESENT);

    String BadDomainTwoError = "Domain 2 is not a valid domain.";
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageIs(BadDomainTwoError));

    // Illegal Trailing Comma
    sessionRolePage.setEmailDomains("@cisco.com,@hello.com,");
    sessionRolePage.clickSaveButton();

    String IllegalCommaError = "Domain 3 is empty. It looks like there are too many commas.";
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageIs(IllegalCommaError));

    // Two Good Domains
    fillOutRequiredSessionRoleFields();
    String roleNameOne = sessionRolePage.getRoleName();

    sessionRolePage.setEmailDomains("@cisco.com,@hello.com");
    sessionRolePage.clickSaveButton();
    Assert.assertTrue(sessionRolePage.assertEmailDomainsErrorMessageNotShowing(), UNEXPECTED_EMAIL_DOMAINS_ERROR);

    handleCleaningUpCreatedSessionRole(roleNameOne);

    // Filling out Domain doesn't save when checkbox isn't selected
    sessionRolePage.navigate();
    fillOutRequiredSessionRoleFields();
    String roleNameTwo = sessionRolePage.getRoleName();

    // click to show text input, fill out, click to hide, then save the page
    sessionRolePage.clickEmailDomainsCheckbox();
    sessionRolePage.setEmailDomains("@cisco.com");
    sessionRolePage.clickEmailDomainsCheckbox();
    sessionRolePage.clickSaveButton();

    // navigate back to the page for the role
    sessionRolesSearchPage.waitForPageLoad();
    handleSelectingSearchPageRole(roleNameTwo);

    // are we on the correct page?
    Assert.assertEquals(sessionRolePage.getRoleName(), roleNameTwo);

    // clicking the checkbox should reveal an empty input
    sessionRolePage.clickEmailDomainsCheckbox();
    Assert.assertEquals(sessionRolePage.getEmailDomains(), "");

    // fill it out again
    sessionRolePage.setEmailDomains("@cisco.com");
    sessionRolePage.clickSaveButton();
    handleSelectingSearchPageRole(roleNameTwo);

    // are we on the correct page and this time the value is maintained
    Assert.assertEquals(sessionRolePage.getRoleName(), roleNameTwo);
    Assert.assertEquals(sessionRolePage.getEmailDomains(), "@cisco.com");

    // cleanup
    sessionRolePage.clickCancelButton();
    handleCleaningUpCreatedSessionRole(roleNameTwo);
  }
}
