package admin.Content.DomainRestrictions;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;


public class SessionLengthsAutomation
{
  private AdminApp adminApp;
  private AttendeeSearchPage attendeeSearchPage;
  private EditSessionPage editSessionPage;
  private AttendeeScheduleTab attendeeScheduleTab;
  private AdminSchedulingTab adminSchedulingTab;
  private DataGenerator generator;
  private AdminSessionParticipantsTab adminSessionParticipantsTab;
  private SessionAddParticipant sessionAddParticipant;
  private NewLengthPage newLengthPage;
  private LengthsSearchPage lengthsSearchPage;
  private SessionSearchPage sessionSearchPage;

  private int sessionLengthId;
  private String sessionId;

  @BeforeClass
  public void setup () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
    adminApp = new AdminApp();
    generator = new DataGenerator();

    newLengthPage = NewLengthPage.getPage();
    lengthsSearchPage = LengthsSearchPage.getPage();
    editSessionPage = EditSessionPage.getPage();
    sessionSearchPage = SessionSearchPage.getPage();
  }

  @AfterClass
  public void closeBrowser () {
    adminApp.deleteSession(sessionId);
    adminApp.deleteSessionLength(sessionLengthId);
    PageConfiguration.getPage().quit();
  }

  @Test (groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19192", firefoxIssue = "RA-22262")
  public void verifyingSessionLengths () {

    newLengthPage.navigate();
    sessionLengthId = generator.generateNumber(600);
    String newSessionDisplayValue = generator.generateName();
    newLengthPage.setLength(Integer.toString(sessionLengthId));
    newLengthPage.setDisplayValue(newSessionDisplayValue);
    newLengthPage.clickSubmitButton();

    sessionId = adminApp.createSessionWithLength(sessionLengthId);

    lengthsSearchPage.navigate();
    lengthsSearchPage.searchFor(Integer.toString(sessionLengthId));
    boolean isDisabledDeletedIcon = lengthsSearchPage.isDisabledDeletedIcon(Integer.toString(sessionLengthId));
    Assert.assertTrue(isDisabledDeletedIcon,"Delete icon is not disabled for this length (display value) " + newSessionDisplayValue);

    editSessionPage.navigate(sessionId);
    editSessionPage.waitForPageLoad();

    editSessionPage.setSessionLength("1 hour");


    lengthsSearchPage.navigate();
    lengthsSearchPage.searchFor(Integer.toString(sessionLengthId));

    isDisabledDeletedIcon = lengthsSearchPage.isDisabledDeletedIcon(Integer.toString(sessionLengthId));
    Assert.assertFalse(isDisabledDeletedIcon,"Delete icon is disabled for this length (display value) " + newSessionDisplayValue);
  }
}

