package admin.Content.DomainRestrictions;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.NewSessionRolesPage;
import testHelp.DataGenerator;

// TODO: All annotations in here commented until ready to do tests for story RA-18196
public class SessionParticipationRestrictions
{
  private AdminApp adminApp;
  private AdminSessionParticipantsTab sessionParticipantsTab;
  private NewSessionRolesPage sessionRolesPage;

  private DataGenerator dataGenerator;

//  @BeforeClass
  public void setup () {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    dataGenerator = new DataGenerator();
    sessionRolesPage = NewSessionRolesPage.getPage();
    sessionParticipantsTab = AdminSessionParticipantsTab.getPage();

  }

//  @AfterClass
  public void tearDown () {
    PageConfiguration.getPage().quit();
  }

  // NOTE: WE NUKED OUR SELECTORS IN SessionParticipantsTab. USE OR ADD SELECTORS TO SessionAddParticipant instead when we do these tests.
//  @Test
  public void sessionParticipants_EmailDomainRestrictionRespected () {
//    // create session
//    String sessionTitle = dataGenerator.generateString();
//    String sessionId = adminApp.createSession(sessionTitle);
//
//    // create sessionRole
//    String sessionRoleName = dataGenerator.generateString();
//    sessionRolesPage.navigate();
//    PageConfiguration.getPage().waitForPageLoad();
//    sessionRolesPage.setRoleName(sessionRoleName);
//    sessionRolesPage.clickEmailDomainsCheckbox();
//    String emailDomains = "@rainfocus.com";
//    sessionRolesPage.setEmailDomains(emailDomains);
//    sessionRolesPage.clickSaveButton();
//    PageConfiguration.getPage().waitForPageLoad();
//
//    // create an attendee
//    // TODO race condition here
//    String email = dataGenerator.generateEmail();
//    Utils.sleep(1500);
//    String attendeeId = adminApp.createAttendee(email);
//    Utils.sleep(2000);
//
//    // TODO: possible race condition here
//    // try to add a participant
//    sessionParticipantsTab.navigate(sessionId);
//    PageConfiguration.getPage().waitForPageLoad();
//    sessionParticipantsTab.clickAddParticipantButton();
//
//    // fill out participant email
//    sessionParticipantsTab.clickParticipantsSearchDropdown();
//    sessionParticipantsTab.setParticipantsSearchDropdownValue(email);
//    /*
//     TODO: select the user after the search happens. you'll need a POJO selector in sessionParticipantsTab
//      also verify if company name was filled out in the modal
//    */
//
//    // fill out session role
//    /*
//     TODO: could not find this dropdown on the page
//      also need to select the role after the search happens. you'll need a POJO selector in sessionParticipantsTab
//    */
//    sessionParticipantsTab.clickParticipantsRoleDropdown();
//    sessionParticipantsTab.setParticipantsRoleDropdownValue(sessionRoleName);
//
//    sessionParticipantsTab.clickSubmitParticipantsModal();
//    String error = sessionParticipantsTab.getSubmissionErrorMessage();
//
//    Assert.assertTrue(error.contains(emailDomains));
//
//    // todo either create a participant with a good domain or create a new test to do the "good" test
//
//    // do final save
//    sessionParticipantsTab.clickAddParticipantButton();
//    Assert.assertTrue(sessionParticipantsTab.waitForParticipantsModalToHide());
  }

  /**
   * The user has no override permissions at all, and the role they’re trying to add will accept no more people
   */
//  @Test
  public void mock1 () { }

  /**
   * The person has the override permission, but not the override domains and they’re sending a bad domain to the endpoint
   */
//  @Test
  public void mock2 () { }

  /**
   * The person has the override domain permission, but not the override participant roles. this should be the same as the first case, they should get the message that says that the role is full. No message about domain emails should be given.
   */
//  @Test
  public void mock3 () { }

  /**
   * The person has both permissions and they get both errors at the same time.
   */
//  @Test
  public void mock4 () { }

  /**
   * There are no problems, no errors are spit out (with override permissions)
   */
//  @Test
  public void mock5 () { }

  /**
   * There are no problems, no errors are spit out (without override permissions)
   */
//  @Test
  public void mock6 () { }
}
