package admin.Content.DomainRestrictions;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AttendeeScheduleAttendedSearch;
import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class SessionParticipantScheduleConflicts
{
  private AdminApp adminApp;
  private AttendeeSearchPage attendeeSearchPage;
  private EditSessionPage editSessionPage;
  private AttendeeScheduleTab attendeeScheduleTab;
  private AttendeeScheduleAttendedSearch attendeeScheduleAttendedSearch;
  private AdminSchedulingTab adminSchedulingTab;
  private DataGenerator generator;
  private AdminSessionParticipantsTab adminSessionParticipantsTab;
  private SessionAddParticipant sessionAddParticipant;
  private SessionSearchPage sessionSearchPage;

  private String dayId = "";
  private String attendeeId = "";
  private String idSession01 = "";
  private String idSession02 = "";
  private String room2 = "";
  private String room1 = "";

  @BeforeClass
  public void setup () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    adminApp = new AdminApp();
    generator = new DataGenerator();

    attendeeSearchPage = AttendeeSearchPage.getPage();
    attendeeScheduleTab = AttendeeScheduleTab.getPage();
    attendeeScheduleAttendedSearch = AttendeeScheduleAttendedSearch.getPage();

    editSessionPage = EditSessionPage.getPage();
    adminSchedulingTab = AdminSchedulingTab.getPage();
    adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    sessionAddParticipant = SessionAddParticipant.getPage();

    sessionSearchPage = SessionSearchPage.getPage();
  }

  @AfterClass
  public void closeBrowser () { PageConfiguration.getPage().quit(); }

  @AfterMethod
  public void cleanup() {
    if (attendeeId != null) adminApp.deleteAttendee(attendeeId);
    if (idSession01!= null) {
        adminSchedulingTab.navigate(idSession01);
        PageConfiguration.getPage().refreshPage();
        adminSchedulingTab.deleteAllSessions();
        adminApp.deleteSession(idSession01);}
    if (idSession02 != null) {
        adminSchedulingTab.navigate(idSession02);
        PageConfiguration.getPage().refreshPage();
        adminSchedulingTab.deleteAllSessions();
        adminApp.deleteSession(idSession02);}
    if (room1 != null) adminApp.deleteSessionRoom(room1);
    if (room2 != null) adminApp.deleteSessionRoom(room2);
    if (dayId != null) SessionDaysSearchPage.getPage().deleteSessionDayById(dayId);
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-25225", firefoxIssue = "RA-25226")
  public void verifyingScheduleConflictsExistInTimesDropdown () {

      String dayName = generator.generateName();
      dayId = adminApp.createDay(dayName, generator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY), generator.generateString());
      String time1 = "07:00 AM";
      String time2 = "08:00 AM";
      room1 = adminApp.createSessionRoom(generator.generateName());

      String participantEmail = generator.generateValidEmail();
      attendeeId = adminApp.createAttendee(participantEmail);

      idSession01 = adminApp.createSessionWithLength(30);
      editSessionPage.waitForPageLoad();
      String codeSession01 = editSessionPage.getSessionCode();
      editSessionPage.setSessionStatus("Accepted");
      adminSchedulingTab.scheduleSessionTime(dayName, time1, room1);

      adminSessionParticipantsTab.navigate(idSession01);
      adminSessionParticipantsTab.clickAddParticipantButton();
      sessionAddParticipant.addParticipantDontSubmit(participantEmail, "Speaker");
      sessionAddParticipant.setCompanyName();
      String lastNameParticipant = sessionAddParticipant.getLastName();
      sessionAddParticipant.submit();

      idSession02 = adminApp.createSessionWithLength(30);
      editSessionPage.waitForPageLoad();
      editSessionPage.getSessionCode();
      editSessionPage.setSessionStatus("Accepted");
      adminSchedulingTab.scheduleSessionTime(dayName, time2, room1);

      adminSessionParticipantsTab.navigate(idSession02);
      adminSessionParticipantsTab.clickAddParticipantButton();
      sessionAddParticipant.addParticipant(participantEmail);

      editSessionPage.waitForPageLoad();
      adminSchedulingTab.clickScheduleTab();
      adminSchedulingTab.editSession();

      int timeConflictsSize = adminSchedulingTab.getTimeConflictsSize(lastNameParticipant, codeSession01);
      Assert.assertTrue(timeConflictsSize > 0, "The number of times with conflicts are not greater than zero. Got " + timeConflictsSize);

      adminSchedulingTab.clickCancelButton();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-20808", firefoxIssue = "RA-21818")
  public void verifyingScheduleConflictsForAttendees() {

      String dayName = generator.generateName();
      dayId = adminApp.createDay(dayName, generator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY), generator.generateString());
      String time2 = "08:00 AM";
      String time3 = "10:00 AM";

      room1 = adminApp.createSessionRoom(generator.generateName());
      room2 = adminApp.createSessionRoom(generator.generateName());

      String attendeeEmail = generator.generateValidEmail();
      attendeeId = adminApp.createAttendee(attendeeEmail);

      idSession02 = adminApp.createSessionWithLength(30);
      editSessionPage.waitForPageLoad();
      String codeSession02 = editSessionPage.getSessionCode();
      editSessionPage.setSessionStatus("Accepted");
      adminSchedulingTab.scheduleSessionTime(dayName, time2, room1);

      idSession01 = adminApp.createSessionWithLength(30);
      editSessionPage.waitForPageLoad();
      String codeSession03 = editSessionPage.getSessionCode();
      editSessionPage.setSessionStatus("Accepted");
      adminSchedulingTab.scheduleSessionTime(dayName, time3, room2);

      attendeeScheduleTab.navigate(attendeeId);
      attendeeScheduleTab.clickEnrolledTab();
      attendeeScheduleTab.clickShowOnlyEnrolledCheckbox();
      attendeeScheduleTab.toggleScheduleDaySelect(dayName);
      attendeeScheduleTab.clickScheduleTimeRow(time2);
      attendeeScheduleTab.addSessionTimeToEnroll(codeSession02);
      Utils.sleep(2000);
      attendeeScheduleTab.clickScheduleTimeRow(time3);
      attendeeScheduleTab.addSessionTimeToEnroll(codeSession03);

      adminSchedulingTab.navigate(idSession02);
      adminSchedulingTab.editSession();
      adminSchedulingTab.setTime(time3);
      adminSchedulingTab.setRoomByRoomId(room1);
      adminSchedulingTab.clickSaveSessionButton();
      adminSchedulingTab.clickAttendeesWarning();

      int attendeesWarningSize = adminSchedulingTab.getAttendeesWarningSize();
      Assert.assertTrue(attendeesWarningSize > 0, "The number of attendees on warning message are not greater than zero. Got " + attendeesWarningSize);

      int csvSize = adminSchedulingTab.clickDownloadButton();
      int rowsSize = adminSchedulingTab.getAttendeeConflictsSize();
      Assert.assertEquals(csvSize, rowsSize, "The number of results are not the same. Expected " + rowsSize + " but instead got " + csvSize);

      adminSchedulingTab.clickAttendeesWithScheduleConflictsCheckBox();
      adminSchedulingTab.clickRescheduleButton();
  }
}
