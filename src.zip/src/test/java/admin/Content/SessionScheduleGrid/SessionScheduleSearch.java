package admin.Content.SessionScheduleGrid;

import apps.PageConfiguration;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.OrgEventSettings;
import apps.admin.adminPageObjects.content.SessionSchedulePage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class SessionScheduleSearch {

    @BeforeClass
    public void schedulePage() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        SessionSchedulePage.getPage().navigate();
    }

    @AfterClass
    public void close() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(firefoxIssue = "RA-52026", chromeIssue = "RA-19685")
    public void filterSessions() {
        final SessionSchedulePage sessionSchedulePage = SessionSchedulePage.getPage();

        sessionSchedulePage.moveToBeginningOfDays();

        //search room filter (doing this first so easier to see scheduled sessions)
        final List<String> originalRooms = sessionSchedulePage.getRooms();

        sessionSchedulePage.filterRooms("presentation");

        PageConfiguration.getPage().justWait();
        final List<String> filteredRooms = sessionSchedulePage.getRooms();
        Assert.assertNotEquals(filteredRooms, originalRooms, "filter rooms did not filter");


        //before filters
        final List<String> nonFilteredAvailableSessions = sessionSchedulePage.getAvailableSessions();
        final List<Map<String, String>> originalAllScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        int disabledCount = (int) originalAllScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();

        Assert.assertEquals(disabledCount, 0, "no scheduled sessions should be disabled yet");

        //session filters
        sessionSchedulePage.filterSessions(new Criteria("Status", "equal to", "Accepted"),
                new Criteria("Status", "not equal to", "Cancelled"),
                new Criteria("Length", "equal to", "1 hour"));

        final List<Map<String, String>> filteredScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        disabledCount = (int) filteredScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();

        Assert.assertTrue(disabledCount > 0, "sessions should be disabled after filters");
        Assert.assertEquals(filteredScheduledSessions.size(), originalAllScheduledSessions.size(), "there are less scheduled sessions after filter (they should only be disabled)");
        List<String> filteredAvailableSessions = sessionSchedulePage.getAvailableSessions();
        Assert.assertNotEquals(filteredAvailableSessions, nonFilteredAvailableSessions, "the filter did not remove any sessions");
        Assert.assertTrue(filteredAvailableSessions.size() > 0, "no sessions visible after filter");


        //colors
        final List<String> originalSessionColors = sessionSchedulePage.getAllSessionColors();
        Assert.assertEquals(new HashSet<>(originalSessionColors).size(), 1, "there is more than one color on the sessions");

        sessionSchedulePage.colors("Session type");

        List<String> sessionColors = sessionSchedulePage.getAllSessionColors();
        Assert.assertNotEquals(sessionColors, originalSessionColors, "session colors did not change when enabling colors");
        Assert.assertTrue(new HashSet<>(sessionColors).size() > 1, "there is only one color on the sessions");

        //search sessions
        sessionSchedulePage.searchSessions("test");
        final List<Map<String, String>> allScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        disabledCount = (int) allScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();

        Assert.assertTrue(disabledCount > 0, "sessions should be disabled after filters");
        Assert.assertEquals(allScheduledSessions.size(), originalAllScheduledSessions.size(), "there are less scheduled sessions after filter (they should only be disabled)");
        Assert.assertNotEquals(allScheduledSessions, filteredScheduledSessions, "search did not change scheduled sessions");

        List<String> searchedSessions = sessionSchedulePage.getAvailableSessions();
        Assert.assertNotEquals(searchedSessions, filteredAvailableSessions, "search did not change the results");
        Assert.assertNotEquals(searchedSessions, nonFilteredAvailableSessions, "search did not change the results");
        Assert.assertTrue(filteredAvailableSessions.size() > 0, "no sessions visible after filter");

        //enrollment
        sessionSchedulePage.enrollment(true);

        final List<Map<String, String>> enrolledScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        disabledCount = (int) enrolledScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();
        Assert.assertTrue(disabledCount > 0, "sessions should be disabled after filters");
        Assert.assertNotEquals(enrolledScheduledSessions, allScheduledSessions, "enrollment did not disable any scheduled sessions");
        Assert.assertEquals(enrolledScheduledSessions.size(), originalAllScheduledSessions.size(), "there are less scheduled sessions after filter (they should only be disabled)");

        //search rooms
        String roomName = "Lando";

        sessionSchedulePage.searchRooms(roomName);

        PageConfiguration.getPage().justWait();
        Utils.waitForTrue(()->!sessionSchedulePage.getRooms().containsAll(filteredRooms));
        final List<String> searchedRoom = sessionSchedulePage.getRooms();
        Assert.assertEquals(searchedRoom.size(), 1, "search did not return the room");
        Assert.assertEquals(searchedRoom.get(0), roomName);

        //action refresh
        sessionSchedulePage.actionsRefresh();
        Utils.sleep(500);
        sessionSchedulePage.moveToBeginningOfDays();

        Assert.assertEquals(sessionSchedulePage.getRooms(), searchedRoom, "action refresh changed the room filters");
        Assert.assertEquals(sessionSchedulePage.getAvailableSessions(), searchedSessions, "action refresh changed the session filters");
        Assert.assertTrue(new HashSet<>(sessionSchedulePage.getAllSessionColors()).size() > 1, "action refresh changed the session colors");

        //browser refresh
        PageConfiguration.getPage().refreshPage();
        Utils.sleep(500);
        sessionSchedulePage.moveToBeginningOfDays();

        Assert.assertEquals(sessionSchedulePage.getRooms().size(), originalRooms.size(), "browser refresh kept the room filters");
        Assert.assertEquals(sessionSchedulePage.getAvailableSessions(), filteredAvailableSessions, "browser refresh changed the session filters");
        Assert.assertEquals(new HashSet<>(sessionSchedulePage.getAllSessionColors()).size(), 1, "browser refresh kept the session colors");

    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(firefoxIssue = "RA-52025", chromeIssue = "RA-52024")
    public void clearingFilters() {
        final SessionSchedulePage sessionSchedulePage = SessionSchedulePage.getPage();

        //before filters
        final List<String> nonFilteredAvailableSessions = sessionSchedulePage.getAvailableSessions();

        //session filters
        sessionSchedulePage.filterSessions(new Criteria("Length", "equal to", "1 hour"));
        Utils.waitForTrue(()->!sessionSchedulePage.getAvailableSessions().containsAll(nonFilteredAvailableSessions));
        List<String> filteredAvailableSessions = sessionSchedulePage.getAvailableSessions();
        Assert.assertNotEquals(filteredAvailableSessions, nonFilteredAvailableSessions, "the filter did not remove any sessions");
        Assert.assertTrue(filteredAvailableSessions.size() > 0, "no sessions visible after filter");
        sessionSchedulePage.clearSessionFilter();
        Utils.waitForTrue(()->sessionSchedulePage.getAvailableSessions().containsAll(nonFilteredAvailableSessions));
        Assert.assertEquals(sessionSchedulePage.getAvailableSessions(), nonFilteredAvailableSessions, "clearing filters did not reset search");

        //colors
        final List<String> originalSessionColors = sessionSchedulePage.getAllSessionColors();
        Assert.assertEquals(new HashSet<>(originalSessionColors).size(), 1, "there is more than one color on the sessions");
        sessionSchedulePage.colors("Session type");
        List<String> sessionColors = sessionSchedulePage.getAllSessionColors();
        Assert.assertNotEquals(sessionColors, originalSessionColors, "session colors did not change when enabling colors");
        Assert.assertTrue(new HashSet<>(sessionColors).size() > 1, "there is only one color on the sessions");
        sessionSchedulePage.clearColors();
        Assert.assertEquals(sessionSchedulePage.getAllSessionColors(), originalSessionColors, "colors did not reset when cleared");

        //search sessions
        sessionSchedulePage.searchSessions("test");
        Utils.waitForTrue(()->!sessionSchedulePage.getAvailableSessions().containsAll(nonFilteredAvailableSessions));
        List<String> searchedSessions = sessionSchedulePage.getAvailableSessions();
        Assert.assertNotEquals(searchedSessions, nonFilteredAvailableSessions, "search did not change the results");
        Assert.assertTrue(filteredAvailableSessions.size() > 0, "no sessions visible after filter");
        sessionSchedulePage.clearSessionSearch();
        Utils.waitForTrue(()->sessionSchedulePage.getAvailableSessions().containsAll(nonFilteredAvailableSessions));
        Assert.assertEquals(sessionSchedulePage.getAvailableSessions(), nonFilteredAvailableSessions, "resetting search did not clear the search");

        //enrollment
        final List<Map<String, String>> allScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        sessionSchedulePage.enrollment(true);

        final List<Map<String, String>> enrolledScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        int disabledCount = (int) enrolledScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();
        Assert.assertTrue(disabledCount > 0, "sessions should be disabled after filters");
        Assert.assertNotEquals(enrolledScheduledSessions, allScheduledSessions, "enrollment did not disable any scheduled sessions");

        sessionSchedulePage.clearEnrollment();
        Utils.sleep(500);

        final List<Map<String, String>> clearedEnrolledScheduledSessions = sessionSchedulePage.getAllScheduledSessions();
        disabledCount = (int) clearedEnrolledScheduledSessions.stream()
                .filter(sess->sess.get("status").equalsIgnoreCase("disabled"))
                .count();
        Assert.assertEquals(disabledCount, 0, "sessions should not be disabled after clearing filter");
        Assert.assertEquals(clearedEnrolledScheduledSessions, allScheduledSessions, "clearing enrollment did not reset filter");

        //search room filter
        final List<String> originalRooms = sessionSchedulePage.getRooms();
        sessionSchedulePage.filterRooms("presentation");
        Utils.sleep(500);
        final List<String> filteredRooms = sessionSchedulePage.getRooms();
        Assert.assertNotEquals(filteredRooms, originalRooms, "filter rooms did not filter");
        sessionSchedulePage.clearRoomFilteres();
        Utils.waitForTrue(()->sessionSchedulePage.getRooms().containsAll(originalRooms));
        Assert.assertEquals(sessionSchedulePage.getRooms(), originalRooms, "clear room filter did not reset search");

        //search rooms
        String roomName = "Lando";
        sessionSchedulePage.searchRooms(roomName);
        Utils.sleep(500);
        Utils.waitForTrue(()->!sessionSchedulePage.getRooms().containsAll(filteredRooms));
        final List<String> searchedRoom = sessionSchedulePage.getRooms();
        Assert.assertEquals(searchedRoom.size(), 1, "search did not return the room");
        Assert.assertEquals(searchedRoom.get(0), roomName);
        sessionSchedulePage.clearRoomSearch();
        Utils.waitForTrue(()->sessionSchedulePage.getRooms().containsAll(originalRooms));
        Assert.assertEquals(sessionSchedulePage.getRooms(), originalRooms, "clear room search did not reset search");

    }
}
