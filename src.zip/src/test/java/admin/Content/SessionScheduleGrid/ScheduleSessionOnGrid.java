package admin.Content.SessionScheduleGrid;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionSchedulePage;
import interaction.screenshots.ScreenShotImage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.Utils;

import java.util.List;
import java.util.Map;

public class ScheduleSessionOnGrid {

    SessionSchedulePage schedulePage = SessionSchedulePage.getPage();
    String sessionName;

    @BeforeMethod
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
        schedulePage.navigate();
    }

    @AfterMethod
    public void close() {
        //unschedule scheduled session
        schedulePage.escapeEditMode();
        if (sessionName != null && schedulePage.getScheduledSessions().stream()
                .anyMatch(s-> s.get("title").equals(sessionName)))
            schedulePage.unscheduleSession(sessionName);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(firefoxIssue = "RA-44701", chromeIssue = "RA-19683")
    public void scheduleSession() {
        int colorDiffAmount = 3500;
        List<String> sessions = schedulePage.getAvailableSessions();

        sessionName = sessions.get(1);
        final List<Map<String, String>> originalScheduledSessions = schedulePage.getScheduledSessions();

        String scheduledSession = originalScheduledSessions.get(0).get("title");

        //schedule a session
        schedulePage.selectUnscheduledSession(1);
        Assert.assertTrue(schedulePage.isScheduleEditMode(), "edit mode not enabled to schedule session");
        schedulePage.clickOpenSpotOnGrid();
        Utils.waitForTrue(()->!schedulePage.isScheduleEditMode());
        Assert.assertFalse(schedulePage.isScheduleEditMode(), "did not disable edit mode on schedule");
        Assert.assertEquals(schedulePage.getScheduledSessions().size(), originalScheduledSessions.size() + 1, "did not add session to the schedule");

        //select a session and check hovers, don't schedule
        schedulePage.selectUnscheduledSession(0);
        Assert.assertTrue(schedulePage.isScheduleEditMode(), "edit mode not enabled to schedule session");

        schedulePage.selectSessionToReschedule(scheduledSession);
        Assert.assertTrue(schedulePage.isScheduleEditMode(), "edit mode not enabled to schedule session");
        Assert.assertTrue(schedulePage.isSessionHoverDisabled(), "not showing the not allowed to be scheduled");

        ScreenShotImage invalidSched = schedulePage.pictureOfHoverSession();

        schedulePage.hoverOpenSpotOnGrid();
        Assert.assertFalse(schedulePage.isSessionHoverDisabled(), "valid spot to schedule, should not be disabled");

        ScreenShotImage validSched = schedulePage.pictureOfHoverSession();

        Assert.assertTrue(validSched.getDiffAmount(invalidSched) > colorDiffAmount, "valid and invalid session scheduling are not different colors");

        schedulePage.escapeEditMode();
        Assert.assertFalse(schedulePage.isScheduleEditMode(), "did not disable edit mode on schedule");

        //reschedule a session, check hover, don't schedule
        Assert.assertTrue(schedulePage.isScheduledSessionClickable(sessionName), "session should be clickable if not editing");
        schedulePage.selectSessionToReschedule(sessionName);
        Assert.assertFalse(schedulePage.isScheduledSessionClickable(sessionName), "session not disabled during reschedule");

        Assert.assertFalse(schedulePage.isSessionHoverDisabled(), "valid spot to schedule, should not be disabled");

        Assert.assertTrue(validSched.getDiffAmount(schedulePage.pictureOfHoverSession()) < colorDiffAmount, "reschedule is not showing as valid to reschedule");

        schedulePage.selectSessionToReschedule(scheduledSession);
        Assert.assertTrue(schedulePage.isScheduleEditMode(), "edit mode not enabled to schedule session");
        Assert.assertTrue(schedulePage.isSessionHoverDisabled(), "not showing the not allowed to be scheduled");

        Assert.assertTrue(invalidSched.getDiffAmount(schedulePage.pictureOfHoverSession()) < colorDiffAmount, "reschedule is not showing as invalid to reschedule when overlapping");

        schedulePage.escapeEditMode();
        Assert.assertFalse(schedulePage.isScheduleEditMode(), "did not disable edit mode on schedule");
        Assert.assertTrue(schedulePage.isScheduledSessionClickable(sessionName), "session should be clickable if not editing");
        Assert.assertFalse(schedulePage.isHoverSessionEnabled(), "still hovering with a session after escape");
    }
}
