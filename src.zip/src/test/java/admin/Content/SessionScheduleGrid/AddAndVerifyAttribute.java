package admin.Content.SessionScheduleGrid;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSchedulePage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.libraries.FormsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class AddAndVerifyAttribute {

    private String sessionUrl;
    private String abstractText;
    private boolean cleanUp = false;
    private boolean abstractCleanUp = false;
    private final String DAY_NAME = "Saturday, 3rd";
    private final String ABBREVIATED_DAY = "Sat, Dec 3";
    private final String ROOM = "1606336266902001P5tw"; // Titan
    private final String TIME = "10:00 AM";
    private final String SESSION = "Session Grid Test Session";
    private final String FORM_CODE = "scheduleSettingsForm";
    private final String[] ATTRIBUTES = {"Times Offered", "Status", "Abstract", "Type", "Submitter Name"};

    private final EditSessionPage sessionEdit = EditSessionPage.getPage();
    private final FormsSearchPage formSearch = FormsSearchPage.getPage();
    private final EditFormPage formEdit = EditFormPage.getPage();
    private final SessionSchedulePage grid = SessionSchedulePage.getPage();

    @BeforeClass
    public void setUp() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        cleanUpForm();
        setUpSession();
    }

    @AfterClass
    public void tearDown() {
        if(cleanUp) {
            cleanUpForm();
        }
        if(abstractCleanUp) {
            PageConfiguration.getPage().navigateTo(sessionUrl);
            sessionEdit.setAbstract(abstractText.replaceAll("Automation", "").trim());
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-44341", chromeIssue = "RA-19700")
    public void verifyAttributesOnGrid() {
        Utils.sleep(3000, "changes to save");
            gridOpenSessionDetails();
        String[] emptyFormAttributes = grid.getListedSessionAttributes();
        Assert.assertEquals(emptyFormAttributes[0], ATTRIBUTES[0], "Default form attribute is incorrect");
        Assert.assertEquals(emptyFormAttributes.length, 1, "With no attributes on the form, only one value should be expected");
        setUpForm();
        cleanUp = true;

            gridOpenSessionDetails();
        String[] attributes = grid.getListedSessionAttributes();
        for(int i = 0; i <= attributes.length - 1; i++) {
            Assert.assertEquals(attributes[i], ATTRIBUTES[i], ATTRIBUTES[i] + " attribute was added to form and is not displaying on the session grid details");
        }

        String[] attributeValues = grid.getListedSessionAttributeValues();
            grid.openSessionDetailsFromGrid(SESSION);
        PageConfiguration.getPage().switchToTab(1);

            abstractText = sessionEdit.getAbstract();
            String modifiedAbstractText = abstractText + " Automation";
            sessionEdit.setAbstract(modifiedAbstractText);
            abstractCleanUp = true;

        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().refreshPage();
            gridOpenSessionDetails();

        String[] newAttributeValues = grid.getListedSessionAttributeValues();
        Assert.assertNotEquals(newAttributeValues, attributeValues, "Arrays compared match and should not after abstract has been edited");
    }

    private void setUpForm() {
        formSearch.navigate();
        formSearch.search(FORM_CODE);
        formSearch.selectFormByCode(FORM_CODE);
        for(int i = 1; i <= ATTRIBUTES.length - 1; i++) {
            formEdit.addExistingAttribute(ATTRIBUTES[i]);
        }
        formEdit.submitForm();
    }

    private void cleanUpForm() {
        formSearch.navigate();
        formSearch.search(FORM_CODE);
        formSearch.selectFormByCode(FORM_CODE);
        String[] attributes = formEdit.getAttributeTitlesOnForm();
        if(attributes.length > 0) {
            formEdit.removeAllAttributes();
        }
        formEdit.submitForm();
    }

    private void setUpSession() {
        AdminSchedulingTab schedule = AdminSchedulingTab.getPage();
        SessionSearchPage sessions = SessionSearchPage.getPage();

        sessions.navigate();
        sessions.search(SESSION);
        sessions.clickResult(SESSION);
        schedule.navigate(sessionEdit.getSessionId());
        sessionUrl = PageConfiguration.getPage().getCurrentUrl();
        if(schedule.getNumScheduledTimes() > 0) {
            schedule.deleteAllSessions();
        }
        schedule.scheduleSessionTime(DAY_NAME, TIME, ROOM);
    }

    private void gridOpenSessionDetails() {
        grid.navigate();
        grid.justWait();
        grid.selectDay(ABBREVIATED_DAY);
        Assert.assertTrue(grid.isSessionOnGrid(SESSION), SESSION + " is not on the schedule grid");
        grid.openSessionDetails(SESSION);
    }
}
