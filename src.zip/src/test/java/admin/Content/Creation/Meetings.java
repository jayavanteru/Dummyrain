package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.*;
import logs.Log;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Meetings {

    private AdminApp adminApp;
    private String meetingId;
    private String meetingProgramId;

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
    }

    @AfterClass
    public void closeBrowser() {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void deleteMeeting() {
        adminApp.deleteMeeting(meetingId);
        adminApp.deleteMeetingProgram(meetingProgramId);
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-27032", chromeIssue = "RA-27031")
    public void createNewMeeting()  {
        String meetingName = "automation" + new DataGenerator().generateString(6);
        String meetingProgramName = "automation" + new DataGenerator().generateString(5);
        String meetingPrefix = "auto" + new DataGenerator().generateString(3);
        Log.info("Meeting name: " + meetingName, getClass().getName());
        Log.info("Meeting program name: " + meetingProgramName, getClass().getName());
        MeetingProgramsSearchPage searchPage = MeetingProgramsSearchPage.getPage();
        NewMeetingProgramPage newMeetingProgram = NewMeetingProgramPage.getPage();
        MeetingProgramSchedulePage schedulePage = MeetingProgramSchedulePage.getPage();
        MeetingProgramRoomsPage roomsPage = MeetingProgramRoomsPage.getPage();
        MeetingsSearchPage meetingsSearchPage = MeetingsSearchPage.getPage();
        NewMeetingPage createMeetingPage = NewMeetingPage.getPage();
        AdminMeetingScheduleTab meetingSchedulePage = AdminMeetingScheduleTab.getPage();

        //create the meeting program
        searchPage.navigate();
        searchPage.addMeetingProgram();
        meetingProgramId = newMeetingProgram.createMeetingProgram(meetingProgramName, meetingPrefix);
        schedulePage.pickOneRandomMeetingLength();
        ArrayList<String> times = schedulePage.pickSomeRandomTimes();
        schedulePage.saveAndContinue();
        schedulePage.roomsTab();
        List<String> rooms = roomsPage.pickSomeRandomRooms();
        roomsPage.saveAndContinue();
        MeetingProgramRolesPage.getPage().goToRolesTab();
        MeetingProgramRolesPage.getPage().useHostRole();
        roomsPage.saveAndContinue();
        roomsPage.goBack();
        Utils.sleep(1500);

        //create the meeting, assign the program
        meetingsSearchPage.navigate();
        Utils.sleep(1000);
        meetingsSearchPage.add();
        meetingId = createMeetingPage.createMeeting(meetingProgramName);
        Utils.sleep(1000);

        //check that schedule has those times and rooms and all that
        EditMeetingPage.getPage().setAbstract();
        EditMeetingPage.getPage().setFirstLength();
        EditMeetingPage.getPage().submit();
        PageConfiguration.getPage().refreshPage();
        meetingSchedulePage.clickScheduleTab();
        meetingSchedulePage.addSession();
        Utils.sleep(200);

        //days
        ArrayList<String> days = meetingSchedulePage.getDays();
        //days.remove("Select a day");
        ArrayList<String> expectedDays = new ArrayList<>();
        for (String time: times) {
            String day = time.split(",")[0];
            if (!expectedDays.contains(day)) expectedDays.add(day);
        }
        days.sort(String::compareToIgnoreCase); expectedDays.sort(String::compareToIgnoreCase);
        for (int i = 0; i < days.size(); ++i) {
            Assert.assertEquals(days.get(i).trim(), expectedDays.get(i).trim(), "The days from the program are not on the meeting");
        }

        //times
        for (String day : days) {
            meetingSchedulePage.setDay(day);
            meetingSchedulePage.waitForTimes();
            ArrayList<String> foundTimes = meetingSchedulePage.getTimes();
            foundTimes.remove("AVAILABLE TIMES");
            ArrayList<String> expectedTimes = new ArrayList<>();
            for (String time: times) {
                if (time.trim().startsWith(day)) {
                    Log.info("expecting time: " + day + " " + time, getClass());
                    expectedTimes.add(time.split(", ")[1].trim());
                }
            }
            foundTimes.sort(String::compareToIgnoreCase);  expectedTimes.sort(String::compareToIgnoreCase);
            Assert.assertEquals(foundTimes, expectedTimes, "The times from the program are not on the meeting");
        }

        //rooms
        List<String> actualRooms = meetingSchedulePage.getRooms();
        actualRooms.remove("AVAILABLE ROOMS");
        actualRooms.sort(String::compareToIgnoreCase); rooms.sort(String::compareToIgnoreCase);

        //the rooms now have the capacity in parenthesis after the room, just remove that for asserting
        actualRooms = Arrays.asList(Arrays.asList(actualRooms.stream().map(s->s.substring(0, s.indexOf("(") - 1)).toArray()).toArray(new String[actualRooms.size()]));
        Assert.assertEquals(actualRooms, rooms, "not the same number of rooms actual: " +
                actualRooms.stream().reduce((a,r)->a += ", " + r) + " expected rooms: " +
                rooms.stream().reduce((a,r)->a += ", " + r));
    }
}
