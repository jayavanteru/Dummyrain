package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.NewSessionRoomPage;
import apps.admin.adminPageObjects.content.RoomsSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionRoomCreation
{
  private AdminApp adminApp;
  private RoomsSearchPage roomsSearchPage;
  private NewSessionRoomPage newSessionRoomPage;
  private DataGenerator dataGenerator;
  private String roomName;
  private String roomId;

  @BeforeClass
  public void setup () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();
    adminApp = new AdminApp();
    roomsSearchPage = RoomsSearchPage.getPage();
    newSessionRoomPage = NewSessionRoomPage.getPage();
    dataGenerator = new DataGenerator();
  }

  @AfterMethod
  public void deleteRooms() {

    roomsSearchPage.searchFor(roomName);
    roomId = roomsSearchPage.getTopResultId();
    adminApp.deleteSessionRoom(roomId);
  }

  @AfterClass
  public void closeBrowser () {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-26599", chromeIssue = "RA-19276")
  public void createContentRoomWithSingleCapacity() {
    roomsSearchPage.navigate();
    roomsSearchPage.clickAdd();

    roomName = dataGenerator.generateName();
    newSessionRoomPage.setRoomName(roomName);

    int roomCapacity = dataGenerator.generateNumber();
    newSessionRoomPage.setRoomSingleCapacity(roomCapacity);

    String roomNotes = dataGenerator.generateString();
    newSessionRoomPage.setRoomNotes(roomNotes);

    newSessionRoomPage.clickSubmitButton();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-26601", chromeIssue = "RA-21347")
  public void createContentRoomWithDailyCapacity() {
    roomsSearchPage.navigate();
    roomsSearchPage.clickAdd();

    roomName = dataGenerator.generateName();
    newSessionRoomPage.setRoomName(roomName);

    newSessionRoomPage.clickToggleCapacityType();

    int roomCapacity = dataGenerator.generateNumber();
    newSessionRoomPage.setRoomDailyCapacity(roomCapacity);

    String roomNotes = dataGenerator.generateString();
    newSessionRoomPage.setRoomNotes(roomNotes);

    newSessionRoomPage.clickSubmitButton();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-26603", chromeIssue = "RA-26608")
  public void editContentRoomWithSingleCapacity() {
    roomsSearchPage.navigate();
    roomsSearchPage.clickAdd();

    roomName = dataGenerator.generateName();
    newSessionRoomPage.setRoomName(roomName);

    int roomCapacity = dataGenerator.generateNumber();
    newSessionRoomPage.setRoomSingleCapacity(roomCapacity);

    String roomNotes = dataGenerator.generateString();
    newSessionRoomPage.setRoomNotes(roomNotes);

    newSessionRoomPage.clickSubmitButton();

    roomsSearchPage.searchFor(roomName);

    // Call editRowRow
    roomsSearchPage.editItem();

    roomNotes = dataGenerator.generateString();
    newSessionRoomPage.setRoomNotes(roomNotes);

    newSessionRoomPage.clickSubmitButton();

    // Search for room again
    roomsSearchPage.searchFor(roomName);

    // Assert result row length is 1
    Assert.assertTrue(roomsSearchPage.getSearchCount() == 1);
  }
}
