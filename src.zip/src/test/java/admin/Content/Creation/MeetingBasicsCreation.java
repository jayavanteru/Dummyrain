package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.NewMeetingRoomPage;
import apps.admin.adminPageObjects.meetings.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class MeetingBasicsCreation {

    private AdminApp adminApp;
    protected DataGenerator dataGenerator;

    @BeforeClass
    public void setUp() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event D");
        dataGenerator = new DataGenerator();
    }

    @AfterClass
    public void tearDown(){
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-27027", chromeIssue = "RA-18635")
    public void createMeetingDay() {
        NewMeetingDayPage newMeetingDayPage = NewMeetingDayPage.getPage();
        newMeetingDayPage.navigate();
        newMeetingDayPage.clickSubmitButton();
        Assert.assertTrue(newMeetingDayPage.hasErrorsOnPage(), "Meeting Day saved without all info filled out");

        String dayName = dataGenerator.generateString();
        String date = dataGenerator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY);

        newMeetingDayPage.setDayName(dayName);
        newMeetingDayPage.setDate(date);
        newMeetingDayPage.clickSubmitButton();

        MeetingDaysSearchPage meetingDaysSearchPage = new MeetingDaysSearchPage();
        meetingDaysSearchPage.waitForPageLoad();
        meetingDaysSearchPage.searchFor(dayName);
        meetingDaysSearchPage.clickResult(0);

        EditMeetingDayPage editMeetingDayPage = new EditMeetingDayPage();

        Assert.assertEquals(editMeetingDayPage.getDayName(), dayName, "Day is not correct. Expected " + dayName + ". Instead got "  + editMeetingDayPage.getDayName());
        Assert.assertEquals(editMeetingDayPage.getDate(), date, "Date is not correct. Expected " + date + ". Instead got " +editMeetingDayPage.getDate());

       editMeetingDayPage.clickCancelButton();
       meetingDaysSearchPage.waitForPageLoad();
       boolean deleted = meetingDaysSearchPage.deleteMeetingDayById(meetingDaysSearchPage.getTopResultId());
       Assert.assertTrue(deleted, "Meeting day was not deleted properly");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-27028", chromeIssue = "RA-18636")
    public void createMeetingRoom() {
        NewMeetingRoomPage newMeetingRoomPage = new NewMeetingRoomPage();
        newMeetingRoomPage.navigate();
        newMeetingRoomPage.clickSubmitButton();
        Assert.assertTrue(newMeetingRoomPage.isRoomNameErrorShowingWith("This is required"), "Meeting Room saved without all info filled out");

        String meetingRoomName = dataGenerator.generateString();
        String  capacity = "5";
        String notes = dataGenerator.generateString();

        newMeetingRoomPage.setRoomName(meetingRoomName);
        newMeetingRoomPage.setRoomSingleCapacity(capacity);
        newMeetingRoomPage.setRoomNotes(notes);
        newMeetingRoomPage.clickSubmitButton();

        MeetingRoomsSearchPage meetingRoomsSearchPage = new MeetingRoomsSearchPage();
        meetingRoomsSearchPage.waitForPageLoad();
        meetingRoomsSearchPage.searchFor(meetingRoomName);
        meetingRoomsSearchPage.clickResult(0);

        EditMeetingRoomPage editMeetingRoomPage = new EditMeetingRoomPage();
        Assert.assertEquals(editMeetingRoomPage.getRoomName(), meetingRoomName, "Meeting room name does not match. Expected " + meetingRoomName + ". Instead got " + editMeetingRoomPage.getRoomName());
        Assert.assertEquals(editMeetingRoomPage.getRoomSingleCapcity(), capacity, "Meeting room capacity does not match. Expected " + capacity + ". Instead got " + editMeetingRoomPage.getRoomSingleCapcity());
        Assert.assertEquals(editMeetingRoomPage.getRoomNotes(), notes, "Meeting room notes do not match. Expected " + notes + ". Instead got " + editMeetingRoomPage.getRoomNotes());

        editMeetingRoomPage.clickCancelButton();
        meetingRoomsSearchPage.waitForPageLoad();
        boolean deleted = meetingRoomsSearchPage.deleteMeetingRoomById(meetingRoomsSearchPage.getTopResultId());
        Assert.assertTrue(deleted, "Meeting room was not deleted properly");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(firefoxIssue = "RA-27030", chromeIssue = "RA-27029")
    public void createMeetingRole() {
        NewMeetingRolePage newMeetingRolePage = new NewMeetingRolePage();
        newMeetingRolePage.navigate();

        String roleName = dataGenerator.generateString();
        String description = dataGenerator.generateString();
        newMeetingRolePage.setRoleName(roleName);
        newMeetingRolePage.setDescription(description);
        newMeetingRolePage.setRoleFunction("Host");
        newMeetingRolePage.clickSubmitButton();

        MeetingRolesSearchPage meetingRolesSearchPage = new MeetingRolesSearchPage();
        meetingRolesSearchPage.waitForPageLoad();
        meetingRolesSearchPage.searchFor(roleName);
        meetingRolesSearchPage.clickResult(0);

        EditMeetingRolePage editMeetingRolePage = new EditMeetingRolePage();
        Assert.assertEquals(editMeetingRolePage.getRoleName(), roleName, "Meeting role name does not match. Expected " + roleName + ". Instead got "+ editMeetingRolePage.getRoleName());
        Assert.assertEquals(editMeetingRolePage.getDescription(), description, "Meeting role description does not match. Expected " + description + ". Instead got" + editMeetingRolePage.getDescription());
        Assert.assertEquals(editMeetingRolePage.getRoleFunction(), "Host", "Meeting role function does not match. Expected Host. Instead got" + editMeetingRolePage.getRoleFunction());

        editMeetingRolePage.clickCancel();
        boolean deleted = meetingRolesSearchPage.deleteMeetingRoleById(meetingRolesSearchPage.getTopResultId());
        Assert.assertTrue(deleted, "Meeting role was not deleted properly");
    }
}
