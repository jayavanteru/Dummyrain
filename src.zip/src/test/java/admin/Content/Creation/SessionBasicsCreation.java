package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionDayPage;
import apps.admin.adminPageObjects.content.NewSessionDayPage;
import apps.admin.adminPageObjects.content.SessionDaysSearchPage;
import apps.admin.adminPageObjects.meetings.EditMeetingDayPage;
import apps.admin.adminPageObjects.meetings.MeetingDaysSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionBasicsCreation {

    private AdminApp adminApp = new AdminApp();
    protected DataGenerator generator;

    @BeforeClass

    public void setUp() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
        generator = new DataGenerator();
    }

    @AfterClass
    public void tearDown() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27039", chromeIssue = "RA-27038")
    public void createSessionDay() {
        NewSessionDayPage newSessionDayPage = new NewSessionDayPage();
        newSessionDayPage.navigate();
        newSessionDayPage.clickSubmitButton();
        Assert.assertTrue(newSessionDayPage.hasErrorsOnPage(), "Session day submitted when no info was filled out");


        String dayName = "automation" + generator.generateString(5);
        String date = generator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY);
        String abbreviation = generator.generateString();

        newSessionDayPage.setDayName(dayName);
        newSessionDayPage.setDate(date);
        newSessionDayPage.setAbbreviation(abbreviation);
        newSessionDayPage.clickSubmitButton();

        SessionDaysSearchPage sessionDaysSearchPage = new SessionDaysSearchPage();
        sessionDaysSearchPage.waitForPageLoad();
        sessionDaysSearchPage.searchFor(dayName);
        sessionDaysSearchPage.clickResult(0);

        EditSessionDayPage editSessionDayPage = new EditSessionDayPage();
        Assert.assertEquals(editSessionDayPage.getDayName(), dayName, "Session day name does not match");
        Assert.assertEquals(editSessionDayPage.getDate(), date, "Session day date does not match");
        Assert.assertEquals(editSessionDayPage.getAbbreviation(), abbreviation, "Session day abbreviation does not match");
        Assert.assertFalse(editSessionDayPage.isAlsoMeetingChecked());

        editSessionDayPage.clickCancelButton();
        sessionDaysSearchPage.waitForPageLoad();
        boolean deleted = sessionDaysSearchPage.deleteSessionDayById(sessionDaysSearchPage.getTopResultId());

        Assert.assertTrue(deleted, "Session day was not deleted properly");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27042", chromeIssue = "RA-27040")
    public void createAlsoMeetingDay() {
        NewSessionDayPage newSessionDayPage = new NewSessionDayPage();
        newSessionDayPage.navigate();
        newSessionDayPage.clickSubmitButton();
        Assert.assertTrue(newSessionDayPage.hasErrorsOnPage(), "Session day submitted when no info was filled out");

        String dayName = "automation" + generator.generateString(5);
        String date = generator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY);
        String abbreviation = generator.generateString();

        newSessionDayPage.setDayName(dayName);
        newSessionDayPage.setDate(date);
        newSessionDayPage.setAbbreviation(abbreviation);
        newSessionDayPage.clickAlsoMeetingCheckbox();
        newSessionDayPage.clickSubmitButton();

        SessionDaysSearchPage sessionDaysSearchPage = new SessionDaysSearchPage();
        sessionDaysSearchPage.waitForPageLoad();
        sessionDaysSearchPage.searchFor(dayName);
        sessionDaysSearchPage.clickResult(0);

        EditSessionDayPage editSessionDayPage = new EditSessionDayPage();
        Assert.assertEquals(editSessionDayPage.getDayName(), dayName, "Session day name does not match");
        Assert.assertEquals(editSessionDayPage.getDate(), date, "Session day date does not match");
        Assert.assertEquals(editSessionDayPage.getAbbreviation(), abbreviation, "Session day abbreviation does not match");
        Assert.assertTrue(editSessionDayPage.isAlsoMeetingChecked());

        editSessionDayPage.clickCancelButton();
        sessionDaysSearchPage.waitForPageLoad();
        boolean deleted = sessionDaysSearchPage.deleteSessionDayById(sessionDaysSearchPage.getTopResultId());

        Assert.assertTrue(deleted, "Session day was not deleted properly");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-18928", firefoxIssue = "RA-20225")
    public void createAlsoMeetingDayAndVerifyInMeetingDaysSearchPage()
    {
        NewSessionDayPage newSessionDayPage = new NewSessionDayPage();
        newSessionDayPage.navigate();
        newSessionDayPage.clickSubmitButton();
        Assert.assertTrue(newSessionDayPage.hasErrorsOnPage(), "Session day submitted when no info was filled out");

        String dayName = "automation" + generator.generateString(5);
        String date = generator.generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YY);
        String abbreviation = generator.generateString();

        newSessionDayPage.setDayName(dayName);
        newSessionDayPage.setDate(date);
        newSessionDayPage.setAbbreviation(abbreviation);
        newSessionDayPage.clickAlsoMeetingCheckbox();
        newSessionDayPage.clickSubmitButton();

        SessionDaysSearchPage sessionDaysSearchPage = new SessionDaysSearchPage();
        sessionDaysSearchPage.waitForPageLoad();
        sessionDaysSearchPage.searchFor(dayName);
        sessionDaysSearchPage.clickResult(0);

        EditSessionDayPage editSessionDayPage = new EditSessionDayPage();
        Assert.assertEquals(editSessionDayPage.getDayName(), dayName, "Session day name does not match");
        Assert.assertEquals(editSessionDayPage.getDate(), date, "Session day date does not match");
        Assert.assertEquals(editSessionDayPage.getAbbreviation(), abbreviation, "Session day abbreviation does not match");
        Assert.assertTrue(editSessionDayPage.isAlsoMeetingChecked());

        MeetingDaysSearchPage meetingDaysSearchPage = new MeetingDaysSearchPage();
        meetingDaysSearchPage.navigate();
        meetingDaysSearchPage.searchFor(dayName);
        meetingDaysSearchPage.waitForPageLoad();
        meetingDaysSearchPage.clickResult(0);

        EditMeetingDayPage editMeetingDayPage = new EditMeetingDayPage();
        Assert.assertEquals(editMeetingDayPage.getDayName(), dayName, "Meeting day name does not match");
        Assert.assertEquals(editMeetingDayPage.getDate(), date, "Meeting day date does not match");
        Assert.assertEquals(editMeetingDayPage.getAbbreviation(), abbreviation, "Meeting day abbreviation does not match");
        Assert.assertTrue(editMeetingDayPage.isAlsoSessionChecked());

        editMeetingDayPage.clickCancelButton();
        editMeetingDayPage.waitForPageLoad();

        boolean deletedMeetingDay = meetingDaysSearchPage.deleteMeetingDayById(meetingDaysSearchPage.getTopResultId());
        Assert.assertTrue(deletedMeetingDay, "Meeting day was not deleted properly");

        sessionDaysSearchPage.navigate();
        sessionDaysSearchPage.waitForPageLoad();
        sessionDaysSearchPage.searchFor(dayName);
        sessionDaysSearchPage.clickResult(0);
        Assert.assertEquals(editSessionDayPage.getDayName(), dayName, "Session day name does not match");
        Assert.assertEquals(editSessionDayPage.getDate(), date, "Session day date does not match");
        Assert.assertEquals(editSessionDayPage.getAbbreviation(), abbreviation, "Session day abbreviation does not match");
        Assert.assertFalse(editSessionDayPage.isAlsoMeetingChecked());

        editSessionDayPage.clickCancelButton();
        editSessionDayPage.waitForPageLoad();

        boolean deletedSessionDay = sessionDaysSearchPage.deleteSessionDayById(meetingDaysSearchPage.getTopResultId());
        Assert.assertTrue(deletedSessionDay, "Session day was not deleted properly");
    }
}
