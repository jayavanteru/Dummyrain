package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionCodesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

public class SessionCodesCreationSuffix
{
    private AdminApp adminApp;
    private SessionCodesPage sessionCodesPage;
    private EditSessionPage editSessionPage;

    private String idSession = "";

    @BeforeClass
    public void setup () {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        adminApp = new AdminApp();

        sessionCodesPage = SessionCodesPage.getPage();
        editSessionPage = EditSessionPage.getPage();
    }

    @AfterClass
    public void closeBrowser () {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void cleanup() {
        sessionCodesPage.navigate();
        sessionCodesPage.disableSuffixes();
        sessionCodesPage.clickSaveButton();

        if (idSession != null) {
          adminApp.deleteSession(idSession);
        }
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19541", firefoxIssue = "RA-22610")
    public void verifyingSuffixesOnSession () {
        sessionCodesPage.navigate();

        sessionCodesPage.enableSuffixes();
        sessionCodesPage.setSufffixEventAttribute("Session track");

        List<String> attributeValues = Arrays.asList("Data integration", "Data preparation", "Data quality", "Data virtualization", "Distributed file stores", "In-memory data fabric",
                "NoSQL databases", "Predictive analytics", "Search and knowledge discovery", "Stream analytics");
        List<String> suffixes = Arrays.asList("DI", "DP", "DQ", "DV", "DFS", "IMDF", "NOSQLDB", "PA", "SKD", "SA");

        for(int index = 0; index < attributeValues.size() ; index++)
        {
            sessionCodesPage.setAffixForAttributeValue(attributeValues.get(index), suffixes.get(index));
        }

        sessionCodesPage.clickSaveButton();

        idSession = adminApp.createSessionWithLength(45);
        editSessionPage.waitForPageLoad();
        String oldCodeSession = editSessionPage.getSessionCode();
        String newCodeSession = "";
        String expectedCodeSession = "";

        for(int index = 0; index < attributeValues.size() ; index++)
        {
            editSessionPage.setSessionTrack(attributeValues.get(index));
            newCodeSession = editSessionPage.getSessionCode();
            expectedCodeSession = oldCodeSession + suffixes.get(index);
            Assert.assertEquals(newCodeSession, expectedCodeSession, "The code for this session actually is " + newCodeSession + " and should be " + expectedCodeSession);
        }
    }
}
