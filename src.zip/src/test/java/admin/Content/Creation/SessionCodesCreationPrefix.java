package admin.Content.Creation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionCodesPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

public class SessionCodesCreationPrefix
{
    private AdminApp adminApp;
    private SessionCodesPage sessionCodesPage;
    private EditSessionPage editSessionPage;

    private String idSession = "";

    @BeforeClass
    public void setup () {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        adminApp = new AdminApp();

        sessionCodesPage = SessionCodesPage.getPage();
        editSessionPage = EditSessionPage.getPage();
    }

    @AfterClass
    public void closeBrowser () {
        PageConfiguration.getPage().quit();
    }

    @AfterMethod
    public void cleanup() {
        sessionCodesPage.navigate();
        sessionCodesPage.disablePrefixes();
        sessionCodesPage.clickSaveButton();

        if (idSession != null) {
            adminApp.deleteSession(idSession);
        }
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19527", firefoxIssue = "RA-22609")
    public void verifyingPrefixesOnSession () {
        sessionCodesPage.navigate();

        sessionCodesPage.enablePrefixes();
        sessionCodesPage.setPrefixEventAttribute("Session type");

        List<String> attributeValues = Arrays.asList("Birds of a feather", "Breakout session", "Conference session", "Demos", "Hands on Lab", "Keynote");
        List<String> prefixes = Arrays.asList("BOF", "BRK", "CONF", "DMO", "HOL", "KY");

        for(int index = 0; index < attributeValues.size() ; index++)
        {
            sessionCodesPage.setAffixForAttributeValue(attributeValues.get(index), prefixes.get(index));
        }

        sessionCodesPage.clickSaveButton();

        idSession = adminApp.createSessionWithLength(45);
        editSessionPage.waitForPageLoad();
        String oldCodeSession = editSessionPage.getSessionCode();
        String newCodeSession = "";
        String expectedCodeSession = "";

        for(int index = 0; index < attributeValues.size() ; index++)
        {
            editSessionPage.setSessionType(attributeValues.get(index));
            newCodeSession = editSessionPage.getSessionCode();
            expectedCodeSession = prefixes.get(index) + oldCodeSession;
            Assert.assertEquals(newCodeSession, expectedCodeSession, "The code for this session actually is " + newCodeSession + " and should be " + expectedCodeSession);
        }
    }
}
