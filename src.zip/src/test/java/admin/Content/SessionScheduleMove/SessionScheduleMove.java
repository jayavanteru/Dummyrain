package admin.Content.SessionScheduleMove;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSchedulePage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;


public class SessionScheduleMove {

    SessionSchedulePage schedulePage = new SessionSchedulePage();
    EditSessionPage editPage = new EditSessionPage();
    AdminSchedulingTab ast = new AdminSchedulingTab();
    String sessionTime = "11:00 AM";
    String previousTime = "11 AM";
    String roomID = "1606336125308001Prvz";
    String previousRoomName = "Delfino";
    String SessionId;
    String sessionDay = "Saturday, 3rd";
    String sessionScheduleDay = "Sat, Dec 3";
    AdminApp aa = new AdminApp();
    public String sessionTitle;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        sessionTitle = new DataGenerator().generateName();
        SessionId = aa.createSession(sessionTitle);
        ast.scheduleSessionTime(sessionDay, sessionTime, roomID);
        schedulePage.navigate();
    }

    @AfterClass
    public void teardown() {
        aa.deleteSession(SessionId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19684", firefoxIssue = "RA-50460")
    public void SessionScheduleMove() {
        //Make sure the session is on the grid
        schedulePage.selectDay(sessionScheduleDay);
        Assert.assertTrue(schedulePage.isSessionScheduled(sessionTitle), "The session is not on the grid.");

        schedulePage.selectSessionToReschedule(sessionTitle);
        //Schedule session in new spot
        schedulePage.clickOpenSpotOnGrid();
        schedulePage.clickRescheduleRoomButton();

        //check title on session page
        schedulePage.openSessionDetails(sessionTitle);
        schedulePage.openSessionDetailsFromGrid(sessionTitle);
        PageConfiguration.getPage().switchToTab(1);
        Assert.assertEquals(editPage.getSessionTitle(), sessionTitle,"The title does not match");
        ast.navigate(SessionId);

        //check time is different
        Assert.assertNotEquals(ast.getScheduledSessionTime(), sessionTime, "The session did not get moved");
        PageConfiguration.getPage().switchToTab(0);

        //schedule to a new room
        schedulePage.swapRoomButton();
        schedulePage.selectNewRoom();

        //check room is different
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        Assert.assertNotEquals(ast.getScheduledRoom(), previousRoomName, "The room did not change");
        PageConfiguration.getPage().switchToTab(0);

        //Schedule session back to old time slot
        schedulePage.selectSessionToReschedule(sessionTitle);
        schedulePage.scheduleInSpecificSlot(previousRoomName, previousTime);
        schedulePage.clickRescheduleRoomButton();
        Assert.assertTrue(schedulePage.isSessionScheduled(sessionTitle), "The session is not on the grid.");

        //check time and room are the same
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        Assert.assertEquals(ast.getScheduledSessionTime(), sessionTime, "The session did not get moved back to original spot");
        Assert.assertEquals(ast.getScheduledRoom(), previousRoomName, "The session did not move back to original room");
        PageConfiguration.getPage().switchToTab(0);

        //unschedule session
        schedulePage.unscheduleSession(sessionTitle);
        Assert.assertFalse(schedulePage.isSessionScheduled(sessionTitle));
    }
}