package admin.Content;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AreasSearchPage;
import apps.admin.adminPageObjects.content.EditAreaPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

public class Areas {

    DataGenerator gen = new DataGenerator();

    protected String roomName;
    protected String roomId;
    private AdminApp admin;
    protected String areaId;

    final AreasSearchPage areasPage = AreasSearchPage.getPage();
    final EditAreaPage editPage = EditAreaPage.getPage();

    @BeforeClass
    public void Setup() {
        admin = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        roomName = gen.generateName();
        roomId = admin.createSessionRoom(roomName);
    }

    @AfterClass
    public void areaTeardown() {
        admin.deleteAreaApi(areaId);
        admin.deleteSessionRoom(roomId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-20458", firefoxIssue = "RA-21395")
    public void AddArea() {
        //Test adding a Area and searching for it
        areasPage.navigate();
        areasPage.addItem();
        String areaName = gen.generateName();
        editPage.setName(areaName);
        editPage.setAvailable(roomName);
        editPage.addRemove(roomName);
        editPage.save();
        areaId = areasPage.getId(areaName);
        //Verify the Area has been created and appears in the search
        assertTrue(areasPage.isSearchPopulated(),"The Area '" + areaName + "' should be in the search results");

        //Verify the delete icon is not available due to a room being added
        assertFalse(areasPage.isDeletable(areaName), "The delete icon should not be present due to a room being added");

        areasPage.editArea(areaName);
        editPage.setSelected(roomName);
        editPage.addRemove(roomName);
        editPage.save();
        //Verify the delete icon is available due to the room being removed
        assertTrue(areasPage.isDeletable(areaName), "The delete icon should be present due to the room being removed");

        areasPage.clear();
        areasPage.deleteArea(areaName);
        areasPage.waitForPageLoad();
        areasPage.search(areaName);
        //Verify the area is deleted and the search returns no results
        assertTrue(areasPage.isSearchEmpty(),"The search results should return with no results");
    }

    @Test(groups = {ReportingInfo.ONSITE})
    @ReportingInfo(chromeIssue = "RA-23072", firefoxIssue = "RA-23073")
    public void EditArea() {
        areasPage.navigate();
        areasPage.addItem();
        editPage.waitForPageLoad();
        editPage.save();
        //Verify error message for required field appears
        assertTrue(editPage.hasRequired(), "An error message should appear stating a field is required");

        //Verify session created is available to select from the list
        assertTrue(editPage.isRoomAvailable(roomName), "The session '" + roomName + "' is not located in the available list");

        editPage.setAvailable(roomName);
        editPage.addRemove(roomName);
        editPage.setSelected(roomName);
        //Verify the room is added to the selected room list
        assertTrue(editPage.isRoomSelected(roomName), "The room '" + roomName + "' was not added to the selected list");

        editPage.addRemove(roomName);
        //Verify the room is removed from the selected room list and added to the available list
        assertTrue(editPage.isRoomAvailable(roomName),"The room '" + roomName + "' was not removed from the selected list");

        editPage.addAll();
        //Verify the room is added to the selected list using add all
        assertTrue(editPage.isRoomSelected(roomName),"The room '" + roomName + "' was not added to the selected list using add all");

        editPage.removeAll();
        //Verify the room is removed from the selected room list and added to the available list using remove all
        assertTrue(editPage.isRoomAvailable(roomName),"The room '" + roomName + "' was not removed from the selected list using remove all");

    }
}
