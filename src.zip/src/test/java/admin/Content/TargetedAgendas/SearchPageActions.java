package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.events.eventsPageObjects.WidgetTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.HashSet;
import java.util.Set;

import static org.testng.Assert.*;

public class SearchPageActions
{
    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String attendeeEmail;
    private String attendeeId;
    private final String GROUP_NAME = "Search Page Actions Test Group";

    private PageConfiguration pageConfiguration = PageConfiguration.getPage();
    private TargetedAgendaGroupsPage adminAgendaGroupsPage = TargetedAgendaGroupsPage.getPage();
    private TargetedAgendasPage adminAgendasPage = TargetedAgendasPage.getPage();
    private WorkflowTargetedAgendaSearchPage workflowAgendaSearchPage = WorkflowTargetedAgendaSearchPage.getPage();
    private WorkflowTargetedAgendaPage workflowAgendaPage = WorkflowTargetedAgendaPage.getPage();
    private WidgetTargetedAgendaPage widgetAgendaPage = WidgetTargetedAgendaPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        attendeeEmail = generator.generateEmail();
        attendeeId = adminApp.createAttendee(attendeeEmail);
        adminAgendaGroupsPage.navigate();
        adminAgendaGroupsPage.selectGroup(GROUP_NAME);

        String[] agendaIds = adminAgendasPage.getAgendaIds();
        adminAgendasPage.cleanUpAutomationAgendas(agendaIds);

        adminAgendasPage.addNewAgenda();
        adminAgendasPage.spoofInAsAttendee(attendeeEmail);
        PageConfiguration.getPage().switchToTab(1);
        workflowAgendaSearchPage.closeCookie();
    }

    @AfterClass
    public void delete() {
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-23250", firefoxIssue = "RA-45428")
    public void searchPageActions() {
        String searchByNameAgenda = "Search By Name Agenda";
        String searchByInternalNotesAgenda = "TA";
        String internalNotes = "Internal notes";
        String newAgenda = generator.generateName();

        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByNameAgenda), "expected agenda '" + searchByNameAgenda + "' to be visible");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByInternalNotesAgenda), "expected agenda '" + searchByInternalNotesAgenda + "' to be visible");

        workflowAgendaSearchPage.filterAgendas(searchByNameAgenda);
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByNameAgenda), "expected agenda '" + searchByNameAgenda + "' to be visible");
        assertTrue(workflowAgendaSearchPage.waitForAgendaNotOnPage(searchByInternalNotesAgenda), "expected agenda '" + searchByInternalNotesAgenda + "' to not be visible");

        workflowAgendaSearchPage.filterAgendas(internalNotes);
        assertTrue(workflowAgendaSearchPage.waitForAgendaNotOnPage(searchByNameAgenda), "expected agenda '" + searchByNameAgenda + "' to not be visible");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByInternalNotesAgenda), "expected agenda '" + searchByInternalNotesAgenda + "' to be visible");

        workflowAgendaSearchPage.clearSearch();
        assertEquals(workflowAgendaSearchPage.getSearchText(), "");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByNameAgenda), "expected agenda '" + searchByNameAgenda + "' to be visible");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByInternalNotesAgenda), "expected agenda '" + searchByInternalNotesAgenda + "' to be visible");

        workflowAgendaSearchPage.previewAgenda(searchByNameAgenda, 2);
        assertEquals(widgetAgendaPage.getTitle(), searchByNameAgenda, "preview did not open agenda '" + searchByNameAgenda + "'");
        pageConfiguration.switchToTab(1);
        workflowAgendaSearchPage.openAgendaLink(searchByNameAgenda, 2);
        assertEquals(widgetAgendaPage.getTitle(), searchByNameAgenda, "copy paste link did not open agenda '" + searchByNameAgenda + "'");
        pageConfiguration.switchToTab(1);

        Set<String> myAgendas = new HashSet<>();

        assertTrue(workflowAgendaSearchPage.isNotCreateTargetedAgendaFailure(), "error message on workflow agenda search page should not be visible before submit");
        workflowAgendaSearchPage.openCreateNewTargetedAgendaModal();
        workflowAgendaSearchPage.createTargetedAgenda(searchByNameAgenda);
        assertTrue(workflowAgendaSearchPage.isCreateTargetedAgendaFailure(), "error message on workflow agenda search page should be visible if submitting with existing name");
        workflowAgendaSearchPage.createTargetedAgenda(newAgenda);
        myAgendas.add(newAgenda);

        workflowAgendaPage.goBack();
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda), "created agenda is not visible");
        workflowAgendaSearchPage.copyAgenda(newAgenda);
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " copy"), "agenda copy failed");
        myAgendas.add(newAgenda + " copy");
        workflowAgendaSearchPage.copyAgenda(newAgenda);
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " copy 1"), "agenda copy failed");
        myAgendas.add(newAgenda + " copy 1");
        workflowAgendaSearchPage.copyAgenda(newAgenda + " copy");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " copy copy"), "agenda copy failed");
        myAgendas.add(newAgenda + " copy copy");

        workflowAgendaSearchPage.editAgenda(newAgenda + " copy");
        workflowAgendaPage.setFocusName(newAgenda);
        assertTrue(workflowAgendaPage.errorIsNotVisible(), "error message on workflow agenda page should not be visible before submit");
        workflowAgendaPage.saveChanges();
        assertTrue(workflowAgendaPage.errorIsVisible(), "error message on workflow agenda page should be visible if submitting with existing name");
        workflowAgendaPage.setFocusName(newAgenda + " changed");
        workflowAgendaPage.saveChanges();
        myAgendas.remove(newAgenda + " copy");
        myAgendas.add(newAgenda + " changed");
        assertTrue(workflowAgendaPage.errorIsNotVisible(), "error message on workflow agenda page should not be visible if submitting with unique name");
        workflowAgendaPage.goBack();
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " changed"), "changed agenda is not visible");


        workflowAgendaSearchPage.copyAgenda(newAgenda + " changed");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " changed copy"), "agenda copy failed");
        myAgendas.add(newAgenda + " changed copy");

        workflowAgendaSearchPage.editAgenda(newAgenda + " copy copy");
        workflowAgendaPage.setFocusName(newAgenda + " copy copy changed");
        workflowAgendaPage.saveChanges();
        myAgendas.remove(newAgenda + " copy copy");
        myAgendas.add(newAgenda + " copy copy changed");
        workflowAgendaPage.goBack();
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(newAgenda + " copy copy changed"), "changed agenda is not visible");

        pageConfiguration.switchToTab(0);
        adminAgendasPage.clickRefreshPage();
        for (String agenda: myAgendas)
            assertTrue(adminAgendasPage.textIsOnPage(agenda), "agenda '" + agenda + "' is missing from admin");

        pageConfiguration.switchToTab(1);

        workflowAgendaSearchPage.clickShowOnlyMyAgendas();
        for (String agenda: myAgendas)
            assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(agenda), "agenda '" + agenda + "' is missing from workflow agenda search page when showing only my agendas");

        assertTrue(workflowAgendaSearchPage.waitForAgendaNotOnPage(searchByNameAgenda), "agenda '" + searchByNameAgenda + "' should not be visible when showing only my agendas");
        assertTrue(workflowAgendaSearchPage.waitForAgendaNotOnPage(searchByInternalNotesAgenda), "agenda '" + searchByInternalNotesAgenda + "' should not be visible when showing only my agendas");
        workflowAgendaSearchPage.clearSearch();
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByNameAgenda), "agenda '" + searchByNameAgenda + "' should be visible when viewing all agendas");
        assertTrue(workflowAgendaSearchPage.waitForAgendaOnPage(searchByInternalNotesAgenda), "agenda '" + searchByInternalNotesAgenda + "' should not visible viewing all agendas");

        for (String agenda: myAgendas)
        {
            workflowAgendaSearchPage.deleteAgenda(agenda);
            assertTrue(workflowAgendaSearchPage.waitForAgendaNotOnPage(agenda), "agenda '" + agenda + "' should have been deleted but was not");
        }
    }
}
