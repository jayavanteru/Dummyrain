package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.*;

public class EditExistingAgenda {

    private String[] sessions;
    private boolean sessionClean;
    private boolean exhibitorClean;
    private boolean speakersClean;
    private boolean demoClean;
    private boolean activityClean;
    private final String GROUP_NAME = "Edit Agenda Group";
    private final String AGENDA_NAME = "Edit Agenda Test";
    private final String[] EXPECTED_SESSIONS = {
            "Grape",
            "Trogdor MR",
            "Trogdor Session Role MR",
            "Watermelon"};

    private TargetedAgendaGroupsPage searchGroups = TargetedAgendaGroupsPage.getPage();
    private TargetedAgendasPage agendasPage = TargetedAgendasPage.getPage();
    private WorkflowTargetedAgendaSearchPage workflowAgendaSearchPage = WorkflowTargetedAgendaSearchPage.getPage();
    private WorkflowTargetedAgendaPage workflowAgendaPage = WorkflowTargetedAgendaPage.getPage();
    private SessionSearchPage sessionSearch = SessionSearchPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        sessionSearch.navigate();
        sessionSearch.toggleAdvancedSearch();
        sessionSearch.advSearch("Session type", "equal to", "Breakout session");
        sessionSearch.advSearch2("Session technology", "equal to", "Hadoop");
        sessionSearch.search();
        sessions = sessionSearch.getSessionNames();
        Arrays.sort(sessions);

        searchGroups.navigate();
        searchGroups.selectGroup(GROUP_NAME);
        agendasPage.editAgenda(AGENDA_NAME);
        PageConfiguration.getPage().switchToTab(1);
        workflowAgendaSearchPage.closeCookie();
    }

    @AfterClass
    public void delete() {
        if(sessionClean) {
            cleanContent("Sessions");
        }
        if(exhibitorClean) {
            cleanContent("Exhibitors");
        }
        if(speakersClean) {
            cleanContent("Speakers");
        }
        if(demoClean) {
            cleanContent("Demos");
        }
        if(activityClean) {
            cleanContent("Activities");
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21613", firefoxIssue = "RA-45527")
    public void editAgenda() {
        runDescriptionAsserts();
        runSessionAsserts();
        runSimpleAsserts("Exhibitors");
        runSimpleAsserts("Speakers");
        runDemoAsserts();
        runActivityAsserts();
    }

    public void runDescriptionAsserts() {
        String sessionDescription = workflowAgendaPage.getSectionDescription();
        workflowAgendaPage.toggleSectionDescription(false);
        workflowAgendaPage.toggleSectionDescription(true);
        Assert.assertEquals(workflowAgendaPage.getSectionDescription(), "", "Section description should be empty when toggled");
        workflowAgendaPage.setSectionDescription(sessionDescription);
    }

    public void runSessionAsserts() {
        workflowAgendaPage.searchForCard("MR");
        String[] searchedSessions = workflowAgendaPage.getCards(true);
        for(int i = 0; i <= searchedSessions.length - 1; i++) {
            Assert.assertTrue(searchedSessions[i].contains("MR"), searchedSessions[i] + " did not contain the searched parameter");
        }
        workflowAgendaPage.clickClear();

        workflowAgendaPage.clickShowMoreFilters(true);
        workflowAgendaPage.selectDropDownAndSetValue("Session Type", "Breakout session");
        workflowAgendaPage.selectDropDownAndSetValue("Session technology", "Hadoop");
        workflowAgendaPage.clickSearch();

        String[] filteredSessions = workflowAgendaPage.getCards(true);
        Arrays.sort(filteredSessions);
        for(int i = 0; i <= EXPECTED_SESSIONS.length - 1; i++) {
            Assert.assertEquals(filteredSessions[i], sessions[i], "Available session did not match previously searched sessions");
            Assert.assertEquals(filteredSessions[i], EXPECTED_SESSIONS[i], "Available session did not match expected sessions");
        }
        String[] sessions = workflowAgendaPage.getCards(true);
        for(int i = 0; i <= sessions.length - 1; i++) {
            workflowAgendaPage.addCardByTitle(sessions[i]);
        }
        sessionClean = true;

        String[] addedSessions = workflowAgendaPage.getCards(false);
        String[] activeCards = workflowAgendaPage.getAddedCards();
        for(int i = 0; i <= addedSessions.length - 1; i++) {
            Assert.assertEquals(addedSessions[i], activeCards[i], "Added cards and active cards did not match");
        }

        for(int i = 0; i <= addedSessions.length - 1; i++) {
            workflowAgendaPage.removeCardByTitle(addedSessions[i], i <= 1);
            String[] added = workflowAgendaPage.getAddedCards();
            for(int x = 0; x <= added.length - 1; x++) {
                Assert.assertNotEquals(added[x], addedSessions[i], "Session card was not removed in delete method");
            }
        }
        sessionClean = false;
    }

    public void runSimpleAsserts(String content) {
        workflowAgendaPage.selectContent(content);
        workflowAgendaPage.searchForCard("");
        String[] cards = workflowAgendaPage.getCards(true);
        int count = Math.min(cards.length, 3) - 1;
        for(int i = 0; i <= count; i++) {
            workflowAgendaPage.addCardByTitle(cards[i]);
        }
        if(content.equals("Exhibitors")) exhibitorClean = true;
        else speakersClean = true;

        String[] addedCards = workflowAgendaPage.getCards(false);
        String[] activeCards = workflowAgendaPage.getAddedCards();
        for(int i = 0; i <= addedCards.length - 1; i++) {
            Assert.assertEquals(addedCards[i], activeCards[i], "Added cards and active cards did not match");
        }

        for(int i = 0; i <= addedCards.length - 1; i++) {
            workflowAgendaPage.removeCardByTitle(addedCards[i], i <= count/2);
            String[] added = workflowAgendaPage.getAddedCards();
            for(int x = 0; x <= added.length - 1; x++) {
                Assert.assertNotEquals(added[x], addedCards[i], "Session card was not removed in delete method");
            }
        }
        if(content.equals("Exhibitors")) exhibitorClean = false;
        else speakersClean = false;
    }

    public void runDemoAsserts() {
        workflowAgendaPage.selectContent("Demos");
        workflowAgendaPage.searchForCard("");
        demoMethod(false, true);
        demoMethod(true, false);
    }

    public void demoMethod(boolean available, boolean rightColumn) {
        String[] cards = workflowAgendaPage.getCards(true);
        int count = Math.min(cards.length, 3) - 1;
        for(int i = 0; i <= count; i++) {
            workflowAgendaPage.addCardByTitle(cards[i]);
        }
        demoClean = true;

        String[] addedCards = workflowAgendaPage.getCards(available);
        String[] activeCards = workflowAgendaPage.getAddedCards();
        for(int i = 0; i <= addedCards.length - 1; i++) {
            Assert.assertEquals(addedCards[i], activeCards[i], "Added cards and active cards did not match");
        }

        for(int i = 0; i <= addedCards.length - 1; i++) {
            workflowAgendaPage.removeCardByTitle(addedCards[i], rightColumn);
            String[] added = workflowAgendaPage.getAddedCards();
            for(int x = 0; x <= added.length - 1; x++) {
                Assert.assertNotEquals(added[x], addedCards[i], "Session card was not removed in delete method");
            }
        }
        demoClean = false;
    }

    public void runActivityAsserts() {
        workflowAgendaPage.selectContent("Activities");
        if(!workflowAgendaPage.hasActivity()) {
            workflowAgendaPage.createGenericActivity();
        }
        Assert.assertTrue(workflowAgendaPage.hasActivity(), "Workflow has no activity");
        workflowAgendaPage.deleteActivityByName("Work Pizza Party");
        activityClean = true;
        Assert.assertFalse(workflowAgendaPage.hasActivity(), "Activity was not deleted properly");
        workflowAgendaPage.createGenericActivity();
        Assert.assertTrue(workflowAgendaPage.hasActivity(), "Activity was not created properly");
        activityClean = false;
    }

    public void cleanContent(String content) {
        PageConfiguration.getPage().refreshPage();
        workflowAgendaPage.selectContent(content);
        if(content.equals("Activities")) {
            if(!workflowAgendaPage.hasActivity()) {
                workflowAgendaPage.createGenericActivity();
            }
        } else {
            String[] addedCards = workflowAgendaPage.getCards(false);
            for (int i = 0; i <= addedCards.length - 1; i++) {
                workflowAgendaPage.removeCardByTitle(addedCards[i], true);
            }
        }
    }
}
