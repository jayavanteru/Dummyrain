package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.events.eventsPageObjects.WidgetTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.List;
import java.util.Map;

public class CreateNewAgenda {

    private AdminApp adminApp = new AdminApp();
    private String attendeeEmail;
    private String attendeeId;
    private final String[] DESCRIPTIONS = {
            "Session Section",
            "Exhibitor Section",
            "Speaker Section",
            "Demo Section",
            "Activities Section"};
    private final String[] DESCRIPTIONS_HTML = {
            "<b>Session</b> <i>Section</i>",
            "<i>Exhib</i><b>itor Section</b>",
            "<i>Speaker</i> <b>Section</b>",
            "<b>Demo S</b><i>ection</i>",
            "<strong>Activities</strong> <em>Section</em>"
    };
    private final String[] EXPECTED_ELEMENTS = {"b", "i", "i", "b", "b", "i", "i", "b", "strong", "em"};
    private final String GROUP_NAME = "TA Building Test Group";
    private final String AGENDA_NAME = "automation agenda " + new DataGenerator().generateString(6);

    private TargetedAgendaGroupsPage searchGroups = TargetedAgendaGroupsPage.getPage();
    private TargetedAgendasPage agendasPage = TargetedAgendasPage.getPage();
    private WorkflowTargetedAgendaSearchPage workflowAgendaSearchPage = WorkflowTargetedAgendaSearchPage.getPage();
    private WorkflowTargetedAgendaPage workflowAgendaPage = WorkflowTargetedAgendaPage.getPage();
    private WidgetTargetedAgendaPage agendaWidgetPage = WidgetTargetedAgendaPage.getPage();

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        attendeeId = adminApp.createAttendee();
        attendeeEmail = EditAttendeePage.getPage().getEmail();
        searchGroups.navigate();
        searchGroups.selectGroup(GROUP_NAME);

        String[] agendaIds = agendasPage.getAgendaIds();
        agendasPage.cleanUpAutomationAgendas(agendaIds);

        agendasPage.addNewAgenda();
        agendasPage.spoofInAsAttendee(attendeeEmail);
        PageConfiguration.getPage().switchToTab(1);
        workflowAgendaSearchPage.closeCookie();
        workflowAgendaSearchPage.openCreateNewTargetedAgendaModal();
        workflowAgendaSearchPage.createTargetedAgenda(AGENDA_NAME);
    }

    @AfterClass
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21612", firefoxIssue = "RA-45303")
    public void createTargetedAgenda() {
            workflowAgendaPage.setDescription("<b>My</b> Test <i>Targeted Agenda</i>");
            workflowAgendaPage.setInternalNotes("Setting some internal notes");
            workflowAgendaPage.saveChanges();
            workflowAgendaPage.preview(2);

        Assert.assertEquals(agendaWidgetPage.getTitle(), AGENDA_NAME, "Title did not match in preview");
        Assert.assertFalse(agendaWidgetPage.textContainsBasicHTML(agendaWidgetPage.getSubHeader()), "HTML is displayed on the widget page and should not be");

        String[] tags = agendaWidgetPage.getSubHeaderHTMLElements();
        Assert.assertEquals(tags[0], "b", "bold tag was not placed properly in the HTML");
        Assert.assertEquals(tags[1], "i", "italic tag was not placed properly in the HTML");

        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();

        String[] sessions = setDescriptionAndAddCards(DESCRIPTIONS_HTML[0]);
        workflowAgendaPage.selectContent("Exhibitors");
        String[] exhibitors = setDescriptionAndAddCards(DESCRIPTIONS_HTML[1]);
        workflowAgendaPage.selectContent("Speakers");
        String[] speakers = setDescriptionAndAddCards(DESCRIPTIONS_HTML[2]);
        workflowAgendaPage.selectContent("Demos");
        String[] demos = setDescriptionAndAddCards(DESCRIPTIONS_HTML[3]);
        workflowAgendaPage.selectContent("Activities");
        setUpActivityWithDescription(DESCRIPTIONS_HTML[4]);

        workflowAgendaPage.preview(2);

        List<Map<String, String>> descriptionHTML = agendaWidgetPage.getSectionDescriptionHTML();

        int expectedIndex = 0;
        for(int i = 0; i <= descriptionHTML.size() - 1; i++) {
            Map<String, String> elements = descriptionHTML.get(i);
            for(int x = 0; x <= elements.size() - 1; x++) {
                Assert.assertEquals(elements.get("child" + x), EXPECTED_ELEMENTS[expectedIndex], "Widget did not have correct html element");
                expectedIndex++;
            }
        }

        String[] descriptions = agendaWidgetPage.getSectionDescriptions();
        assertWidgetData(descriptions[0], DESCRIPTIONS[0], DESCRIPTIONS_HTML[0]);
        assertWidgetData(descriptions[1], DESCRIPTIONS[1], DESCRIPTIONS_HTML[1]);
        assertWidgetData(descriptions[2], DESCRIPTIONS[3], DESCRIPTIONS_HTML[3]);
        assertWidgetData(descriptions[3], DESCRIPTIONS[2], DESCRIPTIONS_HTML[2]);
        assertWidgetData(descriptions[4], DESCRIPTIONS[4], DESCRIPTIONS_HTML[4]);

        for(String session : sessions) {
            Assert.assertTrue(TrogdorSessionCatalog.getPage().isSessionOnCatalog(session), "Session was not added to agenda properly");
        }
        for(String exhibitor : exhibitors) {
            Assert.assertTrue(agendaWidgetPage.isExhibitorOnAgenda(exhibitor), "Exhibitor was not added to agenda properly");
        }
        for(String speaker : speakers) {
            Assert.assertTrue(agendaWidgetPage.isSpeakerOnAgenda(speaker), "Speaker was not added to agenda properly");
        }
        for(String demo : demos) {
            Assert.assertTrue(agendaWidgetPage.isDemoOnAgenda(demo), "Demo was not added to agenda properly");
        }
        Assert.assertTrue(agendaWidgetPage.isActivityOnAgenda("Work Pizza Party"), "Activity was not added to agenda properly");
    }

    public void assertWidgetData(String description, String text, String html) {
        Assert.assertEquals(description, text, "Descriptions did not match");
        Assert.assertNotEquals(description, html, "Description on widget contained HTML");
        Assert.assertFalse(agendaWidgetPage.textContainsBasicHTML(description), "HTML is displayed on the widget page and should not be");
    }

    public String[] setDescriptionAndAddCards(String description) {
        workflowAgendaPage.toggleSectionDescription(true);
        workflowAgendaPage.setSectionDescription(description);
        workflowAgendaPage.searchForCard("");
        String[] cards = workflowAgendaPage.getCards(true);
        int count = Math.min(cards.length, 3) - 1;
        for(int i = 0; i <= count; i++) {
            workflowAgendaPage.addCardByTitle(cards[i]);
        }
        String[] addedCards = workflowAgendaPage.getCards(false);
        for(int i = 0; i <= count; i++) {
            Assert.assertEquals(cards[i], addedCards[i], "Cards selected do not match cards added");
        }
        return addedCards;
    }

    public void setUpActivityWithDescription(String description) {
        workflowAgendaPage.toggleSectionDescription(true);
        workflowAgendaPage.setSectionDescription(description);
        workflowAgendaPage.createGenericActivity();
        Assert.assertTrue(workflowAgendaPage.hasActivity(), "Activity was not added properly");
    }
}
