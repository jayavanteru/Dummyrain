package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.workflows.WorkflowEditPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.util.ArrayList;

public class WorkflowTargetedAgendaWidgetConfig {
    public AdminApp adminApp = new AdminApp();
    public WorkflowTargetedAgendaSearchPage workflowTASearch = new WorkflowTargetedAgendaSearchPage();
    public WorkflowTargetedAgendaPage wfTAPage = new WorkflowTargetedAgendaPage();
    public DataGenerator dataGenerator = new DataGenerator();
    public WorkflowEditPage wfEditPage = WorkflowEditPage.getPage("1528172904735001moL7"); //collections id
    public String oldJson;
    public String userEmail = dataGenerator.generateEmail(); //"ryan.thompson@rainfocus.com";
    public String agendaToSearchFor = "Automation" + dataGenerator.generateString(7); //"Trogdor Edit Test Agenda";
    public String workflowCollections = "collections";
    public final String SESSIONS = "Sessions";
    public final String EXHIBITORS = "Exhibitors";
    public String attendeeId;

    //Check the tabs
    public ArrayList<String> excludedData = new ArrayList<>();
    public ArrayList<String> someExcludedData = new ArrayList<>();
    public ArrayList<String> frameTabs;

    //Ensure old Json is put back
    private Boolean finished = false;
    //span[contains(@title,'Classic')] -- possible Classic Interface, but not needed

    @BeforeClass
    public void setup(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Constellations");
        //Add the tabs
        excludedData.add("Sessions");
        excludedData.add("Exhibitors");
        excludedData.add("Speakers");
        excludedData.add("Demos");
        excludedData.add("Activities");
        someExcludedData.add("Sessions");
        someExcludedData.add("Exhibitors");

        attendeeId = adminApp.createAttendee(userEmail);
        //Get the original Json and set up new Json
        wfEditPage.navigate();
        oldJson = wfEditPage.getJson();
        wfEditPage.addExcludedDataTypes(excludedData);
        wfEditPage.setComment();
        wfEditPage.submit();
    }

    @AfterClass
    public void teardown() {
        if (!finished) {
            PageConfiguration.getPage().switchToTab(0);
            wfEditPage.navigate();
            wfEditPage.setJson(oldJson.replace("\n", ""));
            wfEditPage.setComment();
            wfEditPage.submit();
        }
        wfTAPage.goBack();
        PageConfiguration.getPage().justWait();
        workflowTASearch.filterAgendas(agendaToSearchFor);
        workflowTASearch.deleteAgenda(agendaToSearchFor);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-21702", firefoxIssue = "RA-50950")
    public void WorkflowTargetedAgendaWidgetConfig() {
        //Search for your attendee and spoof into "collections" and create an agenda, search for it and click the edit icon
        adminApp.spoofIntoWorkflow(userEmail, workflowCollections, 1);
        workflowTASearch.openCreateNewTargetedAgendaModal();
        workflowTASearch.createTargetedAgenda(agendaToSearchFor);
        wfTAPage.goBack();
        PageConfiguration.getPage().justWait();
        workflowTASearch.filterAgendas(agendaToSearchFor);
        workflowTASearch.editAgenda(agendaToSearchFor);
        frameTabs = wfTAPage.TAFrameTabs();
        //Assert true that ArrayList of tab names are empty meaning all data types are excluded
        Assert.assertTrue(frameTabs.isEmpty(), "All of the tabs were not removed");

        //Check with 3 tabs removed
        excludedData.remove(SESSIONS);
        excludedData.remove(EXHIBITORS);
        JsonManipAndTATabs(true);
        Assert.assertEquals(frameTabs.size(), someExcludedData.size(), "Different number of tabs");
        Assert.assertEquals(frameTabs, someExcludedData, "The tabs do not match -- 3 tabs removed");

        //Put tabs back and replace Json with oldJson to check that all tabs are showing
        excludedData.add(0, SESSIONS);
        excludedData.add(1, EXHIBITORS);
        JsonManipAndTATabs(false);
        Assert.assertEquals(frameTabs.size(), excludedData.size(), "Different number of tabs");
        Assert.assertEquals(frameTabs, excludedData, "The tabs do not match -- no tabs removed");
        finished = true;
    }

    //Changes the Json and switches back to collections TA receives the showing tabs and stores in frameTabs ArrayList
    public void JsonManipAndTATabs(Boolean addData) {
        //Json
        PageConfiguration.getPage().switchToTab(0);
        wfEditPage.navigate();
        if (addData)
            wfEditPage.addExcludedDataTypes(excludedData);
        else
            wfEditPage.setJson(oldJson.replace("\n", ""));
        wfEditPage.setComment();
        wfEditPage.submit();
        //Collections TA
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        PageConfiguration.getPage().justWait();
        workflowTASearch.filterAgendas(agendaToSearchFor);
        workflowTASearch.editAgenda(agendaToSearchFor);
        if (!frameTabs.isEmpty())
            frameTabs.clear();
        frameTabs = wfTAPage.TAFrameTabs();
    }
}
