package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.admin.adminPageObjects.workflows.WorkflowsSearchPage;
import apps.events.eventsPageObjects.WidgetPage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import interaction.pageObjects.Page;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;

public class EditGroupSettings {
    public TargetedAgendaGroupsPage targetedAgendaGroupsPage;
    public TargetedAgendasPage targetedAgendasPage;
    public WorkflowTargetedAgendaPage workflowTargetedAgendaPage;
    public WorkflowTargetedAgendaSearchPage workflowsSearchPage;
    public WidgetPage widgetPage;

    public ArrayList<String> frameTabs = new ArrayList<>();
    public ArrayList<String> actualFrameTabs = new ArrayList<>();

    public String defaultBuilder = "\n{\"includedDataTypes\": [\"sessions\",\"exhibitors\",\"speakers\",\"demos\",\"activities\"],\"sessionFilter\": [\"\"],\"speakerFilter\": [\"\"],\"exhibitorFilter\": [\"\"],\"demoFilter\": [\"\"],\"subEventValues\": \"\",\"sponsorValues\": \"\",\"showOnlyUserAgendas\": false}";
    public String defaultAgendaOptions = "\n{\"hourFormat.javascript\": \"hh:mm a\",\"sessionDetailsOption\": \"expandSession\",\"sessionTitleConfig\": \"%title% [%code%]\",\"sessionConfig.attributeOrder\": [\"sessiontype\"],\"truncateAbstract\": false,\"loginRedirectUrl\": \"\",\"sessionConfig.expandedViewComponents\": [\"abstract\",\"speakers\",\"times\",\"attributes\"],\"layout\": \"List by Category\",\"dateFormat.java\": \"EEEE, MMM dd\",\"sessionCatalogUrl\": \"\",\"rfShowRoom\": true,\"showSessionTimes\": false,\"widgetDataFormId\": \"\",\"overrideNoSchedulerAccess\": false,\"headerBanner.show\": true,\"showSessionFilesOnPublicCatalog\": false,\"speakers.companySuffix\": \"\",\"hourFormat.java\": \"hh:mm a\",\"dateFormat.javascript\": \"dddd, MMM Do\",\"sessionConfig.hiddenAttributes\": [{\"filterID\": \"day\"},{\"filterID\": \"daytime\"}],\"fileDownloadRequiresLogin\": false,\"defaultBrandingId\": \"\",\"showFiles\": false,\"regUrl\": \"\",\"sessionConfig.showScheduleButton\": true,\"sessionTypeDisplayOrder\": {},\"sessionConfig.collapsedViewComponents\": [\"abstract\",\"speakers\",\"times\"],\"dataSetFilterCode\": \"\",\"externalLogin\": false,\"collectionSectionDescriptions\": {\"Sessions\": \"\",\"Exhibitors\": \"\",\"Demos\": \"\",\"Activities\": \"\",\"Speakers\": \"\"},\"headerTextMappings\": {\"Sessions\": \"Sessions\",\"Exhibitors\": \"Exhibitors\",\"Demos\": \"Demos\",\"Activities\": \"Activities\",\"Speakers\": \"Speakers\"}}";
    //{"includedDataTypes": ["sessions","exhibitors","speakers","demos","activities"],"sessionFilter": [""],"speakerFilter": [""],"exhibitorFilter": [""],"demoFilter": [""],"subEventValues": "","sponsorValues": "","showOnlyUserAgendas": false}
    public String newJsonBuilder = "\n{\"includedDataTypes\": [\"sessions\",\"exhibitors\",\"speakers\"],\"sessionFilter\": [\"1488231530496001CicV\"],\"speakerFilter\": [\"\"],\"exhibitorFilter\": [\"\"],\"demoFilter\": [\"\"],\"subEventValues\": \"\",\"sponsorValues\": \"1567717512579002biPk\",\"showOnlyUserAgendas\": true}";
    //{"hourFormat.javascript": "hh:mm a","sessionDetailsOption": "expandSession","sessionTitleConfig": "%title% [%code%]","sessionConfig.attributeOrder": ["sessiontype"],"truncateAbstract": false,"loginRedirectUrl": "","sessionConfig.expandedViewComponents": ["abstract","speakers","times","attributes"],"layout": "List by Category","dateFormat.java": "EEEE, MMM dd","sessionCatalogUrl": "","rfShowRoom": true,"showSessionTimes": false,"widgetDataFormId": "","overrideNoSchedulerAccess": false,"headerBanner.show": true,"showSessionFilesOnPublicCatalog": false,"speakers.companySuffix": "","hourFormat.java": "hh:mm a","dateFormat.javascript": "dddd, MMM Do","sessionConfig.hiddenAttributes": [{"filterID": "day"},{"filterID": "daytime"}],"fileDownloadRequiresLogin": false,"defaultBrandingId": "","showFiles": false,"regUrl": "","sessionConfig.showScheduleButton": true,"sessionTypeDisplayOrder": {},"sessionConfig.collapsedViewComponents": ["abstract","speakers","times"],"dataSetFilterCode": "","externalLogin": false,"collectionSectionDescriptions": {"Sessions": "","Exhibitors": "","Demos": "","Activities": "","Speakers": ""},"headerTextMappings": {"Sessions": "Sessions","Exhibitors": "Exhibitors","Demos": "Demos","Activities": "Activities","Speakers": "Speakers"}}
    //When data dup happens change the branding id to: 1642779492845001NUAa
    public String newJsonAgendaOptions = "\n{\"hourFormat.javascript\": \"hh:mm a\",\"sessionDetailsOption\": \"expandSession\",\"sessionTitleConfig\": \"%title% [%code%]\",\"sessionConfig.attributeOrder\": [\"sessiontype\"],\"truncateAbstract\": false,\"loginRedirectUrl\": \"\",\"sessionConfig.expandedViewComponents\": [\"abstract\",\"speakers\",\"times\",\"attributes\"],\"layout\": \"List by Category\",\"dateFormat.java\": \"EEEE, MMM dd\",\"sessionCatalogUrl\": \"\",\"rfShowRoom\": true,\"showSessionTimes\": false,\"widgetDataFormId\": \"\",\"overrideNoSchedulerAccess\": false,\"headerBanner.show\": true,\"showSessionFilesOnPublicCatalog\": false,\"speakers.companySuffix\": \"\",\"hourFormat.java\": \"hh:mm a\",\"dateFormat.javascript\": \"dddd, MMM Do\",\"sessionConfig.hiddenAttributes\": [{\"filterID\": \"day\"},{\"filterID\": \"daytime\"}],\"fileDownloadRequiresLogin\": false,\"defaultBrandingId\": \"1642779328800001woUI\",\"showFiles\": false,\"regUrl\": \"\",\"sessionConfig.showScheduleButton\": false,\"sessionTypeDisplayOrder\": {},\"sessionConfig.collapsedViewComponents\": [\"abstract\",\"speakers\",\"times\"],\"dataSetFilterCode\": \"\",\"externalLogin\": false,\"collectionSectionDescriptions\": {\"Sessions\": \"\",\"Exhibitors\": \"\",\"Demos\": \"\",\"Activities\": \"\",\"Speakers\": \"\"},\"headerTextMappings\": {\"Sessions\": \"Sessions\",\"Exhibitors\": \"Exhibitors\",\"Demos\": \"Demos\",\"Activities\": \"Activities\",\"Speakers\": \"Speakers\"}}";
    public String agenda = "Automation" + new DataGenerator().generateString(5);

    boolean finished = false;
    boolean TACreated = false;

    @BeforeClass
    public void setup() {
        targetedAgendaGroupsPage = TargetedAgendaGroupsPage.getPage();
        targetedAgendasPage = TargetedAgendasPage.getPage();
        workflowTargetedAgendaPage = WorkflowTargetedAgendaPage.getPage();
        widgetPage = WidgetPage.getPage();
        workflowsSearchPage = WorkflowTargetedAgendaSearchPage.getPage();
        frameTabs.add("Sessions");
        frameTabs.add("Exhibitors");
        frameTabs.add("Speakers");
        frameTabs.add("Demos");
        frameTabs.add("Activities");

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
    }

    @AfterClass
    public void teardown() {
        if (!finished) {
            targetedAgendaGroupsPage.navigate();
            targetedAgendaGroupsPage.selectGroup("Trogdor Edit Group Settings");
            targetedAgendasPage.openSettingsSlideOut();
            PageConfiguration.getPage().justWait();
            targetedAgendasPage.setAllJson(defaultBuilder.replaceAll(",",",\n"));
            PageConfiguration.getPage().justWait();
            targetedAgendasPage.openSettingsSlideOut();
            PageConfiguration.getPage().justWait();
            targetedAgendasPage.switchToSettingsTab("Agenda Options");
            targetedAgendasPage.setAllJson(defaultAgendaOptions.replaceAll(",",",\n"));
            PageConfiguration.getPage().justWait();
            if (TACreated)
                targetedAgendasPage.deleteAgenda(agenda);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-25224", firefoxIssue = "RA-52900")
    public void EditGroupSettings() {
        targetedAgendaGroupsPage.navigate();
        targetedAgendaGroupsPage.selectGroup("Trogdor Edit Group Settings");

        targetedAgendasPage.search("Trogdor Edit Group Settings Agenda");
        targetedAgendasPage.editAgenda("Trogdor Edit Group Settings Agenda");
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        workflowTargetedAgendaPage.dismissCookie();
        actualFrameTabs = workflowTargetedAgendaPage.TAFrameTabs();

        //checks default settings
        Assert.assertEquals(actualFrameTabs, frameTabs, "Incorrect frame tabs");
        Assert.assertFalse(workflowTargetedAgendaPage.isSponsorTagOnPage(), "Sponsor title is displayed");
        Assert.assertFalse(workflowTargetedAgendaPage.isShowMoreButtonOnPage(), "Show more button is on the page");
        workflowTargetedAgendaPage.preview(2);
        Assert.assertTrue(widgetPage.isScheduleButtonOnPage(), "Schedule button is not on the page");
        Assert.assertFalse(widgetPage.isBaseRFBrandingOnPage(), "Base RF branding is applied");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();

        //Checks the checkbox
        workflowTargetedAgendaPage.goBack();
        workflowsSearchPage.openCreateNewTargetedAgendaModal();
        workflowsSearchPage.createTargetedAgenda(agenda);
        TACreated = true;
        workflowTargetedAgendaPage.goBack();
        workflowsSearchPage.clickShowOnlyMyAgendas();
        Assert.assertTrue(workflowsSearchPage.didSubmitterCreateTheAgenda("Stephanie Hernandez"),"Did not filter to only my agendas");
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().justWait();

        //Set the new JSON
        targetedAgendasPage.openSettingsSlideOut();
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.setAllJson(newJsonBuilder.replaceAll(",",",\n"));
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.openSettingsSlideOut();
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.switchToSettingsTab("Agenda Options");
        targetedAgendasPage.setAllJson(newJsonAgendaOptions.replaceAll(",",",\n"));

        frameTabs.remove(frameTabs.size()-1); //Activities
        frameTabs.remove(frameTabs.size()-1); //Demos

        //Checks the new JSON settings
        targetedAgendasPage.editAgenda("Trogdor Edit Group Settings Agenda");
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        actualFrameTabs = workflowTargetedAgendaPage.TAFrameTabs();
        Assert.assertEquals(actualFrameTabs, frameTabs, "Incorrect frame tabs");
        Assert.assertTrue(workflowTargetedAgendaPage.isSponsorTagOnPage(), "Sponsor title is not displayed");
        Assert.assertTrue(workflowTargetedAgendaPage.isShowMoreButtonOnPage(), "Show more button is not on the page");
        workflowTargetedAgendaPage.preview(2);
        Assert.assertFalse(widgetPage.isScheduleButtonOnPage(), "Schedule button is on the page");
        Assert.assertTrue(widgetPage.isBaseRFBrandingOnPage(), "Base RF branding is not applied");
        PageConfiguration.getPage().close();

        //Disabled checkbox in JSON; checkbox shouldn't be present
        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().justWait();
        workflowTargetedAgendaPage.goBack();
        Assert.assertFalse(workflowsSearchPage.isShowOnlyMyAgendasAvailable(), "The checkbox is not disabled");
        Assert.assertTrue(workflowsSearchPage.didSubmitterCreateTheAgenda("Stephanie Hernandez"),"Did not filter to only my agendas");
        workflowsSearchPage.filterAgendas(agenda);
        workflowsSearchPage.deleteAgenda(agenda);
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);
        PageConfiguration.getPage().justWait();

        //reset JSON to default settings
        targetedAgendasPage.openSettingsSlideOut();
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.setAllJson(defaultBuilder.replaceAll(",",",\n"));
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.openSettingsSlideOut();
        PageConfiguration.getPage().justWait();
        targetedAgendasPage.switchToSettingsTab("Agenda Options");
        targetedAgendasPage.setAllJson(defaultAgendaOptions.replaceAll(",",",\n"));
        finished = true;
    }
}
