package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.manageUsers.SecurityRolesPage;
import interaction.webUI.DesktopAuto;
import logs.ReportingInfo;
import org.checkerframework.checker.units.qual.A;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.Utils;

public class TargetAgendaManageRoles {

    protected AdminApp adminApp;
    private EditUserPage editUserPage = EditUserPage.getPage();
    private SecurityRolesPage securityRoles = SecurityRolesPage.getPage();
    private TargetedAgendasPage agendasPage = TargetedAgendasPage.getPage();
    private TargetedAgendaGroupsPage searchGroups = TargetedAgendaGroupsPage.getPage();

    private final String TA_ID = "1586444966836001YptX";
    private final String TA_Role = "1583446095984001jjpC";
    private final String GroupName = "Trogdor Edit Group Settings";
    private final String Setting1 = "Builder";
    private final String Setting2 = "Agenda Options";
    private final String Setting3 = "Advanced";
    private final String SecurityRole1 = "Manage Targeted Agenda Settings";
    private final String SecurityRole2 = "Manage Targeted Agenda Advanced Settings";
    private final String SecurityRole3 = "Manage Targeted Agendas";

    @BeforeClass
    public void setUp()
    {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
    }

    @AfterClass
    public void endTest() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-30775", firefoxIssue = "RA-51541")
    public void TargetedAgendaManageRoles(){
        //Check to make sure the Settings buttons is clickable and all the settings are visable
        editUserPage.navigate(TA_ID);
        editUserPage.spoofIntoAdmin();
        searchGroups.navigate();
        searchGroups.selectGroup(GroupName);
        agendasPage.openSettingsSlideOut();
        Assert.assertTrue(agendasPage.textIsOnPage(Setting1), "The" +Setting1+ "setting should be displayed but it isn't");
        Assert.assertTrue(agendasPage.textIsOnPage(Setting2), "The" +Setting2+ "setting should be displayed but isn't");
        Assert.assertTrue(agendasPage.textIsOnPage(Setting3), "The" +Setting3+ "settings should be displayed but isn't");
        agendasPage.cancelSettingsSlideOut();
        Utils.sleep(3000);
        editUserPage.returnToUser();
        Utils.sleep(3000);

        //Removes the Manage Targeted Agenda Settings role and verifies that the settings button is no longer clickable
        securityRoles.navigate();
        Utils.sleep(3000);
        securityRoles.search("trogdor");
        securityRoles.editRole(TA_Role);
        securityRoles.toggleSecurityRole(SecurityRole1);
        securityRoles.saveSecurityRole();
        editUserPage.navigate(TA_ID);
        editUserPage.spoofIntoAdmin();
        searchGroups.navigate();
        PageConfiguration.getPage().justWait();
        searchGroups.selectGroup(GroupName);
        Assert.assertFalse(agendasPage.isSettingButtonOnPage(), "The settings button is displayed and it shouldn't be");
        editUserPage.returnToUser();
        Utils.sleep(3000);

        //Adds the Manage Targeted Agenda Settings role back, removes the Manage Targeted Agenda Advanced Settings role and verifies it isn't an option
        securityRoles.navigate();
        securityRoles.search("trogdor");
        securityRoles.editRole(TA_Role);
        Utils.sleep(3000);
        securityRoles.toggleSecurityRole(SecurityRole1);
        securityRoles.toggleSecurityRole(SecurityRole2);
        securityRoles.saveSecurityRole();
        editUserPage.navigate(TA_ID);
        editUserPage.spoofIntoAdmin();
        searchGroups.navigate();
        searchGroups.selectGroup(GroupName);
        agendasPage.openSettingsSlideOut();
        Assert.assertFalse(agendasPage.textIsOnPage(Setting3), "The" +Setting3+ "setting is displayed but shouldn't be" );
        Assert.assertTrue(agendasPage.textIsOnPage(Setting1), "The" +Setting1+ "setting should be displayed but it isn't");
        Assert.assertTrue(agendasPage.textIsOnPage(Setting2), "The" +Setting2+ "setting should be displayed but isn't");
        agendasPage.cancelSettingsSlideOut();
        editUserPage.returnToUser();
        Utils.sleep(3000);

        //Remove all targeted agenda roles and verifies that Targeted Agenda is not an option in the Content Menu
        securityRoles.navigate();
        securityRoles.search("trogdor");
        securityRoles.editRole(TA_Role);
        Utils.sleep(3000);
        securityRoles.toggleSecurityRole(SecurityRole1);
        securityRoles.toggleSecurityRole(SecurityRole3);
        securityRoles.saveSecurityRole();
        editUserPage.navigate(TA_ID);
        editUserPage.spoofIntoAdmin();
        Assert.assertFalse(agendasPage.isTargetedAgendaOnMenu(), "Targeted Agenda is displayed, but it should not be" );
        //Need to get the secondary navigation bar out of the way and this is what I came up with
        NavigationBar.getPage().pinSecondLevel();
        NavigationBar.getPage().unpinSecondLevel();
        editUserPage.returnToUser();
        Utils.sleep(3000);

        //Resets all roles and verifies that targeted agenda is back and all the setting options are visible
        securityRoles.navigate();
        securityRoles.search("trogdor");
        securityRoles.editRole(TA_Role);
        Utils.sleep(3000);
        securityRoles.toggleSecurityRole(SecurityRole1);
        securityRoles.toggleSecurityRole(SecurityRole2);
        securityRoles.toggleSecurityRole(SecurityRole3);
        securityRoles.saveSecurityRole();
        editUserPage.navigate(TA_ID);
        editUserPage.spoofIntoAdmin();
        searchGroups.navigate();
        searchGroups.selectGroup(GroupName);
        agendasPage.openSettingsSlideOut();
        Assert.assertTrue(agendasPage.textIsOnPage(Setting1), "The" +Setting1+ "setting should be displayed but it isn't");
        Assert.assertTrue(agendasPage.textIsOnPage(Setting2), "The" +Setting2+ "setting should be displayed but isn't");
        Assert.assertTrue(agendasPage.textIsOnPage(Setting3), "The" +Setting3+ "settings should be displayed but isn't");
        agendasPage.cancelSettingsSlideOut();
        editUserPage.returnToUser();
    }
}
