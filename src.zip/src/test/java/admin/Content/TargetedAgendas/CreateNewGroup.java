package admin.Content.TargetedAgendas;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.TargetedAgendaGroupsPage;
import apps.admin.adminPageObjects.content.TargetedAgendasPage;
import apps.admin.adminPageObjects.libraries.EditEventAttributePage;
import apps.events.eventsPageObjects.WidgetTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaPage;
import apps.workflows.workflowsPageObjects.WorkflowTargetedAgendaSearchPage;
import logs.ReportingInfo;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import static org.testng.Assert.*;

public class CreateNewGroup
{
  private DataGenerator generator = new DataGenerator();
  private AdminApp adminApp = new AdminApp();

  private PageConfiguration pageConfiguration;

  private TargetedAgendaGroupsPage targetedAgendaGroupsPage;
  private TargetedAgendasPage targetedAgendasPage;
  private WorkflowTargetedAgendaSearchPage workflowTargetedAgendaSearchPage;
  private WorkflowTargetedAgendaPage workflowTargetedAgendaPage;
  private WidgetTargetedAgendaPage widgetTargetedAgendaPage;
  private EditEventAttributePage attributePage;

  private String attendeeEmail;
  private String attendeeId;

  @BeforeClass
  public void setup() {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

    pageConfiguration = PageConfiguration.getPage();

    attendeeEmail = generator.generateEmail();
    attendeeId = adminApp.createAttendee(attendeeEmail);

    targetedAgendaGroupsPage = TargetedAgendaGroupsPage.getPage();
    targetedAgendasPage = TargetedAgendasPage.getPage();
    workflowTargetedAgendaSearchPage = WorkflowTargetedAgendaSearchPage.getPage();
    workflowTargetedAgendaPage = WorkflowTargetedAgendaPage.getPage();
    widgetTargetedAgendaPage = WidgetTargetedAgendaPage.getPage();
    attributePage = EditEventAttributePage.getPage();
  }

  @AfterClass
  public void delete() {
    adminApp.deleteAttendee(attendeeId);
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-25222", firefoxIssue = "RA-43281")
  public void CreateNewGroup()
  {
    String groupName = generator.generateName();
    String targetedAgendaName = generator.generateName();
    String focusOnDocId = "6653920997357396738";

    // Create group
    targetedAgendaGroupsPage.navigate();
    targetedAgendaGroupsPage.openAddGroupModal();
    targetedAgendaGroupsPage.addGroup("Regression Tests Group");
    assertTrue(targetedAgendaGroupsPage.failedToAddGroup());

    targetedAgendaGroupsPage.addGroup(groupName);

    // Create targeted agenda
    targetedAgendasPage.openCreateAgendaModal();
    targetedAgendasPage.spoofInAsAttendee(attendeeEmail);
    pageConfiguration.switchToTab(1);

    workflowTargetedAgendaSearchPage.openCreateNewTargetedAgendaModal();
    workflowTargetedAgendaSearchPage.createTargetedAgenda(targetedAgendaName);

    // Verify group and targeted agenda creation
    workflowTargetedAgendaPage.preview(2);
    assertTrue(Utils.waitForTrue(() -> targetedAgendaName.equals(widgetTargetedAgendaPage.getTitle())));

    targetedAgendaGroupsPage.navigate();
    assertTrue(targetedAgendaGroupsPage.groupIsOnPage(groupName));
    attributePage.navigate(focusOnDocId);
    assertTrue(attributePage.valueExists(targetedAgendaName));

    pageConfiguration.switchToTab(0);
    targetedAgendasPage.clickRefreshPage();
    assertTrue(targetedAgendasPage.textIsOnPage(targetedAgendaName));

    // Delete Group and verify deletion
    targetedAgendasPage.openSettingsSlideOut();
    targetedAgendasPage.switchToSettingsTab("Advanced");
    targetedAgendasPage.deleteCurrentGroup();

    assertFalse(targetedAgendaGroupsPage.groupIsOnPage(groupName));
    attributePage.navigate(focusOnDocId);
    assertFalse(attributePage.valueExists(targetedAgendaName));
  }
}
