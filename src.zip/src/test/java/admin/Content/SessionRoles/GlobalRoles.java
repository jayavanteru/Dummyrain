package admin.Content.SessionRoles;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.EditSessionRolesPage;
import apps.admin.adminPageObjects.content.SessionRolesSearchPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GlobalRoles {

    private boolean cleanUp = false;
    private final String ROLE = "Trogdor MR Global Role";
    private final String USERNAME = "Ryan Thompson";
    private final String RULE = "Add Ryan Thompson as Global Participant";
    private final String VALUE = "Yes";
    private final String USER_EMAIL = "ryan.thompson@rainfocus.com";
    private final String SESSION = "Trogdor MR Global Participant Session";
    private final String DUMP_ROLES = PropertyReader.instance().getProperty("adminUrl") + "/dumpGlobalSessionRoles.jsp";

    private SessionRolesSearchPage roles = SessionRolesSearchPage.getPage();
    private EditSessionRolesPage editRole = EditSessionRolesPage.getPage();

    @BeforeClass
    public void testSetup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
            roles.navigate();
            roles.searchFor(ROLE);
            roles.editItem();

        if(editRole.userHasRule(USERNAME)) {
            editRole.deleteRule(USERNAME);
            editRole.saveSessionRole();
            roles.editItem();
        }
    }

    @AfterClass
    public void testCleanup() {
        if(cleanUp) {
            roles.navigate();
            roles.clickResult(0);
            editRole.deleteRule(USERNAME);
            editRole.saveSessionRole();
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21694", firefoxIssue = "RA-39454")
    public void addRyanThompsonAsGlobalParticipant() {
            editRole.addUserAndQualifiers();
            editRole.searchAndSelectUser(USER_EMAIL);
            editRole.addRuleAttribute(RULE);
            editRole.addRuleValue(VALUE);
            editRole.saveNewRule();
            cleanUp = true;

        Assert.assertTrue(editRole.userHasRule(USERNAME), "Rule for user " + USERNAME + " was not saved");

        SessionSearchPage search = SessionSearchPage.getPage();
            search.navigate();
            search.advSearch(RULE, "equal to", VALUE);
            search.clickSearch();
            search.clickResult(SESSION);

        AdminSessionParticipantsTab tab = AdminSessionParticipantsTab.getPage();
        String sessionId = tab.getId();
            tab.navigate(sessionId);

        PageConfiguration.getPage().navigateTo(DUMP_ROLES);
        PageConfiguration.getPage().waitForPageLoad();
            tab.navigate(sessionId);

        Assert.assertTrue(tab.isGlobalParticipant(USERNAME), USERNAME + " was not added as a global participant");

            roles.navigate();
            roles.clickResult(0);
            editRole.deleteRule(USERNAME);
            editRole.saveSessionRole();
            cleanUp = false;

        PageConfiguration.getPage().navigateTo(DUMP_ROLES);
        PageConfiguration.getPage().waitForPageLoad();

            tab.navigate(sessionId);
        Assert.assertFalse(tab.isGlobalParticipant(USERNAME), USERNAME + " is a global participant and should not be");
    }
}
