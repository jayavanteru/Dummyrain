package admin.Content.SessionRoles;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.List;

public class VerifyEmailRestrictions {

    private AdminApp adminApp;
    private String attendeeId;
    private String attendeeId2;
    private String attendeeName;
    private String attendeeName2;
    private String sessionRoleUrl;
    private String email2;
    private boolean cleanUpRole = false;
    private final DataGenerator dataGenerator = new DataGenerator();
    private final String DOMAIN = "@rainfocus.com";
    private final String AUTOMATION = "Automation";
    private final String ROLE = "Trogdor Email Restriction Role";
    private final String COMPANY = "RainFocus";
    private final String SESSION_CODE = "5119";
    private final String EMAIL = dataGenerator.generateValidEmail();

    private final SessionRolesSearchPage roles = SessionRolesSearchPage.getPage();
    private final EditSessionRolesPage editRole = EditSessionRolesPage.getPage();
    private final SessionSearchPage sessions = SessionSearchPage.getPage();
    private final EditSessionPage edit = EditSessionPage.getPage();
    private final AdminSessionParticipantsTab participants = AdminSessionParticipantsTab.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
        roles.navigate();
        roles.searchFor(ROLE);
        roles.editItem();

        sessionRoleUrl = PageConfiguration.getPage().getCurrentUrl();
        editRole.restrictRoleByEmailDomain(true);
        editRole.setEmailDomain(DOMAIN);
        editRole.saveSessionRole();
        cleanUpRole = true;

        attendeeId = adminApp.createAttendee(EMAIL);
        attendeeName = EditAttendeePage.getPage().getFirstName();

        attendeeId2 = adminApp.createAttendee();
        attendeeName2 = EditAttendeePage.getPage().getFirstName();
        email2 = EditAttendeePage.getPage().getEmail();
    }

    @AfterClass
    public void cleanup() {
        if(cleanUpRole) {
            PageConfiguration.getPage().navigateTo(sessionRoleUrl);
            editRole.restrictRoleByEmailDomain(false);
            editRole.saveSessionRole();
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteAttendee(attendeeId2);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-21285", firefoxIssue = "RA-41645")
    public void verifyEmailRestrictions() {
            sessions.navigate();
            sessions.search(SESSION_CODE);
            sessions.editItem();

            edit.participantsTab();
            List<String> people = participants.getRoleParticipantNames(ROLE);
            for(String person: people) {
                if(person.contains(AUTOMATION)) {
                    participants.deleteParticipantByName(person);
                }
            }
            participants.clickAddParticipantButton();
            participants.searchExistingParticipant(EMAIL);
            participants.setCompany(COMPANY);
            participants.setParticipantRole(ROLE);
        Assert.assertTrue(participants.submitAddParticipantExpectError("Users are required to have " + DOMAIN + " email address"), "Expected error was not found");
            participants.submitAddParticipant();
        Assert.assertTrue(participants.participantScheduled(EMAIL), "Participant was not added correctly");

            participants.clickAddParticipantButton();
            participants.searchExistingParticipant(email2);
            participants.setCompany(COMPANY);
            participants.setParticipantRole(ROLE);
        Assert.assertFalse(participants.submitAddParticipantExpectError("Users are required to have " + DOMAIN + " email address"), "Expected error was not found");
        Assert.assertTrue(participants.participantScheduled(email2), "Participant was not added correctly");

            participants.deleteParticipantByName(attendeeName);
        Assert.assertFalse(participants.participantScheduled(EMAIL), "Participant was not added correctly");

            participants.deleteParticipantByName(attendeeName2);
        Assert.assertFalse(participants.participantScheduled(email2), "Participant was not added correctly");
    }
}
