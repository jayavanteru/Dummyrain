package admin.Content.SessionRoles;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.workflows.WorkflowsApp;
import apps.workflows.workflowsPageObjects.WorkflowCFPHome;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import configuration.PropertyReader;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.HashMap;
import java.util.List;

public class VerifyRoleLimit {

    private AdminApp adminApp;
    private WorkflowsApp workflowApp;
    private String attendeeId;
    private String attendeeName;
    private String sessionRoleUrl;
    private boolean cleanUpRole = false;
    private boolean sessionCleanUp = false;
    private final DataGenerator dataGenerator = new DataGenerator();
    private final String AUTOMATION = "Automation";
    private final String ROLE = "MR Test Role";
    private final String WORKFLOW_ROLE = "Role with Limit of 2 for Breakout";
    private final String ATTRIBUTE = "Breakout session";
    private final String COMPANY = "RainFocus";
    private final String SESSION = "Trogdor Session Role MR";
    private final String ABSTRACT = "Aflac";
    private final String BREAKOUT_ID = "1492531007828001Bnaf";
    private final String SELECT_DROPDOWN = "1488231530496001CicV";
    private final String BOF_ID = "1492531007828004BFCK";
    private final String TITLE = dataGenerator.generateString(6) + " Session";
    private final String EMAIL = dataGenerator.generateValidEmail();

    private final SessionRolesSearchPage roles = SessionRolesSearchPage.getPage();
    private final EditSessionRolesPage editRole = EditSessionRolesPage.getPage();
    private final SessionSearchPage sessions = SessionSearchPage.getPage();
    private final EditSessionPage edit = EditSessionPage.getPage();
    private final AdminSessionParticipantsTab participants = AdminSessionParticipantsTab.getPage();
    private final EditAttendeePage attendee = EditAttendeePage.getPage();
    private final WorkflowCFPHome cfpHome = WorkflowCFPHome.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        workflowApp = new WorkflowsApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
        roles.navigate();
        roles.searchFor(ROLE);
        roles.editItem();

        if(editRole.areThingsAdded()) {
            editRole.deleteAddedThings();
            editRole.saveSessionRole();
            roles.editItem();
        }
        sessionRoleUrl = PageConfiguration.getPage().getCurrentUrl();
        editRole.searchAttributeAndAdd(ATTRIBUTE);
        editRole.setMinRolePerSession("1");
        editRole.setMaxRolePerSession("1");
        editRole.saveSessionRole();
        cleanUpRole = true;

        attendeeId = adminApp.createAttendee(EMAIL);
        attendeeName = EditAttendeePage.getPage().getFirstName();
    }

    @AfterClass
    public void cleanup() {
        if(cleanUpRole) {
            PageConfiguration.getPage().navigateTo(sessionRoleUrl);
            editRole.deleteAddedThings();
            editRole.saveSessionRole();
        }
        if(sessionCleanUp) {
            sessions.navigate();
            sessions.search(TITLE);
            sessions.deleteBySessionTitle(TITLE);
        }
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19650", firefoxIssue = "RA-41535")
    public void verifyRoleLimit() {
            PropertyReader.instance().setProperty("event", "Trogdor Automation");
            PropertyReader.instance().setProperty("callForPapersWorkflowId", "1610576933978001q714");

        String callForPapersWorkflowIdId = PropertyReader.instance().getProperty("callForPapersWorkflowId");
        workflowApp.setupWorkflowAndGetUri(adminApp, callForPapersWorkflowIdId);

            sessions.navigate();
            sessions.search(SESSION);
            sessions.editItem();

            edit.setSessionType(ATTRIBUTE);
            edit.participantsTab();
        Assert.assertTrue(participants.roleHasParticipants(ROLE), "Session has no participants");
            List<String> people = participants.getRoleParticipantNames(ROLE);
            for(String person: people) {
                if(person.contains(AUTOMATION)) {
                    participants.deleteParticipantByName(person);
                }
            }
            participants.clickAddParticipantButton();
            participants.searchExistingParticipant(EMAIL);
            participants.setCompany(COMPANY);
            participants.setParticipantRole(ROLE);
        Assert.assertTrue(participants.submitAddParticipantExpectError("participant limit has been reached"), "Expected error was not found");
            participants.submitAddParticipant();
        Assert.assertTrue(participants.participantScheduled(EMAIL), "Participant was not added correctly");

            participants.deleteParticipantByName(attendeeName);
        Assert.assertFalse(participants.participantScheduled(EMAIL), "Participant was not added correctly");

        HashMap<String, String> customValues = new HashMap<>();
        customValues.put("formSession-title", TITLE);
        customValues.put("formSession-Abstract", ABSTRACT);
        customValues.put(SELECT_DROPDOWN, BOF_ID);

            attendee.navigate(attendeeId);
            attendee.spoofTo("cfpnobranding");

        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("cfpHome"), "Not on the correct page");
            cfpHome.closeCookie();
            cfpHome.start();
        workflowApp.fillOutFormAndSubmit("session", customValues);
            sessionCleanUp = true;

        WorkflowPage workflow = WorkflowPage.getPage();
        Assert.assertTrue(workflow.isBackButtonPresent(), "Back button is not on page but should be");
        Assert.assertTrue(workflow.isContinueButtonPresent(), "Continue button is not on page but should be");
            workflow.clickBackButton();
        Assert.assertTrue(PageConfiguration.getPage().getCurrentUrl().contains("/form/session"), "Not on the correct page");
        customValues.put(SELECT_DROPDOWN, BREAKOUT_ID);
        workflowApp.fillOutFormAndSubmit("session", customValues);

            workflow.addParticipant(EMAIL, WORKFLOW_ROLE);
        Assert.assertTrue(workflow.isBackButtonPresent(), "Back button is not on page but should be when there is a participant");
        Assert.assertTrue(workflow.isContinueButtonPresent(), "Continue button is not on page but should be when there is a participant");

            workflow.removeParticipant(attendeeName);
        Assert.assertFalse(workflow.isBackButtonPresent(), "Back button should not be visible when there are no participants");
        Assert.assertFalse(workflow.isContinueButtonPresent(), "Continue button should not be visible when there are no participants");
    }
}
