package admin.Content;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.meetings.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;
import testHelp.Utils;

public class AddingMeetingParticipant {

    private AdminApp adminApp = new AdminApp();
    DataGenerator dataGenerator = new DataGenerator();
    private String meetingId, attendeeEmail, attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Meeting Event");
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteAttendee(attendeeId);
        adminApp.deleteMeeting(meetingId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(firefoxIssue = "RA-25943", chromeIssue = "RA-25942")
    public void switchParticipantRoles() {
        setUp();

        EditMeetingPage.getPage().participantsTab();
        MeetingParticipantsTab.getPage().addExistingParticipant(attendeeEmail, "Host");

        PageConfiguration.getPage().refreshPage();
        PageConfiguration.getPage().justWait();

        Assert.assertTrue(MeetingParticipantsTab.getPage().participantIsRole(attendeeEmail, "Host"), "ATTENDEE DID NOT GET INITIAL HOST ROLE");

        MeetingParticipantsTab.getPage().clickChangeParticipantRoleById(attendeeId);
        MeetingParticipantsTab.getPage().selectNewRole("Attendee");

        Assert.assertTrue(MeetingParticipantsTab.getPage().participantIsRole(attendeeEmail, "Attendee"));
    }

    public void setUp() {
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail(), attendeeEmail, attendeeEmail);
        meetingId = adminApp.createApprovedMeeting("Meeting Program A");
    }
}
