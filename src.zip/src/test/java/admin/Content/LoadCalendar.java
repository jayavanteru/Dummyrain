package admin.Content;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.events.EventsApp;
import testHelp.DataGenerator;

public class LoadCalendar
{
  static AdminApp adminApp;
  static EventsApp eventsApp;
  private EditWidgetBuilder editWidgetBuilder;
  private WidgetBuilderSearchPage widgetBuilderSearchPage;
  private WidgetBuilderCreateWidgetModal createWidgetModal = WidgetBuilderCreateWidgetModal.getPage();
  private WidgetBuilderAddWidgetModal addWidgetModal = WidgetBuilderAddWidgetModal.getPage();
  private DataGenerator dataGenerator;

//  @BeforeClass
  public void setup () {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    eventsApp = new EventsApp();
    editWidgetBuilder = EditWidgetBuilder.getPage();
    widgetBuilderSearchPage = WidgetBuilderSearchPage.getPage();
    dataGenerator = new DataGenerator();
  }

//  @AfterClass
  public void tearDown () {
    PageConfiguration.getPage().quit();
  }

//  @BeforeMethod
  public void testSetup () {
    widgetBuilderSearchPage.navigate();
  }

  private void cleanupWidget(String widgetId) {
    widgetBuilderSearchPage.navigate();
    adminApp.deleteWidget(widgetId);
  }

// TODO: bring this test back when doing automation story RA-17299-automation
//  /**
//   * Tests that we can reach the calendar in the widgets page
//   */
//  @Test
  public void sessionCatalog_canNavigateToCalendar () {
    widgetBuilderSearchPage.addItem();
    createWidgetModal.clickCalendarType();
    createWidgetModal.clickWidgetTypeNextButton();

    String widgetName = dataGenerator.generateString();
    createWidgetModal.setWidgetName(widgetName);

    String widgetUri = dataGenerator.generateString();
    createWidgetModal.setWidgetPageUri(widgetUri);
    createWidgetModal.clickWidgetNameNextButton();

    // create typical calendar, catalog, navbar widget
    editWidgetBuilder.clickAddAWidgetButton();
    addWidgetModal.clickCatalogType();
    addWidgetModal.clickNavBarType();
    addWidgetModal.clickAddComponentButton();

    String widgetId = editWidgetBuilder.getId();
    editWidgetBuilder.clickSaveWidget();

    widgetBuilderSearchPage.searchFor(widgetName);
    widgetBuilderSearchPage.clickTopSearchResult();

    editWidgetBuilder.clickCalendarSettingsButton();

    cleanupWidget(widgetId);
    // TODO: fill out the catalog url, then try to spoof
  }
}
