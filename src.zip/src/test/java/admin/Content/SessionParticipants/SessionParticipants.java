package admin.Content.SessionParticipants;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SessionParticipants {
    DataGenerator dataGenerator = new DataGenerator();
    String attendeeEmail = dataGenerator.generateEmail();
    String sessionName = dataGenerator.generateName();


    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event F");

        //create attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().add();
        CreateAttendeePage.getPage().fillOutForm(attendeeEmail, attendeeEmail, attendeeEmail);

        //create session
        SessionSearchPage.getPage().navigate();
        SessionSearchPage.getPage().add();
        CreateSessionPage.getPage().filloutForm(sessionName, sessionName);

        //add attendee to session
        EditSessionPage.getPage().participantsTab();
        AdminSessionParticipantsTab.getPage().clickAddParticipant();
        SessionAddParticipant.getPage().addParticipant(attendeeEmail, "Submitter");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-29077", firefoxIssue = "RA-29105")
    public void sessionParticipantCriteria(){
        SessionSearchPage.getPage().navigate();
        SessionSearchPage.getPage().clickClear();
        SessionSearchPage.getPage().toggleAdvancedSearchJavaScript();
        SessionSearchPage.getPage().advSearch("Participant First Name","equal to", attendeeEmail);
        SessionSearchPage.getPage().search();
        Assert.assertTrue(SessionSearchPage.getPage().sessionExists(sessionName));

        SessionSearchPage.getPage().clickClear();
        SessionSearchPage.getPage().advancedSearchAddCriteria();
        SessionSearchPage.getPage().advSearch("Participant Last Name","equal to", attendeeEmail);
        SessionSearchPage.getPage().search();
        Assert.assertTrue(SessionSearchPage.getPage().sessionExists(sessionName));

        SessionSearchPage.getPage().clickClear();
        SessionSearchPage.getPage().advancedSearchAddCriteria();
        SessionSearchPage.getPage().advSearch("Participant Email","equal to", attendeeEmail);
        SessionSearchPage.getPage().search();
        Assert.assertTrue(SessionSearchPage.getPage().sessionExists(sessionName));
    }

    @AfterClass
    public void tearDown(){
        //delete session
        SessionSearchPage.getPage().navigate();
        SessionSearchPage.getPage().searchFor(sessionName);
        SessionSearchPage.getPage().deleteFirstRecord();

        //delete attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        AttendeeSearchPage.getPage().deleteAttendeeByName(attendeeEmail);
        PageConfiguration.getPage().quit();
    }
}