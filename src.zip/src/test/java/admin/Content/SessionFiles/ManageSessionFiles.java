package admin.Content.SessionFiles;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class ManageSessionFiles {
  private AdminApp adminApp = new AdminApp();
  private NewSessionPage newSessionPage = new NewSessionPage();
  private AdminSessionTab adminSessionTab = AdminSessionSummaryTab.getPage();
  private AdminSessionFilesTab adminSessionFilesTab = new AdminSessionFilesTab();
  private SessionSearchPage sessionSearchPage = new SessionSearchPage();
  private FilesPage filesPage = new FilesPage();
  private DataGenerator dataGenerator = new DataGenerator();
  private String sessionTitle = dataGenerator.generateName();

  @BeforeClass
  public void setup () {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }

  @AfterClass
  public void closeBrowser () {
    PageConfiguration.getPage().quit();
  }

  @BeforeMethod
  public void createSession () {
    newSessionPage.navigate();
    newSessionPage.setTitle(sessionTitle);
    newSessionPage.setAbstract(dataGenerator.generateString(32));
    newSessionPage.clickSubmit();
  }

  @AfterMethod
  public void tearDown () {
    sessionSearchPage.navigate();
    sessionSearchPage.search(sessionTitle);
    sessionSearchPage.deleteBySessionTitle(sessionTitle);
  }

  @Test (groups = ReportingInfo.TROGDOR)
  @ReportingInfo(chromeIssue = "RA-19148", firefoxIssue = "RA-19150")
  public void publishAndUnpublish () {
    String linkedPresentationUri = "https://drive.google.com/open?id=1WzGX4LcHvzrPlqixGduvMdYbKyAnoR3QXylWeXDYDhU";
    String linkedPresentationName = dataGenerator.generateName();
    String uploadedPresentationFile = "test_presentation.pdf";
    String id = adminSessionTab.getId();

    adminSessionFilesTab.navigate(id);
    adminSessionFilesTab.addLinkToAPresentation(linkedPresentationUri, linkedPresentationName);
    adminSessionFilesTab.uploadAPresentation(uploadedPresentationFile);
    Assert.assertTrue(adminSessionFilesTab.fileIsAttached(linkedPresentationName), "linked file did not work");
    Assert.assertTrue(adminSessionFilesTab.fileIsAttached(uploadedPresentationFile), "uploaded file did not work");
    adminSessionFilesTab.publishFileByName(linkedPresentationName);
    PageConfiguration.getPage().refreshPage();
    Assert.assertTrue(adminSessionFilesTab.fileNameIsPublished(linkedPresentationName),"file status is not 'Published'");
    adminSessionFilesTab.unpublishFileByName(linkedPresentationName);
    PageConfiguration.getPage().refreshPage();
    Assert.assertFalse(adminSessionFilesTab.fileNameIsPublished(linkedPresentationName), "file status is not 'Unpublished'");
    filesPage.navigate();
    filesPage.publishFileByName(linkedPresentationName);
    PageConfiguration.getPage().refreshPage();
    Assert.assertTrue(filesPage.fileNameIsPublished(linkedPresentationName), "file status change isn't set to 'Published'");
    filesPage.unpublishFileByName(linkedPresentationName);
    PageConfiguration.getPage().refreshPage();
    Assert.assertFalse(filesPage.fileNameIsPublished(linkedPresentationName), "file status change isn't set to 'Not Published'");
  }
}
