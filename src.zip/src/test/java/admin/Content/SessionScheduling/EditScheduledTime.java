package admin.Content.SessionScheduling;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class EditScheduledTime {

    private AdminApp adminApp;
    private String attendeeId;
    private String speakerId;
    private final String COMPANY = "RF";
    private final String TIME = "07:30 AM";
    private final String DAY = "Monday, 5th";
    private final String BELLINI = "1606336091886001FxfW";
    private final String GALILEO = "1610389441541001RItO";
    private final String DELFINO = "1606336125308001Prvz";
    private final String VERONESE = "1606336303609001XU1X";
    private final String EMAIL_SUBJECT_ATTENDEE = "Attendee Session Changed";
    private final String EMAIL_SUBJECT_SPEAKER = "Session Changed";
    private final String S_EMAIL = "rainfocustestautomationuser+speaker9000@gmail.com";
    private final String A_EMAIL = "rainfocustestautomationuser+attendee7000@gmail.com";
    private final String SPEAKER_SESSION = "Trogdor Edit Schedule For Speaker";
    private final String ENROLLED_SESSION = "Trogdor Edit Schedule For Attendee";

    private final SessionSearchPage sessions = SessionSearchPage.getPage();
    private final EditSessionPage edit = EditSessionPage.getPage();
    private final AdminSessionParticipantsTab participants = AdminSessionParticipantsTab.getPage();
    private final AdminSchedulingTab schedule = AdminSchedulingTab.getPage();
    private final AttendeeSearchPage attendeeSearch = AttendeeSearchPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void cleanup() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19861", firefoxIssue = "RA-42645")
    public void editScheduledTimeSpeaker() {
            attendeeSearch.navigate();
            attendeeSearch.searchFor(S_EMAIL);
        if(!attendeeSearch.findAttendeeByText(S_EMAIL)) {
            speakerId = adminApp.createAttendee(S_EMAIL);
        } else {
            speakerId = attendeeSearch.getTopResultId();
        }
            sessions.navigate();
            sessions.search(SPEAKER_SESSION);
            sessions.editItem();

        String sessionId = edit.getSessionId();
        participants.navigate(sessionId);
        if(!participants.isUserParticipant(speakerId)) {
            participants.clickAddParticipant();
            participants.searchExistingParticipant(S_EMAIL);
            participants.setCompany(COMPANY);
            participants.setParticipantRole("Speaker");
            participants.submitAddParticipant();
        }

            schedule.navigate(sessionId);
            schedule.editSession();
        String room = schedule.getScheduledRoom();
        if(room.equals("Bellini")) {
            room = GALILEO;
        } else room = BELLINI;

        String time = schedule.getScheduledSessionTime();
        if(time.equals(TIME)) {
            time = "08:00 AM";
        } else time = TIME;

        EmailApi checkEmail = EmailApi.emailClient();
            schedule.scheduleSessionTime(DAY, time, room);
            schedule.sendEmailToParticipants(false);
            schedule.clickRescheduleButton();

        Assert.assertTrue(checkEmail.waitForEmail(EMAIL_SUBJECT_SPEAKER, S_EMAIL), "waiting for email");
        EmailMessage message = checkEmail.getEmail(EMAIL_SUBJECT_SPEAKER);
        String emailText = message.getBody();
        Assert.assertTrue(emailText.contains(SPEAKER_SESSION), "Body of email does not include session title");

            if(room.equals(BELLINI)) {
                room = GALILEO;
            } else room = BELLINI;

        EmailApi checkEmail2 = EmailApi.emailClient();
            schedule.swapRoomForOnlyScheduledSession(room);
            schedule.sendEmailToParticipants(true);
            schedule.confirmSwapRoom();

        Assert.assertTrue(checkEmail2.waitForEmail(EMAIL_SUBJECT_SPEAKER, S_EMAIL), "waiting for email");
        EmailMessage message2 = checkEmail2.getEmail(EMAIL_SUBJECT_SPEAKER);
        String emailText2 = message2.getBody();
        Assert.assertTrue(emailText2.contains(SPEAKER_SESSION), "Body of email does not include session title");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-42647", firefoxIssue = "RA-42646")
    public void editScheduledTimeAttendee() {
            attendeeSearch.navigate();
            attendeeSearch.searchFor(A_EMAIL);
        if(!attendeeSearch.findAttendeeByText(A_EMAIL)) {
            attendeeId = adminApp.createAttendee(A_EMAIL);
        } else {
            attendeeId = attendeeSearch.getTopResultId();
        }
            sessions.navigate();
            sessions.search(ENROLLED_SESSION);
            sessions.editItem();

        String sessionId = edit.getSessionId();
        schedule.navigate(sessionId);
        int item = Integer.parseInt(schedule.getEnrolledNum().split(" /")[0]);
        boolean enrolled = false;
        if(item > 0) {
            schedule.clickEnrolledResultsLink();
            enrolled = schedule.isAttendeeEnrolledOnModal(A_EMAIL);
        }
        if(!enrolled) {
            schedule.clickEnrolledResultsLink();
            schedule.clickAddAttendeeOnModal();
            schedule.clickSelectAttendeeDropdown();
            schedule.selectAttendeeByEmail(attendeeId, A_EMAIL);
            schedule.clickEnrollButtonOnModal();
            schedule.clickCloseButtonOnModal();
        }

        schedule.editSession();
        String room = schedule.getScheduledRoom();
        if(room.equals("Delfino")) {
            room = VERONESE;
        } else room = DELFINO;

        String time = schedule.getScheduledSessionTime();
        if(time.equals(TIME)) {
            time = "09:00 AM";
        } else time = TIME;

        EmailApi checkEmail = EmailApi.emailClient();
            schedule.scheduleSessionTime(DAY, time, room);
            schedule.sendEmailToAttendees(false);
            schedule.clickRescheduleButton();

        Assert.assertTrue(checkEmail.waitForEmail(EMAIL_SUBJECT_ATTENDEE, A_EMAIL), "waiting for email");
        EmailMessage message = checkEmail.getEmail(EMAIL_SUBJECT_ATTENDEE);
        String emailText = message.getBody();
        Assert.assertTrue(emailText.contains(ENROLLED_SESSION), "Body of email does not include session title");

            if(room.equals(DELFINO)) {
                room = VERONESE;
            } else room = DELFINO;

        EmailApi checkEmail2 = EmailApi.emailClient();
            schedule.swapRoomForOnlyScheduledSession(room);
            schedule.sendEmailToAttendees(true);
            schedule.confirmSwapRoom();

        Assert.assertTrue(checkEmail2.waitForEmail(EMAIL_SUBJECT_ATTENDEE, A_EMAIL), "waiting for email");
        EmailMessage message2 = checkEmail2.getEmail(EMAIL_SUBJECT_ATTENDEE);
        String emailText2 = message2.getBody();
        Assert.assertTrue(emailText2.contains(ENROLLED_SESSION), "Body of email does not include session title");
    }
}
