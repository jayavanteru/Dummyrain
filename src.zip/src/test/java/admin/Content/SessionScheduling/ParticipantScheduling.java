package admin.Content.SessionScheduling;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import apps.admin.adminPageObjects.content.AdminSessionParticipantsTab;
import apps.admin.adminPageObjects.content.SessionAddParticipant;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import configuration.PropertyReader;
import interaction.pageObjects.PageElement;
import logs.ReportingInfo;
import org.apache.commons.lang3.time.DateUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ParticipantScheduling
{
  private AdminApp adminApp;
  private AdminSchedulingTab adminSchedulingTab;
  private DataGenerator dataGenerator;
  private SessionAddParticipant sessionAddParticipant;
  private AdminSessionParticipantsTab adminSessionParticipantsTab;
  private LegacyEventSettings eventSettings;
  private static final int SESSION_LENGTH_45 = 30;
  private String sessionStartInterval;
  private String attendeeId;
  private String sessionRoleId;
  private String session1Id;
  private String session2Id;
  private String session3Id;
  private String roomId;
  private String attendeeEmail;
  private String sessionRoleName;
  private String attendeeFirstName;
  private String attendeeLastName;
  private String company;

  @BeforeClass
  public void setup () {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent();

    adminSchedulingTab = AdminSchedulingTab.getPage();
    adminSessionParticipantsTab = AdminSessionParticipantsTab.getPage();
    sessionAddParticipant = SessionAddParticipant.getPage();
    eventSettings = LegacyEventSettings.getPage();
    dataGenerator = new DataGenerator();

    // get the session start interval
    eventSettings.navigate(PropertyReader.instance().getProperty("eventId"));
    sessionStartInterval = eventSettings.getSessionStartInterval();

    // ensure these lengths are in the system
    adminApp.ensureSessionLengthExists(sessionStartInterval);
    adminApp.ensureSessionLengthExists(SESSION_LENGTH_45);

    /** TEST SETUP */
    attendeeEmail = dataGenerator.generateEmail();
    attendeeId = adminApp.createAttendee(attendeeEmail);

    EditAttendeePage editAttendeePage = EditAttendeePage.getPage();
    editAttendeePage.waitForPageLoad();
    attendeeFirstName = editAttendeePage.getFirstName();
    attendeeLastName = editAttendeePage.getLastName();
    editAttendeePage.setCompany("autocompany");
    company = editAttendeePage.getCompany();
    PersistentProfileForm.getPage().submit();

    // create a session role
    sessionRoleName = dataGenerator.generateName();
    sessionRoleId = adminApp.createAddToScheduleSessionRole(sessionRoleName);

    // create sessions
    session1Id = adminApp.createSessionWithLength(Integer.parseInt(sessionStartInterval));
    session2Id = adminApp.createSessionWithLength(SESSION_LENGTH_45);
    session3Id = adminApp.createSession();

    // create rooms
    String roomName = dataGenerator.generateName();
    roomId = adminApp.createSessionRoom(roomName);
  }

  @AfterClass
  public void closeBrowser () {
    try {
      adminApp.deleteAttendee(attendeeId);
      adminSchedulingTab.navigate(session1Id);
      adminSchedulingTab.deleteAllSessions();
      adminApp.deleteSession(session1Id);
      adminSchedulingTab.navigate(session2Id);
      adminSchedulingTab.deleteAllSessions();
      adminApp.deleteSession(session2Id);
      adminApp.deleteSessionRole(sessionRoleId);
      adminApp.deleteSessionRoom(roomId);
    }
    catch(Exception e){}
    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-25946", chromeIssue = "RA-25945")
  public void deleteParticipant(){
      adminSessionParticipantsTab.navigate(session3Id);
      adminSessionParticipantsTab.clickAddParticipantButton();
      sessionAddParticipant.addParticipantDontSubmit(attendeeEmail, sessionRoleName);

      PageConfiguration.getPage().waitForPageLoad();
      Assert.assertTrue(sessionAddParticipant.allFieldsFilled(attendeeEmail, sessionRoleName, attendeeFirstName, attendeeLastName, company), "Not all fields were filled out as expected");
      sessionAddParticipant.submit();
      Assert.assertTrue(adminSessionParticipantsTab.participantScheduled(attendeeEmail), "Participant was not added correctly");

      PageConfiguration.getPage().refreshPage();
      Assert.assertTrue(adminSessionParticipantsTab.participantScheduled(attendeeEmail), "After refreshing, participant was not there anymore");

      adminSessionParticipantsTab.deleteParticipantByEmail(attendeeEmail);
      Utils.sleep(1000);
      Assert.assertFalse(adminSessionParticipantsTab.participantScheduled(attendeeEmail), "Participant wasn't deleted properly");
  }

  /**
   * Participant on 2 sessions. Adding participants to the session adds to their schedule.
   *
   * Schedule the session for a day, time, room.
   *
   * Assert that second session can be added immediately after the first one ends in the same room at the next start time.
   */
  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(firefoxIssue = "RA-28749", chromeIssue = "RA-28751")
  public void participantConflict() throws Exception {
    /** TEST */
    // add the attendee as a participant to the non-conflicting session
    adminSessionParticipantsTab.navigate(session1Id);
    //Utils.sleep(500);
    adminSessionParticipantsTab.clickAddParticipantButton();
    sessionAddParticipant.addParticipant(attendeeEmail, sessionRoleName);

    // schedule the non-conflicting session
    adminSchedulingTab.navigate(session1Id);
    adminSchedulingTab.clickAddSessionButton();
    String dayName = adminSchedulingTab.setDay(1);
    String firstSessionTime = adminSchedulingTab.setTimeByOrder(1, PageElement.DROPDOWN_ELEMENT_ID);
    adminSchedulingTab.setRoomByRoomId(roomId);

    adminSchedulingTab.clickSaveSessionButton();
    Assert.assertEquals(adminSchedulingTab.getNumScheduledTimes(), 1);

    // add the attendee as a participant to the conflicting session
    adminSessionParticipantsTab.navigate(session2Id);
    adminSessionParticipantsTab.clickAddParticipantButton();
    sessionAddParticipant.addParticipant(attendeeEmail, sessionRoleName);

    // schedule the conflicting session. NOTE: we're selecting a different time and asserting the times between these 2 sessions are different
    adminSchedulingTab.navigate(session2Id);
    adminSchedulingTab.clickAddSessionButton();
    String dayNameConflict = adminSchedulingTab.setDay(1);

    SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    Date originalDate = dateFormat.parse(firstSessionTime);
    Date nextDate = DateUtils.addMinutes(originalDate, Integer.parseInt(sessionStartInterval));
    String nextAvailableTime = dateFormat.format(nextDate);

    adminSchedulingTab.setTimeById(nextAvailableTime);
    adminSchedulingTab.setRoomByRoomId(roomId);
    adminSchedulingTab.clickSaveSessionButton();
    Assert.assertEquals(adminSchedulingTab.getNumScheduledTimes(), 1);

    Assert.assertEquals(dayName, dayNameConflict);
  }
}
