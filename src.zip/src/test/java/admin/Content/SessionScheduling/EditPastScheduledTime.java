package admin.Content.SessionScheduling;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import interaction.pageObjects.PageElement;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EditPastScheduledTime {

    private AdminApp adminApp;
    private String attendeeId;
    private String sessionId;
    private String roomId;
    private final DataGenerator dataGenerator = new DataGenerator();
    private final String EMAIL = dataGenerator.generateEmail();
    private final AdminSchedulingTab tab = AdminSchedulingTab.getPage();

    @BeforeClass
    public void testSetup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Past Event Trogdor Tests");

        String roomName = dataGenerator.generateName();
        roomId = adminApp.createSessionRoom(roomName + " room");

        attendeeId = adminApp.createAttendee(EMAIL);
        sessionId = adminApp.createSessionWithLength(30);
    }

    @AfterClass
    public void testCleanup() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if(attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
        }
        if(sessionId != null) {
            adminApp.deleteSession(sessionId);
        }
        if(roomId != null) {
            adminApp.deleteSessionRoom(roomId);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-37070", firefoxIssue = "RA-37071")
    public void pastScheduleTime() {
            tab.navigate(sessionId);
            tab.clickAddSessionButton();
            tab.setDay(1);
            tab.setTimeByOrder(1, PageElement.DROPDOWN_ELEMENT_ID);
            tab.setRoomByRoomId(roomId);
            tab.clickSaveSessionButton();
        Assert.assertEquals(tab.getNumScheduledTimes(), 1, "Session was not scheduled");

            tab.clickAttendedResultsLink();
            tab.clickAddAttendeeOnModal();
            tab.clickSelectAttendeeDropdown();
            tab.selectAttendeeByEmail(attendeeId, EMAIL);
            tab.clickEnrollButtonOnModal();
            tab.clickCloseButtonOnModal();

        Assert.assertFalse(tab.canDeleteSession(), "Session can be deleted and shouldn't be");

            tab.clickAttendedResultsLink();
            tab.removeAttendeeFromTableOnModal();
            tab.clickCloseButtonOnModal();

        Assert.assertTrue(tab.canDeleteSession(), "Session is not able to be deleted and should be");
            tab.deleteAllSessions();
    }
}
