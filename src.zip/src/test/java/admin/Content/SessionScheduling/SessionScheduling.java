package admin.Content.SessionScheduling;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.LegacyEventSettings;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AdminSchedulingTab;
import configuration.PropertyReader;
import interaction.pageObjects.PageElement;
import logs.ReportingInfo;
import org.apache.commons.lang3.time.DateUtils;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SessionScheduling {

    private AdminApp adminApp;
    private AdminSchedulingTab adminSchedulingTab;
    private DataGenerator dataGenerator;
    private LegacyEventSettings eventSettings;
    private static final int sessionLength = 30;
    private String sessionStartInterval;
    private String session1Id;
    private String session2Id;
    private String roomId;

    @BeforeClass
    public void setup () {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        adminSchedulingTab = AdminSchedulingTab.getPage();
        eventSettings = LegacyEventSettings.getPage();
        dataGenerator = new DataGenerator();

        // get the session start interval
        eventSettings.navigate(PropertyReader.instance().getProperty("eventId"));
        sessionStartInterval = eventSettings.getSessionStartInterval();

        // ensure these lengths are in the system
        adminApp.ensureSessionLengthExists(sessionStartInterval);
        adminApp.ensureSessionLengthExists(sessionLength);
    }

    @AfterClass
    public void closeBrowser () {
        try {
            adminSchedulingTab.navigate(session1Id);
            adminSchedulingTab.deleteAllSessions();
            adminApp.deleteSession(session1Id);

            adminSchedulingTab.navigate(session2Id);
            adminSchedulingTab.deleteAllSessions();
            adminApp.deleteSession(session2Id);
            adminApp.deleteSessionRoom(roomId);
        }
        catch (Exception e){}
        PageConfiguration.getPage().quit();
    }


    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27023", chromeIssue = "RA-27022")
    public void sequentialScheduling() throws Exception{
        /** TEST SETUP */
        // create sessions
        session1Id = adminApp.createSessionWithLength(Integer.parseInt(sessionStartInterval));
        session2Id = adminApp.createSessionWithLength(sessionLength);

        // create a room
        String roomName = dataGenerator.generateString();
        roomId = adminApp.createSessionRoom(roomName);

        /** TEST */
        // schedule the non-conflicting session
        adminSchedulingTab.navigate(session1Id);
        adminSchedulingTab.clickAddSessionButton();
        String dayName = adminSchedulingTab.setDay(1);
        String firstSessionTime = adminSchedulingTab.setTimeByOrder(1, PageElement.DROPDOWN_ELEMENT_ID);
        adminSchedulingTab.setRoomByRoomId(roomId);
        adminSchedulingTab.clickSaveSessionButton();
        Assert.assertEquals(adminSchedulingTab.getNumScheduledTimes(), 1);

        // schedule the conflicting session. NOTE: we're selecting a different time and asserting the times between these 2 sessions are different
        adminSchedulingTab.navigate(session2Id);
        adminSchedulingTab.clickAddSessionButton();
        String dayNameConflict = adminSchedulingTab.setDay(1);

        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date originalDate = dateFormat.parse(firstSessionTime);
        Date nextDate = DateUtils.addMinutes(originalDate, Integer.parseInt(sessionStartInterval));
        String nextAvailableTime = dateFormat.format(nextDate);

        adminSchedulingTab.setTimeById(nextAvailableTime);
        adminSchedulingTab.setRoomByRoomId(roomId);
        adminSchedulingTab.clickSaveSessionButton();
        Assert.assertEquals(adminSchedulingTab.getNumScheduledTimes(), 1);

        Assert.assertEquals(dayName, dayNameConflict);
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27026", chromeIssue = "RA-27025")
    public void overlappingSessions() throws Exception{
/** TEST SETUP */
        // create sessions
        int lengthMultiplier = 3;
        int firstSessionLength = Integer.parseInt(sessionStartInterval) * lengthMultiplier;
        session1Id = adminApp.createSessionWithLength(firstSessionLength);
        session2Id = adminApp.createSessionWithLength(sessionLength);

        // create a room
        String roomName = dataGenerator.generateString();
        roomId = adminApp.createSessionRoom(roomName);

        /** TEST */
        // schedule first session
        adminSchedulingTab.navigate(session1Id);
        adminSchedulingTab.clickAddSessionButton();
        String dayName = adminSchedulingTab.setDay(1);
        String firstSessionTime = adminSchedulingTab.setTimeByOrder(1, PageElement.DROPDOWN_ELEMENT_ID);
        adminSchedulingTab.setRoomByRoomId(roomId);
        adminSchedulingTab.clickSaveSessionButton();
        Assert.assertEquals(adminSchedulingTab.getNumScheduledTimes(), 1);

        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        Date originalDate = dateFormat.parse(firstSessionTime);
        adminSchedulingTab.navigate(session2Id);

        for (int i = 0; i < lengthMultiplier; i++) {
            // get fresh page data
            adminSchedulingTab.clickAddSessionButton();
            String dayNameForConflict = adminSchedulingTab.setDay(1);

            Assert.assertEquals(dayName, dayNameForConflict);

            // picking the time cleared out the room. so open the dropdown to make sure it's unavailable
            Date nextDate = DateUtils.addMinutes(originalDate, Integer.parseInt(sessionStartInterval) * i);
            String nextAvailableTime = dateFormat.format(nextDate);
            adminSchedulingTab.setTimeById(nextAvailableTime);

            Utils.sleep(1000);
            adminSchedulingTab.clickRoomDropdown(roomId);
            Assert.assertTrue(adminSchedulingTab.isDropdownOptionDisabled(roomId), "failed to assert roomId ("+ roomId +") was not available");

            PageConfiguration.getPage().refreshPage();
            adminSchedulingTab.waitForPageLoad();
        }

        // get fresh page data
        adminSchedulingTab.clickAddSessionButton();
        String dayNameForConflict = adminSchedulingTab.setDay(1);
        adminSchedulingTab.setRoomByRoomId(roomId);

        Assert.assertEquals(dayName, dayNameForConflict);

        Date nextDate = DateUtils.addMinutes(originalDate, Integer.parseInt(sessionStartInterval) * lengthMultiplier);
        String nextAvailableTime = dateFormat.format(nextDate);
        adminSchedulingTab.setTimeById(nextAvailableTime);
        adminSchedulingTab.waitForRoomIdToBeEnabled(roomId);
        Assert.assertTrue(adminSchedulingTab.isDropdownOptionEnabled(roomId), "failed to assert roomId ("+ roomId +") became available");

    }
}
