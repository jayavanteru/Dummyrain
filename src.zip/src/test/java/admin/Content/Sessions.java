package admin.Content;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.CreateSessionPage;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.NewSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Sessions {

  SessionSearchPage sessionSearchPage;
  DataGenerator dataGenerator;
  AdminApp adminApp;
  CreateSessionPage createSessionPage;
  NewSessionPage newSessionPage;
  EditSessionPage editSessionPage;
  String sessionTitle, sessionId, attributeName, attributeId;
  String[] options = new String[]{"Option 1", "Option 2", "Option 3", "Option 4", "Option 5"};
  String[] visibleOptions = new String[]{"Option 1", "Option 2", "Option 3"};
  String[] optionsToUncheck = new String[]{"Option 4", "Option 5"};

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    adminApp = new AdminApp();
    createSessionPage = CreateSessionPage.getPage();
    newSessionPage = NewSessionPage.getPage();
    editSessionPage = EditSessionPage.getPage();
    sessionSearchPage = SessionSearchPage.getPage();

    sessionTitle = dataGenerator.generateString();
    attributeName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("IBM", RFConstants.EVENT_NAME_EVENTGERS_TEST);
  }

  @AfterClass
  public void tearDown() {

    // Delete Attribute from Session
    sessionSearchPage.navigate();
    sessionSearchPage.searchFor(sessionTitle);
    sessionSearchPage.clickResult(sessionTitle);
    editSessionPage.openModalForm();
    editSessionPage.deleteAttributeFromModal(attributeName);
    editSessionPage.submitModal();

    // Delete Session
    adminApp.deleteSession(sessionId);

    // Delete Attribute
    adminApp.deleteAttribute(attributeId);

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40714", chromeIssue = "RA-40218")
  public void showHideSessionsAttributes() {

    // Create session attribute
    attributeId = adminApp.createSelectAttribute(attributeName, options, CreateEventAttributePage.AUDIENCE_TYPES.Session);

    // Create Session
    sessionId = adminApp.createSession(sessionTitle);

    // Add attribute to Session
    editSessionPage.openModalForm();
    editSessionPage.addAtribute(attributeName);
    editSessionPage.clickCheckOptionOnOpenFormQuestion(optionsToUncheck);
    editSessionPage.submitModal();

    // Validate Attributes
    editSessionPage.openAttributeSelect(attributeName);
    for (int i = 0; i < visibleOptions.length; i++) {
      Assert.assertTrue(editSessionPage.isAttributeValueVisible(visibleOptions[i]), "Attribute Value is not visible");
    }

    for (int i = 0; i < optionsToUncheck.length; i++) {
      Assert.assertFalse(editSessionPage.isAttributeValueVisible(optionsToUncheck[i]), "Attribute Value should not be visible");
    }
  }
}
