package admin.Content.AccessRules;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditWidgetBuilder;
import apps.admin.adminPageObjects.libraries.EditWidgetCatalogSettings;
import apps.admin.adminPageObjects.libraries.WidgetBuilderSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import apps.events.eventsPageObjects.WidgetSessionDetailsPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class HiddenAttributeCatalog {

    private AdminApp adminApp;
    private String standardAttendeeId;
    private String limitedAccessAttendeeId;
    private String sessionId;
    private final String ACCESS_ORDER = "Full Conference Pass Automation";
    private final String LIMITED_ORDER = "Limited Access Package";
    private final String SESSION = "\"Hidden Attribute Test Session\"";
    private final String WIDGET = "Trogdor Selenium Session Details Catalog";
    private final String HIDDEN_ATTRIBUTE_ID = "1614039064488001bYQO";

    private TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
    private AdminAttendeeOrdersTab orders = AdminAttendeeOrdersTab.getPage();
    private WidgetBuilderSearchPage widgetSearch = WidgetBuilderSearchPage.getPage();
    private EditWidgetBuilder widgetEdits = EditWidgetBuilder.getPage();
    private EditWidgetCatalogSettings settingsPage = EditWidgetCatalogSettings.getPage();
    private WidgetSessionDetailsPage details = WidgetSessionDetailsPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
        NavigationBar.getPage().collapse();
        widgetSearch.navigate();
        widgetSearch.searchFor(WIDGET);
        widgetSearch.editItem();

        widgetEdits.clickCatalogSettingsButton();
        settingsPage.clickLeftNavItem("Schedule Access Attributes");
        if(settingsPage.hasScheduleAccessAttributes()){
            settingsPage.deleteAccessAttributes();
        }
        settingsPage.addScheduleAccessAttribute(HIDDEN_ATTRIBUTE_ID);

        settingsPage.clickSaveSettingsButton();
        widgetEdits.clickSaveWidget();

        limitedAccessAttendeeId = createAttendeeWithOrder(LIMITED_ORDER);
        standardAttendeeId = createAttendeeWithOrder(ACCESS_ORDER);
    }

    @AfterClass
    public void cleanUp() {
        cancelOrderAndDeleteAttendee(standardAttendeeId);
        cancelOrderAndDeleteAttendee(limitedAccessAttendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-43609", firefoxIssue = "RA-43610")
    public void hiddenAttributeCatalogTest() {
        EditAttendeePage.getPage().spoofToWidget(WIDGET);
        PageConfiguration.getPage().justWait();
            catalog.filterCatalog(SESSION);

        String sessionTitle = SESSION.replaceAll("\"", "");
        String sessionAttribute = sessionTitle.replaceAll("Session", "").replaceAll(" ", "");
            sessionId = catalog.getSessionId(sessionTitle);

        Assert.assertTrue(catalog.hasAttributeBySessionId(sessionId, sessionAttribute), "Session is not displaying the attribute but should be");
            catalog.goToSessionDetails(sessionId, sessionTitle);
        Assert.assertTrue(details.sessionDetailsHasAttribute(sessionAttribute),"Details page is not displaying the attribute but should be");

            catalog.signOut();
        PageConfiguration.getPage().close();
        PageConfiguration.getPage().switchToTab(0);

            orders.navigate(limitedAccessAttendeeId);
        EditAttendeePage.getPage().spoofToWidget(WIDGET);
        PageConfiguration.getPage().justWait();
            catalog.filterCatalog(SESSION);

        Assert.assertFalse(catalog.hasAttributeBySessionId(sessionId, sessionAttribute), "Session is displaying the attribute and should not be");
            catalog.goToSessionDetails(sessionId, sessionTitle);
        Assert.assertFalse(details.sessionDetailsHasAttribute(sessionAttribute),"Details page is displaying the attribute and should not be");
    }

    public String createAttendeeWithOrder(String order) {
        String id = adminApp.createAttendee();
        orders.navigate(id);
        orders.addOrder();
        orders.selectPackage(order);
        orders.clickNextOnAddOrderModal();
        orders.setComment("Test");
        orders.submitOrder();
        return id;
    }

    public void cancelOrderAndDeleteAttendee(String attendeeId) {
        orders.navigate(attendeeId);
        orders.selectAllOrders();
        orders.deleteOrders();
        orders.cancelOrder();
        adminApp.deleteAttendee(attendeeId);
    }
}
