package admin.Content.AccessRules;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.events.eventsPageObjects.TrogdorSessionCatalog;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CanSchedule {

    private AdminApp adminApp;
    private String accessRuleId;
    private String attendeeId;
    private String sessionId;
    private final DataGenerator dataGenerator = new DataGenerator();
    private final String EMAIL = dataGenerator.generateEmail();
    private final String TITLE = "Schedule View Access";

    private final NewAccessPage access = NewAccessPage.getPage();
    private final AccessSearchPage accessSearch = AccessSearchPage.getPage();

    @BeforeClass
    public void setup() {
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");

        attendeeId = adminApp.createAttendee(EMAIL);
        AdminAttendeeOrdersTab ordersTabPage = AdminAttendeeOrdersTab.getPage();
        ordersTabPage.navigate(attendeeId);
        ordersTabPage.addOrder();
        ordersTabPage.selectPackage("Exhibitor Registration");
        ordersTabPage.clickNextOnAddOrderModal();
        ordersTabPage.setComment("test");
        ordersTabPage.submitOrder();

        accessSearch.navigate();
        accessSearch.cleanUpAutomatedAccess(accessSearch.getAccessRuleNames());
        accessRuleId = createAccess(EMAIL);
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-44517", chromeIssue = "RA-22084")
    public void verifyShowPublicAndCanSchedule() {
        PageConfiguration.getPage().navigateTo(PageConfiguration.getPage().getData("eventsUrl") + "/widget/rainfocus/trogdorauto/TrogdorSeleniumSessionCatalog");
        TrogdorSessionCatalog catalog = TrogdorSessionCatalog.getPage();
            catalog.justWait();
            catalog.filterCatalog(TITLE);
        Assert.assertFalse(catalog.isSessionOnCatalog(TITLE));

            access.navigate(accessRuleId);
            access.clickShowPublic();
            access.clickSubmit();

        adminApp.spoofIntoCatalog(EMAIL, "Trogdor Selenium Session Catalog", 1);
            catalog.filterCatalog(TITLE);
        Assert.assertTrue(catalog.isSessionOnCatalog(TITLE));
            sessionId = catalog.getSessionId(TITLE);

        //Assert you can't schedule
        catalog.scheduleSessionById(sessionId,true);
        Assert.assertTrue(catalog.modalRenderedWithTitle("Unable to Schedule"));

        PageConfiguration.getPage().switchToTab(0);
            access.navigate(accessRuleId);
            access.clickCanSchedule();
            access.clickSubmit();

        PageConfiguration.getPage().switchToTab(1);
        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(catalog.isSessionOnCatalog(TITLE));

        //Assert you can schedule
        catalog.scheduleSessionById(sessionId, true);
        Assert.assertFalse(catalog.modalRenderedWithTitle("Unable to Schedule"));
        Assert.assertTrue(catalog.isSessionScheduled(sessionId), "Session was not scheduled");
    }

    private String createAccess(String attendeeEmail) {
        access.navigate();
        String accessName = dataGenerator.generateName();
        access.filloutForm(accessName, true, false, false, false, false);
        access.clickAttendeeCriteria();
        access.setCriteriaWithText("Email", "equal to", attendeeEmail);
        access.clickSessionCriteria();
        access.setCriteriaWithDropdown("Title", "equal to", TITLE);
        access.clickSubmit();
        return accessSearch.findAccessRuleId(accessName);
    }

    @AfterClass
    public void teardown() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        adminApp.deleteAttendee(attendeeId);
        accessSearch.navigate();
        accessSearch.cleanUpAutomatedAccess(accessSearch.getAccessRuleNames());
        PageConfiguration.getPage().quit();
    }
}
