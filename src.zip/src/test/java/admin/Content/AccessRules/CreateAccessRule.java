package admin.Content.AccessRules;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.AccessSearchPage;
import apps.admin.adminPageObjects.content.AdminSessionSummaryTab;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.NewAccessPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeSummaryTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CreateAccessRule {
    private final AdminApp adminApp = new AdminApp();
    private final DataGenerator dataGenerator = new DataGenerator();

    private String attendeeId = "";
    private final String attendeeEmail = dataGenerator.generateEmail();
    private String sessionId = "";
    private final String sessionTitle = dataGenerator.generateName();
    private String accessRuleId = "";

    AccessSearchPage accessSearchPage = AccessSearchPage.getPage();
    NewAccessPage newAccessPage = NewAccessPage.getPage();
    EditSessionPage editSessionPage = EditSessionPage.getPage();
    AdminAttendeeSummaryTab adminAttendeeSummaryTab = AdminAttendeeSummaryTab.getPage();
    AdminSessionSummaryTab adminSessionSummaryTab = AdminSessionSummaryTab.getPage();

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        // Create attendee and apply attributes
        attendeeId = adminApp.createAttendee(attendeeEmail);

        // Create session
        sessionId = adminApp.createSession(sessionTitle);
    }

    @AfterClass
    public void teardownTest() {
        // Delete attendee
        adminApp.deleteAttendee(attendeeId);

        // Delete session
        adminApp.deleteSession(sessionId);

        // Delete Access Rule
        adminApp.deleteAccessRule(accessRuleId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(firefoxIssue = "RA-27122", chromeIssue = "RA-19191")
    public void createNewAccess() {
        // Create new Access Rule
        String accessName = dataGenerator.generateName();
        accessSearchPage.navigate();
        accessSearchPage.clickAdd();
        newAccessPage.filloutForm(accessName);
        newAccessPage.clickAttendeeCriteria();
        newAccessPage.setCriteriaWithText("Email", "equal to", attendeeEmail);
        newAccessPage.clickSessionCriteria();
        newAccessPage.setCriteriaWithDropdown("Title", "equal to", sessionTitle);
        newAccessPage.clickSubmit();
        accessSearchPage.searchFor(accessName);
        accessRuleId = accessSearchPage.findAccessRuleId(accessName);

        Assert.assertTrue(accessSearchPage.accessRuleExists(accessName), "Access Rule wasn't created");

        // Verify Access Rule has been applied to the attendee
        adminAttendeeSummaryTab.navigate(attendeeId);

        Assert.assertEquals(adminAttendeeSummaryTab.waitForAccessRulesToLoad(accessName, 3), 3, "Didn't find access rules on Attendees");

        // Verify Access Rule has been applied to the session
        adminSessionSummaryTab.navigate(sessionId);

        Assert.assertEquals(adminSessionSummaryTab.waitForAccessRulesToLoad(accessName, 4), 4, "Didn't find access rules on Session");
    }
}
