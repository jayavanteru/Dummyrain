package admin.Content.SessionProfile;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class SessionProfileLeftForm {

    private String defaultSessionType;
    private String newSessionType;
    private final String BIRDS = "Birds of a feather";
    private final String BREAKOUT = "Breakout session";
    private final String DUPLICATE_CODE = "1028";
    private final String ORIGINAL_CODE = "5119";
    private final String TROGDOR = "Trogdor MR";

    private EditSessionPage edit = EditSessionPage.getPage();

    @BeforeClass
    public void setUp() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RainFocus", "Manual Regression ONLY - Trogdor");
    }

    @AfterClass
    public void tearDown() {
        if(!newSessionType.equals(BREAKOUT)) {
            edit.setSessionType(BREAKOUT);
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = ReportingInfo.TROGDOR)
    @ReportingInfo(chromeIssue = "RA-19852", firefoxIssue = "RA-34245")
    public void editForm() {
        SessionSearchPage sessions = SessionSearchPage.getPage();
            sessions.navigate();
            sessions.searchFor(TROGDOR);
            sessions.openFirstRecord();

            edit.setSessionCode(DUPLICATE_CODE);
        Assert.assertTrue(edit.isErrorWithSubmit(), "Should be an error with submit and there was not");
            edit.setSessionCode(ORIGINAL_CODE);
        Assert.assertFalse(edit.isErrorWithSubmit(), "Submit save should have been successful");

            defaultSessionType = edit.getSessionType();

            if (!defaultSessionType.equals(BIRDS)) {
                edit.setSessionType(BIRDS);
            } else { edit.setSessionType(BREAKOUT); }

         Assert.assertFalse(edit.isErrorWithSubmit(),"Submit save should have been successful");

            newSessionType = edit.getSessionType();
        Assert.assertNotEquals(newSessionType, defaultSessionType,"Session Type edit was not successfully saved");

            edit.setSessionTitle("");
        Assert.assertTrue(edit.cannotSubmitWithError(), "Should not be able to save with a required field empty");
            edit.setSessionTitle(TROGDOR);
    }
}
