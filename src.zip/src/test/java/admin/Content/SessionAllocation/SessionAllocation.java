package admin.Content.SessionAllocation;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.EditSessionPage;
import apps.admin.adminPageObjects.content.SessionAllocationPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.*;
import testHelp.DataGenerator;

public class SessionAllocation {

  private AdminApp adminApp;
  private String sessionId;
  private final String STATUS = "Accepted";
  private final String ATTRIBUTE = "Session technology";
  private final String sessionName = new DataGenerator().generateName();
  //  private String attributeValue = "Hadoop";
  //  private String sessionType = "Breakout session";

  private final SessionAllocationPage allocationPage = SessionAllocationPage.getPage();
  private final EditSessionPage editPage = new EditSessionPage();

  @BeforeClass
  public void setupTest() {
    adminApp = new AdminApp();
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "Trogdor Automation");
  }
  @BeforeMethod
  public void setupMethod() {
    sessionId = adminApp.createSession(sessionName);
    editPage.waitForPageLoad();
    editPage.setSessionStatus(STATUS);
    editPage.addNewAttributeToForm(ATTRIBUTE);
  }

  @AfterClass
  public void closeBrowser() {
    PageConfiguration.getPage().quit();
  }

  @AfterMethod
  public void deleteSession() {
    adminApp.deleteSession(sessionId);
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19958", firefoxIssue = "RA-26732")
  public void editSessionAllocation() {
    String sessionTechName = "Column-oriented databases";
    String sessionType = "Breakout session";

    allocationPage.navigate();
    allocationPage.searchSessionTech(sessionTechName);
    allocationPage.clickSessionTechnology(sessionTechName);

    String oldTimesOffered = allocationPage.getTimesOfferedOnModal(sessionType);
    String newTimesOffered = Integer.toString(Integer.parseInt(oldTimesOffered) + 1);

    allocationPage.setTimesOfferedOnModal(sessionType, newTimesOffered);

    String updatedTimesOffered = allocationPage.getTimesOffered(3);
    int index = updatedTimesOffered.indexOf("/");
    Assert.assertEquals(updatedTimesOffered.substring(index + 1).trim(), newTimesOffered, "Current times offered for session technology " + sessionTechName + " is different. We expected " + newTimesOffered);
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19833", firefoxIssue = "RA-27403")
  public void editSessionStatus() {
    String sessionTechName = "Hadoop";
    String sessionType = "Breakout session";

    editPage.setSessionType(sessionType);
    editPage.setNewAttributeValue(ATTRIBUTE, sessionTechName);

    //Go to Content > Session Allocation and click on “Hadoop”
    allocationPage.navigate();
    allocationPage.searchSessionTech(sessionTechName);
    allocationPage.clickSessionTechnology(sessionTechName);

    //Store current scheduled times value
    int originalAmount = allocationPage.getTimesScheduledOnModal(sessionType);

    //Verify session was created and shows in modal
    allocationPage.searchSessionInModal(sessionType, sessionName);

    Assert.assertTrue(allocationPage.isAnySessions(), "Session wasn't created or set up properly so it's not showing up in Search Results");

    //Update session status and verify it no longer shows in modal
    allocationPage.clickEditSessionInModal();
    allocationPage.changeSessionStatus("Cancelled");
    allocationPage.searchSessionInModal(sessionType, sessionName);

    Assert.assertFalse(allocationPage.isAnySessions(), "Session status wasn't updated properly so it's still showing in Search Results");

    //Verify the scheduled times is reflecting the change
    int updatedAmount  = allocationPage.getTimesScheduledOnModal(sessionType);

    Assert.assertEquals(updatedAmount, (originalAmount - 1), "Current times scheduled for session technology " + sessionTechName + " is different. We expected " + (originalAmount - 1));
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-19964", firefoxIssue = "RA-28543")
  public void editSessionTimesOffered() {
    String sessionTechName = "MapReduce";
    String sessionType = "Breakout session";

    editPage.setSessionType(sessionType);
    editPage.setNewAttributeValue(ATTRIBUTE, sessionTechName);

    //Go to Content > Session Allocation and click on “Hadoop”
    allocationPage.navigate();
    allocationPage.searchSessionTech(sessionTechName);
    allocationPage.clickSessionTechnology(sessionTechName);

    //Store current scheduled times value
    int originalAmount = allocationPage.getTimesScheduledOnModal(sessionType);

    //Verify session was created and shows in modal
    allocationPage.searchSessionInModal(sessionType, sessionName);

    Assert.assertTrue(allocationPage.isAnySessions(), "Session wasn't created or set up properly so it's not showing up in Search Results");

    //Update session status and verify it no longer shows in modal
    allocationPage.clickEditSessionInModal();
    String originalSessionTimesOffered = allocationPage.getSessionTimesOfferedOnModal();
    int originalSessionAmount = Integer.parseInt(originalSessionTimesOffered);
    allocationPage.changeSessionTimesOffered("0");
    allocationPage.searchSessionInModal(sessionType, sessionName);

    Assert.assertFalse(allocationPage.isAnySessions(), "Session status wasn't updated properly so it's still showing in Search Results");

    //Verify the scheduled times is reflecting the change
    int updatedAmount = allocationPage.getTimesScheduledOnModal(sessionType);

    Assert.assertEquals(updatedAmount, (originalAmount - originalSessionAmount), "Current times scheduled for session technology " + sessionTechName + " is different. We expected " + (originalAmount - 1));

    editPage.navigate(sessionId);
    editPage.setSessionTimesOffered(originalSessionTimesOffered);

    //Go to Content > Session Allocation and click on “Hadoop”
    allocationPage.navigate();
    allocationPage.searchSessionTech(sessionTechName);
    allocationPage.clickSessionTechnology(sessionTechName);

    //Store current scheduled times value
    int currentAmount = allocationPage.getTimesScheduledOnModal(sessionType);

    Assert.assertEquals(currentAmount, originalAmount, "Current times scheduled for session technology " + sessionTechName + " is different. We expected " + (originalAmount - 1));
  }

  @Test(groups = {ReportingInfo.TROGDOR})
  @ReportingInfo(chromeIssue = "RA-41558", firefoxIssue = "RA-41559")
  public void editSessionTooManyTimesOffered() {
    String sessionTechName = "Hive";
    String sessionType = "Breakout session";

    editPage.setSessionType(sessionType);
    editPage.setNewAttributeValue(ATTRIBUTE, sessionTechName);

    //Go to Content > Session Allocation and click on “Hadoop”
    allocationPage.navigate();
    allocationPage.searchSessionTech(sessionTechName);
    allocationPage.clickSessionTechnology(sessionTechName);

    //Store current total scheduled times value
    String originalTotalTimesScheduled = allocationPage.getTimesOfferedOnModal(sessionType);
    int originalTotalAmount = Integer.parseInt(originalTotalTimesScheduled);

    //Store current scheduled times value
    int originalAmount = allocationPage.getTimesScheduledOnModal(sessionType);

    //Verify session was created and shows in modal
    allocationPage.searchSessionInModal(sessionType, sessionName);

    Assert.assertTrue(allocationPage.isAnySessions(), "Session wasn't created or set up properly so it's not showing up in Search Results");

    //Update session status and verify it no longer shows in modal
    allocationPage.clickEditSessionInModal();
    String originalSessionTimesOffered = allocationPage.getSessionTimesOfferedOnModal();
    int originalSessionAmount = Integer.parseInt(originalSessionTimesOffered);
    int updatedSessionTimesOffered = (originalTotalAmount - originalAmount) + originalSessionAmount + 1;
    allocationPage.changeSessionTimesOffered(Integer.toString(updatedSessionTimesOffered));

    String errorMessage = allocationPage.getErrorMessageTooManyTimesOfferedOnModal();
    Assert.assertEquals(errorMessage, "Allocation limit exceeded for allocation " + sessionTechName + " & " + sessionType + ": " + originalTotalTimesScheduled + " allocated, attempting to increase to " + Integer.toString(originalAmount + updatedSessionTimesOffered - originalSessionAmount).trim());

    allocationPage.changeSessionTimesOffered(originalSessionTimesOffered);
  }
}
