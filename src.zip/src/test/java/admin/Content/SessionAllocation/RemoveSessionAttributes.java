package admin.Content.SessionAllocation;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.content.SessionAllocationPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class RemoveSessionAttributes {

    private SessionAllocationPage sessionAllocationPage = SessionAllocationPage.getPage();

    @BeforeClass
    public void setupTest() {
        AdminLoginPage.getPage().login();
    }

    @AfterClass
    public void tearDown() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19828", firefoxIssue = "RA-27725")
    public void removeAttributesInUse() {
        OrgEventData.getPage().setOrgAndEvent();
        String rowAttribute = "Session technology";
        String rowAttributeValue = "Hadoop";
        sessionAllocationPage.navigate();
        sessionAllocationPage.clickGearIcon();
        // Attempt to remove attribute in use
        sessionAllocationPage.removeSelectedAttribute(rowAttribute);
        Assert.assertTrue(sessionAllocationPage.hasInUseError("Attributes"), "Error not visible on page");
        // Attempt to remove attribute value in use
        sessionAllocationPage.removeSelectedAttributeValue(rowAttributeValue);
        Assert.assertTrue(sessionAllocationPage.hasInUseError("Values"), "Error not visible on page");
    }

    @Test(groups = {ReportingInfo.TROGDOR})
    @ReportingInfo(chromeIssue = "RA-19829", firefoxIssue = "RA-28520")
    public void removeAttributesNotInUse() {
        String row1 = "Row Attribute";
        String row2 = "Select Rows";
        String rowAttribute = "Session Scan Modes";
        String rowAttributeValue = "Monitoring";
        String column1 = "Column Attribute";
        String column2 = "Select Columns";
        String columnAttribute = "Session Type";
        String columnAttributeValue = "Exhibitor";

        // Navigate to Trogdor Manual rather than Constellations
        AdminLoginPage.getPage().navigate();
        PageConfiguration.getPage().justWait();
        OrgEventData.getPage().setOrgAndEvent("RainFocus","Manual Regression ONLY - Trogdor");
        sessionAllocationPage.navigate();
        sessionAllocationPage.clickGearIcon();

        // Add COLUMN value: Exhibitor
        sessionAllocationPage.clickValuesDropdown(column2);
        sessionAllocationPage.clickDropdownOption(columnAttributeValue);
        Assert.assertTrue(sessionAllocationPage.checkSelectedValueExist(columnAttributeValue), "Element added and should exist");
        // Remove ROW value w/ dropdown: Monitoring
        sessionAllocationPage.clickValuesDropdown(row2);
        sessionAllocationPage.clickDropdownOption(rowAttributeValue);
        Assert.assertFalse(sessionAllocationPage.checkSelectedValueExist(rowAttributeValue), "Element removed and should NOT exist");
        // Remove COLUMN value w/ dropdown: Exhibitor
        sessionAllocationPage.clickAttributeDropdown(row1);
        sessionAllocationPage.removeSelectedAttributeValue("Keynote");
        sessionAllocationPage.clickValuesDropdown(column2);
        sessionAllocationPage.clickDropdownOption(columnAttributeValue);
        Assert.assertFalse(sessionAllocationPage.checkSelectedValueExist(columnAttributeValue), "Element added and should NOT exist");
        // Add ROW value: Monitoring
        sessionAllocationPage.clickValuesDropdown(row2);
        sessionAllocationPage.clickDropdownOption(rowAttributeValue);
        Assert.assertTrue(sessionAllocationPage.checkSelectedValueExist(rowAttributeValue), "Element added and should exist");

        // Remove entire attribute & verify removal also removes all values (Row & Column)
        // TODO: note that selecting an already selected Attribute removes all selected Values
        // Remove COLUMN ATTRIBUTE: Session Scan Modes
        sessionAllocationPage.removeSelectedAttribute(columnAttribute);
        Assert.assertFalse(sessionAllocationPage.checkSelectedValueExist(columnAttributeValue), "Attribute removed; element does NOT exist");
        sessionAllocationPage.clickAttributeDropdown(column1);
        sessionAllocationPage.clickDropdownOption(columnAttribute);
        sessionAllocationPage.clickValuesDropdown(column2);
        sessionAllocationPage.clickDropdownOption(columnAttributeValue);
        Assert.assertTrue(sessionAllocationPage.checkSelectedValueExist(columnAttributeValue), "Element added and should exist");
        // Remove ROW ATTRIBUTE: Session Scan Modes
        sessionAllocationPage.removeSelectedAttribute(rowAttribute);
        Assert.assertFalse(sessionAllocationPage.checkSelectedValueExist(rowAttributeValue), "Attribute removed; element does NOT exist");
        sessionAllocationPage.clickAttributeDropdown(row1);
        sessionAllocationPage.clickDropdownOption(rowAttribute);
        sessionAllocationPage.clickValuesDropdown(row2);
        sessionAllocationPage.clickDropdownOption(rowAttributeValue);

        // cancel to discard any changes
        sessionAllocationPage.clickCancelButton();
    }
}
