//package admin;
//
//import admin.searches.ExhibitorSearch;
//import apps.PageConfiguration;
//import apps.admin.AdminApp;
//import apps.admin.adminPageObjects.AdminLoginPage;
//import apps.admin.adminPageObjects.analysis.NewReportPage;
//import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsPage;
//import apps.admin.adminPageObjects.exhibits.AdminExhibitorNewContactPage;
//import apps.admin.adminPageObjects.exhibits.ExhibitorSearchPage;
//import apps.admin.adminPageObjects.libraries.AdminRuleCreatePage;
//import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
//import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
//import com.mysql.cj.xdevapi.UpdateResult;
//import configuration.PropertyReader;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
//
//public class reportBuilder {
//private AdminApp adminApp;
//
//    @BeforeClass public void setup() {
//        adminApp = new AdminApp();
//        AdminLoginPage.getPage().login();
//        adminApp.setOrgAndEvent();
//    }
//
//    @AfterClass void done() {
//        PageConfiguration.getPage().quit();
//    }
//
//    @Test public void bulk() {
//        NewReportPage reportPage = NewReportPage.getPage();
//        reportPage.navigate
//    }
//
//}
