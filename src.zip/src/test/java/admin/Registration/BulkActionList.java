package admin.Registration;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.Set;

public class BulkActionList {
    DataGenerator dataGenerator = new DataGenerator();
    String attendeeEmail = dataGenerator.generateEmail();

    @BeforeClass
    public void setUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event E");

        //create attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().add();
        CreateAttendeePage.getPage().fillOutForm(attendeeEmail, attendeeEmail, attendeeEmail);
    }

    private void assertShowingUp() {
        Set<String> allIds = AttendeeSearchPage.getPage().getAllIds();
        Assert.assertEquals(allIds.size(), 1, "search did not filter down to the right attendee");
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27981", firefoxIssue = "RA-27982")
    public void bulkEdit(){
        //edit attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        AttendeeSearchPage.getPage().bulkActionList();
        AttendeeBulkActionListPage.getPage().bulkEdit();
        AdminAttendeeBulkEditPage.getPage().bulkUpdateCompanyName("Fail Blog");

        //assert attendee was edited
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        Assert.assertTrue(AttendeeSearchPage.getPage().findAttendeeByText("Fail Blog"));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27983", firefoxIssue = "RA-27984")
    public void checkIn(){
        //check in attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        AttendeeSearchPage.getPage().bulkActionList();
        AttendeeBulkActionListPage.getPage().bulkCheckIn();
        AttendeeBulkCheckInPage.getPage().setBadgePrintLocation();
        AttendeeBulkCheckInPage.getPage().setCheckInMessage(dataGenerator.generateString(10));
        AttendeeBulkCheckInPage.getPage().submit();

        //assert attendee is checked in
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        Assert.assertTrue(AttendeeSearchPage.getPage().attendeeStatusIs(attendeeEmail, "Attended"));
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-27985", firefoxIssue = "RA-27986")
    public void bulkCheckOut(){
        //check in attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        AttendeeSearchPage.getPage().bulkActionList();
        AttendeeBulkActionListPage.getPage().bulkCheckIn();
        AttendeeBulkCheckInPage.getPage().setBadgePrintLocation();
        AttendeeBulkCheckInPage.getPage().setCheckInMessage(dataGenerator.generateString(10));
        AttendeeBulkCheckInPage.getPage().submit();

        //check attendee out
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        AttendeeSearchPage.getPage().bulkActionList();
        AttendeeBulkActionListPage.getPage().bulkCheckOut();

        //assert attendee was checked out
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        assertShowingUp();
        Assert.assertTrue(AttendeeSearchPage.getPage().attendeeStatusIs(attendeeEmail, "Not-Registered"));
    }

    @AfterClass
    public void tearDown(){
        //delete attendee
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeEmail);
        AttendeeSearchPage.getPage().deleteAttendeeByName(attendeeEmail);

        PageConfiguration.getPage().quit();
    }
}