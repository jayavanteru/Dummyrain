package admin.Registration;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.workflows.NewPages;
import apps.admin.adminPageObjects.workflows.NewPagesSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PageBuilderCriteriaViewInPages {

    private String pageId = "16189720593460018TWL";
    private String attendee1 = "qatester@rainfocus.com";
    private String workflow = "Book Hotel Option";

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
    }

    @Test(groups = {ReportingInfo.PBJ})
    @ReportingInfo(chromeIssue = "RA-44492", firefoxIssue = "RA-44493")
    public void criteriaView(){

        NewPagesSearchPage.getPage().navigateById(pageId);
        NewPages.getPage().previewPage(workflow, attendee1);
        Assert.assertTrue(NewPages.getPage().VerifyTextOnPreviewPage("Left panel text and image"), "PB Criteria failed to display the left panel");
        Assert.assertTrue(NewPages.getPage().VerifyTextOnPreviewPage("Main headline"), "PB Criteria failed to display the main headline");
        Assert.assertFalse(NewPages.getPage().VerifyTextOnPreviewPage("Left panel headline"), "PB Criteria shows wrong users info");
    }

    @AfterTest
    public void cleanUp() {
        PageConfiguration.getPage().quit();
    }
}