package admin.Registration.packages;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorPackageSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ScheduledPricing {

    private AdminApp adminApp;
    private String packageId;
    private String attendeeId;

    @BeforeClass
    public void adminSetup(){
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        DataGenerator gen = new DataGenerator();
        attendeeId = adminApp.createAttendee(gen.generateValidEmail());
        Utils.sleep(1000);
}

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26138", chromeIssue = "RA-26137")
    public void defaultPackagePrice() {

        DataGenerator datg = new DataGenerator();
        String name = "Automation" + datg.generateString(5);
        String code = "Auto" + datg.generateString((10));
        int defaultprice = 500;
        int earlyprice = 400;
        int lateprice = 600;
        DateTime earlybird = DateTime.now().plusDays(2);
        DateTime atdoor = DateTime.now().plusDays(4);

        //Creates new package and sets an early price and a late price
        NewPackagePage packagePage = NewPackagePage.getPage().getPage();
        packagePage.navigate();
        Utils.sleep(2000);
        packagePage.enterStandardPackageData(name, code, "User", defaultprice);
        packagePage.addPrice(earlyprice, earlybird);
        packagePage.addPrice(lateprice, atdoor);
        packagePage.submit();

        //Searches for the package that was just created and get the package id
        ExhibitorPackageSearchPage exhibitorPackages = ExhibitorPackageSearchPage.getPage();
        String packageName = exhibitorPackages.searchPackage(name);
        Assert.assertEquals(packageName, name, "Could not find a package that is named; " + name);

        //Verify package price
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        Utils.sleep(100);
        Assert.assertTrue(ordersTab.isPackageAvailable(packageName), "did not find the package on the page it should be there");
        ordersTab.selectPackage(packageName);
        ordersTab.clickNextOnAddOrderModal();
        Assert.assertEquals(ordersTab.getTotalPrice(), "$500.00", "the price should be the package price $500");
    }

        @Test(groups = {ReportingInfo.REGITEL})
        @ReportingInfo(firefoxIssue = "RA-26140", chromeIssue = "RA-26139")
        public void earlyPackagePrice() {

            DataGenerator datg = new DataGenerator();
            String name = "Automation" + datg.generateString(5);
            String code = "Auto" + datg.generateString((10));
            int defaultprice = 500;
            int earlyprice = 400;
            int lateprice = 600;
            DateTime earlybird = DateTime.now().minusDays(2);
            DateTime atdoor = DateTime.now().plusDays(2);

            //Creates new package and sets an early price and a late price
            NewPackagePage packagePage = NewPackagePage.getPage();
            packagePage.navigate();
            Utils.sleep(2000);
            packagePage.enterStandardPackageData(name, code, "User", defaultprice);
            packagePage.addPrice(earlyprice, earlybird);
            packagePage.addPrice(lateprice, atdoor);
            packagePage.submit();

            //Searches for the package that was just created and get the package id
            ExhibitorPackageSearchPage exhibitorPackages = ExhibitorPackageSearchPage.getPage();
            String packageName = exhibitorPackages.searchPackage(name);
            Assert.assertEquals(packageName, name, "Could not find a package that is named; " + name);

            //Verify package price
            AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
            ordersTab.navigate(attendeeId);
            ordersTab.addOrder();
            Utils.sleep(100);
            Assert.assertTrue(ordersTab.isPackageAvailable(packageName), "did not find the package on the page it should be there");
            ordersTab.selectPackage(packageName);
            ordersTab.clickNextOnAddOrderModal();
            Assert.assertEquals(ordersTab.getTotalPrice(), "$400.00", "the price should be the package price $400");
        }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26142", chromeIssue = "RA-26141")
    public void latePackagePrice() {

        DataGenerator datg = new DataGenerator();
        String name = "Automation" + datg.generateString(5);
        String code = "Auto" + datg.generateString((10));
        int defaultprice = 500;
        int earlyprice = 400;
        int lateprice = 600;
        DateTime earlybird = DateTime.now().minusDays(4);
        DateTime atdoor = DateTime.now().minusDays(2);

        //Creates new package and sets an early price and a late price
        NewPackagePage packagePage = NewPackagePage.getPage().getPage();
        packagePage.navigate();
        Utils.sleep(2000);
        packagePage.enterStandardPackageData(name, code, "User", defaultprice);
        packagePage.addPrice(earlyprice, earlybird);
        packagePage.addPrice(lateprice, atdoor);
        packagePage.submit();

        //Searches for the package that was just created and get the package id
        ExhibitorPackageSearchPage exhibitorPackages = ExhibitorPackageSearchPage.getPage();
        String packageName = exhibitorPackages.searchPackage(name);
        Assert.assertEquals(packageName, name, "Could not find a package that is named; " + name);

        //Verify package price
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        Utils.sleep(100);
        Assert.assertTrue(ordersTab.isPackageAvailable(packageName), "did not find the package on the page it should be there");
        ordersTab.selectPackage(packageName);
        ordersTab.clickNextOnAddOrderModal();
        Assert.assertEquals(ordersTab.getTotalPrice(), "$600.00", "the price should be the package price $600");
    }


    @AfterClass
    public void end(){
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();

    }
    @AfterMethod
    public void cleanup(){
        if (packageId != null) {
            adminApp.deletePackage(packageId);
        }

    }
}
