package admin.Registration.packages;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeCustomTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.AttendeeScheduleTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class ComplicatedPackage {

    private AdminApp adminApp;
    String packageName = "Session Registration";
    String packageId = "1514921105614002jIsY";
    private String attendeeId;

    @BeforeClass
    public void setupTest() {
        adminApp = new AdminApp();

        AdminLoginPage.getPage().login();

        OrgEventData.getPage().setOrgAndEvent();

        DataGenerator gen = new DataGenerator();
        attendeeId = adminApp.createAttendee(gen.generateValidEmail());
        Utils.sleep(1000);
    }

    @AfterClass
    public void deleteAttendee() {
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-27763", chromeIssue = "RA-27757")
    public void placeOrderForAttendee() {
        String fieldName = "Attendee Type";
        String regCode = "ses'reg'2";
        AdminAttendeeCustomTab customTab = AdminAttendeeCustomTab.getPage(AdminAttendeeCustomTab.Tab.TAB3);
        AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();
        AttendeeScheduleTab schedule = AttendeeScheduleTab.getPage();

        //verify that the package is not an option to select
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        Assert.assertFalse(ordersTab.isPackageAvailable(packageName), "saw the package on the page it should not be there yet");

        customTab.navigate(attendeeId);
        customTab.checkCheckBoxField(fieldName, 0);
        customTab.submit();

        ordersTab.navigate(attendeeId);
        ordersTab.closeAddOrderModal();
        ordersTab.addRegCode(regCode); //200 discount on package
        ordersTab.addOrder();
        Assert.assertTrue(ordersTab.isPackageAvailable(packageName), "did not find the package '"+packageName+"' on the page it should be there");
        ordersTab.selectPackage(packageName);
        ordersTab.selectFirstSession(packageId);
        String sessionCode = ordersTab.getFirstSessionCode();
        ordersTab.clickNextOnAddOrderModal();
        Utils.waitForTrue(()->ordersTab.getTotalPrice().equals("$300.00"), 45);

        //assert the price is 300, 500 package - 200 from reg code
        Assert.assertEquals(ordersTab.getTotalPrice(), "$300.00", "the price should be the package price $500 - reg code discount $200");
        ordersTab.fillOutOrder();
        ordersTab.submitOrder();

        Assert.assertTrue(ordersTab.verifyPackageOrdered(packageName), "package was not ordered, " + packageName);

        //make sure it scheduled my session
        schedule.navigate(attendeeId);
        Assert.assertTrue(schedule.sessionExists(sessionCode), "the session did not get scheduled from the order, looking for session " + sessionCode);
    }
}
