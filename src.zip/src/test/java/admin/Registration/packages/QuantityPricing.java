package admin.Registration.packages;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.ExhibitorPackageSearchPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class QuantityPricing {

    private AdminApp adminApp;
    private String packageId;
    private String attendeeId;

    private AdminAttendeeOrdersTab ordersTab = AdminAttendeeOrdersTab.getPage();

    @BeforeClass
    public void adminSetup(){
        adminApp = new AdminApp();
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        DataGenerator gen = new DataGenerator();
        attendeeId = adminApp.createAttendee(gen.generateValidEmail());
        Utils.sleep(1000);
}
    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26051", chromeIssue = "RA-26049")
    public void defaultPackagePrice() {

       // This test sets three price ranges, then goes to the order tab and verifies that the price is correct for all the price ranges

        DataGenerator datg = new DataGenerator();
        String name = "Automation" + datg.generateString(5);
        String code = "Auto" + datg.generateString(10);
        int defaultprice = 600;
        String regcodecat = "Exhibitor";
        String codegen = "Single Code";
        String packagepurch = "2 Day Conference Pass";
        String discount = "CertifiedUser";
        String action = "Invite";
        String passavalible = "Immediately";
        int fromA = 1;
        int toA = 4;
        int priceA = 500;
        String nameA = "Group Range A";
        int fromB = 5;
        int toB = 9;
        int priceB = 400;
        String nameB = "Group Range B";
        int fromC = 10;
        int toC = 15;
        int priceC = 300;
        String nameC = "Group Range C";





        //Creates new package and sets GroupPackage values
        NewPackagePage packagePage = NewPackagePage.getPage();
        packagePage.navigate();
        packagePage.enterStandardPackageData(name, code, "User", defaultprice);
        packagePage.groupPackage();
        packagePage.groupYes();
        packagePage.enterGroupPackageData(regcodecat, codegen, packagepurch, discount, action, passavalible);//packagePage.addRange();
        packagePage.enterGroupRangeData(fromA, toA, priceA, nameA);
        packagePage.addRange();
        packagePage.waitForNewRange(2);
        packagePage.enterGroupRangeData(fromB, toB, priceB, nameB);
        packagePage.addRange();
        packagePage.waitForNewRange(3);
        packagePage.enterGroupRangeData(fromC, toC, priceC, nameC);
        packagePage.submit();
       // packagePage.scrollTest();

        //Searches for the package that was just created and get the package id
        ExhibitorPackageSearchPage exhibitorPackages = ExhibitorPackageSearchPage.getPage();
        exhibitorPackages.waitForPageLoad();
        String packageName = exhibitorPackages.searchPackage(name);
        packageId = exhibitorPackages.getId(packageName);
        Assert.assertEquals(packageName, name, "Could not find a package that is named; " + name);

        //Verify package price range 1-15
        ordersTab.navigate(attendeeId);
        ordersTab.addOrder();
        Assert.assertTrue(ordersTab.isPackageAvailable(packageName), "did not find the package on the page it should be there");
        ordersTab.selectPackage(packageName);
        int i=1;

        verifyTotal(packageName, i, priceA);
        i = toA;
        verifyTotal(packageName, i, priceA);
        ++i;
        verifyTotal(packageName, i, priceB);
        i = toB;
        verifyTotal(packageName, i, priceB);
        ++i;
        verifyTotal(packageName, i, priceC);
        i = toC;
        verifyTotal(packageName, i, priceC);
    }

    private void verifyTotal(String packageName, int quantity, int expectedPrice) {
        ordersTab.setQuantity(packageName,quantity);
        String costA = String.format("%,d", quantity*expectedPrice);
        ordersTab.clickNextOnAddOrderModal();
        Assert.assertEquals(ordersTab.getTotalPrice(), "$"+(costA)+".00", "the price should be the package price");
        ordersTab.clickBack();
    }

    @AfterClass
    public void end(){
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();

    }
    @AfterMethod
    public void cleanup(){
        if (packageId != null) {
            adminApp.deletePackage(packageId);
        }

    }
}

