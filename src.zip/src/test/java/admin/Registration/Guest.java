package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.*;
import logs.ReportingInfo;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class Guest {

  private List<String> attendeeIdsToDelete = new ArrayList<>();
  private List<String> packageNamesToDelete = new ArrayList<>();
  private Map<String, List<String>> attendeeIdToPurchasedPackageNames = new HashMap<>();

  // these random letters are added because once the package is created, it is created at the org level and will need a new name/code to be created again
  private static final String packageName = "Automation Guest Package " + RandomStringUtils.randomAlphabetic(5);
  private static final String packageCode = "agp_" + RandomStringUtils.randomAlphabetic(5);

  @BeforeClass
  public void setup()
  {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

    NewPackagePage newPackagePage = new NewPackagePage();
    newPackagePage.navigate();

    packageNamesToDelete.add(packageName);

    newPackagePage.createGuestPackage(packageName, packageCode, "Test guest package created through automation", 10, 4, 1, 0, true, false, true);
    newPackagePage.waitForPageLoad();
  }

  @AfterClass
  public void teardown() throws Exception
  {
    AdminAttendeeOrdersTab attendeeOrdersTab = new AdminAttendeeOrdersTab();
    attendeeIdToPurchasedPackageNames.forEach((attendeeId, packageNames) -> {
      for(String packName : packageNames) {
        attendeeOrdersTab.navigate(attendeeId);
        attendeeOrdersTab.waitForPageLoad();
        PageConfiguration.getPage().refreshPage();
        attendeeOrdersTab.selectOrder(packName);
        attendeeOrdersTab.deleteOrders();
        attendeeOrdersTab.selectGuestLineItems(1);
        attendeeOrdersTab.toggleCancellationEmail();
        attendeeOrdersTab.cancelOrder();
        attendeeOrdersTab.waitForPageLoad();
      }
    });


    AdminApp adminApp = new AdminApp();
    for(String attendeeId : attendeeIdsToDelete) {
      adminApp.deleteAttendee(attendeeId);
    }

    PackageSearchPage packageSearchPage = new PackageSearchPage();
    packageSearchPage.navigate();

    for(String packageName : packageNamesToDelete) {
      packageSearchPage.searchPackage(packageName);
      if(packageSearchPage.isDeletable(0))
        packageSearchPage.deletePackage(0);
    }

    packageSearchPage.waitForPageLoad();

    PageConfiguration.getPage().quit();
  }

  /**
   * create guest package
   * purchase guest package
   * verify that correct number of guests were generated
   * verify that guests show the correct host on their profile order page
   */
  @Test(groups = {ReportingInfo.REGITEL})
  @ReportingInfo(firefoxIssue = "RA-26046", chromeIssue = "RA-26043")
  public void testPurchaseGuestPackageInAdmin() throws Exception
  {
    AdminApp adminApp = new AdminApp();
    String email = "automationHostAttendee_" + RandomStringUtils.randomAlphabetic(5) + "@rainfocus.com";
    String firstName = "Automation";
    String lastName = "Host " + RandomStringUtils.randomAlphabetic(5);
    String attendeeId = adminApp.createAttendee(email, firstName, lastName);

    attendeeIdsToDelete.add(attendeeId);

    AdminAttendeeOrdersTab attendeeOrdersTab = new AdminAttendeeOrdersTab();
    attendeeOrdersTab.navigate(attendeeId);
    attendeeOrdersTab.waitForPageLoad();
    attendeeOrdersTab.addOrder();
    attendeeOrdersTab.selectPackage(packageName);
    attendeeOrdersTab.clickNextOnAddOrderModal();
    attendeeOrdersTab.setComment("Purchase guest package");
    attendeeOrdersTab.submitOrder();

    addPurchasedPackageName(attendeeId, packageName);

    EditGuestModal editGuestModal = new EditGuestModal();
    editGuestModal.openGuestModal();
    String guestFirstName = "Automation";
    String guestLastName = "Guest " + RandomStringUtils.randomAlphabetic(5);
    editGuestModal.editGuestName(0, guestFirstName, guestLastName);
    editGuestModal.closeGuestModal();

    assertTrue(attendeeOrdersTab.verifyPackageOrdered(packageName));

    AttendeeSearchPage attendeeSearchPage = new AttendeeSearchPage();
    attendeeSearchPage.navigate();
    attendeeSearchPage.waitForPageLoad();
    attendeeSearchPage.searchFor(guestLastName);
    assertTrue(attendeeSearchPage.isAnySearchResults());
    attendeeSearchPage.clickResult(0);

    EditAttendeePage editAttendeePage = new EditAttendeePage();
    String guestEmail = editAttendeePage.getEmail();
    assertTrue(StringUtils.containsIgnoreCase(guestEmail, attendeeId), "the guest attendee did not have the id in the email. guest email: " + guestEmail + " attendee Id: " + attendeeId);
    String guestAttendeeId = editAttendeePage.getAttendeeId();
    attendeeOrdersTab.navigate(guestAttendeeId);
    attendeeOrdersTab.waitForPageLoad();

    String hostName = attendeeOrdersTab.getHostName();
    String hostFullName = firstName + " " + lastName;
    assertEquals(hostName, hostFullName);
  }

  private void addPurchasedPackageName(String attendeeId, String packageName) {
    List<String> packageNames = attendeeIdToPurchasedPackageNames.get(attendeeId);
    if(packageNames == null)
      packageNames = new ArrayList<>();

    packageNames.add(packageName);
    attendeeIdToPurchasedPackageNames.put(attendeeId, packageNames);
  }

}
