package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import apps.admin.adminPageObjects.registration.PackageSearchPage;
import logs.ReportingInfo;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class CancelPackageWithFee {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();

    protected String email = "AutomationAttendee" + generator.generateEmail();
    private String attendeeId;
    private String packageId;

    protected String packageName = "PackageWithCancellationFee" + generator.generateName();
    protected String code = "Code" + generator.generateString(5);
    protected String description = "Creating a package with cancellation fee";
    protected String type = "User";

    @BeforeTest
    public void Setup(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().createPackage(packageName, code,  description, type, 10, 5,3, 100);
        NewPackagePage.getPage().clickAddCancellationFee();

        DateTime startDate = DateTime.now().plusDays(-2);
        DateTime endDate = DateTime.now().plusDays(4);

        NewPackagePage.getPage().cancellationFeeDatePicker(startDate, endDate);
        NewPackagePage.getPage().addCancellationFeeAmount(10);
        NewPackagePage.getPage().selectTypeForCancellationFee("Percent");
        NewPackagePage.getPage().submit();
        packageId = PackageSearchPage.getPage().getId(packageName);

        attendeeId = adminApp.createAttendee(email);
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-29425", firefoxIssue = "RA-30129")
    public void CancelPackageWithCancellationFee(){

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().justWait();
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(packageName);
        AdminAttendeeOrdersTab.getPage().clickNextOnAddOrderModal();
        AdminAttendeeOrdersTab.getPage().fillOutOrder();
        AdminAttendeeOrdersTab.getPage().markAsPaid();
        AdminAttendeeOrdersTab.getPage().submitOrder();

        AdminAttendeeOrdersTab.getPage().justWait();
        AdminAttendeeOrdersTab.getPage().selectOrder(packageName);
        AdminAttendeeOrdersTab.getPage().deleteOrders();

        //Assert Cancellation Fee value
        Assert.assertTrue(NewPackagePage.getPage().cancellationFeeAmount("10"),"Wrong cancellation amount");

        AdminAttendeeOrdersTab.getPage().cancelOrder();
        Assert.assertFalse(AdminAttendeeOrdersTab.getPage().verifyPackageOrdered(packageName)); //Make sure package is deleted*/
    }

    @AfterTest
    public void CleanUp(){

        AdminAttendeeOrdersTab.getPage().selectOrder("Cancellation Fee");
        AdminAttendeeOrdersTab.getPage().deleteOrders();
        AdminAttendeeOrdersTab.getPage().cancelOrder();

        adminApp.deleteAttendee(attendeeId);
        adminApp.deletePackage(packageId);

        PageConfiguration.getPage().quit();
    }

}
