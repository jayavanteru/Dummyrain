package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.AdminEventAttributesPage;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class MultipleDiscountUsingAttributes {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String attributeId;
    private String packageId;

    protected String packageName = "PackageNew_" + generator.generateName();
    protected String discountName1 = "discount1_" + generator.generateString(5);
    protected String discountName2 = "discount2_" + generator.generateString(5);
    protected String code = "Code_1" + generator.generateNumber(10090);
    protected String Attribute1 = "Attribute1" + generator.generateString(3);
    protected String Attribute2 = "Attribute2" + generator.generateString(3);

    protected String attributeName = generator.generateName();
    CreateEventAttributePage createEventAttribute = CreateEventAttributePage.getPage();
    AdminEventAttributesPage attributeSearchPage = AdminEventAttributesPage.getPage();

    @BeforeMethod
    public void initial() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        //Create an Attribute
        createEventAttribute.navigate();
        createEventAttribute.createRadioList(attributeName, new String[]{Attribute1, Attribute2}, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);
        createEventAttribute.saveAttribute();

        //Get AttributeID
        attributeSearchPage.searchAttribute(attributeName);
        attributeId = attributeSearchPage.getAttributeId(attributeName);

        //Package Creation
        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().enterStandardPackageData(packageName, code, "User", 100);
        NewPackagePage.getPage().submit();
        packageId = PackageSearchPage.getPage().getId(packageName);

        //Discount1 Creation
        CreateDiscountPage.getPage().navigate();
        CreateDiscountPage.getPage().createDiscountWithQualifiers(discountName1, "Dollars Off", "30", packageName, Attribute1);
        CreateDiscountPage.getPage().submit();

        //Creating an Attendee
        email = generator.generateValidEmail();
        attendeeId = adminApp.createAttendee(email);

        //Discount2 Creation
        CreateDiscountPage.getPage().navigate();
        CreateDiscountPage.getPage().createDiscountWithQualifiers(discountName2, "Percent Off", "50", packageName, Attribute2);
        CreateDiscountPage.getPage().submit();
        PageConfiguration.getPage().waitForPageLoad();

        //Adding attribute to the attendee's demographics tab
        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        AdminAttendeeDemographicsTab.getPage().clickEdit();
        AdminAttendeeDemographicsTab.getPage().searchForExistingFields(attributeName);
        AdminAttendeeDemographicsTab.getPage().submitOnModal();

    }


    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-18981", firefoxIssue = "RA-26099")
    public void multipleDiscountApplied() {

        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        AdminAttendeeDemographicsTab.getPage().chooseFromRadioType(Attribute1);
        AdminAttendeeDemographicsTab.getPage().submit();

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(packageName);
        AdminAttendeeOrdersTab.getPage().clickNextOnAddOrderModal();
        AdminAttendeeOrdersTab.getPage().fillOutOrder();
        AdminAttendeeOrdersTab.getPage().markAsPaid();
        AdminAttendeeOrdersTab.getPage().submitOrder();
        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().checkTotalPrice("$70.00"));

        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        AdminAttendeeDemographicsTab.getPage().chooseFromRadioType(Attribute2);
        AdminAttendeeDemographicsTab.getPage().submit();

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().viewPriceChange(packageName);
        AdminAttendeeOrdersTab.getPage().setComments("Checking for price change");
        AdminAttendeeOrdersTab.getPage().submitOrder();
        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().checkTotalPrice("$50.00"));
    }

    @AfterTest
    public void cleanUp(){

        //Deleting package on the admin side
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        AttendeeSearchPage.getPage().clickResult(0);
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().selectOrder(packageName);
        AdminAttendeeOrdersTab.getPage().deleteOrders();
        AdminAttendeeOrdersTab.getPage().cancelOrder();

        //Remove attribute from demographics page
        AdminAttendeeDemographicsTab.getPage().navigate(attendeeId);
        AdminAttendeeDemographicsTab.getPage().removeAttribute(attributeName);
        AdminAttendeeDemographicsTab.getPage().submitOnModal();

        adminApp.deleteAttendee(attendeeId);

        //Delete First Discount
        DiscountSearchPage.getPage().GoTo();
        DiscountSearchPage.getPage().searchForDiscount(discountName1);
        DiscountSearchPage.getPage().clickResult(0);
        CreateDiscountPage.getPage().removeFirstQualifier();
        String discountId1 = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];
        CreateDiscountPage.getPage().submit();

        DiscountSearchPage.getPage().deleteDiscountApi(discountId1);

        //Delete second discount
        DiscountSearchPage.getPage().GoTo();
        DiscountSearchPage.getPage().searchForDiscount(discountName2);
        DiscountSearchPage.getPage().clickResult(0);
        CreateDiscountPage.getPage().removeFirstQualifier();
        String discountId2 = PageConfiguration.getPage().getCurrentUrl().split("id=")[1];
        CreateDiscountPage.getPage().submit();

        DiscountSearchPage.getPage().deleteDiscountApi(discountId2);

        //Delete Package
        adminApp.deletePackage(packageId);
        //Delete the attribute
        attributeSearchPage.navigate();
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();

    }

}