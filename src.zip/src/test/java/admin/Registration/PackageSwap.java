package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class PackageSwap {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String basicPackage = "BasicPackage";
    private String swapPackage = "Swap Package";
    private String email;
    private String attendeeId;

    @BeforeTest
    public void startUp(){
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        email = generator.generateEmail();
        attendeeId = adminApp.createAttendee(email);

        //Purchase the package
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId);
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(basicPackage);
        AdminAttendeeOrdersTab.getPage().clickNextOnAddOrderModal();
        AdminAttendeeOrdersTab.getPage().fillOutOrder();
        AdminAttendeeOrdersTab.getPage().markAsPaid();
        AdminAttendeeOrdersTab.getPage().submitOrder();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-30303", firefoxIssue = "RA-30304")
    public void basicPackageSwap(){
        //Swap package of the same price
         AdminAttendeeOrdersTab.getPage().selectPackageSwapIcon(basicPackage);
         AdminAttendeeOrdersTab.getPage().justWait();
         AdminAttendeeOrdersTab.getPage().selectPackageOnPackageSwapModal(swapPackage);
         AdminAttendeeOrdersTab.getPage().justWait();
         Assert.assertTrue(AdminAttendeeOrdersTab.getPage().verifyPackageOrdered(swapPackage), "Swaped package is missing");
     }

     @AfterTest
    public void cleanUp(){
         AdminAttendeeOrdersTab.getPage().selectOrder(swapPackage);
         AdminAttendeeOrdersTab.getPage().deleteOrders();
         AdminAttendeeOrdersTab.getPage().cancelOrder();

         adminApp.deleteAttendee(attendeeId);

         PageConfiguration.getPage().quit();
     }
}
