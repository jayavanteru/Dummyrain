package admin.Registration.Emails;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.libraries.NewEmailPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import interaction.gmail.EmailApi;
import interaction.gmail.EmailMessage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MultiAttendeeBulkEmail {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String baseEmail = dataGenerator.generateString(), emailName;
    List<String> attendeeIds = new ArrayList<>(),
            attendeeEmails = new ArrayList<>();

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        attendeeIds.stream().forEach(adminApp::deleteAttendee);

        EmailsSearchPage.getPage().navigate();
        EmailsSearchPage.getPage().searchFor(emailName);
        EmailsSearchPage.getPage().deleteEmail(emailName);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-28464", firefoxIssue = "RA-28465")
    public void multiAttendeeBulkEmail() {
        //create email
        NewEmailPage.getPage().navigate();
        NewEmailPage.getPage().createEmail(emailName = dataGenerator.generateName(), emailName, "test@rainfocus.com", emailName, false, dataGenerator.generateString());

        //create attendees
        for (int i = 0; i < 3; i++) {
            String tempEmail = "rainfocustestautomationuser+" + dataGenerator.generateString() + baseEmail + "@gmail.com";
            attendeeIds.add(adminApp.createAttendee(tempEmail));
            attendeeEmails.add(tempEmail);
        }

        //look for all attendees
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().toggleAdvancedSearchOn();
        AttendeeSearchPage.getPage().advSearch("Email", "contains", baseEmail);
        AttendeeSearchPage.getPage().search();

        //bulk email all the attendees
        AttendeeSearchPage.getPage().clickActions();
        AttendeeSearchPage.getPage().openBulkEmailModal();
        AttendeeSearchPage.getPage().bulkEmail(emailName);

        //assert that emails were sent
        EmailApi.emailClient().waitForEmail(emailName);
        EmailMessage[] recentEmails = EmailApi.emailClient().getRecentEmails(20);
        ArrayList<String> allRecipients = new ArrayList<>();
        Arrays.stream(recentEmails).forEach((email)->{
            String[] recipients = email.getRecipients();
            Arrays.stream(recipients).forEach(allRecipients::add);
        });

        attendeeEmails.stream().forEach((email)->{
            Assert.assertTrue(allRecipients.contains(email), "EMAIL WAS NOT SENT TO ATTENDEE"+email);
        });
    }
}
