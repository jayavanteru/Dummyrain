package admin.Registration.Emails;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class SubUserScheduling {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    //TEST 1:
    //ORG HAS NO SUB USER - Attempt to Schedule a rainfocus email - The UI does not load
    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-46374", firefoxIssue = "RA-46375")
    public void hasNoSubUser() {
        //navigate to org
        OrgEventData.getPage().setOrgAndEvent("No Sub User", "Event");

        //attempt to send email
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().clickActions();
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().setEmailToSend("RAINFOCUS EMAIL");

        //assert email can not be sent
        PageConfiguration.getPage().justWait();
        Assert.assertFalse(AttendeeSearchPage.getPage().bulkEmailCanBeScheduled(), "RAINFOCUS EMAIL SHOULD NOT HAVE BEEN ABLE TO BE SCHEDULED");

        PageConfiguration.getPage().refreshPage();
    }

    //TEST 2:
    //ORG HAS SUB USER - Attempt to Schedule a rainfocus email - The UI loads
    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-46376", firefoxIssue = "RA-46377")
    public void hasSubUser() {
        //navigate to org
        OrgEventData.getPage().setOrgAndEvent("SubUser", "Event A");

        //attempt to send email
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().search();
        AttendeeSearchPage.getPage().clickActions();
        AttendeeSearchPage.getPage().clickBulkEmail();
        AttendeeSearchPage.getPage().setEmailToSend("RAINFOCUS EMAIL");

        //assert email can be sent
        Assert.assertTrue(AttendeeSearchPage.getPage().bulkEmailCanBeScheduled(), "RAINFOCUS EMAIL SHOULD HAVE BEEN ABLE TO BE SCHEDULED");

        PageConfiguration.getPage().refreshPage();
    }
}
