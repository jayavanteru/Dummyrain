package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import apps.admin.adminPageObjects.registration.PackageSearchPage;
import logs.ReportingInfo;
import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.fail;

public class Waitlist
{

  private List<String> packageNamesToDelete = new ArrayList<>();

  @BeforeClass
  public void setup()
  {
    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");
  }

  @AfterClass
  public void teardown()
  {
    PackageSearchPage packageSearchPage = new PackageSearchPage();
    packageSearchPage.navigate();

    for(String packageName : packageNamesToDelete) {
      packageSearchPage.searchPackage(packageName);
      if(packageSearchPage.isDeletable(0))
        packageSearchPage.deletePackage(0);
    }

    PageConfiguration.getPage().quit();
  }

//  @Test
  public void testing()
  {
    try
    {
      // this is a placeholder test just for reference
      String packageName = "colton test 01";
      AdminApp.ensurePackageExists(packageName);
    }
    catch (Exception e)
    {
      fail();
    }
  }

  // this is just a basic test that creates a waitlist package
  // this isn't really testing waitlist functionality itself at all yet, just that a waitlist package can be created
  @Test(groups = {ReportingInfo.REGITEL})
  @ReportingInfo(firefoxIssue = "RA-26048", chromeIssue = "RA-26047")
  public void testCreateWaitlistPackage() {
    NewPackagePage newPackagePage = new NewPackagePage();
    newPackagePage.navigate();
    newPackagePage.waitForPageLoad();

    // these random letters are added because once the package is created, it is created at the org level and will need a new name/code to be created again
    String packageName = "Automation Waitlist Package " + RandomStringUtils.randomAlphabetic(5);
    String packageCode = "awp_" + RandomStringUtils.randomAlphabetic(5);

    packageNamesToDelete.add(packageName);

    newPackagePage.createWaitlistPackage(packageName, packageCode, "Test waitlist package created through automation", 10, 1, 1, 0, true, false, 24, false);

    PackageSearchPage packageSearchPage = new PackageSearchPage();
    packageSearchPage.navigate();
    assertNotNull(packageSearchPage.searchPackage(packageName));
  }

}
