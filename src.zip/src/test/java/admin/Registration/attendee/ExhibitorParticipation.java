package admin.Registration.attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.registration.AdminAttendeeSummaryTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorParticipation {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitorName, exhibitorId,
            attendeeId, attendeeEmail;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Event D");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteExhibitor(exhibitorId);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-39809", firefoxIssue = "RA-39810")
    public void attendeeExhibitorParticipation() {
        setUp();

        EditAttendeePage.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeSummaryTab.getPage().exhibitorParticipationExists(exhibitorName, "New", "Primary Owner"), "EXHIBITOR PARTICIPATION DOES NOT EXIST");
    }

    private void setUp() {
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());
        exhibitorId = adminApp.createExhibitorInCurrentEvent(exhibitorName = dataGenerator.generateName());
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendeeEmail, "Primary Owner");
    }
}
