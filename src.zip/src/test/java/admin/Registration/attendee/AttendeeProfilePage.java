package admin.Registration.attendee;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AttendeeProfilePage
{
  @BeforeClass
  public void setup() {
    AdminApp adminApp = new AdminApp();
    adminApp.setupNewAdminUserAndSpoofTo(RFConstants.ORG_IBM, RFConstants.EVENT_NAME_EVENTGERS_TEST, AdminApp.orgIBMCode);
  }

  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-42037", chromeIssue = "RA-42038")
  public void testEventKeywordsInProfileLeftNavForm()
  {
    /*
      this assumes the setup of actually putting the keywords on the form
    */

    AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
    attendeeSearchPage.navigateToNewAdminPage();
    // created an attendee "Bugs Bunny" in dev/prod
    attendeeSearchPage.searchFor("bugs");
    attendeeSearchPage.clickResult(0);

    Assert.assertTrue(attendeeSearchPage.eventKeywordsInProfileLeftNavForm(), "Keywords on forms on attendee left hand form not working");
  }
}
