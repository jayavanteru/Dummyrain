package admin.Registration.attendee;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class Attendees {

  AttendeeSearchPage attendeeSearchPage;
  EditAttendeePage editAttendeePage;
  CreateAttendeePage createAttendeePage;
  DataGenerator dataGenerator;
  AdminApp adminApp;
  CreateEventAttributePage createEventAttributePage;
  String attendeeEmail, attributeName, attributeId;
  String[] options = new String[]{"Option 1", "Option 2", "Option 3", "Option 4", "Option 5"};
  String[] visibleOptions = new String[]{"Option 1", "Option 2", "Option 3"};
  String[] optionsToUnCheck = new String[]{"Option 4", "Option 5"};

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    adminApp = new AdminApp();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();
    createAttendeePage = CreateAttendeePage.getPage();
    createEventAttributePage = CreateEventAttributePage.getPage();

    attendeeEmail = dataGenerator.generateValidEmail();
    attributeName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);
  }

  @AfterClass
  public void tearDown() {

    // Delete Attribute from Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.clickResult(0);
    editAttendeePage.openAttendeeFormModal();
    editAttendeePage.deleteAttributeFromModal(attributeName);
    editAttendeePage.submitModalAttributes();

    // Delete Attendee
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor(attendeeEmail);
    attendeeSearchPage.deleteFirstRecord();

    // Delete Attribute
    adminApp.deleteAttribute(attributeId);

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-40683", chromeIssue = "RA-40217")
  public void showHideAttendeesAttributes() {

    String attendeeName = dataGenerator.generateString();
    String attendeeLastName = dataGenerator.generateString();

    // Create Attendee attribute
    attributeId = adminApp.createSelectAttribute(attributeName, options, CreateEventAttributePage.AUDIENCE_TYPES.Attendee);

    // Create Attendee
    createAttendeePage.navigate();
    createAttendeePage.fillOutForm(attendeeEmail, attendeeName, attendeeLastName);

    editAttendeePage.openAttendeeFormModal();
    editAttendeePage.addAttribute(attributeName);
    editAttendeePage.clickCheckOptionOnOpenFormQuestion(optionsToUnCheck);
    editAttendeePage.submitModalAttributes();

    editAttendeePage.openAttributeSelect(attributeName);
    for (int i = 0; i < visibleOptions.length; i++) {
      Assert.assertTrue(editAttendeePage.isAttributeValueVisible(visibleOptions[i]), "Attribute Value is not visible");
    }
  }
}
