package admin.Registration.attendee;

import admin.constants.RFConstants;
import apps.PageConfiguration;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.EditEmailPage;
import apps.admin.adminPageObjects.libraries.EmailsSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class AttendeesBulkEmail {

  EmailsSearchPage emailsSearchPage;
  EditEmailPage editEmailPage;
  AttendeeSearchPage attendeeSearchPage;
  EditAttendeePage editAttendeePage;
  DataGenerator dataGenerator;
  String globalEmailName;

  @BeforeClass
  public void setup() {
    dataGenerator = new DataGenerator();
    emailsSearchPage = EmailsSearchPage.getPage();
    editEmailPage = EditEmailPage.getPage();
    attendeeSearchPage = AttendeeSearchPage.getPage();
    editAttendeePage = EditAttendeePage.getPage();

    globalEmailName = dataGenerator.generateName();

    AdminLoginPage.getPage().login();
  }

  @AfterClass
  public void tearDown() {
    // Delete global email
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(globalEmailName);
    emailsSearchPage.deleteEmail(globalEmailName);

    PageConfiguration.getPage().quit();
  }

  @Test(groups = {ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-41023", chromeIssue = "RA-39091")
  public void showHideAttendeesAttributes() {

    // Create global email
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
    emailsSearchPage.navigate();
    emailsSearchPage.addItem();
    editEmailPage.setName(globalEmailName);
    editEmailPage.setSubject(dataGenerator.generateString());
    editEmailPage.setFromAddress(dataGenerator.generateValidEmail());
    editEmailPage.setCode(dataGenerator.generateString());
    editEmailPage.save();

    // Validate Email in Attendee's Bulk Email option
    validateEmailInBulkEmail(globalEmailName);

    // Make a copy of the email
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(globalEmailName);
    emailsSearchPage.copyFirstEmail();
    editEmailPage.emailCopySelectEvent(RFConstants.EVENT_NAME_TVA);
    String copyEmail = globalEmailName + "Copy";
    editEmailPage.setName(copyEmail);
    editEmailPage.save();

    // Validate Email in Attendee's Bulk Email option
    validateEmailInBulkEmail(copyEmail);

    // Delete event email
    emailsSearchPage.navigate();
    emailsSearchPage.searchFor(copyEmail);
    emailsSearchPage.deleteEmail(copyEmail);

    // Validate Email in Attendee's Bulk Email option
    validateEmailInBulkEmail(globalEmailName);
  }

  private void validateEmailInBulkEmail(String email)
  {
    OrgEventData.getPage().setOrgAndEvent("RainFocus", RFConstants.EVENT_NAME_TVA);
    attendeeSearchPage.navigate();
    attendeeSearchPage.searchFor("");
    attendeeSearchPage.clickActions();
    attendeeSearchPage.openBulkEmailModal();
    editAttendeePage.bulkEmailSelectEmailModal(email);
    Assert.assertTrue(editAttendeePage.bulkEmailExistEmail(email), "Email must be visible");
    editAttendeePage.closeBulkEmailModal();
  }
}
