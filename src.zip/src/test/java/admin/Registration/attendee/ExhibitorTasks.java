package admin.Registration.attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.exhibits.AdminExhibitorContactsTab;
import apps.admin.adminPageObjects.exhibits.EditExhibitorPage;
import apps.admin.adminPageObjects.libraries.NewTaskPage;
import apps.admin.adminPageObjects.libraries.TasksSearchPage;
import apps.admin.adminPageObjects.registration.AttendeeTasksTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class ExhibitorTasks {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String exhibitor1Id, exhibitor1Name,
            attendeeId, attendeeEmail,
            qualifierName, qualifierId,
            taskName, taskId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Task Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteTask(taskId);
        adminApp.deleteTaskQualifier(qualifierId);
        adminApp.deleteExhibitor(exhibitor1Id);
        adminApp.deleteAttendee(attendeeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-39836", firefoxIssue = "RA-39837")
    public void exhibitorTasks() {
        setUp();
        EditAttendeePage.getPage().navigate(attendeeId);
        EditAttendeePage.getPage().tasksTab();
        AttendeeTasksTab.getPage().exhibitorTasks();
        Assert.assertTrue(AttendeeTasksTab.getPage().taskExists(taskName), "TASK DID NOT EXISTS FOR EXHIBITOR 1");
    }

    private void setUp() {
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());
        exhibitors();
        task();
    }

    private void exhibitors() {
        exhibitor1Id = adminApp.createExhibitorInCurrentEvent(exhibitor1Name = dataGenerator.generateName());
        EditExhibitorPage.getPage().clickContactsTab();
        AdminExhibitorContactsTab.getPage().addExistingParticipant(attendeeEmail, "Primary Owner");
    }

    private void task(){
        qualifierId = adminApp.createTaskQualifier(qualifierName = dataGenerator.generateName(),
                "Exhibitors", new Criteria[]{
                        new Criteria("Name", "contains", exhibitor1Name),
                }, "");
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().setName(taskName = dataGenerator.generateName());
        NewTaskPage.getPage().setGroup("alpha");
        NewTaskPage.getPage().setEntityType("Exhibitor");
        NewTaskPage.getPage().setType("External URL");
        NewTaskPage.getPage().setDisplayValue(taskName);
        NewTaskPage.getPage().setQualifiers(qualifierName);
        NewTaskPage.getPage().setCode(taskName);
        NewTaskPage.getPage().setExhibitorRole("Primary Owner");
        NewTaskPage.getPage().setExternalURL("www.google.com");
        NewTaskPage.getPage().submit();
        TasksSearchPage.getPage().searchFor(taskName);
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
    }
}
