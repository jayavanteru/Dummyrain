package admin.Registration.attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import apps.admin.adminPageObjects.registration.CreateAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.List;
import java.util.Map;

public class AttendeeCreation {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;

    @BeforeMethod
    public void startup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        email = generator.generateEmail();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-21292", chromeIssue = "RA-18214")
    public void step1(){
        CreateAttendeePage.getPage().navigate();
        CreateAttendeePage.getPage().fillOutForm(email);
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        attendeeId = url[url.length - 1];
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(email);
        List<Map<String, String>> results = AttendeeSearchPage.getPage().getResults();
        Assert.assertEquals(results.size(), 1);
        Assert.assertEquals(results.get(0).get("email"), email);

        attendeeId = AttendeeSearchPage.getPage().getIdByEmail(email);
    }

  @AfterMethod
  public void afterTest() {
        adminApp.deleteAttendee(attendeeId);
      PageConfiguration.getPage().quit();
  }

}

