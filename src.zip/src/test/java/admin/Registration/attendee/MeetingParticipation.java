package admin.Registration.attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.EditMeetingPage;
import apps.admin.adminPageObjects.meetings.MeetingParticipantsTab;
import apps.admin.adminPageObjects.registration.AdminAttendeeSummaryTab;
import apps.admin.adminPageObjects.registration.EditAttendeePage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class MeetingParticipation {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String meetingId, meetingCode, attendeeEmail, attendeeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Meeting Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteMeeting(meetingId);
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-39818", firefoxIssue = "RA-39819")
    public void meetingParticipation() {
        attendeeId = adminApp.createAttendee(attendeeEmail = dataGenerator.generateEmail());
        meetingId = adminApp.createApprovedMeeting("Meeting Program A");
        adminApp.safeSetTextArea("Abstract", dataGenerator.generateString());
        adminApp.safeSetTextBox("Code", meetingCode = dataGenerator.generateName());
        EditMeetingPage.getPage().participantsTab();
        MeetingParticipantsTab.getPage().addExistingParticipant(attendeeEmail, "Attendee");

        EditAttendeePage.getPage().navigate(attendeeId);
        Assert.assertTrue(AdminAttendeeSummaryTab.getPage().meetingParticipationExists(meetingCode, "Approved", "Attendee"), "MEETING PARTICIPATION DOES NOT EXIST");
    }
}
