package admin.Registration.attendee;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.registration.AdminAttendeeTaskTab;
import apps.admin.forms.Form;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.Utils;

public class CompleteTask {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email;
    private String attendeeId;
    private String taskId;
    private String taskQualifierId;

    @BeforeClass
    public void setup() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        email = generator.generateEmail();
       attendeeId = adminApp.createAttendee(email);
    }


    @AfterClass
    public void delete() {
        PageConfiguration.getPage().navigateTo(adminApp.getHost());
        if (attendeeId != null) {
            adminApp.deleteAttendee(attendeeId);
            attendeeId = null;
        } if (taskId != null) {
            //remove the qualifier for deleting
            Utils.sleep(1000);
            EditTaskPage.getPage().navigate(taskId);
            Utils.sleep(500);
            EditTaskPage.getPage().removeQualifiers();
            EditTaskPage.getPage().submit();
            Utils.sleep(500);
            //delete now
            adminApp.deleteTask(taskId);
            adminApp.deleteTaskQualifier(taskQualifierId);
            taskId = null;
        }
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26149", chromeIssue = "RA-19556")
    public void CompleteTaskForAdmin() {
        String formId = "1492465807545001U5ir";
        Criteria taskQualfy = new Criteria("Email", "equal to", email);
        String taskQualifyName = "automation" + generator.generateString(5);
        String taskName = "automation" + generator.generateString(5);

        //get form
        final Form form = adminApp.getForm(formId);

        //create a task
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().createTaskQualifier(taskQualifyName, taskQualfy);
        Utils.sleep(1000); //time to save
        NewTaskPage.getPage().navigate();
        NewTaskPage.getPage().createFormSpeakerTask(taskName, formId, false, taskQualifyName);
        Utils.sleep(500); //time to save

        //get the task qualifier id and task id
        TasksSearchPage.getPage().navigate();
        taskId = TasksSearchPage.getPage().getTaskId(taskName);
        TaskQualifierSearchPage.getPage().navigate();
        taskQualifierId = TaskQualifierSearchPage.getPage().getId(taskQualifyName);

        final AdminAttendeeTaskTab taskTab = AdminAttendeeTaskTab.getPage();

        taskTab.navigate(attendeeId);

        Assert.assertTrue(taskTab.isTaskOnPage(taskName), "did not find task on page. looking for task name: " + taskName);

        taskTab.showToDo();

        taskTab.markTaskComplete(taskName);
        Assert.assertFalse(taskTab.isTaskOnPage(taskName), "found task on page. after completed. " + taskName);

        taskTab.showCompleted();
        Assert.assertTrue(taskTab.isTaskOnPage(taskName), "did not find task on page. after showing completed. looking for task name: " + taskName);

        taskTab.markTaskIncomplete(taskName);
        Assert.assertFalse(taskTab.isTaskOnPage(taskName), "found task on page. after marking incompleted. " + taskName);
        taskTab.showToDo();
        Assert.assertTrue(taskTab.isTaskOnPage(taskName), "did not find task on page. after showing To Do. looking for task name: " + taskName);
    }

}
