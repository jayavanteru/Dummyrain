package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeOrdersTab;
import apps.admin.adminPageObjects.registration.NewPackagePage;
import apps.admin.adminPageObjects.registration.PackageSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class TransferPackages {

    private DataGenerator generator = new DataGenerator();
    private AdminApp adminApp = new AdminApp();
    private String email1 = generator.generateEmail();
    private String email2 = generator.generateEmail();
    private String attendeeId1;
    private String attendeeId2;
    protected String packageName = "AutomationTransfer" + generator.generateName();
    protected String code = "Code" + generator.generateNumber(10090);

    @BeforeMethod
    public void setUp() {

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Regitel");

        attendeeId2 = adminApp.createAttendee(email2);

        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().enterStandardPackageData(packageName, code, "User", 100);
        NewPackagePage.getPage().submit();
    }

    @Test(groups = {ReportingInfo.REGITEL})
    @ReportingInfo(chromeIssue = "RA-31258", firefoxIssue = "RA-31259")
    public void basicTransferPackages() {

        attendeeId1 = adminApp.createAttendee(email1);
        AdminAttendeeOrdersTab.getPage().navigate(attendeeId1);
        AdminAttendeeOrdersTab.getPage().addOrder();
        AdminAttendeeOrdersTab.getPage().selectPackage(packageName);
        AdminAttendeeOrdersTab.getPage().clickNextOnAddOrderModal();
        AdminAttendeeOrdersTab.getPage().fillOutOrder();
        AdminAttendeeOrdersTab.getPage().markAsPaid();
        AdminAttendeeOrdersTab.getPage().submitOrder();

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId1);
        AdminAttendeeOrdersTab.getPage().selectMoreOption("Transfer items");
        AdminAttendeeOrdersTab.getPage().clickTransferToDropDown(email2);
        AdminAttendeeOrdersTab.getPage().selectPackageOnTransferModal(packageName);
        AdminAttendeeOrdersTab.getPage().clickCompleteTransfer();

        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().verifyPackageSelectedOnTransferModal(packageName));
        AdminAttendeeOrdersTab.getPage().clickTransferSelectedItem();
        AdminAttendeeOrdersTab.getPage().justWait();
        Assert.assertFalse(AdminAttendeeOrdersTab.getPage().verifyPackageOrdered(packageName));

        AdminAttendeeOrdersTab.getPage().navigate(attendeeId2);
        Assert.assertTrue(AdminAttendeeOrdersTab.getPage().verifyPackageOrdered(packageName));
    }

    @AfterTest
    public void cleanUp() {
        AdminAttendeeOrdersTab.getPage().selectOrder(packageName);
        AdminAttendeeOrdersTab.getPage().deleteOrders();
        AdminAttendeeOrdersTab.getPage().cancelOrder();

        adminApp.deleteAttendee(attendeeId1);
        adminApp.deleteAttendee(attendeeId2);

        PackageSearchPage.getPage().navigate();
        PackageSearchPage.getPage().searchPackage(packageName);
        PackageSearchPage.getPage().deletePackage(0);

        PageConfiguration.getPage().quit();
    }
}
