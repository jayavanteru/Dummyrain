package admin.Registration;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.registration.AdminAttendeeFilesPage;
import logs.ReportingInfo;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

public class UploadFile {

    private AdminApp adminApp = new AdminApp();
    private DataGenerator generator = new DataGenerator();
    private String fileTypeId = "6654021218154482449";
    private String attendeeId;
    private String fileId;

    @BeforeClass
    public void login() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();

        attendeeId = adminApp.createAttendee(generator.generateValidEmail());
    }

    @AfterClass
    public void delete() {
        if (fileId != null) {
            adminApp.deleteFile(fileId);
        }
        adminApp.deleteAttendee(attendeeId);
        PageConfiguration.getPage().quit();
    }

    //@Test(groups = {"prodTest"}, description = "Uploads a profile photo for an attendee using the api. Checks the photo is showing in the admin")
    public void uploadProfilePhoto_old()  {
        JSONObject response = adminApp.uploadFile(attendeeId, fileTypeId);

        Assert.assertTrue(response.has("data"), "missing response\n" + response);
        JSONObject data = MyJson.getJSONObject(response, "data");

        Assert.assertTrue(data.has("responseCode"), "missing a field\n" + data);
        Assert.assertTrue(data.has("responseMessage"), "missing a field\n" + data);

        Assert.assertEquals(MyJson.getInt(data, "responseCode"), 0, "invalid response code\n" + data);
        Assert.assertEquals(MyJson.getString(data, "responseMessage"), "success", "invalid response message\n" + data);

        Assert.assertTrue(data.has("fileId"), "missing a field\n" + data);
        Assert.assertTrue(data.has("fileUrl"), "missing a field\n" + data);
        Assert.assertTrue(data.has("message"), "missing a field\n" + data);

        Assert.assertTrue(MyJson.getString(data, "fileId").length() > 0, "invalid data in response\n" + data);
        Assert.assertTrue(MyJson.getString(data, "fileUrl").length() > 0, "invalid data in response\n" + data);
        Assert.assertTrue(MyJson.getString(data, "message").length() > 0, "invalid data in response\n" + data);

        fileId = MyJson.getString(data, "fileId");

        //make sure you can see the uploaded pic in the UI
        Utils.sleep(200);
        AdminAttendeeFilesPage filePage = AdminAttendeeFilesPage.getPage();
        filePage.navigate(attendeeId);
        Utils.waitForTrue(filePage::isProfilePhotoUploaded);
        Assert.assertTrue(filePage.isProfilePhotoUploaded(), "the uploaded photo is not showing in the UI");
    }

    @Test(groups = {"prodTest", ReportingInfo.REGITEL})
    @ReportingInfo(firefoxIssue = "RA-26146", chromeIssue = "RA-19030")
    public void uploadProfilePhoto()  {
        AdminAttendeeFilesPage filePage = AdminAttendeeFilesPage.getPage();
        filePage.navigate(attendeeId);

        Assert.assertFalse(filePage.isProfilePhotoDisplayed(), "showing a profile photo when there shouldn't be one");
        filePage.uploadFile("Attendee Profile Photo", "pic1.jpg");
        Utils.waitForTrue(filePage::isProfilePhotoUploaded);
        Assert.assertTrue(filePage.isProfilePhotoUploaded(), "the uploaded photo is not showing in the UI");

        //make sure you can see the uploaded pic in the UI
        PageConfiguration.getPage().refreshPage();
        Assert.assertTrue(filePage.isProfilePhotoDisplayed(), "not showing a profile picture");

        //delete and make sure it is gone
        filePage.deleteFirstFile();
        Utils.waitForTrue(()->!filePage.isProfilePhotoUploaded());
        Assert.assertFalse(filePage.isProfilePhotoUploaded(), "the uploaded photo is in the UI after being deleted");
        PageConfiguration.getPage().refreshPage();
        Assert.assertFalse(filePage.isProfilePhotoDisplayed(), "showing a profile photo when there shouldn't be one");
    }
}
