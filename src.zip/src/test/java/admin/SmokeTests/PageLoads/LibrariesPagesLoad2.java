package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LibrariesPagesLoad2 extends UIVerify{

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26188", chromeIssue = "RA-26187")
    public void ApiProfilesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().API_PROFILES,
                ApiProfileSearchPage.getPage(),
                NewApiProfilePage.getPage(),
                ApiProfilePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26192", chromeIssue = "RA-26189")
    public void AttributesPageLoads() {
        basicItemPages(NavigationBar.getPage().ATTRIBUTES,
                AdminEventAttributesPage.getPage(),
                CreateEventAttributePage.getPage(),
                CreateEventAttributePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26194", chromeIssue = "RA-26193")
    public void BrandingCenterPageLoads() {
        basicItemPages(NavigationBar.getPage().BRANDING_CENTER,
                BrandingSearchPage.getPage(),
                CreateBrandingPage.getPage(),
                CreateBrandingPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26197", chromeIssue = "RA-26196")
    public void DisbursementsPageLoads() {
        basicItemPages(NavigationBar.getPage().DISBURSEMENTS,
                DisbursementsSearchPage.getPage(),
                DisbursementPage.getPage(),
                NewDisbursementPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26199", chromeIssue = "RA-26198")
    public void DuplicatesPageLoads() {
        NavigationBar.getPage().gotoPage(NavigationBar.getPage().DUPLICATES);
        StringBuilder missEl = new StringBuilder();

        DuplicatesPage.getPage().elementsNotLoaded().stream()
                .map(s-> " (" + NavigationBar.getPage().DUPLICATES.pageName + " Search Page " + s + ") ")
                .forEach(missEl::append);

        Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }
}
