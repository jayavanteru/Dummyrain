package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LibrariesPagesLoad3 extends UIVerify {

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26806", chromeIssue = "RA-26805")
    public void RulesPageLoads() {
        basicItemPages(NavigationBar.getPage().RULES,
                AdminRuleSearchPage.getPage(),
                AdminRuleEditPage.getPage(),
                AdminRuleCreatePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26808", chromeIssue = "RA-26807")
    public void SurveysPageLoads() {
        basicItemPages(NavigationBar.getPage().SURVEYS,
                SurveysSearchPage.getPage(),
                EditSurveyPage.getPage(),
                NewSurveyPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26810", chromeIssue = "RA-26809")
    public void TaskQualifierPageLoads() {
        basicItemPages(NavigationBar.getPage().TASK_QUALIFIERS,
                TaskQualifierSearchPage.getPage(),
                EditTaskQualifierPage.getPage(),
                NewTaskQualifierPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26812", chromeIssue = "RA-26811")
    public void TasksPageLoads() {
        basicItemPages(NavigationBar.getPage().TASKS,
                TasksSearchPage.getPage(),
                EditTaskPage.getPage(),
                NewTaskPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26814", chromeIssue = "RA-26813")
    public void TranslationsPageLoads() {
            NavigationBar.getPage().gotoPage(NavigationBar.getPage().TRANSLATIONS);
            StringBuilder missEl = new StringBuilder();
            TranslationSearchPage.getPage().verifyPageLoads();

            TranslationSearchPage.getPage().elementsNotLoaded().stream()
                    .map(s-> " (" + NavigationBar.getPage().TRANSLATIONS.pageName + " Search Page " + s + ") ")
                    .forEach(missEl::append);

            Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }

}
