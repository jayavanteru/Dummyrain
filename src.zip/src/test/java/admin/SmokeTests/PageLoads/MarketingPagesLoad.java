package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.marketing.AdminAccountsSearchPage;
import apps.admin.adminPageObjects.marketing.AdminEditAccountPage;
import apps.admin.adminPageObjects.marketing.AdminNewAccountPage;
import logs.ReportingInfo;
import org.testng.annotations.Test;

public class MarketingPagesLoad extends UIVerify {

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26348", chromeIssue = "RA-26347")
    public void accountsPageLoads() {
        basicItemPages(NavigationBar.getPage().ACCOUNTS,
                AdminAccountsSearchPage.getPage(),
                AdminEditAccountPage.getPage(),
                AdminNewAccountPage.getPage());
    }
}
