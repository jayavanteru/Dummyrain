package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.annotations.Test;

public class LibrariesPagesLoad4 extends UIVerify{

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26703", chromeIssue = "RA-26702")
    public void WebPagesPageLoads() {
        basicItemPages(NavigationBar.getPage().WEB_PAGES,
                CustomPagesSearchPage.getPage(),
                EditCustomPage.getPage(),
                NewCustomPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26697", chromeIssue = "RA-26695")
    public void WidgetBuilderPageLoads() {
        basicItemPages(NavigationBar.getPage().WIDGET_BUILDER,
                WidgetBuilderSearchPage.getPage(),
                EditWidgetBuilder.getPage(),
                NewWidgetBuilder.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26699", chromeIssue = "RA-26698")
    public void WidgetsPageLoads() {
        basicItemPages(NavigationBar.getPage().WIDGETS,
                WidgetSearchPage.getPage(),
                EditWidgetPage.getPage(),
                NewWidgetPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26701", chromeIssue = "RA-26700")
    public void WorkingReportsPageLoads() {
        basicItemPages(NavigationBar.getPage().WORKING_REPORTS,
                WorkingReportSearchPage.getPage(),
                EditWorkingReportPage.getPage(),
                NewWorkingReportPage.getPage());
    }
}
