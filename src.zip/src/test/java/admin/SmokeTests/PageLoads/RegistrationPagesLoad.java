package admin.SmokeTests.PageLoads;

import apps.PageConfiguration;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.registration.*;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.Test;


public class RegistrationPagesLoad extends UIVerify {

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26206", chromeIssue = "RA-26204")
    public void AttendeesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().ATTENDEES,
                AttendeeSearchPage.getPage(),
                EditAttendeePage.getPage(),
                CreateAttendeePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-53489", chromeIssue = "RA-53490")
    public void AttendeesClearButton()
    {
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor("stephen");
        Assert.assertTrue(AttendeeSearchPage.getPage().checkClearedResults(), "Search results have not been cleared from the page");
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26210", chromeIssue = "RA-26208")
    public void CompliancePageLoads()
    {
        basicItemPages(NavigationBar.getPage().COMPLIANCE,
                ComplianceSearchPage.getPage(),
                EditComplianceTypePage.getPage(),
                CreateCompliancePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26212", chromeIssue = "RA-26211")
    public void DiscountPageLoads()
    {
        basicItemPages(NavigationBar.getPage().DISCOUNTS,
                DiscountSearchPage.getPage(),
                EditDiscountPage.getPage(),
                CreateDiscountPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26214", chromeIssue = "RA-26213")
    public void RegistrationPackagesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().REGISTRATION_PACKAGES,
                RegistrationPackageSearchPage.getPage(),
                EditRegistrationPackagePage.getPage(),
                CreateRegistrationPackagePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26216", chromeIssue = "RA-26215")
    public void PriceReasonsPageLoads()
    {
        NavigationBar.getPage().gotoPage(NavigationBar.getPage().PRICE_REASONS);
        StringBuilder missEl = new StringBuilder();

        PriceReasonsSearchPage.getPage().elementsNotLoaded().stream()
                .map(s-> " (" + NavigationBar.getPage().PRICE_REASONS.pageName + " Search Page " + s + ") ")
                .forEach(missEl::append);

        Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26218", chromeIssue = "RA-26217")
    public void RegCodeCategoriesSearchPageLoads()
    {
        basicItemPages(NavigationBar.getPage().REG_CODE_CATEGORIES,
                RegCodeCategoriesSearchPage.getPage(),
                EditRegCodeCategoryPage.getPage(),
                NewRegCodeCategoryPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26221", chromeIssue = "RA-26219")
    public void RegCodePageLoads()
    {
        basicItemPages(NavigationBar.getPage().REG_CODES,
                RegCodeSearchPage.getPage(),
                EditRegCodePage.getPage(),
                NewRegCodePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26223", chromeIssue = "RA-26222")
    public void PaymentTypesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().PAYMENT_TYPES,
                PaymentTypesSearchPage.getPage(),
                EditPaymentTypesPage.getPage(),
                NewPaymentTypePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26225", chromeIssue = "RA-26224")
    public void WaitlistManagementPageLoads(){
        NavigationBar.getPage().gotoPage(NavigationBar.getPage().WAITLIST_MANAGEMENT);
        StringBuilder missEl = new StringBuilder();

        PageConfiguration.getPage().justWait();
        WaitlistManagementPage.getPage().elementsNotLoaded().stream()
                .map(s-> " (" + NavigationBar.getPage().PRICE_REASONS.pageName + " Search Page " + s + ") ")
                .forEach(missEl::append);

        Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }
}
