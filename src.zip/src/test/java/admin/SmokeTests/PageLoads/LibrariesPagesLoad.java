package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.libraries.*;
import logs.ReportingInfo;
import org.testng.annotations.Test;

public class LibrariesPagesLoad extends UIVerify {

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26400", chromeIssue = "RA-26395")
    public void EmailCampaignPageLoads() {
        basicItemPages(NavigationBar.getPage().EMAIL_CAMPAIGNS,
                EmailCampaignsSearchPage.getPage(),
                EditEmailCampaignPage.getPage(),
                NewEmailCampaignPage.getPage());
    }

    @Test(groups = {ReportingInfo.BLUE})
    @ReportingInfo(chromeIssue = "RA-19169", firefoxIssue = "RA-25803")
    public void EmailGroupSearchPageLoads(){
        EmailGroupSearchPage.getPage().navigate();
        basicItemPages(
                EmailGroupSearchPage.getPage(),
                EditEmailGroupPage.getPage(),
                NewEmailGroupPage.getPage()
        );
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26402", chromeIssue = "RA-26401")
    public void EmailPageLoads() {
        basicItemPages(NavigationBar.getPage().EMAILS,
                EmailsSearchPage.getPage(),
                EditEmailPage.getPage(),
                NewEmailPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26407", chromeIssue = "RA-26406")
    public void FileTypesPageLoads() {
        basicItemPages(NavigationBar.getPage().FILE_TYPES,
                FileTypesSearchPage.getPage(),
                EditFileTypePage.getPage(),
                NewFileTypePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26409", chromeIssue = "RA-26408")
    public void FormsPageLoads() {
        basicItemPages(NavigationBar.getPage().FORMS,
                FormsSearchPage.getPage(),
                EditFormPage.getPage(),
                NewFormPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26414", chromeIssue = "RA-26410")
    public void ImportsPageLoads() {
        basicItemPages(NavigationBar.getPage().IMPORTS,
                ImportTemplatesSearchPage.getPage(),
                EditImportTemplatePage.getPage(),
                NewImportTemplatePage.getPage());
    }
}
