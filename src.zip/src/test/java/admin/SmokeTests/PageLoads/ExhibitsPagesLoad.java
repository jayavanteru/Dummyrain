package admin.SmokeTests.PageLoads;

import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.exhibits.*;
import logs.ReportingInfo;
import org.testng.annotations.Test;


public class ExhibitsPagesLoad extends UIVerify {
    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26370", chromeIssue = "RA-26369")
    public void BoothPageLoads()
    {
        basicItemPages(NavigationBar.getPage().BOOTHS,
                BoothsSearchPage.getPage(),
                EditBoothPage.getPage(),
                NewBoothPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26383", chromeIssue = "RA-26371")
    public void ContractItemsPageLoads()
    {
        basicItemPages(NavigationBar.getPage().CONTRACT_ITEMS,
                ContractItemsSearchPage.getPage(),
                EditContractItemPage.getPage(),
                NewContractItemPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26387", chromeIssue = "RA-26386")
    public void ContractLayoutPageLoads()
    {
        basicItemPages(NavigationBar.getPage().CONTRACT_LAYOUTS,
                ContractLayoutsSearchPage.getPage(),
                EditContractLayoutPage.getPage(),
                NewContractLayoutPage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26390", chromeIssue = "RA-26388")
    public void ContractTemplatesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().CONTRACT_TEMPLATES,
                ContractTemplatesSearchPage.getPage(),
                EditContractTemplatePage.getPage(),
                NewContractTemplatePage.getPage());
    }

    @Test(groups = {"prodTest", ReportingInfo.TRIAGE})
    @ReportingInfo(firefoxIssue = "RA-26394", chromeIssue = "RA-26392")
    public void ExhibitorRolesPageLoads()
    {
        basicItemPages(NavigationBar.getPage().EXHIBITOR_ROLES,
                ExhibitorRolesSearchPage.getPage(),
                EditExhibitorRolePage.getPage(),
                NewExhibitorRolePage.getPage());
    }

}
