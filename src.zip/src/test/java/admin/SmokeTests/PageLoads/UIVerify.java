package admin.SmokeTests.PageLoads;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import interaction.pageObjects.PageLoadItemPage;
import interaction.pageObjects.PageLoadSearchPage;
import logs.Log;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import testHelp.SeleniumHelpers;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class UIVerify{


    public String workflowId;
    protected SeleniumHelpers helper;
    protected boolean ignoreEditPencil = false;

    public AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void beforeClassMethod()
    {
        helper = new SeleniumHelpers();

        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent();
        NavigationBar.getPage().pinSecondLevel();
    }

    @AfterClass
    public void stopTest() {
        //AdminLoginPage.getPage().navigate();
        NavigationBar.getPage().unpinSecondLevel();
        PageConfiguration.getPage().quit();
    }

    public void basicItemPages(NavigationBar.NavPage navpage, PageLoadSearchPage searchPage, PageLoadItemPage editPage, PageLoadItemPage createPage) {
        NavigationBar.getPage().gotoPage(navpage);
        searchPage.waitForPageLoad();
        StringBuilder missEl = new StringBuilder();

        searchPage.elementsNotLoaded().stream()
                .map(s-> " (" + navpage.pageName + " Search Page " + s + ") ")
                .forEach(missEl::append);
        searchPage.editItem();
        editPage.waitForPageLoad();
        editPage.elementsNotLoaded().stream()
                .map(s-> " (" + navpage.pageName + " Edit Page " + s + ") ")
                .forEach(missEl::append);
        editPage.cancel();
        searchPage.waitForPageLoad();
        searchPage.addItem();
        createPage.waitForPageLoad();
        createPage.elementsNotLoaded().stream()
                .map(s-> " (" + navpage.pageName + " New Page " + s + ") ")
                .forEach(missEl::append);
        createPage.cancel();

        Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }

    public void basicItemPages(PageLoadSearchPage searchPage, PageLoadItemPage editPage, PageLoadItemPage createPage) {
        searchPage.waitForPageLoad();
        StringBuilder missEl = new StringBuilder();

        searchPage.elementsNotLoaded().stream()
                .map(s-> " ( Search Page " + s + ") ")
                .forEach(missEl::append);
        searchPage.editItem();
        editPage.waitForPageLoad();
        editPage.elementsNotLoaded().stream()
                .map(s-> " ( Edit Page " + s + ") ")
                .forEach(missEl::append);
        editPage.cancel();
        searchPage.waitForPageLoad();
        searchPage.addItem();
        createPage.waitForPageLoad();
        createPage.elementsNotLoaded().stream()
                .map(s-> " ( New Page " + s + ") ")
                .forEach(missEl::append);
        createPage.cancel();

        Assert.assertTrue(missEl.length() <= 0, "Elements not found: " + missEl);
    }

    public void PageLoads(NavigationBar.NavPage navSearchPage, ArrayList<By> searchWebElements, ArrayList<By> newWebElements, ArrayList<By> editWebElements)
    {
        WebDriver browser = PageConfiguration.getPage().getBrowser();

        PageLoads(navSearchPage, searchWebElements);

        clickAdd();

        ArrayList<By> missingNewElements;
        missingNewElements = isLoaded(newWebElements);
        String newValues = "";
        if(missingNewElements.size() > 0) {
            for (int i = 0; i < missingNewElements.size(); i++) {

                newValues = newValues + missingNewElements.get(i).toString() + " ";
            }
        }
        Assert.assertTrue(missingNewElements.isEmpty(), "Not all elements were displayed on the New " + navSearchPage.pageName.toString() + " Page. Missing elements: " + newValues.toString());

        clickCancelOrGoBack();
        clickSearch();
        Utils.sleep(1000);

        By NORESULTS = By.id("noResultMsg");

        if (browser.findElements(NORESULTS).size() <= 0 || !browser.findElement(NORESULTS).isDisplayed()){
            clickResult(0);
            if(browser.findElements(By.xpath("//div[@class=\"modal-dialog\"]/descendant::h3[contains(text(), \"Edit survey data?\")]")).size() > 0){
                browser.findElement(By.xpath("//div[@class=\"modal-dialog\"]/descendant::button[contains(@class, \"confirm\")]")).click();
            }
            ArrayList<By> missingEditElements;
            missingEditElements = isLoaded(editWebElements);
            String editValues = "";
            if(missingEditElements.size() > 0) {
                for (int i = 0; i < missingEditElements.size(); i++) {
                    editValues = editValues + missingEditElements.get(i).toString() + " ";
                }

            }
            Assert.assertTrue(missingEditElements.isEmpty(), "Not all elements were displayed on the Edit " + navSearchPage.pageName.toString() + " Page. Missing elements: " + editValues.toString());
            clickCancelOrGoBack();
        }
    }

    public void PageLoads(NavigationBar.NavPage page, ArrayList<By> elements) {
        NavigationBar navigationBar = NavigationBar.getPage();
        navigationBar.gotoPage(page);
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        WebDriverWait wait = new WebDriverWait(browser, 15);
        wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));

        ArrayList<By> missingSearchElements = isLoaded(elements);

        StringBuilder searchValues = new StringBuilder();
        if(missingSearchElements.size() > 0) {
            for (int i = 0; i < missingSearchElements.size(); i++) {
                searchValues.append(missingSearchElements.get(i).toString()).append(" ");
            }
        }
        Assert.assertTrue(missingSearchElements.isEmpty(), "Not all elements were displayed on the "+page.pageName.toString() + "Page. Missing elements: " + searchValues.toString().toString());
    }

    public void clickAdd()
    {
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        By ADD_BUTTON = By.cssSelector("button[class*=\"fab-btn\"]");
        browser.findElement(ADD_BUTTON).click();
    }

    public void clickCancelOrGoBack()
    {
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        By CANCEL_BUTTON = By.id("cancelButton");
        try {
            WebElement element = browser.findElement(CANCEL_BUTTON);
            helper.scrollToElement(browser, element);
            element.click();
            Log.info("clicking the cancel button", getClass().getName());

        } catch (NoSuchElementException e) {
            JavascriptExecutor js = (JavascriptExecutor) browser;
            js.executeScript("window.history.back();");
            Log.info("clicking the browser back button", getClass().getName());
        }
    }

    public void clickSearch()
    {
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        if (getRowResults().size() <= 0) {
            By SEARCH_BUTTON = By.id("rf-search-button");
            By SEARCH_BUTTON2 = By.cssSelector(".search-actions .mdBtnR-primary");
            if (browser.findElements(SEARCH_BUTTON).size() > 0) {
                browser.findElement(SEARCH_BUTTON).click();
            } else if (browser.findElements(SEARCH_BUTTON2).size() > 0) {
                browser.findElement(SEARCH_BUTTON2).click();
            }
        }
    }

    public void clickResult(int row)
    {
        By td = By.tagName("td");
        By div = By.tagName("div");
        By edit = By.cssSelector("[title='Edit']");
        WebElement rowEl = getRowResults().get(row);

        WebElement el;
        if (!ignoreEditPencil && rowEl.findElements(edit).size() > 0) {
            el = rowEl.findElement(edit);
        }
        else if (rowEl.findElements(td).size() <= 0) {
            el = rowEl;
        }
        else {
            el = rowEl.findElements(td).get(1);
        }
        new Actions(PageConfiguration.getPage().getBrowser()).moveToElement(el).click().perform();
        //el.click();
    }

    public List<WebElement> getRowResults() {
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        helper.setWaitTime(browser, 100L, TimeUnit.MILLISECONDS);
        By RESULTS_ROWS = By.xpath("//*[contains(@id, 'row_') or @class='table-row']");
        Utils.waitForTrue(()->browser.findElements(RESULTS_ROWS).size() > 0);
        helper.resetImplicitWait(browser);
        return browser.findElements(RESULTS_ROWS);
    }

    public ArrayList<By> isLoaded(ArrayList<By> elementList) {
        Log.info("seeing if all expected elements are loaded on the page", getClass().getName());
        WebDriver browser = PageConfiguration.getPage().getBrowser();
        ArrayList<By> problemElements = new ArrayList<>();
        PageConfiguration.getPage().setImplicitWait(100L, TimeUnit.MILLISECONDS);
        for (By element : elementList) {
            int timeToWait = problemElements.size() > 0 ? 0 : 5;
            try {
                if (!helper.waitTillTrue(browser, (b) -> b.findElements(element).size() > 0 && browser.findElement(element).isDisplayed(), timeToWait)) {
                    problemElements.add(element);
                }
            } catch (StaleElementReferenceException e) {
                Log.error("stale element when checking if elements loaded on page, trying again", getClass().getName());
                if (!helper.waitTillTrue(browser, (b) -> b.findElements(element).size() > 0 && browser.findElement(element).isDisplayed(), timeToWait)) {
                    problemElements.add(element);
                }
            }
        }
        helper.resetImplicitWait(browser);
        Log.info("done looking for all expected elements on the page", getClass().getName());
        return problemElements;
    }
}
