package admin.imports;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.NewImportTemplatePage;
import apps.admin.adminPageObjects.registration.AttendeeSearchPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.CSVParser;
import testHelp.DataGenerator;

import java.util.*;

public class GlobalAttendeeImport
{
  @AfterClass
  public void tearDown()
  {
    PageConfiguration.getPage().quit();
  }

  @BeforeClass
  public void setup()
  {
    AdminLoginPage.getPage().login();
  }

  @Test(groups = { ReportingInfo.TVA})
  @ReportingInfo(firefoxIssue = "RA-32718", chromeIssue = "RA-38802")
  public void importGlobalAttendees()
  {
    OrgEventData.getPage().setOrgAndEvent("RainFocus", "GLOBAL");

    final ArrayList<Map<String, String>> importRecords = new ArrayList<>();

    for (int i = 0; i < 4; i++)
    {
      String firstName = "testGlobalImportFirst" + (i+1);
      String lastName = "testGlobalImportLast" + (i+1);
      String email = firstName + "@rainfocus.com";
      Map<String, String> attendeeRowMap = new LinkedHashMap<>();
      attendeeRowMap.put("email", email);
      attendeeRowMap.put("event", (i%2 == 0 ? "eventgers2022" : "constellations"));
      attendeeRowMap.put("firstname", firstName);
      attendeeRowMap.put("lastname", lastName);

      importRecords.add(attendeeRowMap);
    }

    NewImportTemplatePage newImportTemplatePage = new NewImportTemplatePage();
    newImportTemplatePage.navigate();

    newImportTemplatePage.clickTemplateTypeDropdown();
    newImportTemplatePage.chooseImport("Attendee Import");

    final DataGenerator dataGenerator = new DataGenerator();
    String templateName = dataGenerator.generateName();
    newImportTemplatePage.setTemplateName(templateName);

    newImportTemplatePage.clickKeyColumnDropdown();
    newImportTemplatePage.chooseKeyColumn("Email");

    final String csvFile = CSVParser.createCsvFile(importRecords, "accountImport.csv");
    newImportTemplatePage.chooseFileInput(csvFile);

    newImportTemplatePage.clickColumnDropdown(0);
    newImportTemplatePage.setColumnDropdownSearch("Email");

    newImportTemplatePage.clickColumnDropdown(1);
    newImportTemplatePage.setColumnDropdownSearch("Event Code");

    newImportTemplatePage.clickColumnDropdown(2);
    newImportTemplatePage.setColumnDropdownSearch("First Name");

    newImportTemplatePage.clickColumnDropdown(3);
    newImportTemplatePage.setColumnDropdownSearch("Last Name");


    newImportTemplatePage.clickImport();
    newImportTemplatePage.uploadStatus("Attendee", 4, 4, 0, 0);

    verifyAttendeesImportedByEvent("Constellations");
    verifyAttendeesImportedByEvent("Manual ONLY - Eventgers");
  }

  private void verifyAttendeesImportedByEvent(String eventName)
  {
    OrgEventData.getPage().setOrgAndEvent("RainFocus", eventName);
    AttendeeSearchPage attendeeSearchPage = AttendeeSearchPage.getPage();
    attendeeSearchPage.navigate();
    PageConfiguration.getPage().refreshPage();

    //search and verify that there are 4 event attendees with a firstname starting ...
    attendeeSearchPage.searchFor("testGlobalImportFirst");
    List<Map<String, String>> results = AttendeeSearchPage.getPage().getResults();
    Assert.assertEquals(results.size(), 2);

    Set<String> attendeeIds = attendeeSearchPage.getAllIds();

    AdminApp adminApp = new AdminApp();
    attendeeIds.stream().forEach(attendeeId -> adminApp.deleteAttendee(attendeeId));

    attendeeSearchPage.searchFor("testGlobalImportFirst");
    results = AttendeeSearchPage.getPage().getResults();
    Assert.assertEquals(results.size(), 0);
  }
}
