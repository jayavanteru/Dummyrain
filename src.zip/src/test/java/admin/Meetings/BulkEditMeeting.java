package admin.Meetings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.AdminAttendeeBulkEditPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class BulkEditMeeting {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String meetingId, meetingTitle;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Meeting Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(chromeIssue = "RA-32805", firefoxIssue = "RA-39600")
    public void bulkEditMeeting() {
        meetingId = adminApp.createApprovedMeeting("Meeting Program A");
        PersistentProfileForm.getPage().setTextAttribute("Title", meetingTitle = dataGenerator.generateName());
        PersistentProfileForm.getPage().submit();
        MeetingsSearchPage.getPage().navigate();
        MeetingsSearchPage.getPage().searchFor(meetingTitle);
        MeetingsSearchPage.getPage().bulkedit();
        AdminAttendeeBulkEditPage.getPage().bulkEditSelectValue("Status", "Declined");

        MeetingsSearchPage.getPage().navigate();
        MeetingsSearchPage.getPage().searchFor(meetingTitle);
        MeetingsSearchPage.getPage().clickResult(meetingTitle);
        Assert.assertTrue(PersistentProfileForm.getPage().getSelectAttributeValue("Status").contains("Declined"), "MEETING WAS NOT EDITED");
    }
}
