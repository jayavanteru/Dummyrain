package admin.Meetings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.EditColumnsModal;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.libraries.CreateEventAttributePage;
import apps.admin.adminPageObjects.libraries.EditFormPage;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

public class EditMeetingColumn {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String meetingId, meetingTitle,
            attributeName, attributeId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation" ,"Blue Meeting Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteMeeting(meetingId);
        adminApp.deleteAttribute(attributeId);

        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(chromeIssue = "RA-40211", firefoxIssue = "RA-40212")
    public void editMeetingColumns() {
        attributeId = adminApp.createCheckBoxAttribute(attributeName = dataGenerator.generateName(), new String[]{"One"}, CreateEventAttributePage.AUDIENCE_TYPES.Meeting);
        meetingId = adminApp.createApprovedMeeting("Meeting Program A");

        PersistentProfileForm.getPage().edit();
        EditFormPage.getPage().addExistingAttribute(attributeName);
        EditFormPage.getPage().submitForm();

        PersistentProfileForm.getPage().clickCheckBoxValue(attributeName, "One");
        PersistentProfileForm.getPage().submit();

        adminApp.safeSetTextBox("Title", meetingTitle = dataGenerator.generateName());

        MeetingsSearchPage.getPage().navigate();
        EditColumnsModal.getPage().addColumn(attributeName);

        MeetingsSearchPage.getPage().searchFor(meetingTitle);

        Assert.assertTrue(MeetingsSearchPage.getPage().columnExists(attributeName), "COLUMN DOES NOT EXIST");
        Assert.assertTrue(MeetingsSearchPage.getPage().attributeValueExists(meetingTitle, "One"), "ATTRIBUTE VALUE DOES NOT EXIST");
    }
}
