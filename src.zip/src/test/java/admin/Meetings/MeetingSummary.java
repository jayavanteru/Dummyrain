package admin.Meetings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.EditMeetingPage;
import apps.admin.adminPageObjects.meetings.MeetingSchedulePage;
import apps.admin.adminPageObjects.meetings.MeetingSummaryTab;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.Map;

public class MeetingSummary {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();
    String meetingId;

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Meeting Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        adminApp.deleteMeeting(meetingId);
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(chromeIssue = "RA-31606", firefoxIssue = "RA-39645")
    public void meetingSummary() {
        meetingId = adminApp.createApprovedMeeting("Meeting Program A");
        EditMeetingPage.getPage().schedulingTab();
        Map<String, String> data = MeetingSchedulePage.getPage().easySchedule();
        EditMeetingPage.getPage().summaryTab();
        Assert.assertTrue(MeetingSummaryTab.getPage().scheduleRendered("December 17, 2027", data.get("time"), data.get("room").substring(0, data.get("room").indexOf("(")-1)), "SCHEDULE DID NOT APPEAR");
    }
}
