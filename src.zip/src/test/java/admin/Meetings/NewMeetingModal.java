package admin.Meetings;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.AdminLoginPage;
import apps.admin.adminPageObjects.NavigationBar;
import apps.admin.adminPageObjects.OrgEventData;
import apps.admin.adminPageObjects.meetings.MeetingsSearchPage;
import apps.admin.adminPageObjects.meetings.NewMeetingPage;
import logs.ReportingInfo;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import testHelp.DataGenerator;

import java.util.Arrays;

public class NewMeetingModal {
    DataGenerator dataGenerator = new DataGenerator();
    AdminApp adminApp = new AdminApp();

    @BeforeClass
    public void beforeClass() {
        AdminLoginPage.getPage().login();
        OrgEventData.getPage().setOrgAndEvent("RF Automation", "Blue Meeting Event");
        NavigationBar.getPage().collapse();
    }

    @AfterClass
    public void afterClass() {
        PageConfiguration.getPage().quit();
    }

    @Test(groups = {ReportingInfo.NETWOOKIE})
    @ReportingInfo(chromeIssue = "RA-31583", firefoxIssue = "RA-39957")
    public void newMeetingModal() {
        String[] days = {"Day A"};
        String[] times = {"7:00", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00"};
        String[] rooms = {"Room A"};

        MeetingsSearchPage.getPage().navigate();
        MeetingsSearchPage.getPage().add();
        NewMeetingPage.getPage().selectMeetingProgram("Meeting Program A");

        Arrays.stream(days).forEach((day)->{
            Assert.assertTrue(NewMeetingPage.getPage().dayExists(day), String.format("DAY '%s' DOES NOT EXIST", day));
        });

        Arrays.stream(times).forEach((time)->{
            Assert.assertTrue(NewMeetingPage.getPage().timeExists(time), "TIME '%s' DOES NOT EXIST");
        });

        Arrays.stream(rooms).forEach((room)->{
            Assert.assertTrue(NewMeetingPage.getPage().roomExists(room), String.format("ROOM '%s' DOES NOT EXIST", room));
        });
    }
}
