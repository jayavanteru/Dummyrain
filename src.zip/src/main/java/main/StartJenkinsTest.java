package main;

import configuration.PropertyReader;
import interaction.api.Api;
import interaction.api.ApiConfig;
import logs.Log;
import org.json.JSONObject;
import testHelp.MyJson;

import java.util.List;

public class StartJenkinsTest {

    public static ApiConfig startTest(String env, String browser, List<String> testpaths, String branch) {
        while (testpaths.size() > 20) {
            startTest(env, browser, testpaths.subList(20, testpaths.size()-1), branch);
            testpaths = testpaths.subList(0, 19);
        }
        final JSONObject jsonBody = new JSONObject();
        MyJson.put(jsonBody, "TESTPATH", testpaths.stream().reduce((a, b)-> a = a+"\n"+b).get());
        MyJson.put(jsonBody, "ENV", env);
        MyJson.put(jsonBody, "BRANCH", branch);
        MyJson.put(jsonBody, "CHROME", String.valueOf(browser.equalsIgnoreCase("chrome")));
        MyJson.put(jsonBody, "FIREFOX", String.valueOf(browser.equalsIgnoreCase("firefox")));
        MyJson.put(jsonBody, "EDGE", String.valueOf(browser.equalsIgnoreCase("edge")));

//        String postUrl = "https://rainfocustesting.westus.cloudapp.azure.com/view/Command%20Central/job/Test_Starter/buildWithParameters?" +
//                "Group=AllTests&BRANCH="+branch+"&env=" + env + "&browserName=" + browser + "&TestPath=" + test;

        return runPost(jsonBody);
    }

    public static ApiConfig startTest(String env, String browser, String xrayIssue, List<String> testpaths, String branch) {
        while (testpaths.size() > 20) {
            startTest(env, browser, xrayIssue, testpaths.subList(20, testpaths.size()-1), branch);
            testpaths = testpaths.subList(0, 19);
        }
        final JSONObject jsonBody = new JSONObject();

        MyJson.put(jsonBody, "TESTPATH", testpaths.stream().reduce((a, b)-> a = a+"\n"+b).get());
        MyJson.put(jsonBody, "ENV", env);
        MyJson.put(jsonBody, "BRANCH", branch);
        MyJson.put(jsonBody, "CHROME", String.valueOf(browser.equalsIgnoreCase("chrome")));
        MyJson.put(jsonBody, "FIREFOX", String.valueOf(browser.equalsIgnoreCase("firefox")));
        MyJson.put(jsonBody, "EDGE", String.valueOf(browser.equalsIgnoreCase("edge")));
        MyJson.put(jsonBody, "XRAYISSUEKEY", xrayIssue);

//        String postUrl = "https://rainfocustesting.westus.cloudapp.azure.com/view/Command%20Central/job/Test_Starter/buildWithParameters?" +
//                "Group=AllTests&BRANCH="+branch+"&env=" + env + "&browserName=" + browser + "&TestPath=" + test + "&xrayIssueKey=" + xrayIssue;

        return runPost(jsonBody);
    }

    private static ApiConfig runPost(JSONObject postBody) {
        String url = "https://jenkins-qa.corp.rainfocus.com/job/Test_Starter/buildWithParameters";
        final Api client = Api.getClient();
        ManualAuthorization.jenkinsAuth(client);
        MyJson.put(postBody, "token", "Ra1yN4wlqZPH5MelpLhWN6q2OGwLYdtF");
        MyJson.put(postBody, "cause", PropertyReader.instance().getProperty("jenkinsnote"));

        final ApiConfig apiConfig = new ApiConfig(url, postBody);
        apiConfig.setUrlParams(true);

        ApiConfig request = client.get(apiConfig);
        if (request.getResponse().toString().contains("Authentication required")) {
            Log.info("FAILED TO START TESTS, TRYING AGAIN", StartJenkinsTest.class);
            client.jumpcloudAuth = false;
            ManualAuthorization.jenkinsAuth(client);
            request = client.get(apiConfig);
        }
        return request;
    }
}
