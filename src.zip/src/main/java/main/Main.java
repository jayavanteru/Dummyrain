package main;

import configuration.PropertyReader;
import interaction.DriverManager;
import logs.Log;
import main.ui.TestChooser;
import org.testng.TestNG;

import java.io.*;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    public static Throwable failure = null;
    public static String env;
    public static HashMap<String, String> descriptions = new HashMap<>();

    public static void main(String[] args) throws Throwable {
        setCustomParams();
        if (args.length <= 0) {
            TestChooser.startApp();
            return;
        }
        String path = getFullPath(args[0]);
        env = PropertyReader.instance().getProperty("env");
        env = env.equals("") ? "prod" : env;
        Log.info("environment set to " + env, Main.class);

        //hack code to be able to set environment variable in jenkins
        //=============================================================================
        if (path.equalsIgnoreCase("setenvchannel")) {
            File file = new File("jenkins.properties");
            file.createNewFile();
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.append("channel:")
                    .append(PropertyReader.instance().getProperty("channel-" + env));
            fileWriter.close();
            return;
        }
        //=============================================================================

        if (PropertyReader.instance().getProperty("runTestMethod").equalsIgnoreCase("true")) {
            args[0] = createTestXmlFileMethod(path);
        } else {
            args[0] = createTestXmlFileClass(path);
        }

        TestNG.privateMain(args, new TestListener());

        if (failure != null && Boolean.parseBoolean(PropertyReader.instance().getProperty("rerunFailedTestJar"))) {
            failure = null;
            DriverManager.resetButton();
            //try the test again, maybe it will pass this time
            TestNG.privateMain(args, new TestListener());
        }
        //fix junit reports
        alterTestNGResults(path);
//        XrayUpload.uploadResults();
        //in case the test doesn't run the quit, this will do it
        DriverManager.getDriverManager(Thread.currentThread().getName()).quit();
        //update descriptions
//        descriptions.forEach(XrayUpload::addDescriptionInJira);
        if (failure != null) {
            throw failure;
        }
    }

    private static String createTestXmlFileMethod(String fullPath) {
        String group = fullPath.split("\\.")[0];
        fullPath = fullPath.substring(group.length() + 1);
        setGroup(group);

        String[] splitPath = fullPath.split("\\.");
        String testMethod = splitPath[splitPath.length-1];
        String classPath = fullPath.substring(0, fullPath.length() - (testMethod.length() + 1));
        PropertyReader.instance().setProperty("classPath", classPath);
        PropertyReader.instance().setProperty("testMethod", testMethod);

        String contents = PropertyReader.instance().getProperty("methodXmlFile");

        return writeFile(contents);
    }

    private static String createTestXmlFileClass(String fullPath) {
        String group = fullPath.split("\\.")[0];
        fullPath = fullPath.substring(group.length() + 1);
        setGroup(group);

        PropertyReader.instance().setProperty("classPath", fullPath);
        String contents = PropertyReader.instance().getProperty("classXmlFile");

        return writeFile(contents);
    }

    private static String writeFile(String contents) {
        File xmlFile = new File("testconfig.xml");
        FileWriter writer;
        try {
            writer = new FileWriter(xmlFile, false);
            writer.write(contents);
            writer.close();
        } catch (IOException e) {
            Log.error(e, Main.class);
            e.printStackTrace();
        }

        return xmlFile.getPath();
    }

    private static void setGroup(String group) {
        if (group.equals(TestFinder.allGroup)) {
            PropertyReader.instance().setProperty("testngGroup", "");
        } else {
            PropertyReader.instance().setProperty("testngGroup", "<run><include name=\""+group+"\"/></run>");
        }
    }

    private static String getFullPath(String path) {
        return path.replace("/", ".")
                .replace("\\", ".");
    }

    private static void setCustomParams() {
        if (PropertyReader.instance().hasProperty("customParameters")) {
            String params = PropertyReader.instance().getProperty("customParameters");
            final String[] paramArray = params.split(",");
            for (String param : paramArray) {
                String[] kvsplit = param.split("=");
                String key = kvsplit[0].trim();
                String value = kvsplit.length > 1 ? kvsplit[1].trim() : "";
                PropertyReader.instance().setProperty(key, value);
            }
        }
    }

    private static void alterTestNGResults(String betterTestName) {
        boolean nextLineLink = false;
        boolean hasReportUrl = PropertyReader.instance().hasProperty("testngReportUrl");
        boolean method = PropertyReader.instance().getProperty("runTestMethod").equalsIgnoreCase("true");
        String group = betterTestName.split("\\.")[0];
        betterTestName = PropertyReader.instance().getProperty("browserName") + " "+ betterTestName.substring(group.length() + 1);
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("test-output/testng-results-better.xml"), Charset.forName("UTF-8")));
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("test-output/testng-results.xml")));

            while (reader.ready()) {
                String line = reader.readLine();
                if (line.matches(".*?<test-method.+?name=\".+")) {
                    String finalTestName = betterTestName;
                    if (!method) {
                        final Pattern pattern = Pattern.compile("name=\"(.+?)\"");
                        final Matcher matcher = pattern.matcher(line);
                        matcher.find();
                        finalTestName = betterTestName + "." + matcher.group(1);
                    }
                    line = line.replaceFirst("name=\".+?\"", "name=\""+finalTestName+"\"");
                } else if (hasReportUrl && line.contains("<full-stacktrace>")) {
                    nextLineLink = true;
                } else if (nextLineLink) {
                    nextLineLink = false;
                    String url = PropertyReader.instance().getProperty("testngReportUrl");
                    line = line.replace("<![CDATA[", "<![CDATA[" + url + " | ");
                }
                writer.write(line);
                writer.newLine();
            }

            reader.close();
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

