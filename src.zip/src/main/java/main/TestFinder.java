package main;

import configuration.PropertyReader;
import logs.Log;
import logs.ReportingInfo;
import org.testng.annotations.Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class TestFinder {

    private static String fileName = "tests.txt";
    public static Set<String> fullList;
    private static URLClassLoader loader;
    private static String jarPath;

    public static final String allGroup = "AllTests";

    /**
     * find the tests in the repo
     */
    public static void main(String[] args) {
        jarPath = args[0];
        File file = new File(fileName);
        file.delete();
        try {
            if (fullList == null) file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            URL url = new File(jarPath).toURI().toURL();
            loader = new URLClassLoader(new URL[]{url}, TestFinder.class.getClassLoader());
            Thread.currentThread().setContextClassLoader(loader);

            findClassesJar(new File(jarPath));

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    private static void findTests(String clazz) {
        Log.allLogging = false;
        final String untrackedProperty = PropertyReader.instance().getProperty("findUntrackedTests");
        Log.allLogging = true;
        if (untrackedProperty != null && untrackedProperty.equalsIgnoreCase("true")) {
            untrackedTests(clazz);
            return;
        }
        try {
            Class classToLoad = Class.forName(clazz, false, loader);
            for (Method m : classToLoad.getMethods()) {
                List<Annotation> annotations = new ArrayList<>();
                annotations.addAll(Arrays.asList(m.getDeclaredAnnotations()));
                annotations.removeIf(a -> !a.annotationType().equals(Test.class));
                if (annotations.size() > 0) {
                    String testName = clazz + "." + m.getName();
                    if (fullList == null) {
                        writeFile(allGroup + "." + testName);
                    } else {
                        //get xray issue keys
                        String issueKeys = "";
                        if (m.getAnnotation(ReportingInfo.class) != null) {
                            ReportingInfo reportingInfo = m.getAnnotation(ReportingInfo.class);
                            issueKeys = "|=|CH" + reportingInfo.chromeIssue() +"FF"+ reportingInfo.firefoxIssue();
                            for (String group : m.getAnnotation(Test.class).groups()) {
                                issueKeys += "*"+group;
                            }
                        }
                        fullList.add(testName + issueKeys);
                    }
                    for (String group : m.getAnnotation(Test.class).groups())
                        if (!group.equals(allGroup) && fullList == null) {
                            writeFile(group + "." + testName);
                        }
                }
            }
        } catch(ClassNotFoundException|NoClassDefFoundError|UnsupportedClassVersionError e) {
//            e.printStackTrace();
        }
    }

    private static void untrackedTests(String clazz) {
        try {
            Class classToLoad = Class.forName(clazz, false, loader);
            for (Method m : classToLoad.getMethods()) {
                List<Annotation> annotations = new ArrayList<>();
                annotations.addAll(Arrays.asList(m.getDeclaredAnnotations()));
                annotations.removeIf(a ->
                        !(a.annotationType().equals(Test.class) || a.annotationType().equals(ReportingInfo.class)));
                if (annotations.size() > 0) {
                    String testName = clazz + "." + m.getName();

                    if (m.getAnnotation(Test.class) == null) {
                        System.out.println("failed while loading class" + classToLoad.getName());
                    }
                    final List<String> myGroups = Arrays.asList(m.getAnnotation(Test.class).groups());
                    if (myGroups.isEmpty() || (myGroups.size() == 1 && myGroups.contains("prodTest")) ||
                            (m.getAnnotation(ReportingInfo.class) == null)) {
                        writeFile(allGroup + "." + testName);
                    }
                }
            }
        } catch(ClassNotFoundException|NoClassDefFoundError|UnsupportedClassVersionError e) {
//            e.printStackTrace();
        }
    }

    private static void writeFile(String line) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))){
            writer.write(line);
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean findClassesJar(File file) {
        if (file.getName().toLowerCase().endsWith(".jar")) {
            JarFile jar = null;
            try {
                jar = new JarFile(file);
            } catch (Exception ex) {

            }
            if (jar != null) {
                Enumeration<JarEntry> entries = jar.entries();
                while (entries.hasMoreElements()) {
                    JarEntry entry = entries.nextElement();

                    String name = entry.getName();
                    int extIndex = name.lastIndexOf(".class");
                    if (extIndex > 0) {
                        findTests(name.substring(0, extIndex).replace("/", "."));
                    }
                }
            }
        }
        return true;
    }
}