package main;

import apps.PageConfiguration;
import apps.admin.AdminApp;
import interaction.api.Api;
import logs.Log;
import testHelp.Utils;

public class ManualAuthorization {

    public static void jenkinsAuth(Api api) {
        if (api.jumpcloudAuth) return;

        String jump = "https://console.jumpcloud.com/login?context=sso&redirectTo=saml2%2Fjenkins-qa";
        final Thread signinThread = new Thread(() -> {
            Log.info("need to sign in to jumpcloud", ManualAuthorization.class);
            PageConfiguration.getPage().navigateTo(jump);
            while (PageConfiguration.getPage().getCurrentUrl().contains("jumpcloud")) {
                Utils.sleep(800);
            }
            final AdminApp adminApp = new AdminApp();
            adminApp.setApi(api);
            Utils.sleep(2000);
            adminApp.syncCookieFromBrowserToApi();
            PageConfiguration.getPage().quit();
            api.jumpcloudAuth = true;
        });
        signinThread.start();
        try {
            signinThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.error(e, ManualAuthorization.class);
        }
    }

    public static void jiraAuth(Api api) {
        if (api.jiraAuth) return;

        String auth = "https://rainfocus.atlassian.net";
        final Thread signinThread = new Thread(() -> {
            Log.info("need to sign in to jira", ManualAuthorization.class);
            PageConfiguration.getPage().navigateTo(auth);
            Utils.sleep(1500);
            while (!PageConfiguration.getPage().getCurrentUrl().contains(auth)) {
                Utils.sleep(800);
            }
            final AdminApp adminApp = new AdminApp();
            adminApp.setApi(api);
            Utils.sleep(2000);
            adminApp.syncCookieFromBrowserToApi();
            PageConfiguration.getPage().quit();
            api.jiraAuth = true;
        });
        signinThread.start();
        try {
            signinThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.error(e, ManualAuthorization.class);
        }
    }
}
