package main.ui;

import configuration.PropertyReader;
import interaction.DriverManager;
import interaction.api.ApiConfig;
import logs.Log;
import logs.ReportingInfo;
import main.Main;
import main.StartJenkinsTest;
import main.TestFinder;
import main.XrayUpload;
import org.json.JSONArray;
import org.json.JSONObject;
import testHelp.MyJson;
import testHelp.Utils;

import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class TestChooser {
    private JComboBox comboBox1;
    private JButton startTestButton;
    private JPanel mainPanel;
    private JComboBox key;
    private JTextField value;
    private JButton scale;
    private JButton jenkins;
    private JButton searchButton;
    private JTextField searchField;
    private JButton resetSearchButton;
    private JTextField jiraSearchField;
    private JButton jiraSearchBtn;
    private JButton openXrayParse;
    private JTextArea jiraSearchResults;
    private JFrame jiraSearchFrame;
    private JProgressBar jiraSearchProgress;
    private JLabel jiraSearchCount;
    private JButton startTestCollection;
    private JFrame xrayOutputInput;
    private JButton parseStart;
    private JTextArea xrayPasteField;
    private JComboBox teamchooser;
    private JLabel chromeLabel;
    private JCheckBox chromeOption;
    private JLabel firefoxLabel;
    private JCheckBox firefoxOption;
    private JButton xrayKeysBtn;
    private JTextField xrayKeysField;
    private final ArrayList<JComponent> compList = new ArrayList<>();
    private HashSet<String> jiraTestCollection;
    private static final ArrayList<JFrame> framList = new ArrayList<>();
    private final String noTestFound = "No Test Found";
    private Box sections;

    private static PropertyReader props = PropertyReader.instance();

    public static void startApp() {
        JPanel mainPanel = new TestChooser().mainPanel;
        props.setProperty("runTestMethod", "true");
        props.setProperty("rerunFailedTestJar", "false");
        props.setProperty("stopTestOnFailure", "true");
        props.setProperty("branch", "master");
        Log.debugEnabled = false;
        JFrame frame = new JFrame("Test Runner");
        framList.add(frame);
        frame.setContentPane(mainPanel);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public TestChooser() {
        //get a loading box up there so we know it is doing things
        JPanel loading = new JPanel();
        loading.add(new JLabel("LOADING..."));
        JFrame loadingFrame = new JFrame("LOADING");
        loadingFrame.add(loading);
        loadingFrame.pack();
        loadingFrame.setVisible(true);

        mainPanel = new JPanel();
        compList.add(mainPanel);
        comboBox1 = new JComboBox();
        compList.add(comboBox1);
        searchButton = new JButton("Search");
        compList.add(searchButton);
        searchField = new JTextField();
        compList.add(searchField);
        resetSearchButton = new JButton("Reset Search");
        compList.add(resetSearchButton);
        startTestButton = new JButton("Start Test");
        compList.add(startTestButton);
        JLabel count = new JLabel();
        compList.add(count);
        scale = new JButton("ZOOM");
        compList.add(scale);
        jenkins = new JButton("Start On Jenkins");
        compList.add(jenkins);
        key = new JComboBox();
        compList.add(key);
        value = new JTextField("dev");
        compList.add(value);
        jiraSearchField = new JTextField();
        jiraSearchField.setText("project = RA AND issuetype = \"Xray Test\" AND labels = automated AND priority = 1st");
        compList.add(jiraSearchField);
        jiraSearchBtn = new JButton("JQL Jira Search");
        openXrayParse = new JButton("Open Xray Parse");
        compList.add(jiraSearchBtn);
        compList.add(openXrayParse);
        teamchooser = new JComboBox();
        compList.add(teamchooser);
        chromeLabel = new JLabel("Chrome");
        chromeOption = new JCheckBox();
        compList.add(chromeLabel);
        compList.add(chromeOption);
        firefoxLabel = new JLabel("FireFox");
        firefoxOption = new JCheckBox();
        compList.add(firefoxLabel);
        compList.add(firefoxOption);
        xrayKeysBtn = new JButton("Xray Keys");
        compList.add(xrayKeysBtn);
        xrayKeysField = new JTextField();
        compList.add(xrayKeysField);

        //jira search pieces
        jiraSearchResults = new JTextArea(30, 100);
        startTestCollection = new JButton("Start Collection Of Tests On Jenkins");
        jiraSearchCount = new JLabel();
        jiraSearchProgress = new JProgressBar();
        compList.add(jiraSearchResults);
        compList.add(jiraSearchProgress);
        compList.add(startTestCollection);
        compList.add(jiraSearchCount);

        parseStart = new JButton("Parse Results and Start On Jenkins");
        xrayPasteField = new JTextArea(30, 100);
        compList.add(parseStart);
        compList.add(xrayPasteField);

        Box box0 = Box.createHorizontalBox();
        box0.add(searchField);
        box0.add(searchButton);
        box0.add(resetSearchButton);

        Box box1 = Box.createHorizontalBox();
        box1.add(comboBox1);
        box1.add(startTestButton);

        Box box2 = Box.createHorizontalBox();
        box2.add(count);
        box2.add(key);
        box2.add(value);
        box2.add(jenkins);
        box2.add(scale);

        Box box3 = Box.createHorizontalBox();
        box3.add(jiraSearchField);
        box3.add(jiraSearchBtn);
        box3.add(openXrayParse);

        Box box4 = Box.createHorizontalBox();
        box4.add(xrayKeysField);
        box4.add(teamchooser);
        box4.add(chromeLabel);
        box4.add(chromeOption);
        box4.add(firefoxLabel);
        box4.add(firefoxOption);
        box4.add(xrayKeysBtn);

        sections = Box.createVerticalBox();
        sections.add(box0);
        sections.add(box1);
        sections.add(box2);
        sections.add(box3);
        sections.add(box4);
        mainPanel.add(sections);

        searchButton.addActionListener(this::searchForTest);
        resetSearchButton.addActionListener(this::resetTestList);
        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                searchForTest(e);
            }
        });

        startTestButton.addActionListener(this::runTest);
        value.addFocusListener(new PropertyFocus());
        key.addActionListener(this::selectProperty);
        AutoCompletion.enable(comboBox1);
        AutoCompletion.enable(key);
        scale.addActionListener(this::scale);
        jenkins.addActionListener(this::runJenkins);
        jiraSearchBtn.addActionListener(this::jiraSearch);
        openXrayParse.addActionListener(this::createXrayInputWindow);
        xrayKeysBtn.addActionListener(this::findAllXrayKeys);

        //find all the tests
        populateTestList();
        //list all the properties
        populatePropertyList();

        count.setText("Number of tests: " + TestFinder.fullList.size() + "         ");

        loadingFrame.setVisible(false);
    }

    private void findAllXrayKeys(ActionEvent actionEvent) {
        StringBuilder keys = new StringBuilder("key in (");
        String team = teamchooser.getSelectedItem().toString();
        boolean chr = chromeOption.isSelected();
        boolean ff = firefoxOption.isSelected();
        String separator = "";
        String keyfinder = "([A-Z]+?\\-[0-9]+)";

        for (String test : TestFinder.fullList) {
            if (test.contains("*" + team)) {
                if (chr) {
                    keys.append(separator)
                            .append("\"")
                            .append(Utils.regexStringExtractor(test, "CH" + keyfinder))
                            .append("\"");
                    separator = ",";
                }
                if (ff) {
                    keys.append(separator)
                            .append("\"")
                            .append(Utils.regexStringExtractor(test, "FF" + keyfinder))
                            .append("\"");
                    separator = ",";
                }
            }
        }
        keys.append(")");
        xrayKeysField.setText(keys.toString());
    }

    private void scale(ActionEvent actionEvent) {
        int increaseSize = 5;
        for (JComponent comp : compList) {
            if (comp != null) {
                Font f = comp.getFont();
                comp.setFont(new Font(f.getName(), f.getStyle(), f.getSize() + increaseSize));
            }
        }

        framList.forEach(f->f.setSize(f.getPreferredSize()));
    }

    private void runJenkins(ActionEvent actionEvent) {
        final String env = props.getProperty("env");
        final String browserName = props.getProperty("browserName");
        final String xrayIssue = props.getProperty("xrayIssueKey");
        final String branch = props.getProperty("branch");
        if (comboBox1.getSelectedItem() != null) {
            List<String> paths = new ArrayList<>();
            paths.add(comboBox1.getSelectedItem().toString());

            final ApiConfig apiConfig = xrayIssue == null || xrayIssue.isEmpty() ? StartJenkinsTest.startTest(env, browserName, paths, branch) : StartJenkinsTest.startTest(env, browserName, xrayIssue, paths, branch);

            final JFrame testframe = new JFrame("jenkins " + paths.get(0));
            final JTextArea testlog = this.watchLog(testframe);
            testframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            testlog.append("posting to: " + apiConfig.getUrl());
            testlog.append("\n");
            testlog.append(apiConfig.getResponse().toString());
        }
    }

    private void searchForTest(Object actionEvent) {
        //otherwise the box shrinks all ugly like after a search
        final int width = comboBox1.getWidth();
        comboBox1.setPreferredSize(new Dimension(width, 10));

        final String text = searchField.getText();
        comboBox1.removeAllItems();
        final List<String> testList = testSearch(text);
        testList.forEach(this::getTestName);

        selectProperty(actionEvent);
    }

    private List<String> testSearch(String searchText) {
        String text = searchText.toLowerCase().trim();
        final List<String> testList = TestFinder.fullList.stream()
                .filter(t -> t.toLowerCase().contains(text))
                .collect(Collectors.toList());

        //if the key was searched set the browser to that key
        if (testList.size() == 1) {
            String test = testList.get(0).toLowerCase();
            if (test.contains("ff" + text)) {
                props.setProperty("browserName", "firefox");
            } else if (test.contains("ch" + text)) {
                props.setProperty("browserName", "chrome");
            }
        }
        return testList;
    }

    private String findATest(String param) {
        return TestFinder.fullList.stream()
                .filter(t -> t.toLowerCase().contains(param.toLowerCase()))
                .map((l) -> {
                    String browser = l.contains("CH" + param) ? " chrome" : l.contains("FF" + param) ? " firefox" : "";
                    return l.trim().split("\\|=\\|")[0] + browser;
                })
                .findFirst().orElse(noTestFound);
    }

    private void resetTestList(ActionEvent actionEvent) {
        searchField.setText("");
        comboBox1.removeAllItems();
        TestFinder.fullList.forEach(this::getTestName);
    }

    private void getTestName(String fullTest) {
        comboBox1.addItem(parseTestName(fullTest));
    }

    private String parseTestName(String fullTest) {
        return fullTest.split("\\|=\\|")[0];
    }

    private void runTest(ActionEvent actionEvent) {
        final String testname = comboBox1.getSelectedItem().toString();
        final JFrame testframe = new JFrame(testname);
        framList.add(testframe);
        String param = "AllTests."+testname;

        //clear things that need clear
        DriverManager.deleteDrivers(testname);
        PropertyReader.instance().refreshUnique();

        //create the seperate thread
        Thread runTest = new Thread(() -> {
            try {
                Main.main(new String[]{param});
            } catch (Throwable throwable) {
                throwable.printStackTrace();
            } finally {
                Main.failure = null;
                testframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
            }
        });

        //logging
        final JTextArea testlog = this.watchLog(testframe);
        Log.customLogging.put(testname, (l)->{
            if (l.contains("---------------------- SKIPPED ----------------------") ||
                    l.contains("---------------------- FAILED ----------------------")) {
                testframe.getContentPane().setBackground(Color.red);
            }
            else if (l.contains("---------------------- PASSED ----------------------") &&
                    !testframe.getContentPane().getBackground().equals(Color.red))
            {
                testframe.getContentPane().setBackground(Color.green);
            }

            testlog.append(l);
            testlog.append("\n");
        });

        //start thread
        runTest.setName(testname);
        runTest.start();
    }

    private void populateTestList() {
        TestFinder.fullList = new TreeSet<>();
        TestFinder.main(new String[]{"TestRunner.jar"});
        resetTestList(null);

        for (String team : ReportingInfo.ALLTEAMS) teamchooser.addItem(team);
    }

    private void populatePropertyList() {
        String[] properties = {"env", "browserName", "xrayIssueKey", "reportToJira", "jenkinsnote","org", "event", "adminUrl", "adminEmail", "adminPassword", "eventsUrl",
                                "workflowsUrl", "leadsUrl", "stopTestOnFailure", "realEmailAddress", "realEmailPassword", "branch"};
        for (String prop : properties) {
            key.addItem(prop);
        }
    }

    private void selectProperty(Object e) {
        String key = this.key.getSelectedItem().toString();
        value.setText(props.getProperty(key));
    }

    private void jiraSearch(ActionEvent actionEvent) {
        //create the new box
        if (jiraSearchFrame == null) createJiraSearchBox();

        //clear old data
        jiraSearchResults.setText("");
        jiraTestCollection = new HashSet<>();
        jiraSearchProgress.setValue(0);
        jiraSearchProgress.setVisible(true);

        String jql = jiraSearchField.getText();
        new Thread(()->{
        int total = 100; //seed amount
        for (int j = 0; j < total; j += 50) {
            final JSONObject jsonObject = XrayUpload.jiraSearch(jql, j);
            final JSONArray issues = MyJson.getJSONArray(jsonObject, "issues");

            //actual total from the search
            total = MyJson.getInt(jsonObject, "total");
            //use total to update search bar
            jiraSearchProgress.setMaximum(total);

            //get all the pages of the search and append the tests
            for (int i = 0; i < issues.length(); ++i) {
                JSONObject issue = MyJson.getJSONObject(issues, i);
                String key = MyJson.getString(issue, "key");
                String summary = MyJson.getString(MyJson.getJSONObject(issue, "fields"), "summary");
                String testPath = findATest(key);
                jiraSearchResults.append(key + " " + summary + " | " + testPath + "\n");
                if (!testPath.equals(noTestFound)) jiraTestCollection.add(testPath);
                jiraSearchProgress.setValue(j+i);
                jiraSearchCount.setText((j+i+1) + "/" + total);
            }
        }
        jiraSearchProgress.setVisible(false);
        }).start();
    }

    private void createXrayInputWindow(ActionEvent event) {
        xrayOutputInput = new JFrame("Paste Test Results");
        framList.add(xrayOutputInput);

        JPanel panel = new JPanel();
        final Box section0 = Box.createHorizontalBox();
        section0.add(parseStart);
        parseStart.addActionListener(this::parseAndStartTests);

        final Box section1 = Box.createHorizontalBox();
        section1.add(xrayPasteField);

        final Box jiraSections = Box.createVerticalBox();
        jiraSections.add(section0);
        jiraSections.add(section1);
        panel.add(jiraSections);
        xrayOutputInput.setContentPane(panel);
        xrayOutputInput.pack();
        xrayOutputInput.setVisible(true);
    }

    private void parseAndStartTests(ActionEvent actionEvent) {
        String name = "jenkins xray parse";
        final JFrame testframe = new JFrame(name);
        framList.add(testframe);
        final JTextArea testlog = this.watchLog(testframe);
        Log.customLogging.put(name, (l)-> testlog.append(l+"\n"));
        testframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

        Thread parseing = new Thread(()-> {
            final String text = xrayPasteField.getText().replace("\n", " ").replace("\t", " ");
            final List<String> collect = Arrays.stream(text.split(" "))
                    .filter((s) -> s.matches("RA-[0-9]*"))
                    .collect(Collectors.toList());

            List<String> chromeTestPath = new ArrayList<>();
            List<String> firefoxTestPath = new ArrayList<>();
            List<String> edgeTestPath = new ArrayList<>();
            String test;

            for (String c : collect) {
                final List<String> testList = testSearch(c);
                if (testList.size() > 0) {
                    List<String> path = props.getProperty("browserName").equalsIgnoreCase("chrome") ? chromeTestPath : props.getProperty("browserName").equalsIgnoreCase("firefox") ? firefoxTestPath : edgeTestPath;
                    test = parseTestName(testList.get(0));
                    Log.info(c + " " + test, getClass());
                    path.add(test);
                }
            }

            //start the tests
            startXrayParseJenkins(chromeTestPath, "chrome");
            startXrayParseJenkins(firefoxTestPath, "firefox");
            startXrayParseJenkins(edgeTestPath, "edge");
        });
        Log.info("before thread starts", getClass());
        parseing.setName(name);
        parseing.start();
    }

    private void startXrayParseJenkins(List<String> testPaths, String browser) {
        final String env = props.getProperty("env");
        final String xrayIssue = props.getProperty("xrayIssueKey");
        final String branch = props.getProperty("branch");

        if (testPaths.size() > 0) {
            ApiConfig config = xrayIssue == null || xrayIssue.isEmpty() ? StartJenkinsTest.startTest(env, browser, testPaths, branch) : StartJenkinsTest.startTest(env, browser, xrayIssue, testPaths, branch);
            Log.info("posting to: " + config.getUrl(), getClass());
            Log.info(config.getResponse().toString(), getClass());
        }
    }

    private void createJiraSearchBox() {
        jiraSearchFrame = new JFrame("Jira Search");
        jiraTestCollection = new HashSet<>();
        framList.add(jiraSearchFrame);

        JPanel panel = new JPanel();

        final Box section0 = Box.createHorizontalBox();
        section0.add(jiraSearchProgress);
        section0.add(jiraSearchCount);

        final Box section1 = Box.createHorizontalBox();
        section1.add(jiraSearchField);
        section1.add(jiraSearchBtn);
        section1.add(startTestCollection);
        startTestCollection.addActionListener(this::startTestCollection);

        final Box section2 = Box.createHorizontalBox();
        JScrollPane scrollPane = new JScrollPane(jiraSearchResults, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        section2.add(scrollPane, BorderLayout.CENTER);

        final Box jiraSections = Box.createVerticalBox();
        jiraSections.add(section0);
        jiraSections.add(section1);
        jiraSections.add(section2);
        panel.add(jiraSections);
        jiraSearchFrame.setContentPane(panel);
        jiraSearchFrame.pack();
        jiraSearchFrame.setVisible(true);
        jiraSearchFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                final Box section3 = Box.createHorizontalBox();
                section3.add(jiraSearchField);
                section3.add(jiraSearchBtn);
                section3.add(openXrayParse);
                sections.add(section3);
                mainPanel.updateUI();
                super.windowClosing(e);
                jiraSearchFrame = null;
            }
        });
        jiraSearchFrame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        sections.remove(3);

        mainPanel.updateUI();

    }

    private void startTestCollection(ActionEvent actionEvent) {
        final String env = props.getProperty("env");
        final String browserName = props.getProperty("browserName");
        final String xrayIssue = props.getProperty("xrayIssueKey");
        final String branch = props.getProperty("branch");
        final JFrame testframe = new JFrame("jenkins Test Collection Start");
        final String threadName = "jenkinsCollectionStart";
        final JTextArea testlog = this.watchLog(testframe);

        final Thread thread = new Thread(() -> {
            testframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

            for (String browser : new String[]{"chrome", "firefox", "edge"}) {
                final List<String> testPaths = jiraTestCollection.stream()
                        .filter((test) -> test.split(" ")[1].equalsIgnoreCase(browser))
                        .map((test) -> test.split(" ")[0])
                        .collect(Collectors.toList());

                final ApiConfig apiConfig = xrayIssue == null || xrayIssue.isEmpty() ? StartJenkinsTest.startTest(env, browser, testPaths, branch) : StartJenkinsTest.startTest(env, browser, xrayIssue, testPaths, branch);
                Log.info("Started " + testPaths.size() + " Tests On Jenkins with " + browser, getClass());
            }

        });
        thread.setName(threadName);
        thread.start();

        Log.customLogging.put(threadName, (l)->{
            testlog.append(l);
            testlog.append("\n");
        });
    }

    private JTextArea watchLog(JFrame frame) {
        JPanel panel = new JPanel();
        JTextArea log = new JTextArea(20, 70);
        compList.add(log);
        log.setFont(scale.getFont());
        log.setAutoscrolls(true);
        log.setLineWrap(true);
        log.setWrapStyleWord(true);
        ((DefaultCaret)log.getCaret()).setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        JScrollPane scrollPane = new JScrollPane(log, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        panel.add(scrollPane, BorderLayout.CENTER);
        frame.setContentPane(panel);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        return log;
    }

    class PropertyFocus implements FocusListener {

        @Override
        public void focusGained(FocusEvent e) { }

        @Override
        public void focusLost(FocusEvent e) {
            props.setProperty(key.getSelectedItem(), value.getText());
        }
    }
}
