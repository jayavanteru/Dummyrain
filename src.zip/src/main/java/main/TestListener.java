package main;

import configuration.PropertyReader;
import interaction.DriverManager;
import interaction.pageObjects.TestPagesList;
import interaction.pageObjects.WebPage;
import logs.Log;
import logs.ReportingInfo;
import logs.TestResultReportInfo;
import org.monte.media.Format;
import org.monte.media.FormatKeys;
import org.monte.media.math.Rational;
import org.monte.screenrecorder.ScreenRecorder;
import org.testng.*;

import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import static org.monte.media.FormatKeys.*;
import static org.monte.media.VideoFormatKeys.*;

public class TestListener implements ITestListener {

    ScreenRecorder screenRecorder;
    private logTestResult logResults = new logTestResult();

    @Override
    public void onTestStart(ITestResult iTestResult) {
        //url encode the name
        TestPagesList.resetPagesList();
        TestPagesList.testName = iTestResult.getMethod().getMethodName();
        String name = "%22" + PropertyReader.instance().getProperty("browserName") + "%20" + iTestResult.getMethod().getQualifiedName() + "%22";
        String desc = iTestResult.getMethod().getDescription();
        Main.descriptions.put(name, desc);

//        uploadResults(iTestResult.getMethod(), TestResultReportInfo.TestStatus.EXECUTING);
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) { outputPages();}

    @Override
    public void onTestFailure(ITestResult iTestResult) {
        outputPages();
        fail(iTestResult);

        takeScreenshot(iTestResult);
        if (Boolean.parseBoolean(PropertyReader.instance().getProperty("stopTestOnFailure"))) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        outputPages();
        if (Main.failure == null) {
            Main.failure = iTestResult.getThrowable();
        }
        takeScreenshot(iTestResult);
    }

    protected void outputPages() {
        try {
            TestPagesList.outputPages();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void uploadResults(ITestNGMethod iTestResult, TestResultReportInfo.TestStatus status) {
        final PropertyReader properties = PropertyReader.instance();
        if (properties.getProperty("reportToJira").equalsIgnoreCase("false")) return;
        final ReportingInfo reportInfo = iTestResult
                .getConstructorOrMethod()
                .getMethod()
                .getAnnotation(ReportingInfo.class);
        String env = properties.getProperty("env");
        if ((properties.hasProperty("xrayIssueKey") && !properties.getProperty("xrayIssueKey").isEmpty()) ||
                (reportInfo != null && (env.equalsIgnoreCase("dev") || env.equalsIgnoreCase("ibm")))) {
            final TestResultReportInfo reportResult = new TestResultReportInfo(reportInfo, status);

            if (Main.failure != null) reportResult.setError(Main.failure);
            reportResult.setPath(iTestResult.getQualifiedName());
            //report everywhere
            for (String group : iTestResult.getGroups()) {
                reportResult.setTeam(group);
                XrayUpload.uploadResults(reportResult);
            }
        }
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {

    }

    @Override
    public void onStart(ITestContext iTestContext) {
        //Create a instance of GraphicsConfiguration to get the Graphics configuration
        //of the Screen. This is needed for ScreenRecorder class.
        GraphicsConfiguration gc = GraphicsEnvironment
                .getLocalGraphicsEnvironment()
                .getDefaultScreenDevice()
                .getDefaultConfiguration();

        //Create a instance of ScreenRecorder with the required configurations
        try {
            screenRecorder = new ScreenRecorder(gc, null,
                    new Format(MediaTypeKey, FormatKeys.MediaType.FILE, MimeTypeKey, MIME_AVI),
                    new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                            CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
                            DepthKey, 24, FrameRateKey, Rational.valueOf(15),
                            QualityKey, 1.0f,
                            KeyFrameIntervalKey, (15 * 60)),
                            null, //new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey,"black",FrameRateKey, Rational.valueOf(1))
                    null,
                    new File("."));
            screenRecorder.start();
        } catch (IOException | AWTException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }

        //set the team name
        setTeam(iTestContext);
    }

    @Override
    public void onFinish(ITestContext iTestContext) {
        iTestContext.getPassedTests().getAllMethods().forEach(logResults::setPassed);
        iTestContext.getSkippedTests().getAllMethods().forEach(logResults::setSkipped);
        iTestContext.getFailedTests().getAllMethods().forEach(logResults::setFailed);
        iTestContext.getFailedConfigurations().getAllMethods().forEach(logResults::setFailed);
        for (ITestNGMethod method : iTestContext.getFailedConfigurations().getAllMethods()) {
            iTestContext.getFailedConfigurations().getResults(method).forEach(this::fail);
        }

        logResults.done();

        if (screenRecorder != null) {
            try {
                screenRecorder.stop();
                if (Main.failure == null) {
                    for (File file : screenRecorder.getCreatedMovieFiles()) {
                        file.delete();
                    }
                }
            } catch (IOException e) {
                Log.error(e, getClass());
                e.printStackTrace();
            }
        }
        addVideo();
    }

    private void setTeam(ITestContext iTestContext) {
        final HashSet<String> groupList = new HashSet<String>();

        final String[] groups = Arrays.stream(iTestContext.getAllTestMethods())
                .map(tm -> tm.getGroups())
                .reduce((a, b) -> {
                    String[] next = new String[a.length + b.length];
                    int i = 0;
                    for (; i < a.length; ++i) next[i] = a[i];
                    for (int j = 0; j < b.length; ++j) next[i + j] = b[j];
                    return next;
                }).orElseGet(() -> new String[]{"automation"});
        for (String g : groups) groupList.add(g);
        groupList.remove(ReportingInfo.PRODUCTION);
        if (groupList.size() > 0){
            PropertyReader.instance().setProperty("team", groupList.toArray()[0]);
        }
    }

    private class logTestResult {

        Map<ITestNGMethod, Integer> testMethods = new HashMap<>();
        private final int PASS = 0;
        private final int SKIP = 1;
        private final int FAIL = 2;

        public void setPassed(ITestNGMethod method) {
            Log.info(method.getQualifiedName() + "\n---------------------- PASSED ----------------------", getClass());
            if (!testMethods.containsKey(method)) {
                testMethods.put(method, PASS);
            }
        }

        public void setSkipped(ITestNGMethod method) {
            Log.info(method.getQualifiedName() + "\n---------------------- SKIPPED ----------------------", getClass());
            if (!testMethods.containsKey(method) || testMethods.get(method) < SKIP) {
                testMethods.put(method, SKIP);
            }
        }

        public void setFailed(ITestNGMethod method) {
            Log.info(method.getQualifiedName() + "\n---------------------- FAILED ----------------------", getClass());
            if (!testMethods.containsKey(method) || testMethods.get(method) < FAIL) {
                testMethods.put(method, FAIL);
            }
        }

        public void done() {
            testMethods.forEach(this::reportResult);
        }

        private void reportResult(ITestNGMethod method, int result) {
            switch (result) {
                case PASS:
                    logPassed(method);
                    break;
                case SKIP:
                    logSkipped(method);
                    break;
                case FAIL:
                default:
                    logFailed(method);
                    break;
            }
        }
    }

    private void fail(ITestResult iTestResult) {
        Log.error(iTestResult.getThrowable(), getClass());
        //we will just give back the first failure
        if (Main.failure == null) {
            Main.failure = iTestResult.getThrowable();
        }
    }

    private void logFailed(ITestNGMethod method) {
        Log.info(method.getQualifiedName() + "\n---------------------- FAILED ----------------------", getClass());
        uploadResults(method, TestResultReportInfo.TestStatus.FAILED);
    }

    private void logSkipped(ITestNGMethod method) {
        Log.info(method.getQualifiedName() + "\n---------------------- SKIPPED ----------------------", getClass());
        uploadResults(method, TestResultReportInfo.TestStatus.FAILED);
    }

    private void logPassed(ITestNGMethod method) {
        Log.info(method.getQualifiedName() + "\n---------------------- PASSED ----------------------", getClass());
        uploadResults(method, TestResultReportInfo.TestStatus.PASSED);
    }

    private void takeScreenshot(ITestResult test) {
        StringBuilder testName = new StringBuilder(test.getName() + "(");
        String seperator = "";
        for (Object param : test.getParameters()) {
            testName.append(seperator).append(param);
            seperator = ",";
        }
        testName.append(")");
        String threadName = Thread.currentThread().getName();
        try {
            Log.info("taking screenshot", getClass().getName());
            String filename = logs.FileWriter.getFilePath(testName.toString()) + ".png";
            if (DriverManager.isWebDriverCreatedForThread(threadName)) {
                DriverManager.getWebDriver(threadName).takeScreenShot(filename);
                screenshotToReporter(testName.toString());
            }
        } catch (NullPointerException e) {
            Log.error("Failed to take screenshot, probably something wrong with the driver", getClass().getName());
        }
    }

    private void screenshotToReporter(String testname) {
        File ssfile = new File("test-output/screenshot.html");
        File testDir = new File("test-output");
        String videoName = screenRecorder.getCreatedMovieFiles().stream()
                .min((a, b) -> (int) (a.lastModified() - b.lastModified()))
                .map(File::getName)
                .orElse("No_Video");
        if (!testDir.exists()) {
            testDir.mkdir();
        }
        if (!ssfile.exists()) {
            try {
                ssfile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try (FileWriter fileWriter = new FileWriter(ssfile, true)) {
            fileWriter.append(getLinksHtml(videoName))
                    .append("<a href=\"../").append(testname).append(".png\"><button>OPEN IMAGE</button></a>")
                    .append("<h3>")
                    .append(testname)
                    .append("</h3><img src='../")
                    .append(testname)
                    .append(".png'/></div>");
        } catch (IOException e) {
            e.printStackTrace();
            Log.error(e, getClass());
        }
    }

    private void addVideo() {
        File ssfile = new File("test-output/screenshot.html");
        File testDir = new File("test-output");
        String videoName = screenRecorder.getCreatedMovieFiles().stream()
                .min((a, b) -> (int) (a.lastModified() - b.lastModified()))
                .map(File::getName)
                .orElse("No_Video");
        if (!testDir.exists()) {
            testDir.mkdir();
        }
        if (!ssfile.exists()) {
            try {
                ssfile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try (FileWriter fileWriter = new FileWriter(ssfile, true)) {
                fileWriter.append(getLinksHtml(videoName));
            } catch (IOException e) {
                e.printStackTrace();
                Log.error(e, getClass());
            }
        }
    }

    private String getLinksHtml(String videoName) {
        return "<div><a href=\"../"+videoName+"\" target=\"_blank\"><button>DOWNLOAD VIDEO</button></a>&nbsp;"+
                "<a href=\"../../console#footer\"><button>GO TO LOGS</button></a></div>";
    }
}
