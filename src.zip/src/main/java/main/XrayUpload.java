package main;

import configuration.PropertyReader;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.ApiJson;
import logs.Log;
import logs.TestResultReportInfo;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import testHelp.Utils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.concurrent.*;

public class XrayUpload {

    private static HashMap<String, JSONObject> responses = new HashMap<>();

    public enum Project {AUT, RA}

    private static String getToken() {
        return PropertyReader.instance().getProperty("xrayApiToken");
//        int tries = 4;
//        while (token == null && --tries > 0) {
//            //config
//            ApiConfig authConfig = new ApiConfig("https://xray.cloud.getxray.app/api/v1/authenticate",
//                    MyJson.createJSON("{ 'client_id':'CDE5D1601944434598910FE63DBCE75F', 'client_secret':'590af8455ea5e24ddc227612615f8b000a8a89fda8618f44e46c2727d3ccef35' }"));
//            authConfig.setContentType("application/json");
//            JSONObject response = Api.getClient().post(authConfig)
//                    .getResponse();
//
//            token = MyJson.getString(response, "data");
//            if (token == null) {
//                Utils.sleep(1000, "wait and try to get a token again");
//            }
//        }
//        return token.replace("\"", "");
    }

    public static void uploadResults() throws IOException {
        String issueKey;
        //-------------- temporary --------------
        if (PropertyReader.instance().getProperty("browserName").equalsIgnoreCase("edge")) {
            issueKey = getTeamIssueNumber("edgomation-"+ Main.env, Project.AUT);
        } else if (PropertyReader.instance().hasProperty("xrayIssueKey") && !PropertyReader.instance().getProperty("xrayIssueKey").isEmpty()) {
            issueKey = PropertyReader.instance().getProperty("xrayIssueKey");
        }
        //-------------- temporary --------------
        else issueKey = getTeamIssueNumber("Automation-"+ Main.env, Project.AUT);
        if (issueKey == null) {
            Log.warn("no automation test execution issue found", XrayUpload.class);
            return;
        }
        //post the results
        ApiConfig config = new ApiConfig("https://xray.cloud.getxray.app/api/v1/import/execution/testng?projectKey=AUT&testExecKey=" + issueKey);
        config.setHeader("Authorization", "Bearer " + getToken());

        //read the file contents to the input type
        File testng = new File("test-output/testng-results-better.xml");
        HttpEntity input = new StringEntity(Files.readAllLines(testng.toPath()).stream().reduce((a, b)->a +"\n"+ b).get());
        config.setContentType("text/xml");
        config.setPostEntity(input);

        //post it
        xrayPost(config);
    }

    public static void uploadResults(final TestResultReportInfo info) {
        info.setTestExecIssue(getTeamIssueNumber(info.getTeam(), Project.RA));
        if (info.getTestExecIssue() == null || info.getIssueKey().equals("NOT_SUPPORTED")) {
            Log.warn("no test execution issue found for team " + info.getTeam(), XrayUpload.class);
            return;
        }

        //post the results
        ApiConfig config = new ApiConfig("https://xray.cloud.getxray.app/api/v1/import/execution", formatXrayImport(info));
        config.setHeader("Authorization", "Bearer " + getToken());
        config.setContentType("application/json");

        //post it
        xrayPost(config);
    }

    private static void xrayPost(final ApiConfig postconfig) {
        // create thread pool
        ExecutorService executor = Executors.newFixedThreadPool(1);

        // submit futureTask1 to ExecutorService
        final Future<ApiBody> submitApiCall = executor.submit(() -> {
            Api.getClient().post(postconfig);
            Log.info("xray post response: " + postconfig.getResponse(), XrayUpload.class);
            return postconfig.getResponseAsApiBody();
        });
        try {
            executor.shutdown();
            ApiBody response = submitApiCall.get(10, TimeUnit.SECONDS);
            final ApiJson nextValidRequestDate = response.get("nextValidRequestDate");
            if (nextValidRequestDate != null) {
                final DateTime nextTime = new DateTime(nextValidRequestDate.getOriginalValue());
                Utils.waitForTrue(nextTime::isBeforeNow, 300, 5000);
                xrayPost(postconfig);
            }
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            Log.error("time out waiting for xray response", XrayUpload.class);
            Api.getClient().abort();
            e.printStackTrace();
        }

        try {
            executor.awaitTermination(120, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.info("xray thread pool has terminated", XrayUpload.class);
    }

    public static void addDescriptionInJira(String testname, String description) {
        Api client = new Api();
        String password = "Basic YnJ5Y2UuZm9yZEByYWluZm9jdXMuY29tOmxpdHRsZU9ORTE=";

        ApiConfig config = new ApiConfig("https://rainfocus.atlassian.net/rest/api/2/search?jql=summary~"+testname);
        config.setHeader("Authorization", password);
        config.setHeader("Content-Type","application/json");

        try {
            JSONObject response = client.get(config).getResponse();

            JSONObject issue = response.getJSONArray("issues")
                    .getJSONObject(0);

            String currentDesc = issue
                    .getJSONObject("fields")
                    .getString("description");

            if (description != null && !description.equalsIgnoreCase(currentDesc)) {
                issue.getString("self");
                config = new ApiConfig(issue.getString("self"));

                JSONObject body = new JSONObject("{'fields':{'description':'" + description + "'}}");

                config.setHeader("Authorization", password);
                config.setHeader("Content-Type", "application/json");
                config.setBody(body);

                client.put(config);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static JSONObject formatXrayImport(final TestResultReportInfo info) {
        JSONObject ximport = new JSONObject();
        JSONObject test = new JSONObject();
        JSONArray tests = new JSONArray();

        try {
            test.put("testKey", info.getIssueKey());
            test.put("status", info.getTestStatus().name());

            test.put("comment", info.getEnv() + " " + info.getBrowser() + " " + info.getPath() +
                    "\n\n" + info.getResultUrl() + "\n\n" + info.getError());

            tests.put(test);
            ximport.put("testExecutionKey", info.getTestExecIssue());
            ximport.put("tests", tests);
        } catch (JSONException e) {
            Log.error(e, XrayUpload.class);
        }

        return ximport;
    }

    public static JSONObject jiraSearch(String query, int startAt) {
        JSONObject jsonObject = null;
        try {
            jsonObject = jiraCall("https://rainfocus.atlassian.net/rest/api/2/search?startAt="+startAt+"&jql=", query);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    public static String getTeamIssueNumber(String team, Project proj) {
        //use xray issue key and ignore the searching
        if (PropertyReader.instance().hasProperty("xrayIssueKey") && !PropertyReader.instance().getProperty("xrayIssueKey").isEmpty()) {
            return PropertyReader.instance().getProperty("xrayIssueKey");
        }
        String baseUrl = "https://rainfocus.atlassian.net/rest/api/2/search?jql=";
        String params = "'summary'~'"+team+"'AND'status'!='TO DO'AND'status'!='Backlog'AND'status'!='Done'AND'type'='Test Execution'AND 'project'='" + proj.name()+"'ORDER BY createdDate DESC";

        String issue = null;
        JSONObject response = null;
        try {
            response = responses.containsKey(baseUrl + params) ? responses.get(baseUrl + params) : jiraCall(baseUrl, params);
            issue = response.getJSONArray("issues").getJSONObject(0).getString("key");
        } catch (JSONException e) {
            Log.info("did not find an execution issue for team " + team, XrayUpload.class);
        } catch (UnsupportedEncodingException e) {
            Log.error(e, XrayUpload.class);
            e.printStackTrace();
        }

        responses.put(baseUrl + params, response);
        return issue;
    }

    private static JSONObject jiraCall(String baseUrl, String urlparam) throws UnsupportedEncodingException {
        String url = baseUrl + URLEncoder.encode(urlparam, "UTF-8");
        final Api client = Api.getClient();
        ApiConfig config = new ApiConfig(url);

        String password;
        if (PropertyReader.instance().hasProperty("JIRA_TOKEN")) {
            password = "Basic " + PropertyReader.instance().getProperty("JIRA_TOKEN");
            config.setHeader("Authorization", password);
        } else {
            ManualAuthorization.jiraAuth(client);
        }

        config.setHeader("Content-Type","application/json");

        return client.get(config).getResponse();
    }
}
