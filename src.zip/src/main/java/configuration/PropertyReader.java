package configuration;

import logs.Log;
import testHelp.DataGenerator;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PropertyReader {

    private Properties properties = new Properties();
    private Properties override = new Properties();
    private String uniqueId;
    private static PropertyReader reader;

    private PropertyReader() {
        refreshUnique();
        readInPropertyFile();
        loadTemplates();
    }

    public void refreshUnique() {
        uniqueId = new DataGenerator().generateString(10);
    }

    public static PropertyReader instance() {
        if (reader == null) {
            reader = new PropertyReader();
        }
        return reader;
    }

    public String getProperty(String key) {
        if (key.equals("unique")) return uniqueId;
        String value = override.getProperty(key);
        if (value == null) {
            value = System.getProperty(key);
        }
        if (value ==  null) {
            value = System.getenv(key);
        }
        if (value == null) {
            value = properties.getProperty(key);
        }
        if (value == null) {
            Log.error("property not found " + key, getClass().getName());
            return null;
        } else {
            return buildPartialData(value);
        }
    }

    public void setProperty(String key, String value) {
        override.setProperty(key, value);
        readInPropertyFile();
        loadTemplates();
    }

    public void setProperty(Object key, Object value) {
        setProperty(key.toString(), value.toString());
    }

    public boolean hasProperty(String key) {
        return override.containsKey(key) ||
                System.getenv(key) != null ||
                System.getProperty(key) != null ||
                properties.containsKey(key);
    }


    public String findAndReplaceProperties(String base) {
        return buildPartialData(base);
    }

    private void readInPropertyFile() {
        String[] propertyFileNames = {"default.properties", "admin.properties", "events.properties", "workflow.properties", "leads.properties", "loadTest.properties", "jenkins.properties", "api.properties", "mobile.properties"};
        try {
            //load properties from all the files
            for (String fileName : propertyFileNames) {
                InputStreamReader inputStreamReader = new InputStreamReader(PropertyReader.class.getClassLoader().getResourceAsStream(fileName), "UTF-8");
                properties.load(inputStreamReader);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTemplates() {
        String templatename = getProperty("env");
        final Properties templateReader = new Properties();
        try {
            templateReader.load(new InputStreamReader(PropertyReader.class.getClassLoader().getResourceAsStream("templates.properties"), "UTF-8"));
            if (templateReader.containsKey(templatename)) {
                final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(templateReader.getProperty(templatename).getBytes());
                templateReader.load(byteArrayInputStream);
                for (String propName : templateReader.stringPropertyNames()) {
                    properties.setProperty(propName, templateReader.getProperty(propName));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String buildPartialData(String template) {
        while (template.contains("{{") && template.contains("}}")) {
            //use regex matching
            Pattern compile = Pattern.compile("(\\{\\{.*?}})");
            Matcher matcher = compile.matcher(template).usePattern(compile);

            if (matcher.find()) {
                //find all the variables in the string and replace them
                String group = matcher.group(0);
                //need to remove the { } to find the value
                String replaceProperty = getProperty(group.substring(2, group.length() - 2));
                template = template.replace(group, replaceProperty);
            }
        }
        return template;
    }
}
