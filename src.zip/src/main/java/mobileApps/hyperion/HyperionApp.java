package mobileApps.hyperion;

import mobileApps.MobileApp;

public class HyperionApp extends MobileApp {

}
