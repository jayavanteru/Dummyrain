package mobileApps;

import interaction.pageObjects.MobilePage;

public class MobileConfiguration extends MobilePage {

    public static MobileConfiguration getPage() {
        return initialize(MobileConfiguration.class);
    }
    @Override
    public void quit() {
        super.quit();
    }
}
