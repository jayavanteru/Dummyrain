package interaction;

public abstract class UIInteraction {

}
