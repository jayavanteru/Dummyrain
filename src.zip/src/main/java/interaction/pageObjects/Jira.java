package interaction.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import testHelp.Utils;

import java.util.ArrayList;

public class Jira extends WebPage {

    protected final By TEST_CASES = By.cssSelector(".iojxET td:nth-child(3) > span");
    protected final By COUNTER_PASSED = By.id("xray-progress-passed--counter");
    protected final By COUNTER_FAILED = By.id("xray-progress-failed--counter");
    protected final By COUNTER_TODO = By.id("xray-progress-todo--counter");
    protected final By FILTER = rfBy.text("Filters");
    protected final By TEST_STATUS = rfBy.xpath("//*[text()='TestRun Status']/parent::div[@class='sc-gzOgki irHDty']/descendant::div[@class='css-10nd86i']");
    protected final By USERNAME = rfBy.id("username");
    protected final By PASSWORD = rfBy.id("password");
    protected final By SUBMIT_FILTER = By.xpath("//*[text()='Apply']");

    //singleton initializer
    public static Jira getPage() {
        return initialize(Jira.class);
    }

    public ArrayList<String> tests() {
        ArrayList<String> findTests = new ArrayList<>();
        for (WebElement el : findElements(TEST_CASES)) {
            findTests.add(getText(el));
        }

        return findTests;
    }

    public void navigate(String key) {
        String url = "https://rainfocus.atlassian.net/browse/" + key;
        navigateTo(url);
        sendKeys(USERNAME, getData("jirausername"), Keys.ENTER);
        findElement(PASSWORD).sendKeys(getData("jirapassword"));
        sendKeys(PASSWORD, Keys.ENTER);

        waitForPageUrlToStartWith(url);
        waitForPageLoad();
    }

    public void switchToXray() {
        waitForElementOnPage(By.tagName("iframe"));
        switchToIframe();
        waitForPageLoad();
    }

    public void filterTodo() {
        webDriverWaitUntil(ExpectedConditions.elementToBeClickable(FILTER), 60);
        click(FILTER);

        waitForElementToBeClickable(TEST_STATUS);
        scrollToElement(TEST_STATUS);
        moveToAndClick(TEST_STATUS);
        Utils.sleep(500);
        sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
        click(SUBMIT_FILTER);

        Utils.sleep(5000, "really make sure this is loaded");

        waitForPageLoad();
    }

    public void filterFailed() {
        webDriverWaitUntil(ExpectedConditions.elementToBeClickable(FILTER), 60);
        click(FILTER);

        waitForElementToBeClickable(TEST_STATUS);
        scrollToElement(TEST_STATUS);
        moveToAndClick(TEST_STATUS);
        Utils.sleep(500);
        sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
        click(SUBMIT_FILTER);

        Utils.sleep(5000, "really make sure this is loaded");

        waitForPageLoad();
    }

    public int getPassed() {
        waitForElementOnPage(COUNTER_PASSED);
        return Integer.parseInt(getText(COUNTER_PASSED));
    }

    public int getFailed() {
        waitForElementOnPage(COUNTER_FAILED);
        return Integer.parseInt(getText(COUNTER_FAILED));
    }

    public int getTodo() {
        waitForElementOnPage(COUNTER_TODO);
        return Integer.parseInt(getText(COUNTER_TODO));
    }
}
