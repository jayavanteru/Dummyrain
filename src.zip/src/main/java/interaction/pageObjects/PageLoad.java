package interaction.pageObjects;

import org.openqa.selenium.By;

import java.util.List;

public interface PageLoad {

    List<By> elementsNotLoaded();

    void waitForPageLoad();

}
