package interaction.pageObjects;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import testHelp.Utils;

import java.util.concurrent.TimeUnit;

public abstract class BaseSearchPage extends WebPage {

    protected final By ADV_EXPR_DROPDOWN = By.xpath("//div[@data-qa='expression']");
    protected final By ADV_EXPR_OPTION_AND = rfBy.datatest("select-dropdown-result-item-AND");
    protected final By ADV_EXPR_OPTION_OR = rfBy.datatest("select-dropdown-result-item-OR");
    protected final By ADV_EXPR_OPTION_CUSTOM = rfBy.datatest("select-dropdown-result-item-Custom");
    protected final By ADV_EXPR_OPTION_COUNT = rfBy.datatest("select-dropdown-result-item-Count");
    protected final By NO_RESULTS_MSG = By.className("no-search-results");
    protected final By FIRST_ROW = By.cssSelector("a[class='table-row']");
    protected final By SEARCH_TEXTBOX = By.id("filter_param");
    protected final By SEARCH_BUTTON = By.xpath("//*[@data-test='rf-button-actions-search']//*[contains(text(), 'Search')]");
    protected final By CLEAR_BUTTON = By.xpath("//span[text()='Clear']//ancestor::button");
    protected final By EDIT_COLUMNS = rfBy.xpath("//button//span[contains(text(), 'Edit Columns')]");

    protected final By TABLE_RESULTS = By.xpath("//div[@class =\"table-results\"]");


    public void searchFor(String search) {
        justWait();
        click(CLEAR_BUTTON);
        sendKeys(SEARCH_TEXTBOX, search);
        search();
        //wait for results or no results message
        try {
            setImplicitWait(100, TimeUnit.MILLISECONDS);
            Utils.waitForTrue(()->findElements(FIRST_ROW).size() > 0 || findElements(NO_RESULTS_MSG).size() > 0, 30);
        } finally {
            resetImplicitWait();
        }
    }

    public void search() {
        justWait();
        superSafeClick(SEARCH_BUTTON);
    }

    public int getResultsNumber()
    {
        String resultsInt = findElement(TABLE_RESULTS).getText();

        try{
            findElement(NO_RESULTS_MSG);
            return 0;
        }
        catch(NoSuchElementException el) {
            waitForSearchResults();
            String[] splitResults = resultsInt.split("of ");
            return Integer.parseInt(splitResults[1]);
        }
    }

    private void waitForSearchResults()
    {
        String resultsInt = findElement(TABLE_RESULTS).getText();

        Utils.waitForTrue(() ->
            !StringUtils.equalsIgnoreCase(resultsInt, "Showing 0 results"), 5);
    }

    public void selectAdvancedExpression(String operator)
    {
        scrollToElement(ADV_EXPR_DROPDOWN);
        click(ADV_EXPR_DROPDOWN);

        if (StringUtils.equalsIgnoreCase(operator, "AND"))
        {
            click(ADV_EXPR_OPTION_AND);
        }
        else if (StringUtils.equalsIgnoreCase(operator, "OR"))
        {
            click(ADV_EXPR_OPTION_OR);
        }
        else if (StringUtils.equalsIgnoreCase(operator, "Custom"))
        {
            click(ADV_EXPR_OPTION_CUSTOM);
        }
        else if (StringUtils.equalsIgnoreCase(operator, "Count"))
        {
            click(ADV_EXPR_OPTION_COUNT);
        }
        else
        {
            throw new IllegalArgumentException("Invalid advanced-expression operator: " + operator);
        }
    }

    public void openEditColumns()
    {
        click(EDIT_COLUMNS);
    }
}
