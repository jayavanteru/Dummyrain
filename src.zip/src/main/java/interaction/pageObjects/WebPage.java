package interaction.pageObjects;

import configuration.PropertyReader;
import interaction.DriverManager;
import interaction.api.ApiConfig;
import interaction.screenshots.ScreenShotDriver;
import interaction.screenshots.ScreenShotImage;
import interaction.webUI.DesktopAuto;
import interaction.webUI.NetworkMonitor;
import interaction.webUI.NetworkRequest;
import interaction.webUI.WebUI;
import logs.Log;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.MoveTargetOutOfBoundsException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import testHelp.MyJson;
import testHelp.Utils;

import javax.annotation.Nonnull;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;


public class WebPage extends Page{

    private WebDriver browser;
    private ScreenShotDriver screenShots;
//    private int apiTryCount = 100;
    private boolean boolResult;
    private String stringResult;
    private Dimension dimensionResult;
    private Rectangle rectangleResult;
    private Point pointResult;
    private WebElement elementResult;
    private List<WebElement> elementListResult;

    protected void setBrowser(WebDriver browser) {
        this.browser = browser;
    }

    protected WebDriver getBrowser() {
        TestPagesList.addClass(getClass().getName());
        if (browser == null) {
            final WebUI webDriver = DriverManager.getWebDriver(Thread.currentThread().getName());
            browser = webDriver.getBrowser();
            screenShots = webDriver.getScreenShotDriver();
        }
        return browser;
    }

    private DesktopAuto getDesktopAuto() {
        return DriverManager.getDesktopDriver(Thread.currentThread().getName());
    }

    private NetworkMonitor getNetwork() {
        return DriverManager.getDriverManager(Thread.currentThread().getName()).getNetworkMonitor();
    }

    protected void startNetworkMonitoring() {
        getNetwork().startMonitoring();
    }

    protected void stopNetworkMonitoring() {
        getNetwork().stopMonitoring();
    }

    protected NetworkRequest getRequestByEndpoint(String endpoint) {
        return getNetwork().getRequest(endpoint);
    }

    protected WebUI getWebUI() {
        return DriverManager.getWebDriver(Thread.currentThread().getName());
    }

    private boolean isBrowserOpen() {
        return DriverManager.isWebDriverCreatedForThread(Thread.currentThread().getName());
    }

    private boolean isNetworkMonitorRunning() {
        return DriverManager.isNetworkMonitorCreatedForThread(Thread.currentThread().getName());
    }

    protected void navigateTo(String url) {
        Log.info("navigating to " + url, getClass());
        getBrowser().navigate().to(url);
        waitForPageLoad();
        justWait();
    }

    protected void navigateBack() {
        Log.info("navigating back a page", getClass());
        getBrowser().navigate().back();
    }

    protected void navigateForward() {
        Log.info("navigating forward a page", getClass());
        getBrowser().navigate().forward();
    }

    protected void refreshPage() {
        Log.info("refreshing page", getClass());
        getBrowser().navigate().refresh();
        waitForPageLoad();
    }

    protected void click(By identifier) {
        Log.info("clicking on element: " + identifier.toString(), getClass());
        catchStaleElements(()->{
            getBrowser().findElement(identifier).click();
        });
        justWait();
    }

    protected void click(WebElement element) {
        Log.info("clicking on element: " + element.getTagName(), getClass());
        element.click();
        justWait();
    }

    protected void clickAtOffset(int x, int y) {
        Log.info("clicking on page at, x: " + x + " y: " + y, getClass());
        new Actions(getBrowser()).moveByOffset(x, y).click().perform();
        justWait();
    }

    protected void sendKeys(By identifier, String keys) {
        Log.info("sending keys '" + keys + "' to element: " + identifier.toString(), getClass());
        catchStaleElements(()->{
            getBrowser().findElement(identifier).sendKeys(keys);
        });
    }

    protected void sendKeys(By identifier, CharSequence... keys) {
        StringBuilder keyLog = new StringBuilder();
        String seperator = "";
        for (CharSequence key : keys) {
            keyLog.append(seperator);
            keyLog.append(key.toString());
            seperator = ",";
        }
        Log.info("sending keys '" + keyLog + "' to element: " + identifier.toString(), getClass());
        catchStaleElements(()->{
            getBrowser().findElement(identifier).sendKeys(keys);
        });
    }

    protected void sendKeys(WebElement element, CharSequence... keys) {
        StringBuilder keyLog = new StringBuilder();
        String seperator = "";
        for (CharSequence key : keys) {
            keyLog.append(seperator);
            keyLog.append(key.toString());
            seperator = ",";
        }
        Log.info("sending keys '" + keyLog + "' to element: " + element.getTagName(), getClass());
        element.sendKeys(keys);
    }

    protected void sendKeys(WebElement element, String keys) {
        Log.info("sending keys '" + keys + "' to element: " + element.getTagName(), getClass());
        element.sendKeys(keys);
    }

    //send a string or org.openqa.selenium.Keys for custom keys
    protected void sendKeys(CharSequence... keys) {
        StringBuilder keyLog = new StringBuilder();
        String seperator = "";
        for (CharSequence key : keys) {
            keyLog.append(seperator);
            keyLog.append(key.toString());
            seperator = ",";
        }
        Log.info("sending keys '" + keyLog + "' to Browser",getClass());
        new Actions(getBrowser()).sendKeys(keys).perform();
    }


    protected void sendKeysToDesktop(String keys) {
        getDesktopAuto().sendKeys(keys);
    }

    protected WebElement findElement(By identifier) {
        Log.info("finding element: " + identifier, getClass());
        elementResult = null;
        catchStaleElements(()->{
            elementResult = getBrowser().findElement(identifier);
        });
        return elementResult;
    }

    protected List<WebElement> findElements(By identifier) {
        Log.info("finding element: " + identifier, getClass());
        elementListResult = null;
        catchStaleElements(()->{
            elementListResult = getBrowser().findElements(identifier);
        });
        return elementListResult;
    }

  protected WebElement getElementByXpath(String xpath)
  {
    try
    {
      return findElement(By.xpath(xpath));
    }
    catch (Exception e)
    {
      return null;
    }
  }

    protected void scrollToTopOfPage() {
        Log.info("scrolling to the top of the page", getClass());
        ((JavascriptExecutor) getBrowser()).executeScript("window.scrollTo(0, 0);");
    }

    protected void scrollToElement(By identifier) {
        Log.info("scrolling to element: " + identifier, getClass());
        catchStaleElements(()->{
            ((JavascriptExecutor) getBrowser()).executeScript("arguments[0].scrollIntoView(true);", getBrowser().findElement(identifier));
        });
    }

    protected void scrollToElement(WebElement element) {
        Log.info("scrolling to element: " + element.getTagName(), getClass());
        ((JavascriptExecutor) getBrowser()).executeScript("arguments[0].scrollIntoView(true);", element);
    }

    protected void scrollElementToMiddle(By identifier) {
        Log.info("scrolling to element: " + identifier, getClass());
        catchStaleElements(()->{
            ((JavascriptExecutor) getBrowser()).executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", getBrowser().findElement(identifier));
        });
    }

    protected void scrollElementToMiddle(WebElement element) {
        Log.info("scrolling to element: " + element.getTagName(), getClass());
        ((JavascriptExecutor) getBrowser()).executeScript("arguments[0].scrollIntoView({block: 'center', inline: 'nearest'});", element);
    }

    protected void scrollUp() {
        Log.info("scrolling up", getClass());
        new Actions(getBrowser()).sendKeys(Keys.ARROW_UP).perform();
        justWait();
    }

    protected void scrollDown() {
        Log.info("scrolling down", getClass());
        new Actions(getBrowser()).sendKeys(Keys.ARROW_DOWN).perform();
        justWait();
    }

    protected boolean waitForPageUrlToContain(String url) {
        Log.info("Waiting for the url to contain " + url, getClass());
        Utils.waitForTrue(()->getBrowser().getCurrentUrl().contains(url));
        return getBrowser().getCurrentUrl().contains(url);
    }

    protected boolean waitForPageUrlToEndWith(String url) {
        Log.info("Waiting for the url to end with " + url, getClass());
        Utils.waitForTrue(()->getBrowser().getCurrentUrl().endsWith(url));
        return getBrowser().getCurrentUrl().endsWith(url);
    }

    protected boolean waitForPageUrlToStartWith(String url) {
        Log.info("Waiting for the url to start with " + url, getClass());
        Utils.waitForTrue(()->getBrowser().getCurrentUrl().startsWith(url));
        return getBrowser().getCurrentUrl().startsWith(url);
    }

    protected String getCurrentUrl() {
        String currentUrl = getBrowser().getCurrentUrl();
        Log.info("current url: " + currentUrl, getClass());
        return currentUrl;
    }

    protected String getPageSource() {
        Log.info("getting page source", getClass());
        return getBrowser().getPageSource();
    }

    protected String getTitle() {
        Log.info("getting title", getClass());
        return getBrowser().getTitle();
    }

    protected void selectByVisibleText(By identifier, String text) {
        Log.info("selecting " + text + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).selectByVisibleText(text);
        });
    }

    protected void selectByIndex(By identifier, int index) {
        Log.info("selecting " + index + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).selectByIndex(index);
        });
    }

    protected void selectByValue(By identifier, String value) {
        Log.info("selecting " + value + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).selectByValue(value);
        });
    }

    protected void deselectByIndex(By identifier, int index) {
        Log.info("deselecting " + index + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).deselectByIndex(index);
        });
    }

    protected void deselectByValue(By identifier, String value) {
        Log.info("deselecting " + value + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).deselectByValue(value);
        });
    }

    protected void deselectByVisibleText(By identifier, String text) {
        Log.info("deselecting " + text + " for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).deselectByVisibleText(text);
        });
    }

    protected List<WebElement> getOptions(By identifier) {
        Log.info("get options for " + identifier.toString(), getClass());
        elementListResult = null;
        catchStaleElements(()->{
            elementListResult = new Select(getBrowser().findElement(identifier)).getOptions();
        });
        return elementListResult;
    }

    protected void deselectAll(By identifier) {
        Log.info("deselecting all for element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Select(getBrowser().findElement(identifier)).deselectAll();
        });
    }

    protected void selectByVisibleText(WebElement element, String text) {
        Log.info("selecting " + text + " for element " + element.getTagName(), getClass());
        new Select(element).selectByVisibleText(text);
    }

    protected void selectByIndex(WebElement element, int index) {
        Log.info("selecting " + index + " for element " + element.getTagName(), getClass());
        new Select(element).selectByIndex(index);
    }

    protected void selectByValue(WebElement element, String value) {
        Log.info("selecting " + value + " for element " + element.getTagName(), getClass());
        new Select(element).selectByValue(value);
    }

    protected void deselectByIndex(WebElement element, int index) {
        Log.info("deselecting " + index + " for element " + element.getTagName(), getClass());
        new Select(element).deselectByIndex(index);
    }

    protected void deselectByValue(WebElement element, String value) {
        Log.info("deselecting " + value + " for element " + element.getTagName(), getClass());
        new Select(element).deselectByValue(value);
    }

    protected void deselectByVisibleText(WebElement element, String text) {
        Log.info("deselecting " + text + " for element " + element.getTagName(), getClass());
        new Select(element).deselectByVisibleText(text);
    }

    protected List<WebElement> getOptions(WebElement element) {
        Log.info("get options for " + element.getTagName(), getClass());
        return new Select(element).getOptions();
    }

    protected void deselectAll(WebElement element) {
        Log.info("deselecting all for element " + element.getTagName(), getClass());
        new Select(element).deselectAll();
    }

    protected <T> T webDriverWaitUntil(ExpectedCondition<T> waitMethod, int timeoutInSeconds) {
        Log.info("web driver wait until, timeout seconds: " + timeoutInSeconds, getClass());
        return new WebDriverWait(getBrowser(), timeoutInSeconds).until(waitMethod);
    }

    protected <T> void webDriverWaitUntil(ExpectedCondition<T> waitMethod) {
        webDriverWaitUntil(waitMethod, Utils.defaultWaitSeconds());
    }

    protected <T> void waitForElementNotToHaveClass(By identifier, String className) {
        webDriverWaitUntil(ExpectedConditions.not(ExpectedConditions.attributeContains(identifier, "class", className)));
    }

    protected <T> void waitForElementNotToHaveClass(WebElement element, String className) {
        webDriverWaitUntil(ExpectedConditions.not(ExpectedConditions.attributeContains(element, "class", className)));
    }

    protected <T> void waitForElementToBeClickable(By identifier) {
        webDriverWaitUntil(ExpectedConditions.and(ExpectedConditions.elementToBeClickable(identifier), ExpectedConditions.not(ExpectedConditions.attributeContains(identifier, "class", "disabled"))));
    }

    protected <T> void waitForElementToBeClickable(WebElement element) {
        webDriverWaitUntil(ExpectedConditions.elementToBeClickable(element));
    }

    protected <T> void waitForElementToBeClickable(By identifier, int maxSeconds) {
        webDriverWaitUntil(ExpectedConditions.and(ExpectedConditions.elementToBeClickable(identifier), ExpectedConditions.not(ExpectedConditions.attributeContains(identifier, "class", "disabled"))), maxSeconds);
    }

    protected <T> void waitForElementToBeClickable(WebElement element, int maxSeconds) {
        webDriverWaitUntil(ExpectedConditions.elementToBeClickable(element), maxSeconds);
    }

    protected String getWindowHandle() {
        String windowHandle = getBrowser().getWindowHandle();
        Log.info("window handle: " + windowHandle, getClass());
        return windowHandle;
    }

    protected Set<String> getWindowHandles() {
        Set<String> windowHandles = getBrowser().getWindowHandles();
        StringBuilder logText = new StringBuilder();
        String seperator = "";
        for (String handle : windowHandles) {
            logText.append(seperator);
            logText.append(handle);
            seperator = ",";
        }
        Log.info("window handles: " + logText, getClass());
        return windowHandles;
    }

    protected Alert switchToAlert() {
        Log.info("switching to alert", getClass());
        return getBrowser().switchTo().alert();
    }

    protected void switchToWindow(String windowHandle) {
        Log.info("switching to window: " + windowHandle, getClass());
        getBrowser().switchTo().window(windowHandle);
    }

    protected void switchToTab(int index) {
        ArrayList<String> tabs = new ArrayList<>(getBrowser().getWindowHandles());
        switchToWindow(tabs.get(index));
    }

    protected void switchToFrame(WebElement frame) {
        Log.info("switching to frame: " + frame, getClass());
        getBrowser().switchTo().frame(frame);
    }

    protected void switchToFrame(int frame) {
        Log.info("switching to frame: " + frame, getClass());
        getBrowser().switchTo().frame(frame);
    }

    protected void switchToFrame(String frame) {
        Log.info("switching to frame: " + frame, getClass());
        getBrowser().switchTo().frame(frame);
    }

    protected void switchToActiveElement() {
        Log.info("switching to the active element", getClass());
        getBrowser().switchTo().activeElement();
    }

    protected void switchToDefaultContent() {
        Log.info("switching to default content", getClass());
        getBrowser().switchTo().defaultContent();
    }

    protected void switchToParentFrame() {
        Log.info("switching to the parent frame", getClass());
        getBrowser().switchTo().parentFrame();
    }

    protected void switchToIframe() {
        Log.info("switching to iframe", getClass());
        WebElement iframe = getBrowser().findElement(By.tagName("iframe"));
        getBrowser().switchTo().frame(iframe);
    }

    protected void switchToIframe(int frame) {
        Log.info("switching to iframe "+ frame, getClass());
        WebElement iframe = getBrowser().findElements(By.tagName("iframe")).get(frame);
        getBrowser().switchTo().frame(iframe);
    }

    protected void keyDown(Keys key) {
        Log.info("key down " + key.name(), getClass());
        new Actions(getBrowser()).keyDown(key).perform();
    }

    protected void keyUp(Keys key) {
        Log.info("key up " + key.name(), getClass());
        new Actions(getBrowser()).keyUp(key).perform();
    }

    protected void clickAndHold(By identifier) {
        Log.info("click and hold " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).clickAndHold(getBrowser().findElement(identifier)).perform();
        });
        justWait();
    }

    protected void clickOffset(By identifier, int xOffset, int yOffset) {
        Log.info("click offset by X "+xOffset+" and Y "+yOffset+" of element: " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).moveToElement(getBrowser().findElement(identifier), xOffset, yOffset).click().perform();
        });
        justWait();
    }

    protected void clickAndHold(WebElement element) {
        Log.info("click and hold " + element.getTagName(), getClass());
        new Actions(getBrowser()).clickAndHold(element).perform();
        justWait();
    }

    protected void clickAndHold() {
        Log.info("click and hold ", getClass());
        new Actions(getBrowser()).clickAndHold().perform();
        justWait();
    }

    protected void clickOffset(WebElement element, int xOffset, int yOffset) {
        Log.info("click offset by X "+xOffset+" and Y "+yOffset+" of element: " + element.getTagName(), getClass());
        new Actions(getBrowser()).moveToElement(element, xOffset, yOffset).click().perform();
        justWait();
    }

    protected void moveMouseToTopCorner() {
        Log.info("start moving mouse back to top left corner", getClass());
        int x = 1040, y = 744;
        while (x > 0 || y > 0) {
            try {
                moveByOffset(-x, 0);
            } catch (MoveTargetOutOfBoundsException e) {
                x = x > 1 ? x/2 : 0;
            }
            try {
                moveByOffset(0, -y);
            } catch (MoveTargetOutOfBoundsException e) {
                y = y > 1 ? y/2 : 0;
            }
        }

        Log.info("mouse moved back to top left corner", getClass());
    }

    protected void moveByOffset(int xOffset, int yOffset){
        Log.info("move to offset by X "+xOffset+" and Y "+yOffset, getClass());
        new Actions(getBrowser()).moveByOffset(xOffset, yOffset).perform();
    }

    protected void keyDown(CharSequence chars) {
        Log.info("key down " + chars, getClass());
        new Actions(getBrowser()).keyDown(chars).perform();
    }

    protected void keyDown(By identifier, CharSequence chars) {
        Log.info("key down " + chars + " on element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).keyDown(getBrowser().findElement(identifier), chars).perform();
        });
    }

    protected void keyDown(WebElement element, CharSequence chars) {
        Log.info("key down " + chars + " on element " + element.getTagName(), getClass());
        new Actions(getBrowser()).keyDown(element, chars).perform();
    }

    protected void KeyUp(CharSequence chars) {
        Log.info("key up " + chars, getClass());
        new Actions(getBrowser()).keyUp(chars).perform();
    }

    protected void keyUp(By identifier, CharSequence chars) {
        Log.info("key up " + chars + " on element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).keyUp(getBrowser().findElement(identifier), chars).perform();
        });
    }

    protected void moveTo(By identifier) {
        Log.info("moving to element " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).moveToElement(getBrowser().findElement(identifier)).perform();
        });
    }

    protected void moveToAndClick(By identifier) {
        Log.info("moving to element " + identifier.toString() + " and clicking", getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).moveToElement(getBrowser().findElement(identifier)).click().perform();
        });
        justWait();
    }

    protected void moveToAndDoubleClick(By identifier) {
        Log.info("moving to element " + identifier.toString() + " and clicking", getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).moveToElement(getBrowser().findElement(identifier)).doubleClick().perform();
        });
        justWait();
    }

    protected void keyUp(WebElement element, CharSequence chars) {
        Log.info("key up " + chars + " on element " + element.getTagName(), getClass());
        new Actions(getBrowser()).keyUp(element, chars).perform();
    }

    protected void moveTo(WebElement element) {
        Log.info("moving to element " + element.getTagName(), getClass());
        new Actions(getBrowser()).moveToElement(element).perform();
    }

    protected void moveToAndClick(WebElement element) {
        Log.info("moving to element " + element.getTagName() + " and clicking", getClass());
        new Actions(getBrowser()).moveToElement(element).click().perform();
        justWait();
    }

    protected void releaseClick() {
        Log.info("releasing click", getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).release().perform();
        });
        justWait();
    }

    protected void doubleClick(By identifier) {
        Log.info("double click " + identifier.toString(), getClass());
        catchStaleElements(()->{
            new Actions(getBrowser()).doubleClick(getBrowser().findElement(identifier)).release().perform();
        });
        justWait();
    }

    protected void movePhysicalMouse(int x, int y) {
        getDesktopAuto().moveMouseTo(x, y);
    }

    protected void clear(By identifier) {
        Log.info("clearing field " + identifier.toString(), getClass());
        catchStaleElements(()->{
            getBrowser().findElement(identifier).clear();
        });
    }

    protected void setInput(By input, String value) {
        clear(input);
        sendKeys(input, value);
    }

    protected void clearWithBackSpace(By identifier) {
        Log.info("using backspace to clear field " + identifier.toString(), getClass());
        int length = getBrowser().findElement(identifier).getAttribute("value").length();
        Keys[] bslist = new Keys[length];
        for (int i = 0; i < length; ++i) {
            bslist[i] = Keys.BACK_SPACE;
        }
        if (bslist.length > 0){
            catchStaleElements(() -> {
                getBrowser().findElement(identifier).sendKeys(bslist);
            });
        }
    }

    protected void clearWithBackSpace(WebElement element) {
        Log.info("using backspace to clear field " + element.getTagName(), getClass());
        int length = element.getAttribute("value").length();
        Keys[] bslist = new Keys[length];
        for (int i = 0; i < length; ++i) {
            bslist[i] = Keys.BACK_SPACE;
        }
        if (bslist.length  > 0) {
            element.sendKeys(bslist);
        }
    }

    protected void copyToClipboard() {
        Log.info("copy to clipboard", getClass());
        if (System.getProperty("os.name").toLowerCase().contains("mac")) {
            new Actions(getBrowser()).keyDown(Keys.COMMAND).perform();
            new Actions(getBrowser()).sendKeys("c").perform();
            new Actions(getBrowser()).keyUp(Keys.COMMAND).perform();
        }else if (System.getProperty("os.name").toLowerCase().contains("win")){
            new Actions(getBrowser()).keyDown(Keys.CONTROL).keyUp(Keys.CONTROL).perform();
            new Actions(getBrowser()).sendKeys("c").perform();
            new Actions(getBrowser()).keyUp(Keys.CONTROL).perform();
        }
        else {
            //new Actions(getBrowser()).keyDown(Keys.SHIFT).build().perform();
            new Actions(getBrowser()).keyDown(Keys.CONTROL).build().perform();
            new Actions(getBrowser()).sendKeys("c").build().perform();
            //new Actions(getBrowser()).keyUp(Keys.SHIFT).build().perform();
            new Actions(getBrowser()).keyUp(Keys.CONTROL).build().perform();
        }
    }

    protected void selectAll() {
        Log.info("selecting all", getClass());
        if (System.getProperty("os.name").toLowerCase().contains("mac")) {
            new Actions(getBrowser()).keyDown(Keys.COMMAND).build().perform();
            new Actions(getBrowser()).sendKeys("a").build().perform();
            new Actions(getBrowser()).keyUp(Keys.COMMAND).build().perform();

        }else if (System.getProperty("os.name").toLowerCase().contains("win")){
            new Actions(getBrowser()).keyDown(Keys.CONTROL).keyUp(Keys.CONTROL).build().perform();
            new Actions(getBrowser()).sendKeys("a").build().perform();
            new Actions(getBrowser()).keyUp(Keys.CONTROL).build().perform();
        }
        else {
           // new Actions(getBrowser()).keyDown(Keys.SHIFT).build().perform();
            new Actions(getBrowser()).keyDown(Keys.CONTROL).build().perform();
            new Actions(getBrowser()).sendKeys("a").build().perform();
           // new Actions(getBrowser()).keyUp(Keys.SHIFT).build().perform();
            new Actions(getBrowser()).keyUp(Keys.CONTROL).build().perform();
        }
    }

    protected void customClick(WebElement element, int clickTimes)  {
        Log.info("clicking on " + element + " " + clickTimes + " times", getClass());
        final Actions actions = new Actions(getBrowser()).moveToElement(element);
        for (int i = 0; i < clickTimes; ++i) {
            actions.click();
        }
        actions.perform();
    }

    protected void customClick(By identifier, int clickTimes)  {
        Log.info("clicking on " + identifier + " " + clickTimes + " times", getClass());
        catchStaleElements(()->{
            WebElement element = getBrowser().findElement(identifier);
            final Actions actions = new Actions(getBrowser()).moveToElement(element);
            for (int i = 0; i < clickTimes; ++i) {
                actions.click();
            }
            actions.perform();
        });

    }

    protected String getAttribute(By identifier, String attribute) {
        Log.info("getting attribute '"+attribute+"' from '"+identifier.toString()+"'", getClass());
        stringResult = "";
        catchStaleElements(()->{
            stringResult = getBrowser().findElement(identifier).getAttribute(attribute);
        });
        return stringResult;
    }

    protected String getCssValue(By identifier, String css) {
        Log.info("getting css value '"+css+"' for '" + identifier.toString() + "'", getClass());
        stringResult = "";
        catchStaleElements(()->{
            stringResult = getBrowser().findElement(identifier).getCssValue(css);
        });
        return stringResult;
    }

    protected Point getLocation(By identifier) {
        Log.info("getting location for " + identifier.toString(), getClass());
        pointResult = null;
        catchStaleElements(()->{
            pointResult = getBrowser().findElement(identifier).getLocation();
        });
        return pointResult;
    }

    protected Rectangle getRect(By identifier) {
        Log.info("getting rectangle for " + identifier.toString(), getClass());
        rectangleResult = null;
        catchStaleElements(()->{
            rectangleResult = getBrowser().findElement(identifier).getRect();
        });
        return rectangleResult;
    }

    protected Dimension getSize(By identifier) {
        Log.info("getting size for " + identifier.toString(), getClass());
        dimensionResult = null;
        catchStaleElements(()->{
            dimensionResult = getBrowser().findElement(identifier).getSize();
        });
        return dimensionResult;
    }

    protected String getTagName(By identifier) {
        Log.info("getting tag name for " + identifier.toString(), getClass());
        stringResult = "";
        catchStaleElements(()->{
            stringResult = getBrowser().findElement(identifier).getTagName();
        });
        return stringResult;
    }

    protected String getText(By identifier) {
        Log.info("getting text for " + identifier.toString(), getClass());
        stringResult = "";
        catchStaleElements(()->{
            stringResult = getBrowser().findElement(identifier).getAttribute("textContent");
        });
        return stringResult;
    }

    protected String getValue(By identifier) {
        Log.info("getting value for " + identifier.toString(), getClass());
        stringResult = "";
        catchStaleElements(()->{
            stringResult = getBrowser().findElement(identifier).getAttribute("value");
        });
        return stringResult;
    }

    protected boolean isDisplayed(By identifier) {
        Log.info("getting is displayed for " + identifier.toString(), getClass());
        boolResult = false;
        catchStaleElements(()->{
            boolResult = getBrowser().findElement(identifier).isDisplayed();
        });
        return boolResult;
    }

    protected boolean isEnabled(By identifier) {
        Log.info("getting is enabled for " + identifier.toString(), getClass());
        boolResult = false;
        catchStaleElements(()->{
            boolResult = getBrowser().findElement(identifier).isEnabled();
        });
        return boolResult;
    }

    protected boolean isSelected(By identifier) {
        Log.info("getting is selected for " + identifier.toString(), getClass());
        boolResult = false;
        catchStaleElements(()->{
            boolResult = getBrowser().findElement(identifier).isSelected();
        });
        return boolResult;
    }

    protected void submit(By identifier) {
        Log.info("submitting: " + identifier.toString(), getClass());
        catchStaleElements(()->{
            getBrowser().findElement(identifier).submit();
        });
    }

    protected boolean isElementOnPage(By identifier) {
        Log.info("seeing if element exists on the page " + identifier.toString(), getClass());
        boolResult = false;
        catchStaleElements(()->{
            boolResult = getBrowser().findElements(identifier).size() > 0;
        });
        return boolResult;
    }

    protected boolean isElementsOnPage(List<By> identifiers) {
        boolResult = true;
        for (By identifier : identifiers) {
            Log.info("seeing if element exists on the page " + identifier.toString(), getClass());
            catchStaleElements(() -> {
                boolResult = boolResult && getBrowser().findElements(identifier).size() > 0;
            });
        }
        return boolResult;
    }

    protected List<By> findMissingElements(By[] identifiers) {
        List<By> notLoaded = new ArrayList<>();
        setImplicitWait(100L, TimeUnit.MILLISECONDS);

        for (By elid : identifiers) {
            if (notLoaded.size() < 1) waitForElementOnPage(elid);
            if (!(isElementOnPage(elid) && isDisplayed(elid))) {
                notLoaded.add(elid);
            }
        }

        resetImplicitWait();
        return notLoaded;
    }

    protected boolean waitForElementOnPage(By identifier) {
        return waitForElementOnPage(identifier, Utils.defaultWaitSeconds());
    }

    protected boolean waitForElementsOnPage(final By... identifier) {
        setImplicitWait(100, TimeUnit.MILLISECONDS);
        boolean answer = Utils.waitForTrue(()-> {
            boolean result = false;
            for (By id : identifier) {
                result = result || isElementOnPage(id);
            }
            return result;
        });
        resetImplicitWait();
        return answer;
    }

    protected boolean waitForElementOnPage(By identifier, int maxtimeoutSeconds) {
        Log.info("waiting for element exists on the page " + identifier.toString(), getClass());
        boolResult = false;
        catchStaleElements(()->{
            boolResult = Utils.waitForTrue(()->getBrowser().findElements(identifier).size() > 0, maxtimeoutSeconds);
        });
        return boolResult;
    }

    protected boolean waitForElementNotOnPage(By identifier) {
        return waitForElementNotOnPage(identifier, Utils.defaultWaitSeconds());
    }

    protected boolean waitForElementNotOnPage(By identifier, int maxtimeout) {
        Log.info("waiting for element to not exist on the page " + identifier.toString(), getClass());
        boolResult = false;
        setImplicitWait(1, TimeUnit.SECONDS);
        catchStaleElements(()->{
            boolResult = Utils.waitForTrue(()->getBrowser().findElements(identifier).size() <= 0, maxtimeout);
        });
        setImplicitWait(Long.parseLong(PropertyReader.instance().getProperty("implicitWaitSeconds")), TimeUnit.SECONDS);
        return boolResult;
    }

    protected void doubleClick(WebElement element) {
        Log.info("double click " + element.getTagName(), getClass());
        new Actions(getBrowser()).doubleClick(element).perform();
        justWait();
    }

//todo: HTML5 drag-and-drop is not supported by Selenium.
// If we want the ability to drag-and-drop based on x/y coordinates, we will need to implement a JavaScript solution (similar to the dragAndDrop() method below)
//
//    protected void dragAndDrop(WebElement from, int xoffset, int yoffset)
//    {
//      String logMessage = "drag and dropping "+from.getTagName()+" to offset ("+xoffset+", "+yoffset+")";
//      new Actions(getBrowser()).dragAndDropBy(from, xoffset, yoffset).release().perform();
//    }
//    protected void dragAndDropByOffset(By startIdentifier, int xMoveAmount, int yMoveAmount)
//    {
//      String logMessage = "drag and dropping  " + startIdentifier.toString() + " by X: " + xMoveAmount + " and Y: " + yMoveAmount;
//      catchStaleElements(()->{
//        new Actions(getBrowser()).dragAndDropBy(getBrowser().findElement(startIdentifier), xMoveAmount, yMoveAmount).perform();
//      });
//    }
//    protected void dragAndDropByOffset(WebElement element, int xMoveAmount, int yMoveAmount)
//    {
//      String logMessage = "drag and dropping  " + element.toString() + " by X: " + xMoveAmount + " and Y: " + yMoveAmount;
//      new Actions(getBrowser()).dragAndDropBy(element, xMoveAmount, yMoveAmount).perform();
//    }

    protected void dragAndDrop(By fromIdentifier, By toIdentifier)
    {
      String logMessage = "drag and dropping from " + fromIdentifier.toString() + " to " + toIdentifier.toString();
      dragAndDrop(findElement(fromIdentifier), findElement(toIdentifier), logMessage);
    }
    protected void dragAndDrop(@Nonnull WebElement fromElement, @Nonnull WebElement toElement)
    {
      String logMessage = "drag and dropping from " + fromElement.getTagName() + " to " + toElement.getTagName();
      dragAndDrop(fromElement, toElement, logMessage);
    }

    /**
     * HTML5 drag-and-drop (DND) is not supported by Selenium.<br/>
     * As a work-around, we use native JavaScript to simulate the old way of performing DND, which includes <code>dragStart</code>, <code>drop</code>, and <code>dragEnd</code> commands.<br/>
     * <br/>
     * See also:<br/>
     * <a href="https://stackoverflow.com/questions/39436870/why-drag-and-drop-is-not-working-in-selenium-webdriver/62677813">Why drag and drop is not working in Selenium Webdriver?</a><br/>
     * <a href="https://www.linkedin.com/pulse/javascriptexecutor-selenium-gaurav-gupta/">How to perform drag and drop in Selenium</a><br/>
     *
     * @param fromElement starting location of the DND (i.e., where the mouse will <code>clickAndHold()</code>)
     * @param toElement ending location of the DND (i.e., where the mouse will <code>release()</code>)
     */
    private void dragAndDrop(@Nonnull WebElement fromElement, @Nonnull WebElement toElement, String logMessage)
    {
      Log.info(logMessage, getClass());

      JavascriptExecutor js = (JavascriptExecutor) getBrowser();
      js.executeScript(
        "function createEvent(typeOfEvent) {\n" +
          "  var event = document.createEvent(\"CustomEvent\");\n" +
          "  event.initCustomEvent(typeOfEvent, true, true, null);\n" +
          "  event.dataTransfer = {\n" +
          "    data: {},\n" +
          "    setData: function (key, value) {\n" +
          "      this.data[key] = value;\n" +
          "    },\n" +
          "    getData: function (key) {\n" +
          "      return this.data[key];\n" +
          "    }\n" +
          "  };\n" +
          "  return event;\n" +
          "}\n" +
          "\n" +
          "function dispatchEvent(element, event, transferData) {\n" +
          "  if (transferData !== undefined) {\n" +
          "    event.dataTransfer = transferData;\n" +
          "  }\n" +
          "  if (element.dispatchEvent) {\n" +
          "    element.dispatchEvent(event);\n" +
          "  } else if (element.fireEvent) {\n" +
          "    element.fireEvent(\"on\" + event.type, event);\n" +
          "  }\n" +
          "}\n" +
          "\n" +
          "function simulateHTML5DragAndDrop(sourceElement, destinationElement) {\n" +
          "  var dragStartEvent = createEvent('dragstart');\n" +
          "  dispatchEvent(sourceElement, dragStartEvent);\n" +
          "  var dropEvent = createEvent('drop');\n" +
          "  dispatchEvent(destinationElement, dropEvent, dragStartEvent.dataTransfer);\n" +
          "  var dragEndEvent = createEvent('dragend');\n" +
          "  dispatchEvent(sourceElement, dragEndEvent, dropEvent.dataTransfer);\n" +
          "}\n" +
          "\n" +
          "var source = arguments[0];\n" +
          "var destination = arguments[1];\n" +

          "simulateHTML5DragAndDrop(source,destination);", fromElement, toElement);

      //This is the old way that no longer works with HTML5 (see method javadoc above for more details)
      //new Actions(getBrowser()).dragAndDrop(fromElement, toElement).perform();
    }

    protected void clear(WebElement element) {
        Log.info("clearing field " + element.getTagName(), getClass());
        element.clear();
    }

    protected String getAttribute(WebElement element, String attribute) {
        Log.info("getting attribute '"+attribute+"' from '"+element.getTagName()+"'", getClass());
        return element.getAttribute(attribute);
    }

    protected String getCssValue(WebElement element, String css) {
        Log.info("getting css value '"+css+"' for '" + element.getTagName() + "'", getClass());
        return element.getCssValue(css);
    }

    protected Point getLocation(WebElement element) {
        Log.info("getting location for " + element.getTagName(), getClass());
        return element.getLocation();
    }

    protected Rectangle getRect(WebElement element) {
        Log.info("getting rectangle for " + element.getTagName(), getClass());
        return element.getRect();
    }

    protected Dimension getSize(WebElement element) {
        Log.info("getting size for " + element.getTagName(), getClass());
        return element.getSize();
    }

    protected String getTagName(WebElement element) {
        Log.info("getting tag name for " + element.getTagName(), getClass());
        return element.getTagName();
    }

    protected String getValue(WebElement element) {
        Log.info("getting value for " + element.getTagName(), getClass());
        return element.getAttribute("value");
    }

    protected String getText(WebElement element) {
        Log.info("getting text for " + element.getTagName(), getClass());
        return element.getText();
    }

    protected boolean isDisplayed(WebElement element) {
        Log.info("getting is displayed for " + element.getTagName(), getClass());
        return element.isDisplayed();
    }

    protected boolean isEnabled(WebElement element) {
        Log.info("getting is enabled for " + element.getTagName(), getClass());
        return element.isEnabled();
    }

    protected boolean isSelected(WebElement element) {
        Log.info("getting is selected for " + element.getTagName(), getClass());
        return element.isSelected();
    }

    protected void submit(WebElement element) {
        Log.info("submitting: " + element.getTagName(), getClass());
        element.submit();
    }

    protected void close() {
        Log.info("closing the browser", getClass());
        if (isBrowserOpen()) {
            getBrowser().close();
        }
    }

    protected void quit() {
        Log.info("quitting out of the browser", getClass());
        if (isBrowserOpen()) {
            getBrowser().quit();
            if (isNetworkMonitorRunning()) {
                getNetwork().stop();
            }
        }
    }

    protected void setWindowfullscreen() {
        Log.info("setting window to full screen", getClass());
        getBrowser().manage().window().fullscreen();
    }

    protected void setWindowSize(int width, int height) {
        Log.info("setting window size to width: " + width + " height: " + height, getClass());
        getBrowser().manage().window().setSize(new Dimension(width, height));
    }

    protected void setWindowMaximize() {
        Log.info("setting window to maximize", getClass());
        getBrowser().manage().window().maximize();
    }

    protected void deleteAllCookies() {
        Log.info("deleting all the cookies", getClass());
        if (isBrowserOpen()) {
            getBrowser().manage().deleteAllCookies();
        }
    }

    protected void deleteCookieNamed(String cookieName) {
        Log.info("deleting cookie named " + cookieName, getClass());
        if (isBrowserOpen()) {
            getBrowser().manage().deleteCookieNamed(cookieName);
        }
    }

    protected void addCookie(Cookie cookie) {
        Log.info("adding cookie named " + cookie.getName(), getClass());
        getBrowser().manage().addCookie(cookie);
    }

    protected void addCookie(String name, String value) {
        Log.info("adding cookie, name: " + name + " value: " + value, getClass());
        getBrowser().manage().addCookie(new Cookie(name, value));
    }

    protected Set<Cookie> getCookies() {
        Log.info("getting all cookies", getClass());
        return getBrowser().manage().getCookies();
    }

    protected Cookie getCookieNamed(String name) {
        Log.info("getting cookie named " + name, getClass());
        return getBrowser().manage().getCookieNamed(name);
    }

    protected ScreenShotImage takeScreenShot() {
        return screenShots.getScreenShot(getBrowser());
    }

    protected ScreenShotImage takeScreenShot(By el) {
        return takeScreenShot(findElement(el));
    }

    protected ScreenShotImage takeScreenShot(WebElement el) {
        //page scroll adjustment
        final int eytra = ((Long)((JavascriptExecutor)getBrowser()).executeScript("return window.pageYOffset")).intValue();
        final int extra = ((Long)((JavascriptExecutor)getBrowser()).executeScript("return window.pageXOffset")).intValue();

        Log.info("take screenshot of element on page " + el, getClass());
        final Rectangle rect = el.getRect();
        final ScreenShotImage screenShot = screenShots.getScreenShot(getBrowser());
        final Rectangle bodySize = findElement(By.tagName("body")).getRect();
        screenShot.scaleImage(bodySize.width, bodySize.height);
        return screenShot.getSubImage(rect.x - extra, rect.y - eytra, rect.width, rect.height);
    }

    protected void setImplicitWait(long time, TimeUnit unit) {
        Log.info("setting implicit wait time to " + time + " " + unit.name(), getClass());
        getBrowser().manage().timeouts().implicitlyWait(time, unit);
    }

    protected void resetImplicitWait() {
        Long time = Long.valueOf(properties.getProperty("implicitWaitSeconds"));
        setImplicitWait(time, TimeUnit.SECONDS);
    }

    protected void setPageLoadTimeout(long time, TimeUnit unit) {
        Log.info("setting page load timeout to " + time + " " + unit.name(), getClass());
        getBrowser().manage().timeouts().pageLoadTimeout(time, unit);
    }

    protected void setScriptTimeout(long time, TimeUnit unit) {
        Log.info("setting script timeout to " + time +" "+ unit.name(), getClass());
        getBrowser().manage().timeouts().setScriptTimeout(time, unit);
    }

    protected void setAttribute(By identifier, String attribute, String value) {
        Log.info("setting attribute '"+attribute+"' to '"+value+"' for element '"+identifier.toString()+"'", getClass());
        catchStaleElements(()->{
            WebElement element = getBrowser().findElement(identifier);
            ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].setAttribute('"+attribute+"', '"+value+"')", element);
        });
    }

    protected void setAttribute(WebElement element, String attribute, String value) {
        Log.info("setting attribute '"+attribute+"' to '"+value+"' for element '"+element.getTagName()+"'", getClass());
        ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].setAttribute('"+attribute+"', '"+value+"')", element);
    }

    protected String executeJavaScript(String javascript) {
        Log.info("running script: " + javascript, getClass());
        return (String)((JavascriptExecutor)getBrowser()).executeScript(javascript);
    }

    protected void setInnerHtml(By identifier, String innerHtml) {
        Log.info("setting innerHML for '"+identifier.toString()+"' to '"+innerHtml+"''", getClass());
        catchStaleElements(()->{
            WebElement element = getBrowser().findElement(identifier);
            ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].innerHTML='"+innerHtml.replace("'", "\\'")+"'", element);
        });

    }

    protected void setInnerHtml(WebElement element, String innerHtml) {
        Log.info("setting innerHML for '"+element.getTagName()+"' to '"+innerHtml+"''", getClass());
        ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].innerHTML='"+innerHtml.replace("'", "\\'")+"'", element);
    }

    protected void setValue(By identifier, String value) {
        Log.info("setting value for '"+identifier.toString()+"' to '"+value+"''", getClass());
        catchStaleElements(()->{
            WebElement element = getBrowser().findElement(identifier);
            ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].value='"+value.replace("'", "\\'")+"'", element);
            element.click();
        });

    }

    protected void removeElement(By identifier) {
        Log.info("Removing attribute from page " + identifier, getClass());
        catchStaleElements(()->{
            WebElement element = getBrowser().findElement(identifier);
            ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].remove();", element);
        });
    }

    protected void removeElement(WebElement element) {
        Log.info("Removing attribute from page " + element, getClass());
        catchStaleElements(()->{
            ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].remove();", element);
        });
    }

    protected void setValue(WebElement element, String value) {
        Log.info("setting value for '"+element.getTagName()+"' to '"+value+"''", getClass());
        ((JavascriptExecutor)getBrowser()).executeScript("arguments[0].value='"+value.replace("'", "\\'")+"'", element);
        element.click();
    }

    protected void catchStaleElements(Runnable runnable) {
        try {
            runnable.run();
        } catch (StaleElementReferenceException e) {
            Log.warn("Stale element exception, trying again", getClass());
            runnable.run();
        }
    }

    public void waitForPageLoad() {
        waitForPageLoad(30);
    }

    public void waitForPageLoad(int maxSeconds) {
        Log.info("waiting for the page to load", getClass());
        String javascript = "return document.readyState === 'complete'";
        int retry = maxSeconds * 2;
        boolean loaded = false;
        while (!loaded && retry-- > 0) {
            loaded = (boolean) ((JavascriptExecutor)getBrowser()).executeScript(javascript);
            Log.info("waiting for the page to load", WebPage.class);
        }
        boolean loadedajax = false;
        while(!loadedajax && retry --> 0 ) {
            loadedajax = (Boolean) ((JavascriptExecutor)getBrowser()).executeScript("return (window.jQuery != null) && (jQuery.active === 0);");
        }
    }

  /**
   * Does a screenshot comparison, keeps checking screenshots till the page stops changing
   */
  public void justWait() {
        getBrowser();
        screenShots.wait(browser);
    }

    protected void waitForAjax() {
        waitForAjax(5);
    }

    protected void waitForAjax(int maxSeconds) {
        int retry = maxSeconds * 2;
        boolean loadedajax = false;
        while(!loadedajax && retry --> 0 ) {
            loadedajax = (Boolean) ((JavascriptExecutor)getBrowser()).executeScript("return (window.jQuery != null) && (jQuery.active === 0);");
        }
    }

    public boolean deleteEntityById (String deleteUrl, String entityId) {
        String url = getData("adminUrl") + "/" + deleteUrl + "?id=" + entityId;
        JSONObject response = post(url).getResponse();

        boolean status;

        try {
            status = StringUtils.defaultString(response.getJSONObject("data").getString("status")).equalsIgnoreCase("success");
        } catch (Exception e) {
            status = false;
        }

        return status;
    }

    //================================== API calls through the getBrowser() ==================================
    protected ApiConfig post(String path, HashMap<String, String> headers, String body) {
        return apiCallBody("POST", createApiConfig(path, headers, body));
    }

    protected ApiConfig postAsUrlParams(String path, String body) {
        ApiConfig apiConfig = createApiConfig(path, null, body);
        apiConfig.setUrlParams(true);
        return apiCall("POST", apiConfig);
    }

    protected ApiConfig postAsUrlParams(String path, HashMap<String, String> headers, String body) {
        ApiConfig apiConfig = createApiConfig(path, headers, body);
        apiConfig.setUrlParams(true);
        return apiCall("POST", apiConfig);
    }

    protected ApiConfig put(String path, HashMap<String, String> headers, String body) {
        return apiCallBody("PUT", createApiConfig(path, headers, body));
    }

    protected ApiConfig patch(String path, HashMap<String, String> headers, String body) {
        return apiCallBody("PATCH", createApiConfig(path, headers, body));
    }

    protected ApiConfig get(String path, HashMap<String, String> headers) {
        return apiCall("GET", createApiConfig(path, headers, null));
    }

    protected ApiConfig delete(String path, HashMap<String, String> headers) {
        return apiCall("DELETE", createApiConfig(path, headers, null));
    }

    protected ApiConfig post(String path, String body) {
        return apiCallBody("POST", createApiConfig(path, null, body));
    }

    protected ApiConfig post(ApiConfig config) {
        return apiCallBody("POST", config);
    }

    protected ApiConfig post(String path) {
        return apiCall("POST", createApiConfig(path, null, null));
    }

    protected ApiConfig put(String path, String body) {
        return apiCallBody("PUT", createApiConfig(path, null, body));
    }

    protected ApiConfig patch(String path, String body) {
        return apiCallBody("PATCH", createApiConfig(path, null, body));
    }

    protected ApiConfig get(String path) {
        return apiCall("GET", createApiConfig(path, null, null));
    }

    protected ApiConfig get(ApiConfig apiConfig) {
        return apiCall("GET", apiConfig);
    }

    protected ApiConfig delete(String path) {
        return apiCall("DELETE", createApiConfig(path, null, null));
    }

    protected String getcsrfToken() {
        return ((JavascriptExecutor) getBrowser()).executeScript("return typeof rfcsrf === 'undefined' ? '' : rfcsrf").toString();
    }

    protected ApiConfig apiCallBody(String type, ApiConfig config) {
        waitForPageLoad();
        String path = config.getUrl();
        String rfcsrf = getcsrfToken();
        config.setHeader("rfcsrf", rfcsrf);
        HashMap<String, String> headers = config.getHeaders();
        String body = config.getBody().toString();

        StringBuilder javaScriptCall = new StringBuilder("window.testresponse=undefined;window.testresponsecode=undefined;\nTAEapicall = new XMLHttpRequest();\n");
        javaScriptCall.append("TAEapicall.open('").append(type.toUpperCase()).append("', '").append(path).append("');\n");
        headers.forEach((k,v)-> javaScriptCall.append("TAEapicall.setRequestHeader('").append(k).append("', '").append(v).append("');\n"));
        javaScriptCall.append("TAEapicall.onload = function() {window.testresponse = TAEapicall.response; window.testresponsecode=TAEapicall.status;};\n");
        javaScriptCall.append("TAEapicall.send(JSON.stringify(").append(body).append("));\n");

        Log.info("running api call "+type+" to " + path, getClass());
        Log.debug("api call: " + javaScriptCall.toString(), getClass());

        String response = null;
        ((JavascriptExecutor)getBrowser()).executeScript(javaScriptCall.toString());
        int tried = Integer.parseInt(PropertyReader.instance().getProperty("browserApiCallTimeout")) / 300;
        int responseCode = 0;
        Object rawresponse = null;
        while ((rawresponse == null || responseCode == 0) && --tried > 0) {
            Utils.sleep(300);
            rawresponse = ((JavascriptExecutor)getBrowser()).executeScript("return window.testresponsecode");
            if (rawresponse != null) {
                responseCode = Math.toIntExact((Long) rawresponse);
            }
        } if (responseCode == 0) {
            Log.error("never got a response back for the api call " + config.getUrl(), getClass());
        } else {
            response = (String) ((JavascriptExecutor) getBrowser()).executeScript("return window.testresponse");
            Log.info("api call finished with response code " + responseCode, getClass());
        }

        Log.debug("api response: " + response, getClass());
        if (response != null) {
            config.setRawResponse(response);
            config.setResponse(MyJson.createJSON(response));
        }
        config.setBodyResponseCode(responseCode);
        return config;
    }

    protected ApiConfig apiCall(String type, ApiConfig config) {
        waitForPageLoad(30);
        String path = config.getUrl();
        String rfcsrf = getcsrfToken();
        config.setHeader("rfcsrf", rfcsrf);
        HashMap<String, String> headers = config.getHeaders();

        StringBuilder javaScriptCall = new StringBuilder("window.testresponse=undefined;window.testresponsecode=0;\nTAEapicall = new XMLHttpRequest();\n");
        javaScriptCall.append("TAEapicall.open('").append(type.toUpperCase()).append("', '").append(path).append("');\n");
        headers.forEach((k,v)-> javaScriptCall.append("TAEapicall.setRequestHeader('").append(k).append("', '").append(v).append("');\n"));
        javaScriptCall.append("TAEapicall.onload = function() {window.testresponse = TAEapicall.response; window.testresponsecode=TAEapicall.status;};\n");
        javaScriptCall.append("TAEapicall.send();\n");

        Log.info("running api call "+type+" to " + path, getClass());
        Log.debug("api call: " + javaScriptCall.toString(), getClass());

        String response = null;
        ((JavascriptExecutor)getBrowser()).executeScript(javaScriptCall.toString());
        int tried = Integer.parseInt(PropertyReader.instance().getProperty("browserApiCallTimeout")) / 300;
        int responseCode = 0;
        Object rawresponse = null;
        while ((rawresponse == null || responseCode == 0) && --tried > 0) {
            Utils.sleep(300);
            rawresponse = ((JavascriptExecutor)getBrowser()).executeScript("return window.testresponsecode");
            if (rawresponse != null) {
                responseCode = Math.toIntExact((Long) rawresponse);
            }
        } if (responseCode == 0) {
            Log.error("never got a response back for the api call " + config.getUrl(), getClass());
        } else {
            response = (String) ((JavascriptExecutor) getBrowser()).executeScript("return window.testresponse");
            Log.info("api call finished with response code " + responseCode, getClass());
        }

        Log.debug("api response: " + response, getClass());
        if (response != null) {
            config.setRawResponse(response);
            config.setResponse(MyJson.createJSON(response));
        }
        config.setBodyResponseCode(responseCode);
        return config;
    }

    //==================================================================================================

    private ApiConfig createApiConfig(String path, HashMap<String, String> headers, String body) {
        ApiConfig config = new ApiConfig(path);
        if (headers != null) {
            config.setHeaders(headers);
        }
        if (body != null) {
            config.setBody(MyJson.createJSON(body));
        }
        return config;
    }

    protected void superSafeClick(By element){
        waitForElementOnPage(element);
        scrollToElement(element);
        waitForElementToBeClickable(element);
        click(element);
    }

    protected void superSafeClickMidScroll(By element){
        waitForElementOnPage(element);
        scrollElementToMiddle(element);
        waitForElementToBeClickable(element);
        click(element);
    }

    protected void clickWithJavaScriptByXPath(String xpath){
        executeJavaScript("document.evaluate(\""+xpath+"\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click()");
    }

    protected void sendKeysActiveElement(String text)
    {
        Log.info("sending text '"+text+"' to active element ", getClass());
        getBrowser().switchTo().activeElement().clear();
        getBrowser().switchTo().activeElement().sendKeys(text);
    }

    protected String getClipboardContents()
    {
      Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
      Transferable contents = clipboard.getContents(null);
      if (contents == null)
        return null;

      try {
        return (String) contents.getTransferData(DataFlavor.stringFlavor);
      } catch (Exception e) {
        return null;
      }
    }
}

