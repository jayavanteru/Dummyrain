package interaction.pageObjects;

public interface PageLoadItemPage extends PageLoad {

    void cancel();
}
