package interaction.pageObjects;

import logs.Log;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestPagesList {
    private static HashMap<String, Integer> pages = new HashMap<>();
    private static HashMap<String, Integer> methods = new HashMap<>();
    public static String testName;
    public static String previous;

    public static void resetPagesList() {
        pages = new HashMap<>();
        methods = new HashMap<>();
        previous = null;
    }

    public static void outputPages() throws IOException {
        saveFile(pages, "pages");
        saveFile(methods, "methods");
    }

    private static void saveFile(HashMap<String, Integer> map, String name) throws IOException {
        final FileWriter fileWriter = new FileWriter(testName + "_" + name + ".csv", true);
        for (String key : map.keySet()) {
            fileWriter.append(key)
                    .append(",")
                    .append(key.substring(key.lastIndexOf(".")+1))
                    .append(",")
                    .append(map.get(key).toString())
                    .append("\n");
        }
        fileWriter.close();
    }

    public static void addClass(String name) {
        String method = getMethodInfo(name);
        if (!method.equals(previous) && !method.isEmpty()) {
            previous = method;
            add(pages, name);
            add(methods, method);
        }
    }

    private static void add(HashMap<String, Integer> map, String key) {
        if (!map.containsKey(key)) {
            map.put(key, 0);
        }
        map.put(key, map.get(key) + 1);
    }

    private static String getMethodInfo(String name) {
        final StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StringBuilder methods = new StringBuilder();
        for (StackTraceElement ste : stackTrace) {
            if (ste.getClassName().equals(name)) {
                methods = new StringBuilder();
                methods.append(name)
                        .append(".")
                        .append(ste.getMethodName());
            }
        }
        return methods.toString();
    }

}
