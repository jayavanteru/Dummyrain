package interaction.pageObjects;

import configuration.PropertyReader;
import logs.Log;
import testHelp.DataGenerator;
import testHelp.SeleniumHelpers;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

public abstract class Page {

    protected DataGenerator data;
    protected SeleniumHelpers helper;
    protected PropertyReader properties = PropertyReader.instance();
    private static HashMap<String, Object> instances = new HashMap<>();

    public Page() {
        helper = new SeleniumHelpers();
        data = helper.data;
    }

    protected static <T> T initialize(Class clazz, Object... params) {
        String id = Thread.currentThread().getName() + clazz.getName();
        Class[] paramClasses = new Class[params.length];
        for (int i = 0; i < params.length; ++i) {
            paramClasses[i] = params[i].getClass();
        }
        if (!instances.containsKey(id)) {
            try {
                instances.put(id, clazz.getConstructor(paramClasses).newInstance(params));
            } catch (InstantiationException | IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                StringBuilder debugParam = new StringBuilder();
                for (Object param : params) debugParam.append(" ").append(param);
                Log.error("failed to create page object " + clazz.getName() + " using parameters" + debugParam.toString(), clazz);
                Log.error(e, clazz);
            }
        }
        return (T)instances.get(id);
    }

    public static void resetAllPageObjects() {
        instances = new HashMap<>();
    }

    public String getData(String key) {
        return properties.getProperty(key);
    }
    
    public boolean hasData(String key) {
        return properties.hasProperty(key);
    }

    protected void addData(String key, String value) {
        properties.setProperty(key, value);
    }

    protected void addRandomString(String key, int stringLength) {
        properties.setProperty(key, data.generateString(stringLength));
    }


}
