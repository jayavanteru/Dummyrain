package interaction.pageObjects;

public class PageElement
{
  public static final String DROPDOWN_ELEMENT_LABEL = "DROPDOWN_ELEMENT_LABEL";
  public static final String DROPDOWN_ELEMENT_ID = "DROPDOWN_ELEMENT_ID";
}
