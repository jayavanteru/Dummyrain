package interaction.pageObjects;

public interface PageLoadSearchPage extends PageLoad{

    void addItem();

    void editItem();
}