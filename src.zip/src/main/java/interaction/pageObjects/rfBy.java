package interaction.pageObjects;
import org.openqa.selenium.By;

public abstract class rfBy extends By {

    public static By datatest(String dataTest) {
        return new ByCssSelector("[data-test='"+dataTest+"']");
    }

    public static By datatestContains(String dataTest) {
        return new ByCssSelector("[data-test*='"+dataTest+"']");
    }

    public static By title(String title) {
        return new ByCssSelector("[title='"+title+"']");
    }

    public static By placeholder(String placeholder) {
        return new ByCssSelector("[placeholder='"+placeholder+"']");
    }

    public static By value(String value) {
        return new ByCssSelector("[value='"+value+"']");
    }

    public static By text(String text) {
        return new ByXPath(".//*[text()='"+text+"']");
    }

    public static By attribute(String attribute, String value){
        return new ByCssSelector("["+attribute+"='"+value+"']");
    }

    public static By attributeContains(String attribute, String value){
        return new ByCssSelector("["+attribute+"*='"+value+"']");
    }

    public static By textContains(String text){
        return new ByXPath("//*[contains(text(), '"+text+"')]");
    }
}

