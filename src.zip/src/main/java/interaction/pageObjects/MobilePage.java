package interaction.pageObjects;

import interaction.DriverManager;
import interaction.api.ApiConfig;
import interaction.mobile.MobileUI;
import interaction.webUI.WebUI;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidTouchAction;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.offset.PointOption;
import org.apache.poi.ss.formula.functions.T;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import testHelp.Utils;

public class MobilePage extends WebPage {

    private WebDriver browser;

    @Override
    protected WebDriver getBrowser() {
        if (browser == null) {
            final MobileUI webDriver = DriverManager.getMobileDriver(Thread.currentThread().getName());
            browser = webDriver.getDriver();
//            screenShots = webDriver.getScreenShotDriver();
        }
        return browser;
    }

    @Override
    public void justWait() { }

    public void mobileWait() {
        Utils.sleep(1500, "for animated transitions");
    }

    @Override
    public void waitForPageLoad() { }

    @Override
    protected void sendKeys(By identifier, String keys) {
        click(identifier);
        super.sendKeys(identifier, keys);
    }

    @Override
    protected void sendKeys(WebElement identifier, String keys) {
        click(identifier);
        super.sendKeys(identifier, keys);
    }

    @Override
    protected void quit() {
        getBrowser().quit();
    }

    protected void keyboardSearch() {
        KeyEvent keyEvent = new KeyEvent();
        ((AndroidDriver) browser).pressKey(keyEvent.withKey(AndroidKey.ENTER));
    }

}
