package interaction.webUI;

import configuration.PropertyReader;
import interaction.UIInteraction;
import interaction.screenshots.ScreenShotDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import logs.Log;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeDriverService;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import testHelp.Utils;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class WebUI extends UIInteraction {

    private WebDriver browser;
    private PropertyReader properties;
    NetworkMonitor network;
    private ScreenShotDriver screenShots;

    public WebUI(NetworkMonitor proxy) {
        network = proxy;
        properties = PropertyReader.instance();
        screenShots = new ScreenShotDriver();
        String name = Thread.currentThread().getName();
        Log.info("starting browser under thread name " + name, getClass());

        startUpBrowser();
    }

    public WebDriver getBrowser() {
        return browser;
    }

    public ScreenShotDriver getScreenShotDriver() {
        return screenShots;
    }

    public void setBrowser(WebDriver driver) {
        browser = driver;
    }

    public void toMobileSize() {
        setBrowserSize(360, 640);
        //the bottom scroll bar gets in the way, just disabling it for mobile testing
        ((JavascriptExecutor)browser).executeScript("document.body.style.overflowX = 'hidden';");
    }

    public void refresh() {
        browser.navigate().refresh();
    }

    public void takeScreenShot(String filename) {
        File screenshot = ((TakesScreenshot) browser).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(screenshot, new File(filename));
        } catch (IOException e) {
            Log.error("failed to copy screenshot file, in WebUI", getClass().getName());
            Log.error(e.getMessage(), getClass().getName());
        }
    }

    public void restartBrowser(Set<Cookie> cookies, String url) {
        Log.info("restarting the browser", getClass().getName());
        startUpBrowser();
        browser.navigate().to(url);
        browser.manage().deleteAllCookies();
        for (Cookie cookie : cookies) {
            browser.manage().addCookie(cookie);
        }
        Log.info("going to the URL where the test starts "+url, getClass().getName());
        browser.navigate().to(url);
        Utils.sleep(1000);
        browser.navigate().refresh();
        Utils.sleep(500);
    }

    private void setBrowserSize(int width, int height) {
        Log.info("Setting browser size to " + width + " X " + height, getClass().getName());
        browser.manage().window().setSize(new Dimension(width, height));
    }

    private RemoteWebDriver getRemoteDriver() throws MalformedURLException {
        RemoteWebDriver driver;
        // Example test environment. NOTE: Gridlastic auto scaling requires all
        // these 3 environment variables in each request.
        // see test environments for capabilities to use https://www.gridlastic.com/test-environments.html
        String platform_name = properties.getProperty("platformName");
        String browser_name = properties.getProperty("browserName").toLowerCase();
        String browser_version = properties.getProperty(browser_name.replace(" ", "") + "Version");

        // optional video recording
        String record_video = properties.getProperty("recordVideo");

        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("seleniumProtocol", "WebDriver");
        capabilities.setCapability("javascriptEnabled", properties.getProperty("javascriptEnabled"));
        if (platform_name.equalsIgnoreCase("win7")) {
            capabilities.setPlatform(Platform.VISTA);
        }
        if (platform_name.equalsIgnoreCase("win8")) {
            capabilities.setPlatform(Platform.WIN8);
        }
        if (platform_name.equalsIgnoreCase("win8_1")) {
            capabilities.setPlatform(Platform.WIN8_1);
        }
        if (platform_name.equalsIgnoreCase("win10")) {
            capabilities.setPlatform(Platform.WIN10);
        }
        if (platform_name.equalsIgnoreCase("linux")) {
            capabilities.setPlatform(Platform.LINUX);
        }
        capabilities.setBrowserName(browser_name);
        capabilities.setVersion(browser_version);

        // video record
        if (record_video.equalsIgnoreCase("True")) {
            capabilities.setCapability("video", "True"); // NOTE: "True" is a case sensitive string, not boolean.
        } else {
            capabilities.setCapability("video", "False"); // NOTE: "False" is a case sensitive string, not boolean.
        }

        //Chrome specifics
        if (browser_name.equalsIgnoreCase("chrome")){
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--disable-browser-side-navigation");
            options.addArguments("disable-infobars"); // starting from Chrome 57 the info bar displays with "Chrome is being controlled by automated test software."
            // On Linux start-maximized does not expand browser window to max screen size. Always set a window size and window position.
            if (platform_name.equalsIgnoreCase("linux")) {
                options.addArguments(Arrays.asList("--window-position=0,0"));
                options.addArguments(Arrays.asList("--window-size=1920,1080"));
            } else {
                options.addArguments(Arrays.asList("--start-maximized"));
            }
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
        }

        //Firefox specifics
        if (browser_name.equalsIgnoreCase("firefox")){
            // If you are using selenium 3 and test Firefox versions below version 48
            if(Integer.parseInt(browser_version)<48){
                capabilities.setCapability("marionette", false);
            }
        }

        Log.info("connecting to gridlastic..", getClass().getName());
        URL url = new URL(properties.getProperty("remoteUrl"));
        driver = new RemoteWebDriver(url ,capabilities);
        Log.info("successfully connected to gridlastic!", getClass().getName());
        // On LINUX/FIREFOX the "driver.manage().window().maximize()" option does not expand browser window to max screen size. Always set a window size.
        if (platform_name.equalsIgnoreCase("linux") && browser_name.equalsIgnoreCase("firefox")) {
            driver.manage().window().setSize(new Dimension(1920, 1080));
        }

        if (record_video.equalsIgnoreCase("True")) {
            String gridlasticVideoUrl = properties.getProperty("gridlasticVideoUrl") + driver.getSessionId();
            Log.info("Test Video: " + gridlasticVideoUrl, getClass().getName());
        }

        return driver;
    }

    private void startUpBrowser() {
        if (properties.getProperty("runRemote").equalsIgnoreCase("true")) {
            try {
                browser = getRemoteDriver();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        } else {
            Proxy seleniumProxy = null;
            if (network != null) seleniumProxy = network.createSeleniumProxy();
            try {
                switch (properties.getProperty("browserName").toLowerCase()) {
                    case "chrome":
                        //WebDriverManager.chromedriver().version("83.0.4103.39").setup();
                        WebDriverManager.chromedriver().setup();
                        ChromeOptions options = new ChromeOptions();
                        options.setCapability(CapabilityType.PROXY, seleniumProxy);
                        options.addArguments("start-maximized"); // https://stackoverflow.com/a/26283818/1689770
                        options.addArguments("enable-automation"); // https://stackoverflow.com/a/43840128/1689770
//                        options.addArguments("--headless"); // only if you are ACTUALLY running headless
                        options.addArguments("--no-sandbox"); //https://stackoverflow.com/a/50725918/1689770
//                        options.addArguments("--disable-infobars"); //https://stackoverflow.com/a/43840128/1689770
                        options.addArguments("--disable-dev-shm-usage"); //https://stackoverflow.com/a/50725918/1689770
                        options.addArguments("--disable-browser-side-navigation"); //https://stackoverflow.com/a/49123152/1689770
                        options.addArguments("--disable-gpu"); //https://stackoverflow.com/questions/51959986/how-to-solve-selenium-chromedriver-timed-out-receiving-message-from-renderer-exc
                        options.addArguments("--ignore-certificate-errors");

                        Map<String, Object> prefs = new HashMap<>();
                        if (properties.getProperty("lang").equalsIgnoreCase("spanish"))
                            prefs.put("intl.accept_languages", "es,es_MX,en,en_US");
                        options.setExperimentalOption("prefs", prefs);
//                        options.addArguments("-lang=sl");

                        browser = new ChromeDriver(options);
                        break;
                    case "firefox":
                        WebDriverManager.firefoxdriver().setup();
//                        WebDriverManager.firefoxdriver().driverVersion("").setup();
                        FirefoxOptions ffoptions = new FirefoxOptions();
                        ffoptions.setCapability(CapabilityType.PROXY, seleniumProxy);
                        ffoptions.addPreference("browser.download.manager.showWhenStarting", false);
                        ffoptions.addPreference("browser.helperApps.alwaysAsk.force", false);
                        ffoptions.addPreference("browser.helperApps.neverAsk.saveToDisk", "text/xml,text/calendar,text/plain,application/xml,text/vcs,text/ics,text/csv,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,image/jpeg,image/png" );
                        ffoptions.addPreference("browser.download.viewableInternally.enabledTypes", "");
                        ffoptions.addPreference("pdfjs.disabled", true);
                        if (properties.getProperty("lang").equalsIgnoreCase("spanish"))
                            ffoptions.addPreference("intl.accept_languages", "es,es_MX,en,en_US");
                        browser = new FirefoxDriver(ffoptions);
                        break;
                    case "edge":
                        properties.setProperty(EdgeDriverService.EDGE_DRIVER_VERBOSE_LOG_PROPERTY, "true");
                        WebDriverManager.edgedriver().forceDownload().setup();
                        Log.info("edge driver version: " + WebDriverManager.edgedriver().getDownloadedDriverVersion(), getClass());
                        EdgeOptions edgeOptions = new EdgeOptions();
                        edgeOptions.setCapability(CapabilityType.PROXY, seleniumProxy);
                        browser = new EdgeDriver(edgeOptions);
                        break;
                    case "internet explorer":
                        WebDriverManager.iedriver().setup();
                        //get the options
                        InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                        ieOptions.setCapability(CapabilityType.PROXY, seleniumProxy);
                        browser = new InternetExplorerDriver(ieOptions);
                        break;
                    case "safari":
                        //get the options
                        SafariOptions safariOptions = new SafariOptions();
                        safariOptions.setCapability(CapabilityType.PROXY, seleniumProxy);
                        browser = new SafariDriver(safariOptions);
                        break;
    //              case "opera":
    //                  WebDriverManager.operadriver().setup();
    //                  //get the options
    //                  OperaOptions operaOptions = getOptions(new OperaOptions());
    //                  browser = new OperaDriver(operaOptions);
    //                  break;
                    default:
                        browser = null;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                e.printStackTrace();
                throw e;
            }
        }
        //maximize all of it
//        browser.manage().window().setSize(new Dimension(1040, 744));
        browser.manage().window().maximize();
        browser.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    private DesiredCapabilities getCapabilities() {
        String[] options = properties.getProperty("DesiredCapabilitiesProperties").split(",");
        DesiredCapabilities capabilities = new DesiredCapabilities();

        //set the rest of the capabilities
        for (String option : options) {
            String property = properties.getProperty(option);
            if (property != null && !property.isEmpty()) {
                if (property.toLowerCase().equals("false") || property.toLowerCase().equals("true")) {
                    capabilities.setCapability(option, Boolean.parseBoolean(property));
                } else {
                    capabilities.setCapability(option, property);
                }
            }
        }

        return capabilities;
    }

    private String getBrowserVersion() {
        String browser = properties.getProperty("browserName").toLowerCase();
        return properties.getProperty(browser.replace(" ", "") + "Version");
    }
}
