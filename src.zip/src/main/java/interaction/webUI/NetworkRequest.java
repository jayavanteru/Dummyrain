package interaction.webUI;

import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.core.har.HarPostData;

import java.util.HashMap;

public class NetworkRequest {

    private HarEntry requestInfo;

    protected NetworkRequest(HarEntry entry) {
        requestInfo = entry;
    }

    public String getUrl() {
        return requestInfo.getRequest().getUrl();
    }

    public boolean isEndpoint(String apiEndpoint) {
        final String url = getUrl();
        return url.endsWith(apiEndpoint) ||
                url.contains(apiEndpoint + "?");
    }

    public HashMap<String, String> getRequestHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        requestInfo.getRequest().getHeaders()
                .forEach(header -> headers.put(header.getName(), header.getValue()));
        return headers;
    }

    public HashMap<String, String> getResponseHeaders() {
        HashMap<String, String> headers = new HashMap<>();
        requestInfo.getResponse().getHeaders()
                .forEach(header -> headers.put(header.getName(), header.getValue()));
        return headers;
    }

    public String getRequestMethod() {
        return requestInfo.getRequest().getMethod();
    }

    public int getResponseStatusCode() {
        return requestInfo.getResponse().getStatus();
    }

    public String getResponseStatus() {
        return requestInfo.getResponse().getStatusText();
    }

    public String getResponseContent() {
        return requestInfo.getResponse().getContent().getText();
    }

    public String getRequestBody() {
        final HarPostData postData = requestInfo.getRequest().getPostData();
        return postData == null ? null : postData.getText();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(getRequestMethod());
        builder.append(" ");
        builder.append(getUrl());
        builder.append(" ");
        builder.append(getResponseStatus());
        builder.append(" ");
        builder.append(getResponseStatusCode());
        builder.append("\n================================ Request Headers ==================================\n");
        getRequestHeaders().forEach((k,v) -> builder.append(k).append(": ").append(v).append("\n"));
        builder.append("\n================================ Request Body =====================================\n");
        builder.append(getRequestBody());
        builder.append("\n================================ Response Headers =================================\n");
        getResponseHeaders().forEach((k,v) -> builder.append(k).append(": ").append(v).append("\n"));
        builder.append("\n================================ Response Body ====================================\n");
        builder.append(getResponseContent());
        return builder.toString();
    }
}
