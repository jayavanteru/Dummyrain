package interaction.webUI;

import logs.Log;
import testHelp.Utils;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

public class DesktopAuto {

    private Robot robot;

    public DesktopAuto() {
        String name = Thread.currentThread().getName();
        Log.info("starting desktop automation under thread name " + name, getClass());
        try {
            robot = new Robot();
            robot.setAutoWaitForIdle(true);
        } catch (AWTException e) {
            e.printStackTrace();
        }
    }

    public void sendKeys(String keys) {
        Log.info("sending keys to the computer: " + keys, Utils.class);

        for (char key : keys.toCharArray()) {
            List<Integer> keycodes = convertToKeyCode(key);
            keycodes.forEach(robot::keyPress);
            keycodes.forEach(robot::keyRelease);
        }
    }

    public void moveMouseTo(int x, int y) {
        Log.info("moving mouse to x: " + x + " y: " + y, getClass());
        robot.mouseMove(x, y);
    }

    public void quit() {
        //make sure anything that is open is escaped out of
        robot.keyPress(KeyEvent.VK_ESCAPE);
        robot.keyRelease(KeyEvent.VK_ESCAPE);
        robot.keyPress(KeyEvent.VK_ESCAPE);
        robot.keyRelease(KeyEvent.VK_ESCAPE);
        robot = null;
    }

    private List<Integer> convertToKeyCode(char key) {
        ArrayList<Integer> codes = new ArrayList<>();
        switch (key) {
            case ':':
                codes.add(KeyEvent.VK_SHIFT);
                codes.add(KeyEvent.VK_SEMICOLON);
                break;
            case '_':
                codes.add(KeyEvent.VK_SHIFT);
                codes.add(KeyEvent.VK_MINUS);
                break;
            case '\n':
                codes.add(KeyEvent.VK_ENTER);
                break;
            default:
                codes.add(KeyEvent.getExtendedKeyCodeForChar(key));
        }
        return codes;
    }
}
