package interaction.webUI;

import logs.Log;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.proxy.CaptureType;
import org.openqa.selenium.Proxy;
import org.testng.Assert;

public class NetworkMonitor {

    private BrowserMobProxy proxy;

    public NetworkMonitor() {
        proxy = new BrowserMobProxyServer();
        proxy.setTrustAllServers(true);
        proxy.start(0);
        proxy.enableHarCaptureTypes(CaptureType.RESPONSE_CONTENT, CaptureType.REQUEST_CONTENT,
                CaptureType.REQUEST_HEADERS, CaptureType.RESPONSE_HEADERS);
    }

    public BrowserMobProxy getProxy() {
        return proxy;
    }

    public Proxy createSeleniumProxy() {
        Log.info("creating the selenium network proxy", getClass());
        Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
        String hostIp = "127.0.0.1";//Inet4Address.getLocalHost().getHostAddress();
        seleniumProxy.setHttpProxy(hostIp + ":" + proxy.getPort());
        seleniumProxy.setSslProxy(hostIp + ":" + proxy.getPort());
        return seleniumProxy;
    }

    public void stop() {
        try {
            Log.info("Stopping network proxy", getClass());
            proxy.stop();
        } catch (IllegalStateException e) {}
    }

    public NetworkRequest getRequest(String endpoint) {
        final Har har = proxy.getHar();
        Assert.assertNotNull(har, "Network Monitor not running, call startMonitoring() before searching for request");

        Log.info("searching for network call " + endpoint, getClass());
        return proxy.getHar().getLog().getEntries().stream()
                .map(NetworkRequest::new)
                .filter(r -> r.isEndpoint(endpoint))
                .reduce((first, second)-> second)
                .orElse(null);
    }

    public void startMonitoring() {
        Log.info("Starting to monitor the network", getClass());
        proxy.newHar();
    }

    public void stopMonitoring() {
        Log.info("Stopping network monitoring", getClass());
        proxy.endHar();
    }

}

