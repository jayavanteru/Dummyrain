package interaction.gmail;

import com.sun.mail.imap.IMAPBodyPart;
import com.sun.mail.util.BASE64DecoderStream;
import logs.Log;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.io.RandomAccessBuffer;
import org.apache.pdfbox.io.RandomAccessFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.jsoup.Jsoup;

import javax.mail.*;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailMessage {

    private Message message;
    private String body;
    private ArrayList<String> attachments;

    public EmailMessage(Message msg) {
        message = msg;
        attachments = new ArrayList<>();
    }

    public Message getRawMessage() {
        return message;
    }

    public void markEmailAsRead() {
        Log.info("setting email as read", getClass());
        try {
            message.setFlag(Flags.Flag.SEEN, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public void markEmailAsUnread() {
        Log.info("setting email as unread", getClass());
        try {
            message.setFlag(Flags.Flag.SEEN, false);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public void deleteEmail() {
        Log.info("deleting email", getClass());
        try {
            message.setFlag(Flags.Flag.DELETED, true);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    public String getSubject() {
        String subject = null;
        try {
            subject = message.getSubject();
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return subject;
    }

    public String getBody() {
        if (body == null) getTextFromMessage(message);
        return Jsoup.parse(body).text();
    }

    public ArrayList<String> getAttachments() {
        if (body == null) getTextFromMessage(message);
        return attachments;
    }

    public String[] getFrom() {
        String[] from = null;
        try {
            from = getAddressList(message.getFrom());
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return from;
    }

    public String[] getRecipients() {
        String[] recipients = null;
        try {
            recipients = getAddressList(message.getAllRecipients());
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return recipients;
    }

    public String[] getReplyTo() {
        String[] addresses = null;
        try {
            addresses = getAddressList(message.getReplyTo());
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return addresses;
    }

    public Date getSentDate() {
        Date sentDate = null;
        try {
            sentDate = message.getSentDate();
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return sentDate;
    }

    public Date getReceivedDate() {
        Date receivedDate = null;
        try {
            receivedDate = message.getReceivedDate();
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return receivedDate;
    }

    public int getMessageNumber() {
        return message.getMessageNumber();
    }

    public boolean bodyContains(String txt) {
        return getBody().contains(txt);
    }

    public boolean attachmentContains(String txt) {
        return getAttachments().stream().anyMatch(msg -> msg.contains(txt));
    }

    public boolean hasAttachment() {
        boolean attachment = false;
        try {
            attachment = message.isMimeType("multipart/*") &&
                    ((MimeMultipart) message.getContent()).getCount() > 1;
        } catch (MessagingException | IOException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return attachment;
    }

    private void getTextFromMessage(Message message) {
        Log.info("retrieving content for email", getClass());
        ArrayList<String> result = new ArrayList<>();
        try {
            if (message.isMimeType("text/*")) {
                body = message.getContent().toString();
                result = attachments;
            } else if (message.isMimeType("multipart/*")) {
                MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();

                //top level loop to find body and attachments
                int count = mimeMultipart.getCount();
                for (int i = 0; i < count; i++) {
                    BodyPart bodyPart = mimeMultipart.getBodyPart(i);
                    if (bodyPart.getContent() instanceof MimeMultipart) {
                        getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent(), result);
                    } else {
                        result.add(extractText(bodyPart));
                    }

                    if (body == null) {
                        body = result.stream().reduce((a, b) -> a + "\n" + b).orElse("");
                        result = attachments;
                    }
                }
            }
        } catch (IOException | MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
    }

    private ArrayList<String> getTextFromMimeMultipart(MimeMultipart mimeMultipart, ArrayList<String> content)  throws MessagingException, IOException{
        int count = mimeMultipart.getCount();
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
            if (bodyPart.getContent() instanceof MimeMultipart) {
                getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent(), content);
            } else {
                content.add(extractText(bodyPart));
            }
        }
        return content;
    }

    private String extractText(BodyPart bodyPart) throws MessagingException, IOException {
        String text;
        //pdf coming through as plain text
        if (bodyPart.isMimeType("text/plain") && bodyPart.getContentType().contains(".pdf")) {
            File file = new File("attachment.pdf");
            ((IMAPBodyPart) bodyPart).saveFile(file);
            text = pdfAsText(file);
            file.delete();
        }
        else if (bodyPart.isMimeType("text/plain")) {
            text = bodyPart.getContent().toString();
        } else if (bodyPart.isMimeType("text/html")) {
            String html = (String) bodyPart.getContent();
            text = Jsoup.parse(html).text();
        } else if (bodyPart.isMimeType("application/pdf") || bodyPart.isMimeType("application/OCTET-STREAM")) {
            try (PDDocument document = PDDocument.load((BASE64DecoderStream) bodyPart.getContent())) {
                PDFTextStripper stripper = new PDFTextStripper();
                text = stripper.getText(document);
            }
        } else {
            text = bodyPart.getFileName();
            ((IMAPBodyPart) bodyPart).saveFile(text == null ? "emailAttachment.obj" : text);
        }
        return text;
    }

    private String pdfAsText(File file) throws IOException {
        PDFParser parser = new PDFParser(new RandomAccessFile(file,"r"));
        parser.parse();
        COSDocument cosDoc = parser.getDocument();
        PDFTextStripper pdfStripper = new PDFTextStripper();
        PDDocument pdDoc = new PDDocument(cosDoc);
        return pdfStripper.getText(pdDoc);
    }

    private String[] getAddressList(Address[] addresses) {
        String[] addressString = new String[addresses.length];
        //regex pattern to find an email in a string
        Pattern pattern = Pattern.compile(".*?([\\w|\\d|+]+@[\\w|\\d]+\\.\\w+).*");
        for (int i = 0; i < addresses.length; ++i) {
            String address = addresses[i].toString();
            Matcher matcher = pattern.matcher(address);
            matcher.find();
            addressString[i] = matcher.group(1);
        }
        return addressString;
    }
}
