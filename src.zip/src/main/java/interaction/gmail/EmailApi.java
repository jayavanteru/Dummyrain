package interaction.gmail;
import configuration.PropertyReader;
import logs.Log;
import org.joda.time.DateTime;
import testHelp.Utils;

import javax.mail.*;
import javax.mail.internet.MimeMessage;
import java.util.*;

//this is setup to work with gmail
public class EmailApi {

    //enable imap in settings -> https://support.google.com/mail/answer/7126229?hl=en
    //allow less secure apps -> https://myaccount.google.com/lesssecureapps?pli=1
    //disable captcha -> https://accounts.google.com/b/0/DisplayUnlockCaptcha

    private static EmailApi instance;

    private Folder inbox;
    private Folder spam;
    private Store store;
    private Session session;
    private final String email;

    public static EmailApi emailClient() {
        if (instance == null) {
            instance = new EmailApi();
        }
        return instance;
    }

    private EmailApi() {
        PropertyReader reader = PropertyReader.instance();
        email = reader.getProperty("realEmailAddress");
        String password = reader.getProperty("realEmailPassword");
        String host = reader.getProperty("emailImapHost");
        Properties props = new Properties();
        try{
            Log.info("connecting to email account " + email, getClass());
            //set email protocol to IMAP
            props.setProperty("mail.store.protocol", "imaps");
            props.setProperty("mail.host", host);
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.port", "465");
            props.put("mail.smtp.socketFactory.port", "465");
            props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
            props.put("mail.smtp.socketFactory.fallback", "false");

            //set up the session
            session = Session.getDefaultInstance(props,
                    new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(email, password);
                        }
                    });

            store = session.getStore("imaps");
            //Connect to your email account
            store.connect(host, email, password);

            //Get reference to your INBOX
            inbox = store.getFolder("INBOX");
            spam = store.getFolder("[Gmail]/Spam");
            inbox.open(Folder.READ_WRITE);
            spam.open(Folder.READ_WRITE);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        Log.info("email connected", getClass());
    }

    public void close() {
        try {
            inbox.close(true);
            spam.close(true);
            store.close();
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
    }

    public EmailMessage[] getEmails(int from, int to) {
        Message[] messages = null;
        Log.info("Getting emails from " + from + " to " + to, getClass());
        try {
            messages = inbox.getMessages(from, to);
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return convertToEmailMessage(messages);
    }

    public EmailMessage sendEmail(String subject, String toemail, String content) {
        MimeMessage mimeMessage = new MimeMessage(session);
        Log.info("sending email to " + toemail, getClass());
        try {
            mimeMessage.setSubject(subject);
            mimeMessage.addRecipients(Message.RecipientType.TO, toemail);
            mimeMessage.setText(content);
            Transport.send(mimeMessage);

        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }

        Log.info("email sent successfully!", getClass());
        return new EmailMessage(mimeMessage);
    }

    public EmailMessage sendEmail(String subject, String toemail, String content, String contentType) {
        MimeMessage mimeMessage = new MimeMessage(session);
        Log.info("sending email to " + toemail, getClass());
        try {
            mimeMessage.setSubject(subject);
            mimeMessage.addRecipients(Message.RecipientType.TO, toemail);
            mimeMessage.setContent(content, contentType);
            Transport.send(mimeMessage);

        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }

        Log.info("email sent successfully!", getClass());
        return new EmailMessage(mimeMessage);
    }

    public int getEmailCount() {
        int count = 0;
        try {
            count = inbox.getMessageCount() + spam.getMessageCount();
            Log.info("current email count is " + count, getClass());
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return count;
    }

    public int getPastEmailCount() {
        final DateTime past = DateTime.now().minusSeconds(2);
        int emailCount = getEmailCount();
        for (EmailMessage email : getRecentEmails()) {
            if (past.isBefore(new DateTime(email.getReceivedDate()))) --emailCount;
        }

        return emailCount;
    }

    public boolean waitForEmail() {
        final int count = getPastEmailCount();
        Log.info("waiting for new email to arrive", getClass());
        return Utils.waitForTrue(()->getEmailCount() > count, 20);
    }

    public boolean waitForEmail(String subject) {
        final int count = getPastEmailCount();
        Log.info("waiting for new email with subject: " + subject, getClass());
        return Utils.waitForTrue(()->getEmailCount() > count &&
                getMostRecentEmail().getSubject().equals(subject), 60);
    }

    public boolean waitForEmail(String subject, String recipient) {
        final int count = getPastEmailCount();
        Log.info("waiting for new email with subject: " + subject + " and sent to email " + recipient, getClass());
        return Utils.waitForTrue(()->getEmailCount() > count &&
                getMostRecentEmail().getSubject().equals(subject) &&
                Arrays.stream(getMostRecentEmail().getRecipients()).anyMatch(r-> r.equalsIgnoreCase(recipient)), 60);
    }

    public EmailMessage getEmail(String subject) {
        Log.info("Getting email " + subject, getClass());

        //to find the most recent email with that subject we will look at the most recent 15
        EmailMessage[] recentEmails = getRecentEmails(15);
        for (int i = 0; i < recentEmails.length; ++i) {
            if (recentEmails[i].getSubject().equals(subject)) {
                return recentEmails[i];
            }
        }

        Log.warn("could not find email '" + subject + "' in the last 15 emails", getClass());
        return null;
    }

    public EmailMessage[] getRecentEmails() {
        return getRecentEmails(15);
    }

    public EmailMessage getMostRecentEmail() {
        return getRecentEmails(1)[0];
    }

    private EmailMessage[] convertToEmailMessage(Message[] msgs) {
        return Arrays.stream(msgs).map(EmailMessage::new).toArray(EmailMessage[]::new);
    }

    public EmailMessage[] getRecentEmails(int amount) {
        EmailMessage[] em = new EmailMessage[amount];
        List<EmailMessage> messages = new ArrayList<>();
        messages.addAll(Arrays.asList(getMessages(amount, inbox)));
        messages.addAll(Arrays.asList(getMessages(amount, spam)));

        messages.sort(Comparator.comparing(EmailMessage::getReceivedDate).reversed());
        messages.subList(0, amount).toArray(em);
        return em;
    }

    private EmailMessage[] getMessages(int recent, Folder folder) {
        Message[] messages = new Message[0];
        //by subtracting one it will return this many, otherwise it is one too many
        Log.info("Getting the most recent " +recent-- + " emails", getClass());
        try {
            int count = folder.getMessageCount();
            int startCount = count > recent ? count - recent : count;
            if (count > 0) messages = folder.getMessages(startCount, count);
        } catch (MessagingException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return convertToEmailMessage(messages);
    }
}