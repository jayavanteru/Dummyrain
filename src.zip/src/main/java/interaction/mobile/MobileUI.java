package interaction.mobile;

import configuration.PropertyReader;
import interaction.UIInteraction;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import logs.Log;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class MobileUI extends UIInteraction {

    private MobileDriver driver;
    private PropertyReader reader = PropertyReader.instance();

    public MobileUI(){
        String driverType = reader.getProperty("mobileDriverType");
        URL appiumUrl = null;

        try {
            appiumUrl = new URL("http://127.0.0.1:4723/wd/hub");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
            switch (driverType) {
                case "ANDROID_LEADS":
                    driver = new AndroidDriver(appiumUrl, getAndroidLeadsCapabilities());

                    break;
                case "ANDROID_SETTINGS":
                    driver = new AndroidDriver(appiumUrl, getAndroidSettingsCapabilities());
                    break;
                case "IOS_LEADS":
                    driver = new IOSDriver(appiumUrl, getIosLeadsCapabilities());
                    break;
                case "IOS_SETTINGS":
                    driver = new IOSDriver(appiumUrl, getIosSettingsCapabilities());
                    break;
                case "IOS_HYPERION":
                    driver = new IOSDriver(appiumUrl, getIosHyperionCapabilities());
                    break;
                case "IOS_AEGIS":
                    driver = new IOSDriver(appiumUrl, getIosAegisCapabilities());
                    break;
                case "ANDROID_AEGIS":
                    driver = new AndroidDriver(appiumUrl, getAndroidAegisCapabilities());
                    break;
                default:
                    Log.error("The app did not set the App Type correctly " + driverType + " is an invalid mobile type", getClass().getName());
            }
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    public MobileDriver getDriver() {
        return driver;
    }

    private DesiredCapabilities getAndroidLeadsCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
//        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("deviceName", "Nexus 5 API 25");
        capabilities.setCapability("platformName", "Android");
//        capabilities.setCapability("VERSION", "8");
        capabilities.setCapability("appPackage", "com.rainfocus.leads");
        capabilities.setCapability("appActivity", "com.rainfocus.leads.MainActivity");
        Log.info("loading app from: " + reader.getProperty("ANDROID_LEADS"), getClass());
        capabilities.setCapability("app", reader.getProperty("ANDROID_LEADS"));

        return capabilities;
    }

    private DesiredCapabilities getAndroidAegisCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
//        capabilities.setCapability("automationName", "UiAutomator2");
        capabilities.setCapability("deviceName", "Nexus 5 API 25");
        capabilities.setCapability("platformName", "Android");
//        capabilities.setCapability("VERSION", "8");
        capabilities.setCapability("appPackage", "com.aegis");
        capabilities.setCapability("appActivity", "com.aegis.MainActivity");
        Log.info("loading app from: " + reader.getProperty("ANDROID_LEADS"), getClass());
        capabilities.setCapability("app", reader.getProperty("ANDROID_AEGIS"));

        return capabilities;
    }

    private DesiredCapabilities getIosAegisCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", "iPhone 11");
        capabilities.setCapability("platformName", "iOS");
        capabilities.setCapability("platformVersion", "13.3");
        capabilities.setCapability("automationName", "XCUITest");
        Log.info("loading app from: " + reader.getProperty("IOS_AEGIS"), getClass());
        capabilities.setCapability("app", reader.getProperty("IOS_AEGIS"));

        return capabilities;
    }

    private DesiredCapabilities getIosHyperionCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("deviceName", reader.getProperty("iosDevice"));
        capabilities.setCapability("platformName", "iOS");
        capabilities.setCapability("platformVersion", reader.getProperty("iosVersion"));
//        capabilities.setCapability("automationName", "XCUITest");
        Log.info("loading app from: " + reader.getProperty("IOS_HYPERION"), getClass());
        capabilities.setCapability("app", reader.getProperty("IOS_HYPERION"));

        return capabilities;
    }

    private DesiredCapabilities getIosLeadsCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        return capabilities;
    }

    private DesiredCapabilities getIosSettingsCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        return capabilities;
    }

    private DesiredCapabilities getAndroidSettingsCapabilities() {
        DesiredCapabilities capabilities = new DesiredCapabilities();
        return capabilities;
    }
}
