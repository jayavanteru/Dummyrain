package interaction;

import configuration.PropertyReader;
import interaction.mobile.MobileUI;
import interaction.pageObjects.Page;
import interaction.webUI.DesktopAuto;
import interaction.webUI.NetworkMonitor;
import interaction.webUI.WebUI;
import logs.Log;
import org.testng.Assert;

import java.util.HashMap;

public class DriverManager {

    private static HashMap<String, DriverManager> drivers = new HashMap<>();
    private WebUI webUI;
    private MobileUI mobileUI;
    private NetworkMonitor networkMonitor;
    private DesktopAuto desktopAuto;

    public static DriverManager getDriverManager(String threadName) {
        if (!drivers.containsKey(threadName)) {
            drivers.put(threadName, new DriverManager());
        }
        return drivers.get(threadName);
    }

    public static DesktopAuto getDesktopDriver(String threadName) {
        return getDriverManager(threadName).getDesktopAuto();
    }

    public static WebUI getWebDriver(String threadName) {
        return getDriverManager(threadName).getWebUI();
    }

    public static MobileUI getMobileDriver(String threadName) {
        return getDriverManager(threadName).getMobileUI();
    }

    public static boolean isWebDriverCreatedForThread(String threadName) {
        return drivers.containsKey(threadName) && drivers.get(threadName).webUI != null;
    }

    public static boolean isMobileDriverCreatedForThread(String threadName) {
        return drivers.containsKey(threadName) && drivers.get(threadName).mobileUI != null;
    }

    public static boolean isNetworkMonitorCreatedForThread(String threadName) {
        return drivers.containsKey(threadName) && drivers.get(threadName).networkMonitor != null;
    }

    public static void deleteDrivers(String threadName) {
        if (drivers.containsKey(threadName)) {
            drivers.remove(threadName);
            Page.resetAllPageObjects();
        }
    }

    public static void resetButton() {
        Log.info("Reset. page objects and web drivers will be created new now", WebUI.class);
        drivers = new HashMap<>();
        Page.resetAllPageObjects();
    }

    public void quit() {
        if (desktopAuto != null) desktopAuto.quit();
        if (webUI != null) webUI.getBrowser().quit();
        if (networkMonitor != null) networkMonitor.stop();
    }

    public DesktopAuto getDesktopAuto() {
        if (desktopAuto == null) initializeDesktop();
//        Assert.assertNotNull(desktopAuto, "DesktopAuto Robot driver was not initialized. Add 'PropertyReader.instance().setProperty(\"enableDesktopAutomation\", true);' to the very beginning of the test");
        return desktopAuto;
    }

    public WebUI getWebUI() {
        if (webUI == null) {
//            initializeDesktop();
            initializeNetworkMonitor();
            webUI = new WebUI(networkMonitor);
        }
        return webUI;
    }

    public MobileUI getMobileUI() {
        if (mobileUI == null) {
            mobileUI = new MobileUI();
        }
        return mobileUI;
    }

    public NetworkMonitor getNetworkMonitor() {
        Assert.assertNotNull(networkMonitor, "Network Monitor driver was not initialized. Add 'PropertyReader.instance().setProperty(\"enableNetworkLogging\", true);' to the very beginning of the test");
        return networkMonitor;
    }

    private void initializeDesktop() {
        desktopAuto = new DesktopAuto();
    }

    private void initializeNetworkMonitor() {
        if (Boolean.parseBoolean(PropertyReader.instance().getProperty("enableNetworkLogging"))) {
            networkMonitor = new NetworkMonitor();
        }
    }
}
