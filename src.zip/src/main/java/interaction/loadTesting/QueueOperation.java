package interaction.loadTesting;

import testHelp.Utils;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.function.Consumer;

public class QueueOperation<T> extends LoadQueue<T>{

    private Consumer<T> operation;

    public QueueOperation(Consumer<T> func) {
        operation = func;
        queue = new ArrayBlockingQueue<>(500);
        startThread();
    }

    public void add(T item) {
        queue.offer(item);
    }

    @Override
    protected void run() {
        while (!isDone() || !queue.isEmpty()) {
            if (queue.isEmpty()) {
                Utils.sleep(200);
            } else {
                operation.accept(queue.poll());
            }
        }
    }
}
