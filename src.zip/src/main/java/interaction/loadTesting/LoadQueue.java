package interaction.loadTesting;

import java.util.ArrayList;
import java.util.Queue;

public abstract class LoadQueue<T> {

    protected Queue<T> queue;
    private static boolean done = false;
    private static Object doneLock = new Object();
    protected static ArrayList<Thread> ts = new ArrayList<>();
    protected Thread t;

    public void startThread() {
        t = new Thread(this::run);
        t.start();
        ts.add(t);
    }

    public static void join() {
        ts.forEach(t-> {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
    }

    abstract protected void run();

    protected boolean isDone() {
        return done;
    }

    public static void finish() {
        synchronized (doneLock) {
            done = true;
        }
    }
}
