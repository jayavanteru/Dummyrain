package interaction.loadTesting;

import interaction.api.ApiConfig;
import org.json.JSONObject;

import java.util.concurrent.Callable;
import java.util.function.Predicate;

public class ApiTimer {

    private final long milliseconds;
    private final int responseCode;
    public final JSONObject response;
    public final JSONObject body;
    public final String url;
    public final Predicate test;
    private final boolean passed;

    //only necessary things are url, milliseconds and passed
    public ApiTimer(ApiTimer timer, boolean barebones) {
        this.url = timer.url;
        this.milliseconds = timer.milliseconds;
        this.passed = timer.passed;
        if (barebones) {
            this.responseCode = -1;
            this.response = null;
            this.body = null;
            this.test = null;
        } else {
            this.responseCode = timer.responseCode;
            this.response = timer.response;
            this.body = timer.body;
            this.test = timer.test;
        }
    }

    public ApiTimer(Callable<ApiConfig> func, Predicate eval, int expectedResponseCode) {
        test = eval;
        Timer timer = new Timer();
        timer.start();
        ApiConfig config = null;
        try {
            config = func.call();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (config != null) {
                response = config.getResponse();
                responseCode = config.getBodyResponseCode();
                body = config.getBody();
                url = config.getUrl();
            }
            else {
                response = null;
                responseCode = -1;
                body = null;
                url = null;
            }
        }
        milliseconds = timer.getMilliseconds();
        passed = responseCode == expectedResponseCode && test.test(response);
    }

    public long getMilliseconds() {
        return milliseconds;
    }

    public boolean greaterThan(ApiTimer b) {
        return getMilliseconds() > b.getMilliseconds();
    }

    public boolean pass() {
        return passed;
    }
}
