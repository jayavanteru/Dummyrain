package interaction.loadTesting;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.Callable;

public class BuildReport {

    private HashMap<String, ApiTimerCollection> apiTimers;
    private int rows;
    private Callable<Integer> threads;
    private final Timer timer;
    public String graphReportFileName = "graphData.csv";

    public BuildReport(HashMap<String, ApiTimerCollection> timedCalls, Timer timer) {
        apiTimers = timedCalls;
        this.timer = timer;
    }

    public void setThreadCountCall(Callable<Integer> threadCall) {
        threads = threadCall;
    }

    public void printGraphs() {
        rows = 0;
        try {
            System.out.println(String.format("\t%d %s\t%d %s\t%d %s %n%s",
                    threads.call(), "threads",
                    getCallsPerSecond(), "calls per second",
                    timer.getSecond(),"seconds",
                    separate()));
            rows += 2;
        } catch (Exception e) {
            e.printStackTrace();
        }
        synchronized (apiTimers) {
            for (String key : apiTimers.keySet()) {
                String row = String.format("%-75s", key);

                int avg = Math.toIntExact(apiTimers.get(key).getAverage());
                int currentAvg = Math.toIntExact(apiTimers.get(key).getRecentAverage());
                int count = apiTimers.get(key).getCount();
                int persec = apiTimers.get(key).getRecentCount();
                int failures = apiTimers.get(key).getFailureCount();
                int slowest = Math.toIntExact(apiTimers.get(key).getMax());
                int fastest = Math.toIntExact(apiTimers.get(key).getMin());

                System.out.println(row + format(fastest, slowest, count, persec, failures, avg, currentAvg));
                rows += 4;
            }
        }
    }

    public void printFullReport() {
        synchronized (apiTimers) {
            final ArrayList<Thread> threads = new ArrayList<>();
            //add all the file writing threads
            threads.add(new Thread(this::makeGraphFile));
            apiTimers.keySet().forEach(k -> threads.add(new Thread(()->this.makeTextFile(k))));

            //start all threads
            threads.forEach(Thread::start);

            //wait for threads to be done
            for (Thread t : threads) {
                try {
                    t.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void erase() {
        for (int i = 0; i < rows; ++ i) {
            System.out.print(String.format("\033[%dA", 0)); // Move up
            System.out.print("\033[2K"); // Erase line content
        }
    }

    private  void makeTextFile(String key) {
        ArrayList<String> errors = new ArrayList<>();
        File file = new File(key.replace("/", "_") + ".txt");

        try (FileWriter fileWriter = new FileWriter(file)) {
            file.createNewFile();

            ArrayList<Long> avgs = apiTimers.get(key).getAverages();
            ArrayList<Integer> Allfailures = apiTimers.get(key).getFailures();
            ArrayList<Integer> counts = apiTimers.get(key).getCounts();
            ArrayList<Long> fastests = apiTimers.get(key).getMins();
            ArrayList<Long> slowests = apiTimers.get(key).getMaxs();
            errors.addAll(apiTimers.get(key).getFailureResponses());

            for (int i = 0; i < avgs.size(); i++) {
                int avg = Math.toIntExact(avgs.get(i));
                int fastest = Math.toIntExact(fastests.get(i));
                int slowest = Math.toIntExact(slowests.get(i));
                int failures = Allfailures.get(i);
                int count = counts.get(i);

                fileWriter.append(String.valueOf(i))
                        .append("\t")
                        .append(formatFile(avg, fastest, slowest, count, failures))
                        .append("\n");
            }

            //write out all the errors
            fileWriter.append("\n\n\nErrors:\n\n");
            for (String error : errors) {
                fileWriter.append(error).append("\n\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void makeGraphFile() {
        Set<String> keys = apiTimers.keySet();
        File file = new File(graphReportFileName);
        //create hash map for averages and populate it
        final HashMap<String,ArrayList<Long>> averages = new HashMap<>();
        apiTimers.forEach((k,v)->averages.put(k,v.getAverages()));

        //write the file
        try(FileWriter fileBody = new FileWriter(file)) {
            file.createNewFile();

            //header
            for (String key : keys) {
                fileBody.append(key).append(",");
            }

            //body
            int max = timer.getSecond();
            for (int i = 0; i < max; ++i) {
                fileBody.append("\n");
                for (String key : keys) {
                    long cell = apiTimers.get(key).getAverages().get(i);
                    fileBody.append(String.valueOf(cell)).append(",");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int getCallsPerSecond() {
        ArrayList<Integer> totalCounts = new ArrayList<>();
        synchronized (apiTimers) {
            apiTimers.forEach((k,v)->totalCounts.addAll(v.getCounts()));
        }

        return totalCounts.stream()
                .reduce((a, b) -> a + b)
                .map(integer -> integer / timer.getSecond())
                .orElse(0);
    }

    private String formatFile(int avg, int fastest, int slowest, int total, int failures) {
        int amount = ((avg) / 100) + 1;
        String graph = String.format("|%-" + amount + "s|", '=').replace(" ", "=");
        String numbers = String.format("avg: %d * fastest: %d * slowest: %d * total: %d * failures: %d", avg, fastest, slowest, total, failures);
        return String.format("%-40s %n \t %s",numbers, graph);
    }

    private String format(int fastest, int slowest, int total, int perSec, int failures, int avg, int current) {
        int amount = ((avg) / 100) + 1;
        int now = ((current) / 100) + 1;
        String graph = String.format("|%-" + amount + "s|", '=').replace(" ", "=");
        String graphCurrent = String.format("|%-" + now + "s|", '=').replace(" ", "=");
        String numbers = String.format("fastest: %d * slowest: %d * total: %d * per sec: %d * failures: %d", fastest, slowest, total, perSec, failures);
        return String.format("%-40s %n \taverage\t %s\t%s %n\tcurrent\t %s\t%s %n%s",numbers, graph, avg, graphCurrent, current, separate());
    }

    private String separate() {
        return String.format("%-160s", "-").replace(" ", "-");
    }
}
