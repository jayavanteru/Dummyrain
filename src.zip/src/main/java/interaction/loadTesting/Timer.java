package interaction.loadTesting;

public class Timer {

    private long clock;

    public void start() {
        clock = System.currentTimeMillis();
    }

    public int getSecond() {
        return (int) ((System.currentTimeMillis() - clock)/1000);
    }

    public long getMilliseconds() {
        return System.currentTimeMillis() - clock;
    }
}
