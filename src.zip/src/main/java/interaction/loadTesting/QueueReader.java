package interaction.loadTesting;

import testHelp.Utils;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.function.Supplier;

public class QueueReader<T> extends LoadQueue<T>{

    private Supplier<T> operation;
    private final int size = 10;

    public QueueReader(Supplier<T> func) {
        operation = func;
        queue = new ArrayBlockingQueue<>(size);
        startThread();
    }

    public T get() {
        return Utils.waitForTrue(() -> queue.size() > 0) ? queue.poll() : null;
    }

    @Override
    protected void run() {
        while (!isDone()) {
            if (queue.size() < size) {
                queue.add(operation.get());
            } else {
                Utils.sleep(200);
            }
        }
    }
}
