package interaction.loadTesting;

import interaction.api.Api;
import interaction.api.ApiConfig;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.Callable;
import java.util.function.Predicate;

public class ApiRunner {

    private static Api api;
    private HashMap<String, ApiTimerCollection> perEndpoint;
    private final Timer timer;
    private static HashSet<String> runOnce;

    public ApiRunner(HashMap<String, ApiTimerCollection> perEndpoint, Timer timer) {
        this.perEndpoint = perEndpoint;
        this.timer = timer;
        if (api == null) {
            api = new Api();
            runOnce = new HashSet<>();
        }
    }

    public JSONObject get(final String url, Predicate test, int expectedResponseCode) {
        return makeCall(()->api.get(new ApiConfig(url)), url, test, expectedResponseCode);
    }

    public JSONObject post(final String url, Predicate test, int expectedResponseCode) {
        return makeCall(()->api.post(new ApiConfig(url)), url, test, expectedResponseCode);
    }

    public JSONObject post(final String url, final JSONObject body, Predicate test, int expectedResponseCode) {
        ApiConfig config = new ApiConfig(url, body);
        config.setContentType("application/json");
        JSONObject response = makeCall(() -> api.post(config), url, test, expectedResponseCode);
        return response;
    }

    public JSONObject postAsUrl(final String url, final JSONObject body, Predicate test, int expectedResponseCode) {
        ApiConfig config = new ApiConfig(url, body);
        config.setUrlParams(true);
        config.setContentType("application/json");
        JSONObject response = makeCall(() -> api.post(config), url, test, expectedResponseCode);
        return response;
    }

    public JSONObject postAsForm(final String url, final JSONObject body, Predicate test, int expectedResponseCode) {
        ApiConfig config = new ApiConfig(url, body);
        config.setForm(true);
        config.setContentType("application/x-www-form-urlencoded");
        JSONObject response = makeCall(() -> api.post(config), url, test, expectedResponseCode);
        return response;
    }

    private JSONObject makeCall(Callable apiCall, String url, Predicate test, int expectedResponseCode) {
        ApiTimer timer = new ApiTimer(apiCall, test, expectedResponseCode);
        url = url.split("\\?")[0];

        synchronized (perEndpoint) {
            if (!perEndpoint.containsKey(url)) {
                perEndpoint.put(url, new ApiTimerCollection(this.timer));
            }
            perEndpoint.get(url).addTimer(timer);
        }
        return timer.response;
    }

    //only run once
    public synchronized void getOnce(final String url, Predicate test, int expectedResponseCode) {
        if (runOnce.add(url)) {
            makeCall(() -> api.get(new ApiConfig(url)), url, test, expectedResponseCode);
        }
    }

    public synchronized void postOnce(final String url, Predicate test, int expectedResponseCode) {
        if (runOnce.add(url)) {
            makeCall(() -> api.post(new ApiConfig(url)), url, test, expectedResponseCode);
        }
    }

    public synchronized void postOnce(final String url, final JSONObject body, Predicate test, int expectedResponseCode) {
        if (runOnce.add(url)) {
            ApiConfig config = new ApiConfig(url, body);
            config.setContentType("application/json");
            makeCall(() -> api.post(config), url, test, expectedResponseCode);
        }
    }

    public synchronized void postAsUrlOnce(final String url, final JSONObject body, Predicate test, int expectedResponseCode) {
        if (runOnce.add(url)) {
            ApiConfig config = new ApiConfig(url, body);
            config.setUrlParams(true);
            config.setContentType("application/json");
            makeCall(() -> api.post(config), url, test, expectedResponseCode);
        }
    }
}
