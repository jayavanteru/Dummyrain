package interaction.loadTesting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ApiTimerCollection {

    private Map<Integer, ArrayList<ApiTimer>> timersPerSecond;
    private final Timer timer;

    public ApiTimerCollection(Timer timer) {
        this.timer = timer;
        timersPerSecond = new HashMap<>();
    }

    public void addTimer(ApiTimer timer) {
        int second = this.timer.getSecond();
        timer = trimTimer(timer);
        synchronized (timersPerSecond) {
            if (!timersPerSecond.containsKey(second)) {
                timersPerSecond.put(second, new ArrayList<>());
            }
            timersPerSecond.get(second).add(timer);
        }
    }

    public Long getAverage() {
        int maxSecond = timer.getSecond();
        long total = 0;
        int count = 0;

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find average
                ArrayList<ApiTimer> timers = timersPerSecond.get(i);

                long average = timers.stream()
                        .map(ApiTimer::getMilliseconds)
                        .reduce((a, b) -> a + b).orElse(0L);

                total += average;
                count += timers.size();
            }
        }
        if (count == 0) count = 1;
        return total/count;
    }

    public int getCount() {
        int maxSecond = timer.getSecond();
        int count = 0;

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find total number
                count += timersPerSecond.get(i).size();
            }
        }
        return count;
    }

    public ArrayList<Integer> getCounts() {
        int maxSecond = timer.getSecond();
        ArrayList<Integer> counts = new ArrayList<>();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find total number
                counts.add(timersPerSecond.get(i).size());
            } else {
                counts.add(0);
            }
        }
        return counts;
    }

    public ArrayList<Long> getAverages() {
        int maxSecond = timer.getSecond();
        ArrayList<Long> averages = new ArrayList<>();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find average
                ArrayList<ApiTimer> timers = timersPerSecond.get(i);

                long average = timers.stream()
                        .map(ApiTimer::getMilliseconds)
                        .reduce((total, value)->total + value).orElse(0L);

                averages.add(average/timers.size());
            } else {
                averages.add(0L);
            }
        }

        return averages;
    }

    public Long getRecentAverage() {
        int lastSecond = timer.getSecond() - 1;
        long recentAvg = 0;

        if (timersPerSecond.containsKey(lastSecond)) {
            ArrayList<ApiTimer> apiTimers = timersPerSecond.get(lastSecond);
            long allTotal = apiTimers.stream()
                    .map(ApiTimer::getMilliseconds)
                    .filter(time -> !time.equals(0L))
                    .reduce((total, value)->total + value).orElse(0L);
            recentAvg = allTotal / apiTimers.size();
        }

        return recentAvg;
    }

    public int getRecentCount() {
        int lastSecond = timer.getSecond() - 1;
        int count = 0;

        if (timersPerSecond.containsKey(lastSecond)) {
            ArrayList<ApiTimer> apiTimers = timersPerSecond.get(lastSecond);
            count = apiTimers.size();
        }

        return count;
    }

    public ArrayList<Long> getMaxs() {
        int maxSecond = timer.getSecond();
        ArrayList<Long> maxs = new ArrayList<>();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find max time
                ArrayList<ApiTimer> timers = timersPerSecond.get(i);
                long max = timers.stream()
                        .reduce((a, b)-> a.greaterThan(b) ? a : b)
                        .map(ApiTimer::getMilliseconds).orElse(0L);

                maxs.add(max);
            } else {
                maxs.add(0L);
            }
        }

        return maxs;
    }

    public Long getMax() {
        return getMaxs().stream().reduce((a, b) -> a > b ? a : b).orElse(0L);
    }

    public Long getMin() {
        return getMins().stream().filter(x -> x > 0).reduce((a, b) -> a > b ? b : a).orElse(0L);
    }

    public ArrayList<Long> getMins() {
        int maxSecond = timer.getSecond();
        ArrayList<Long> mins = new ArrayList<>();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {
                //find smallest time
                ArrayList<ApiTimer> timers = timersPerSecond.get(i);
                long max = timers.stream()
                        .reduce((a, b)-> a.greaterThan(b) ? b : a)
                        .get().getMilliseconds();

                mins.add(max);
            } else {
                mins.add(0L);
            }
        }

        return mins;
    }

    public ArrayList<Integer> getFailures() {
        ArrayList<Integer> allFailures = new ArrayList<>();
        int maxSecond = timer.getSecond();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {

                int failures = (int) timersPerSecond.get(i).stream()
                        .map(ApiTimer::pass)
                        .filter(a->!a).count();

                allFailures.add(failures);
            } else {
                allFailures.add(0);
            }
        }
        return allFailures;
    }

    public ArrayList<String> getFailureResponses() {
        ArrayList<String> responses = new ArrayList<>();
        for (ArrayList<ApiTimer> timers : timersPerSecond.values()) {
            for (ApiTimer timer : timers) {
                if (!timer.pass()) {
                    String output = "Url: " + timer.url +
                            "\nBody: " + timer.body +
                            "\nResponse: " + timer.response;
                    responses.add(output);
                }
            }
        }

        return responses;
    }

    public int getFailureCount() {
        int failCount = 0;
        int maxSecond = timer.getSecond();

        for (int i = 0; i < maxSecond; ++i) {
            if (timersPerSecond.containsKey(i)) {

                int failures = (int) timersPerSecond.get(i).stream()
                        .map(ApiTimer::pass)
                        .filter(a->!a).count();

                failCount += failures;
            }
        }
        return failCount;
    }

    private ApiTimer trimTimer(ApiTimer timer) {
        if (timer.pass()){
            //if it passes all we need is the bare bones
            return new ApiTimer(timer, true);
        }
        else return timer;
    }
}
