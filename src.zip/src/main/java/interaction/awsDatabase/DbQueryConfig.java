package interaction.awsDatabase;

import logs.Log;

public class DbQueryConfig {

    private String custom;
    private String[] select;
    private String from;
    private String where;

    public static DbQueryConfig createConfig(String from, String where, String... select) {
        DbQueryConfig config = new DbQueryConfig();
        config.setFrom(from);
        config.setWhere(where);
        config.setSelect(select);
        return config;
    }

    public static DbQueryConfig createCustomConfig(String query) {
        DbQueryConfig config = new DbQueryConfig();
        config.setCustom(query);
        return config;
    }

    public String getQueryString() {
        if (custom != null) {
            return custom;
        }
        String seperator = "";
        StringBuilder queryString = new StringBuilder("select ");
        for (String s : select) {
            queryString.append(seperator).append(s);
            seperator = ", ";
        }
        queryString.append(" from ")
                .append(from)
                .append(" where ")
                .append(where);

        return queryString.toString();
    }

    public void setCustom(String query) {
        custom = query;
    }

    public void setSelect(String... select) {
        for (String s : select) {
            if (s.trim().equals("*")) {
                Log.error("Database queries do not support 'select *' yet, you need to say what columns you want", getClass().getName());
            }
        }
        this.select = select;
    }

    public String[] getSelect() {
        return select;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setWhere(String where) {
        this.where = where;
    }
}
