package interaction.awsDatabase;

import configuration.PropertyReader;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import testHelp.MyJson;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Properties;

public class DbQueryRunner {

    Connection dbConnection;

    public DbQueryRunner() {
        try {
            connectDb();
        } catch (SQLException e) {
            Log.error("unable to connect to database", getClass().getName());
            Log.error(e.getMessage(), getClass().getName());
            e.printStackTrace();
        }
    }

    public boolean runAction(DbQueryConfig config) {
        Statement statement = null;
        boolean pass = false;
        try {
            String sql = config.getQueryString();
            Log.info("running query " + sql, getClass().getName());
            statement = dbConnection.createStatement();
            pass = statement.execute(sql);
        } catch (SQLException e) {
            Log.error("Db query failed", getClass().getName());
            Log.error(e.getMessage(), getClass().getName());
            e.printStackTrace();
        }
        Log.info("query result: " + pass, getClass().getName());
        return pass;
    }

    public JSONArray runQuery(DbQueryConfig config) {
        JSONArray rows = new JSONArray();
        try {
            String sql = config.getQueryString();

            Log.info("running query " + sql, getClass().getName());
            Statement statement = dbConnection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);

            Log.info("collecting results of executed query", getClass().getName());
            while (resultSet.next()) {
                JSONObject row = new JSONObject();
                for (String column : config.getSelect()) {
                    MyJson.put(row, column, resultSet.getString(column));
                }
                rows.put(row);
            }
            resultSet.close();
        } catch (SQLException e) {
            Log.error("Db query failed", getClass().getName());
            Log.error(e.getMessage(), getClass().getName());
            e.printStackTrace();
        }
        Log.info("db results: " + rows.toString(), getClass().getName());
        return rows;
    }

    public ResultSet runQueryResultSet(DbQueryConfig config) {
        ArrayList<HashSet<String>> rows = new ArrayList<>();
        ResultSet resultSet = null;
        try {
            String sql = config.getQueryString();

            Log.info("running query " + sql, getClass().getName());
            Statement statement = dbConnection.createStatement();
            resultSet = statement.executeQuery(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }

    private void connectDb() throws SQLException {
        PropertyReader reader = PropertyReader.instance();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            Log.error("no MySQL JDBC Driver", getClass().getName());
            Log.error(e.getMessage(), getClass().getName());
            return;
        }

        Properties dbprop = new Properties();
        dbprop.setProperty("ssl", "true");
        dbprop.setProperty("user", reader.getProperty("dbUsername"));
        dbprop.setProperty("password", reader.getProperty("dbPassword"));
        dbConnection = DriverManager.getConnection(reader.getProperty("dbUrl"), dbprop);
        Log.info("Connected to database!", getClass().getName());
    }

    public void closeConnection() {
        Log.info("Closing the database connection", getClass().getName());
        try {
            dbConnection.close();
        } catch (SQLException e) {
            Log.error("failed to close connection", getClass().getName());
            Log.info(e.getMessage(), getClass().getName());
        }
    }
}
