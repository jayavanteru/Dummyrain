package interaction.screenshots;

import logs.Log;
import org.openqa.selenium.WebDriver;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class StoreScreenShot {

    public static void saveScreenShot(WebDriver browser, String name) {
        saveScreenShot(new ScreenShotImage(browser), name);
    }

    public static void saveScreenShot(ScreenShotImage shot, String name) {
        File myImageFile = new File("/Users/bryceford/Pictures/screenshots/" + name + ".png");
        Log.info("Capturing screenshot and saving to " + myImageFile.getAbsolutePath(), StoreScreenShot.class);
        final BufferedImage image = shot.getImage();
        try {
            ImageIO.write(image, "png", myImageFile);

//            Files.setAttribute(myImageFile.toPath(), fileAttribute, 100);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean isScreenShotSaved(String name) {
        File myImageFile = new File("/Users/bryceford/Pictures/screenshots/" + name + ".png");
        return myImageFile.exists();
    }

    public static ScreenShotImage openScreenShot(String filename) {
        BufferedImage image = null;
        int diffAmount = 0;
        final File file = new File("/Users/bryceford/Pictures/screenshots/"+filename+".png");
        Log.info("opening screenshot from " + file.getAbsolutePath(), StoreScreenShot.class);
        try {
            image = ImageIO.read(file);
//            diffAmount = (int) Files.getAttribute(file.toPath(), fileAttribute);

        } catch (IOException e) {
            e.printStackTrace();
        }
        final ScreenShotImage screenShotImage = new ScreenShotImage(image);
        screenShotImage.setId(filename);
//        screenShotImage.setAcceptableDiff(diffAmount);
        return screenShotImage;
    }
}
