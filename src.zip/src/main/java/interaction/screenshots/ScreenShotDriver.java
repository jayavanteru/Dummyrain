package interaction.screenshots;

import configuration.PropertyReader;
import org.apache.commons.codec.digest.DigestUtils;
import org.joda.time.DateTime;
import org.openqa.selenium.WebDriver;
import testHelp.Utils;

public class ScreenShotDriver {

    private ScreenShotImage previousImage;

    public void wait(final WebDriver browser) {
        if (Boolean.parseBoolean(PropertyReader.instance().getProperty("screenShotCompare"))) {
            final waitObject waitObject = new waitObject(browser);

            do {
                if (previousImage != null) previousImage.resetDiff();
                else previousImage = getScreenShot(browser);
                Thread thread = new Thread(waitObject::start);
                thread.start();
                final DateTime parseTimeout = DateTime.now().plusMillis(1000);
                while ((waitObject.isWorking() && parseTimeout.isAfterNow())) {
                    Utils.sleep(100);
                }
                thread.interrupt();
            } while (!previousImage.isScreenMatching() && waitObject.isWithinTimeout());
        }
    }

    public ScreenShotImage getScreenShot(final WebDriver browser) {
        return new ScreenShotImage(browser);
    }

    private class waitObject {
        private boolean waiting;
        private final WebDriver browser;
        private final DateTime timeout;

        public waitObject(WebDriver browser) {
            this.browser = browser;
            waiting = true;
            timeout = DateTime.now().plusSeconds(15);
        }

        public void start() {
            setWaiting(true);
            try {
                isScreenMatching();
            } catch (Exception e) { }
        }

        public boolean isWorking() {
            return waiting && timeout.isAfterNow();
        }

        public boolean isWithinTimeout() {
            return timeout.isAfterNow();
        }

        private synchronized void setWaiting(boolean result) {
            waiting = result;
        }

        private void isScreenMatching() {
            final ScreenShotImage base = previousImage;
            final ScreenShotImage screen = new ScreenShotImage(browser);
            previousImage = screen;
            screen.getMatching(base);
            setWaiting(false);
        }
    }

    private boolean recordScreen(WebDriver browser, String name) {
        StoreScreenShot.saveScreenShot(browser, name);
        return true;
    }

    private ScreenShotImage findExistingScreenShot(String name) {
        return StoreScreenShot.openScreenShot(name);
    }

    public static String discoverId() {
        StringBuilder myId = new StringBuilder(PropertyReader.instance().getProperty("browserName"));
        for (StackTraceElement trace : Thread.currentThread().getStackTrace()) {
            myId.append(trace.toString());
        }

        return DigestUtils.md5Hex(myId.toString());
    }
}

