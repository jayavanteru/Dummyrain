package interaction.screenshots;

import logs.Log;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ScreenShotImage {

    private Screenshot image;
    private String id;
    private int acceptableDiff = 100;
    private ImageDiff differ;

    public ScreenShotImage(BufferedImage image) {
        this(new Screenshot(image));
    }

    public ScreenShotImage(Screenshot image) {
        this.image = image;
    }

    public ScreenShotImage(File file) throws IOException {
        this(ImageIO.read(file));
    }

    public ScreenShotImage(WebDriver browser) {
        this(new AShot().shootingStrategy(ShootingStrategies.simple()).takeScreenshot(browser));
    }

    public Screenshot getScreenShot() {
        return image;
    }

    public BufferedImage getImage() {

        return image.getImage();
    }

    public void save(String name) {
        final File file = new File(name);
        try {
            file.createNewFile();
            ImageIO.write(getImage(), "PNG", file);
        } catch (IOException e) {
            Log.error(e, getClass());
        }
    }

    public boolean isElementMatchingOnPage(WebElement el, ScreenShotImage expectedImage) {
        //get element dimensions
        final Rectangle elementSize = el.getRect();

        //scale the expected image to expected size
        final Image scaledInstance = expectedImage.getImage().getScaledInstance(elementSize.width, elementSize.height, Image.SCALE_SMOOTH);
        final BufferedImage bufferedScaleImage = new BufferedImage(elementSize.width, elementSize.height, BufferedImage.TYPE_INT_RGB);
        bufferedScaleImage.getGraphics().drawImage(scaledInstance, 0, 0, null);
        //create a Screenshot Image Object from the scaled image
        expectedImage = new ScreenShotImage(bufferedScaleImage);

        //get the sub image from the page and run the comparison
        final BufferedImage subimage = getImage().getSubimage(elementSize.x, elementSize.y, elementSize.width, elementSize.height);
        expectedImage.setAcceptableDiff(getAcceptableDiff());
        expectedImage.getDiffImage(new ScreenShotImage(subimage)).save("difpic.jpg");
        return expectedImage.isScreenMatching(new ScreenShotImage(subimage));
    }

    public ScreenShotImage getSubImage(int x, int y, int width, int height) {
        final BufferedImage subimage = getImage().getSubimage(x, y, width, height);
        return new ScreenShotImage(subimage);
    }

    public void scaleImage(int width, int height) {
        final Image scaledInstance = getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        final BufferedImage bufferedScaleImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        bufferedScaleImage.getGraphics().drawImage(scaledInstance, 0, 0, null);
        //create a Screenshot Image Object from the scaled image
        image = new Screenshot(bufferedScaleImage);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAcceptableDiff() {
        return acceptableDiff;
    }

    public void setAcceptableDiff(int acceptableDiff) {
        this.acceptableDiff = acceptableDiff;
    }

    public void getMatching(ScreenShotImage screen) {
        differ = new ImageDiffer().makeDiff(image, screen.image);
    }

    public void resetDiff() {
        differ = null;
    }

    public boolean isScreenMatching() {
        if (differ != null) {
            return evaluateDiff(differ);
        } else return false;
    }

    public boolean isScreenMatching(ScreenShotImage screen) {
        if (screen != null) {
            final ImageDiff diff = new ImageDiffer().makeDiff(image, screen.image);
            return evaluateDiff(diff);
        } else return false;
    }

    public int getDiffAmount(ScreenShotImage screen) {
        final ImageDiff diff = new ImageDiffer().makeDiff(image, screen.image);
        return diff.getDiffSize();
    }

    public boolean isScreenMatching(WebDriver browser) {
        ScreenShotImage currentImage = new ScreenShotImage(browser);
        return isScreenMatching(currentImage);
    }

    public ScreenShotImage getDiffImage(ScreenShotImage screen) {
        Log.info("generating a diff image", getClass());
        ImageDiff diff = new ImageDiffer().makeDiff(image, screen.image);
        return new ScreenShotImage(diff.getMarkedImage());
    }

    private boolean evaluateDiff(ImageDiff diff) {
        Log.info("comparing 2 images, the difference is " + diff.getDiffSize(), getClass());
        return diff.getDiffSize() <= getAcceptableDiff();
    }
}
