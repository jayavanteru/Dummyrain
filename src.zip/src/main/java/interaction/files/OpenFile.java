package interaction.files;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import logs.Log;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.joda.time.DateTime;
import org.testng.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import testHelp.Utils;

import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class OpenFile {

    private File file;

    private static OpenFile foundFile;

    public OpenFile(String filePath) {
        this(new File(filePath));
    }

    public OpenFile(File openfile) {
        file = openfile;
    }

    public static OpenFile OpenDownloadedFile(String filename) {
        String home = System.getProperty("user.home") + "/Downloads/";
        return new OpenFile(home + filename);
    }

    public static OpenFile OpenRecentDownloadedFileMatchingPattern(String pattern, int maxseconds) {
        if (Utils.waitForTrue(()->
                (foundFile = OpenRecentDownloadedFile()) != null &&
                        foundFile.getName().matches(pattern), maxseconds)) {
            return foundFile;
        }
        return null;
    }

    //the file needs to have been downloaded in the last 30 seconds
    public static OpenFile OpenRecentDownloadedFile() {
        final DateTime timeout = DateTime.now().plusSeconds(30);
        long recenttime = 30000; //30 seconds back
        long recentfuture = System.currentTimeMillis() + recenttime;
        long recentpast = System.currentTimeMillis() - recenttime;

        String downloadDir = System.getProperty("user.home") + "/Downloads/";
        File tempfile = new File(downloadDir);
        File mostrecent = null;


        while ((mostrecent == null ||
                (mostrecent.lastModified() < recentpast &&
                        System.currentTimeMillis() < recentfuture)) &&
                timeout.isAfterNow())
        {
            Utils.sleep(500, "waiting for file to download");
            mostrecent = Arrays.stream(tempfile.listFiles())
                    .reduce((afile, bfile) -> afile.lastModified() > bfile.lastModified() ? afile : bfile).orElse(null);
        }

        return mostrecent.lastModified() > recentpast ? new OpenFile(mostrecent) : null;
    }

    public static boolean fileTypeMatches(String expectedType){
        final DateTime timeout = DateTime.now().plusSeconds(15);
        long recenttime = 30000; //30 seconds back
        long recentfuture = System.currentTimeMillis() + recenttime;
        long recentpast = System.currentTimeMillis() - recenttime;

        String downloadDir = System.getProperty("user.home") + "/Downloads/";
        File tempfile = new File(downloadDir);
        File mostrecent = null;

        while ((mostrecent == null ||
                (mostrecent.lastModified() < recentpast &&
                        System.currentTimeMillis() < recentfuture)) &&
                timeout.isAfterNow())
        {
            Utils.sleep(500, "waiting for file to download");
            mostrecent = Arrays.stream(tempfile.listFiles())
                    .reduce((afile, bfile) -> afile.lastModified() > bfile.lastModified() ? afile : bfile).orElse(null);
        }

        return mostrecent.getName().contains(expectedType);
    }

    public static OpenFile OpenRecentDownloadedFile(Pattern pattern) {
        long recenttime = 30000; //30 seconds back
        long recentfuture = System.currentTimeMillis() + recenttime;
        long recentpast = System.currentTimeMillis() - recenttime;

        File downloadDir = new File( System.getProperty("user.home") + "/Downloads/");

        String[] fileNames = downloadDir.list();
        for (String f : fileNames) {
            Matcher matcher = pattern.matcher(f);
            if (matcher.lookingAt() == true) {
                String[] splits = f.split("_");
                String[] split2 = splits[2].split(".");
                Integer time = Integer.parseInt(split2[0]);
                if(time < recentfuture && time > recentpast) {
                    foundFile = OpenDownloadedFile(f);
                    return foundFile;
                }
            }
        }
        return null;
    }

    public static OpenFile OpenRecentDownloadedFileMatchingPattern(String pattern) {
        if (Utils.waitForTrue(()->
            (foundFile = OpenRecentDownloadedFile()) != null &&
            foundFile.getName().matches(pattern))) {
            return foundFile;
        }
        return null;
    }

    public File getFile() {
        return file;
    }

    public String getName() {
        return file.getName();
    }

    public String getContent() {
        String content = "";
        try {
            Files.readAllLines(file.toPath(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.error("failed to read file", getClass());
            Log.error(e, getClass());
            e.printStackTrace();
        }

        return content;
    }

    public String getFirstLine() {
        String line = "";
        try {
            line = new BufferedReader(new FileReader(file)).readLine();
        } catch (IOException e) {
            Log.error("failed to read file", getClass());
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return line;
    }

    public List<Map<String, String>> getCsvMap() {
        return read(file);
    }

    public Stream<String> getStream() {
        Stream<String> lines = null;
        try {
            lines = Files.lines(file.toPath());
        } catch (IOException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }
        return lines;
    }

    @Override
    public boolean equals(Object otherFile) {
        if (otherFile instanceof OpenFile) {
            return Arrays.equals(((OpenFile) otherFile).getFileByteArray(), getFileByteArray());
        }
        return false;
    }

    private byte[] getFileByteArray() {
        try {
            return Files.readAllBytes(file.toPath());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new byte[0];
    }

    private List<Map<String, String>> read(File file) {
        List<Map<String, String>> response = new LinkedList<>();
        CsvMapper mapper = new CsvMapper();
        CsvSchema schema = CsvSchema.emptySchema().withHeader();
        try {
            MappingIterator<Map<String, String>> iterator = mapper.reader(Map.class)
                    .with(schema)
                    .readValues(file);
            while (iterator.hasNext()) {
                response.add(iterator.next());
            }
        } catch (Exception e) {
            Log.error("failed to parse csv", getClass());
            Log.error(e, getClass());
        }
        return response;
    }

    public List<Map<String, String>> parseXLSX() throws IOException {
        FileInputStream fis = new FileInputStream(file);
        XSSFWorkbook myWorkBook = new XSSFWorkbook(fis);
        XSSFSheet mySheet = myWorkBook.getSheetAt(0);
        List<Map<String, String>> mapLinkedList = new LinkedList<>();
        List<String> headers = new LinkedList<>();

        Iterator<org.apache.poi.ss.usermodel.Row> rowIterator = mySheet.iterator();

        if(rowIterator.hasNext()) {
            org.apache.poi.ss.usermodel.Row row = rowIterator.next();
            Iterator<org.apache.poi.ss.usermodel.Cell> cellIterator = row.cellIterator();
            for(int i = 0; cellIterator.hasNext(); i++) {
                org.apache.poi.ss.usermodel.Cell cell = cellIterator.next();
                String header = cell.getStringCellValue();
                headers.add(i, header);
            }
        }
        while (rowIterator.hasNext()) {
            org.apache.poi.ss.usermodel.Row row = rowIterator.next();
            Map<String, String> map = new HashMap<>();
            Iterator<org.apache.poi.ss.usermodel.Cell> cellIterator = row.cellIterator();
            while(cellIterator.hasNext()) {

                String value;
                org.apache.poi.ss.usermodel.Cell cell = cellIterator.next();
                value = getCellContents(cell);
                int columnIndex = cell.getColumnIndex();
                String key = headers.get(columnIndex);
                map.put(key, value);

            }
            mapLinkedList.add(map);
        }
        return mapLinkedList;
    }

    public static String getCellContents(Cell cell)
    {
        String value;
        if (cell.getCellType() == CellType.NUMERIC)
        {
            value = String.valueOf(new Double(cell.getNumericCellValue()).intValue());
        }
        else if (cell.getCellType() == CellType.BOOLEAN)
        {
            value = cell.getBooleanCellValue() ? "true" : "false";
        }
        else
        {
            value = cell.getStringCellValue();
            value = value.replaceAll("(\\r\\n|\\r)", "\n");
        }
        return value;
    }

    public String getXLSXContentsMD5() throws IOException, NoSuchAlgorithmException
    {
        ZipSecureFile.setMinInflateRatio(0.001);
        try (FileInputStream fis = new FileInputStream(file);
             XSSFWorkbook myWorkBook = new XSSFWorkbook(fis))
        {
            XSSFSheet mySheet = myWorkBook.getSheetAt(0);
            StringBuilder contentsBuilder = new StringBuilder();

            final int numRows = mySheet.getLastRowNum();
            final int chunkSize = 100;
            final int numChunks = (int) Math.ceil(((double) numRows) / chunkSize);
            
            for (int i = 0; i < numChunks; ++i)
            {
                StringBuilder chunkContentsBuilder = new StringBuilder();
                
                for (int j = i * chunkSize; j < (i + 1) * chunkSize && j < numRows; ++j)
                {
                    Row row = mySheet.getRow(j);
                    Iterator<Cell> cellIterator = row.cellIterator();
                    while (cellIterator.hasNext())
                    {
                        Cell cell = cellIterator.next();
                        chunkContentsBuilder.append(getCellContents(cell));
                    }
                }
                
                contentsBuilder.append(getMD5FromString(chunkContentsBuilder.toString()));
            }

            final String contents = contentsBuilder.toString();
            return getMD5FromString(contents);
        }
    }

    public String getMD5FromString(String contents) throws NoSuchAlgorithmException
    {
        final MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(contents.getBytes());
        final byte[] digest = md.digest();
        return DatatypeConverter.printHexBinary(digest).toUpperCase();
    }


    public List<Map<String, String>> parseXML(String searchPage) throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(true);
        factory.setIgnoringElementContentWhitespace(true);

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(file);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName(searchPage);
        List<Map<String, String>> mapLinkedList = new LinkedList<>();

        for(int temp = 0; temp < nList.getLength(); temp++) {
            Map<String, String> nodeMap = new HashMap<>();
            Node node = nList.item(temp);
            Element element = (Element) node;
            NodeList childNodes = element.getChildNodes();
            for(int i = 0; i < childNodes.getLength(); i++){
                if(childNodes.item(i).getNodeType() == Node.ELEMENT_NODE){
                    String key = childNodes.item(i).getNodeName();
                    String value = childNodes.item(i).getTextContent();
                    nodeMap.put(key, value);
                }
            }
            mapLinkedList.add(nodeMap);
        }
        return mapLinkedList;
    }

    public static boolean compareResults(List<Map<String, String>> expectedResults, List<Map<String, String>> actualResults) {
        for (Map<String, String> row: expectedResults){
            if(!contains(row, actualResults)) return false;
        }
        return true;
    }

    public static void assertSameUK(List<Map<String, String>> adminRecords, List<Map<String, String>> l2) {
        Assert.assertEquals(adminRecords.size(), l2.size(), "not the same number of records");
        Assert.assertTrue(adminRecords.get(0).size() <= l2.get(0).size(), "the export does not have all the columns that the admin has");

        for (int i = 0; i < adminRecords.size(); ++i) {
            for (String key : adminRecords.get(i).keySet()) {
                String key2 = key.replace(" ", "");
                String actualkey = l2.contains(key) ? key : key2;
                if (actualkey.equalsIgnoreCase("packagename")) actualkey = "packages";
                Assert.assertEquals(adminRecords.get(i).get(key), l2.get(i).get(actualkey.toUpperCase()), "record did not match from search and export on " + key);
            }
        }
    }

    public static void assertSameLK(List<Map<String, String>> adminRecords, List<Map<String, String>> l2) {
        Assert.assertEquals(adminRecords.size(), l2.size(), "not the same number of records");
        Assert.assertTrue(adminRecords.get(0).size() <= l2.get(0).size(), "the export does not have all the columns that the admin has");

        for (int i = 0; i < adminRecords.size(); ++i) {
            for (String key : adminRecords.get(i).keySet()) {
                String key2 = key.replace(" ", "");
                String actualkey = l2.contains(key) ? key : key2;
                Assert.assertEquals(adminRecords.get(i).get(key), l2.get(i).get(actualkey), "record did not match from search and export on " + key);
            }
        }
    }

    private static boolean contains(Map<String, String> row, List<Map<String, String>> list){
        for (Map<String, String> findRow : list) {
            if(rowEquals(row, findRow)) {
                return true;
            }
        }
        return false;
    }

    private static boolean rowEquals(Map<String, String> expectedRow, Map<String, String> actualRow) {
        Set<String> keys = actualRow.keySet();
        Set<String> expectedKeys = expectedRow.keySet();
        if(expectedKeys.size() == keys.size()) {
            for (String key : keys) {
                if(!expectedKeys.contains(key) || !expectedRow.get(key).equals(actualRow.get(key))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
