package interaction.api;

import configuration.PropertyReader;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.ApiBodyFactory;
import interaction.api.apiObjects.BodyFromFile;
import org.apache.http.HttpEntity;
import org.json.JSONObject;
import testHelp.MyJson;
import testHelp.Utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;

public class ApiConfig {

    private String url;
    private JSONObject body;
    private JSONObject response;
    private String rawResponse;
    private int bodyResponseCode;
    private int responseCode;
    private boolean urlParams;
    private HttpEntity postEntity;
    private HashMap<String, String> headers;
    public static final HashMap<String, String> permanentHeaders = new HashMap<>();
    private boolean form = false;
    private long responseTime;

    public ApiConfig() {
        headers = new HashMap<>(permanentHeaders);
        setContentType("*");
    }

    public ApiConfig(String url) {
        this();
        setUrl(url);
    }

    public ApiConfig(String url, JSONObject body) {
        this(url);
        setBody(body);
    }

    public ApiConfig(String url, String jsonBody) {
        this(url, MyJson.createJSON(jsonBody));
    }

    public String getUrl() {
        return isUrlParams() ? addParamsToUrl(url, body) : url;
    }

    public void setUrl(String url) {
        this.url = PropertyReader.instance().findAndReplaceProperties(url);
    }

    public JSONObject getBody() {
        return isUrlParams() ? null : body;
    }

    public void setBody(JSONObject body) {
        this.body = body;
    }

    public void setBody(String jsonBody) {setBody(MyJson.createJSON(jsonBody));}

    public void setBodyFromFile(String filename) {
        setBody((JSONObject) BodyFromFile.getFile(filename).getJsonValue());
    }

    public JSONObject getResponse() {
        return response;
    }

    public ApiBody getResponseAsApiBody() {
        return ApiBodyFactory.parseJson(rawResponse);
    }

    public void setResponse(JSONObject response) {
        this.response = response;
    }

    public void setRawResponse(String response) {
        rawResponse = response;
    }

    public boolean isUrlParams() {
        return urlParams;
    }

    public void setUrlParams(boolean urlParams) {
        this.urlParams = urlParams;
    }

    private String addParamsToUrl(String url, JSONObject params) {
        String seperator = url.contains("?") ? "&" : "?";
        Iterator keys = params.keys();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            String value = MyJson.getString(params, key);
            //encode that value
            try {
                value = URLEncoder.encode(value, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            url += seperator + key + "=" + value;
            //        .replace("{", "");
            seperator = "&";
        }
        return url;
    }

    public String getContentType() {
        return headers.get("Content-Type");
    }

    public void setContentType(String contentType) {
        headers.put("Content-Type", contentType);
    }

    public HttpEntity getPostEntity() {
        return postEntity;
    }

    public void setPostEntity(HttpEntity postEntity) {
        this.postEntity = postEntity;
    }

    public int getBodyResponseCode() {
        return bodyResponseCode;
    }

    public void setBodyResponseCode(int bodyResponseCode) {
        this.bodyResponseCode = bodyResponseCode;
    }

    public HashMap<String, String> getHeaders() {
        return headers;
    }

    public void setHeader(String key, String value) {
        headers.put(key, value);
    }

    public void setHeaders(HashMap<String, String> headers) {
        this.headers.putAll(headers);
    }

    public boolean isForm() {
        return form;
    }

    public void setForm(boolean form) {
        this.form = form;
    }

    public boolean schemaValidate(JSONObject pattern) {
        return Utils.schema(pattern, getResponse());
    }

    public float getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(long milliseconds) {
        responseTime = milliseconds;
    }

    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }
}
