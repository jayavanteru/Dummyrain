package interaction.api;

import apps.admin.AdminApp;
import apps.admin.forms.Form;
import org.json.JSONObject;
import testHelp.DataGenerator;
import testHelp.MyJson;

public class CommonApiActions {

    private static AdminApp adminApp;
    private static final String rainfocusOrgCode = "WDhrQi36D8KWFBBhGxp8B8xUsOIlqD3hnLQGkiZO";
    private static final String constellationsEventId = "149202933754rain2025";
    private static final DataGenerator generator = new DataGenerator();

    public static AdminApp getAdminApp() {
        if (adminApp == null) {
            adminApp = new AdminApp();
            adminApp.setApi(Api.getClient());
            getAdminApp().loginApi();
        }
        return adminApp;
    }

    //returns the attendee id
    public static String createAttendee_Constellations(String email, String password, String... replaceFields) {
        String createFormId = "961c413c-1fbf-11e7-822e-06fe95280409";

        getAdminApp().setOrgAndEventApi(rainfocusOrgCode, constellationsEventId);
        Form formApi = getAdminApp().getFormApi(createFormId, replaceFields);
        formApi.addOverride("formAttendee.email", email);

        JSONObject response = getAdminApp().saveObjectApi(createFormId, formApi);

        String id = MyJson.getString(MyJson.getJSONObject(response, "data"), "objectId");

        getAdminApp().changePasswordApi(id, password);
        return id;
    }

    //returns the exhibitor id
    public static String createExhibitor_Constellations(String name) {
        JSONObject body = new JSONObject();

        MyJson.put(body, "exhibitor.name", name);
        MyJson.put(body, "exhibitor.description", generator.generateString());
        MyJson.put(body, "exhibitor.email", generator.generateEmail());
        MyJson.put(body, "eventIds", constellationsEventId);
        MyJson.put(body, "exhibitor.exhibitorId", "");
        MyJson.put(body, "id", "");
        MyJson.put(body, "exhibitor.url", generator.generateString());
        MyJson.put(body, "exhibitor.phone", generator.generatePhone());
        MyJson.put(body, "exhibitor.address1", generator.generateStreetAddress());
        MyJson.put(body, "exhibitor.address2", generator.generateStreetAddress());
        MyJson.put(body, "exhibitor.city", generator.generateString());
        MyJson.put(body, "exhibitor.stateId", "");
        MyJson.put(body, "exhibitor.foreignstate", "");
        MyJson.put(body, "exhibitor.countryId", "");
        MyJson.put(body, "exhibitor.zip", generator.generateString(5));

        JSONObject response = getAdminApp().postAsUrlParams("/processExhibitor.focus", body);

        String redirect = MyJson.getString(MyJson.getJSONObject(response, "data"), "redirect");
        return redirect.split("id=")[1].split("&")[0];
    }

    public static JSONObject deleteAttendee(String attendeeId) {
        return getAdminApp().deleteAttendeeApi(attendeeId);
    }
}
