package interaction.api;

import configuration.PropertyReader;
import interaction.loadTesting.Timer;
import logs.Log;
import org.apache.http.*;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import testHelp.MyJson;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class Api {

    public boolean jumpcloudAuth = false;
    public boolean jiraAuth = false;

    HttpClientContext context;

    public HashSet<CustomCookie> cookies;
    CloseableHttpClient httpClient;
    CloseableHttpClient httpsClient;
    private HttpRequestBase currentRequest;

    private static Api apiClient;

    public static ApiConfig Get(String url) {
        return getClient().get(new ApiConfig(url));
    }

    public static ApiConfig Post(String url) {
        return getClient().post(new ApiConfig(url));
    }

    public static ApiConfig Post(String url, JSONObject body) {
        return getClient().post(new ApiConfig(url, body));
    }

    public static Api getClient() {
        if (apiClient == null) {
            apiClient = new Api();
        }
        return apiClient;
    }

    public Api() {
        context = HttpClientContext.create();
        cookies = new HashSet<>();

        try {
            createAllAcceptingClient();
        } catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
            Log.error(e, getClass());
            e.printStackTrace();
        }

    }

    private void createAllAcceptingClient()
            throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

        // allow everything through
        SSLContext sslContext = SSLContextBuilder
                .create()
                .loadTrustMaterial((x509Certificates, s) -> true)
                .build();

        HostnameVerifier allowAllHosts = new NoopHostnameVerifier();

        // create an SSL Socket Factory that uses our custom ssl verify
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, allowAllHosts);

        //create registry of the ssl connection to add it to our connection manager
        Registry<ConnectionSocketFactory> socketFactoryRegistryssl = RegistryBuilder.<ConnectionSocketFactory> create().register("https", sslsf).build();
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory> create().build();

        //how many threads can the client have running at once
        int threadMax = Integer.parseInt(PropertyReader.instance().getProperty("absoluteApiThreadMax"));

        // create the connection manager with all our settings
        PoolingHttpClientConnectionManager connectionManagerssl = new PoolingHttpClientConnectionManager(socketFactoryRegistryssl);
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);

        connectionManagerssl.setMaxTotal(threadMax);
        connectionManagerssl.setDefaultMaxPerRoute(threadMax);

        connectionManager.setMaxTotal(threadMax);
        connectionManager.setDefaultMaxPerRoute(threadMax);


        // create the HttpClient using our pool connection manager, and the ssl connection
        httpClient = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .build();

        httpsClient = HttpClients.custom()
                .setConnectionManager(connectionManagerssl)
                .build();

    }

    public void abort() {
        currentRequest.abort();
    }

    public ApiConfig post(ApiConfig apiConfig) {
        //build the request
        Log.info("Posting to: " + apiConfig.getUrl(), getClass().getName());
        HttpPost postRequest = new HttpPost(apiConfig.getUrl());

        return updateRequest(postRequest, apiConfig);
    }

    public ApiConfig put(ApiConfig apiConfig) {
        //build the request
        Log.info("Posting to: " + apiConfig.getUrl(), getClass().getName());
        HttpPut putRequest = new HttpPut(apiConfig.getUrl());

        return updateRequest(putRequest, apiConfig);
    }

    public ApiConfig get(ApiConfig apiConfig) {
        //build the request
        HttpGet getRequest = new HttpGet(apiConfig.getUrl());
        Log.info("Get from: " + apiConfig.getUrl(), getClass().getName());

        send(getRequest, apiConfig);

        Log.debug("api response: " + apiConfig.getResponse(), getClass());
        return apiConfig;
    }

    private ApiConfig updateRequest(HttpEntityEnclosingRequestBase postRequest, ApiConfig apiConfig) {
        //add body
        HttpEntity input = null;
        try {
            if (apiConfig.getBody() != null) {
                if (apiConfig.isForm()) {
                    ArrayList<NameValuePair> list = new ArrayList<>();
                    JSONObject json = apiConfig.getBody();
                    Iterator keys = apiConfig.getBody().keys();

                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        list.add(new BasicNameValuePair(key, MyJson.getString(json, key)));
                    }
                    input = new UrlEncodedFormEntity(list, "UTF-8");
                } else {
                    input = new StringEntity(apiConfig.getBody().toString());
                }
                postRequest.setHeader(HttpHeaders.CONTENT_TYPE, apiConfig.getContentType());

            } else if (apiConfig.getPostEntity() != null) {
                input = apiConfig.getPostEntity();
                postRequest.setHeader(HttpHeaders.CONTENT_TYPE, apiConfig.getContentType());
            }
        } catch (UnsupportedEncodingException e) {
            Log.error("Failed to attach body to post request", getClass().getName());
            Log.error(apiConfig.getBody().toString(), getClass().getName());
            e.printStackTrace();
        }
        postRequest.setEntity(input);

        send(postRequest, apiConfig);

        Log.debug("api response: " + apiConfig.getResponse(), getClass());
        return apiConfig;
    }

    protected void send(HttpRequestBase request, ApiConfig config) {
        String savedJson = "";
        currentRequest = request;
        request.addHeader("Accept", "*/*");
        request.addHeader("Cache-Control", "no-cache");
        HashMap<String, String> headers = config.getHeaders();
        for (String headerkey : headers.keySet()) {
            request.addHeader(headerkey, headers.get(headerkey));

        }
        synchronized (cookies) {
            for (CustomCookie c : cookies) {
                request.addHeader("Cookie", c.toString());
            }
        }

        try {
            //send the request
            HttpClientContext contextCopy;
            synchronized (context) {
                contextCopy = new HttpClientContext(context);
            }
            Timer timer = new Timer();
            timer.start();
            HttpResponse response;

            if (config.getUrl().startsWith("https")) {
                response = httpsClient.execute(request, contextCopy);
            } else {
                response = httpClient.execute(request, contextCopy);
            }
            config.setResponseTime(timer.getMilliseconds());

            config.setResponseCode(response.getStatusLine().getStatusCode());

            //save any cookies
            synchronized (context) {
                context = contextCopy;
            }
            saveCookies(context.getCookieStore().getCookies());
            saveCookies(response.getHeaders("Set-Cookie"));

            //save response
            BufferedReader br = new BufferedReader(new InputStreamReader(
                            response.getEntity() == null ?
                            new ByteArrayInputStream("".getBytes()) :
                            response.getEntity().getContent()));

            String output;
            while ((output = br.readLine()) != null) {
                savedJson += output;
            }
        } catch (IOException e) {
            Log.info("API request failed", getClass().getName());
            Log.error(e, getClass());
        } finally {
            request.releaseConnection();
        }

        config.setRawResponse(savedJson.trim());
        try {
            setResponse(new JSONObject(savedJson.trim()), config);
        } catch (JSONException e) {
            Log.error("request did not return valid JSON ", getClass().getName());
            Log.error(savedJson.trim(), getClass().getName());
            setResponse(MyJson.createJSON("{'data':'" + savedJson.replace("'", "\"") + "'}"), config);
        }
    }

    private void setResponse(JSONObject response, ApiConfig apiConfig) {
        apiConfig.setResponse(response);
        if (response.has("responseCode")) {
            apiConfig.setBodyResponseCode(MyJson.getInt(response, "responseCode"));
        }
    }

    private void saveCookies(Header[] headers) {
        for (Header h : headers) {
            try {
                saveCookie(new CustomCookie(h.getValue()));
            } catch (Exception e) {
                Log.error(e, getClass());
            }
        }
    }

    private void saveCookies(List<Cookie> cookieList) {
        for (Cookie c : cookieList) {
            try {
                saveCookie(new CustomCookie(c));
            } catch (Exception e) {
                Log.error(e, getClass());
            }
        }
    }

    private void saveCookie(CustomCookie cookie) {
        synchronized (cookies) {
            cookies.removeIf((ck) -> ck.toString().equals(cookie.toString()));
            cookies.add(cookie);
        }
    }
}


