package interaction.api;


import configuration.PropertyReader;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.ApiBodyFactory;
import interaction.api.apiObjects.BodyFromFile;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import testHelp.Utils;

import java.util.HashMap;
import java.util.Map;

public class ApiDriver {

    private Api client;
    private static final String pathSeparate = ",";
    private static final String apiValueProperty = "api_";
    private static final String apiSchemaProperty = "api_schema_";

    public ApiConfig post(String url) {
        return post(new ApiConfig(url));
    }

    public ApiConfig get(String url) {
        return post(new ApiConfig(url));
    }

    public ApiConfig post(ApiConfig config) {
        return getClient().post(config);
    }

    public ApiConfig get(ApiConfig config) {
        return getClient().post(config);
    }

    public ApiConfig post(String url, String apiBodyFileName) {
        return post(url, apiBodyFileName, new HashMap<>());
    }

    public ApiConfig post(ApiConfig config, ApiBody body) {
        config.setBody((JSONObject) body.getJsonValue());
        return post(config);
    }

    //overrides for the body, key is the path to the attribute separated by ,
    public ApiConfig post(String url, String apiBodyFileName, Map<String, Object> overrides) {
        final ApiConfig config = new ApiConfig(url);
        final ApiBody apiBody = BodyFromFile.getFile(apiBodyFileName);
        addOverridesValue(apiBody, overrides);
        config.setBody((JSONObject) apiBody.getJsonValue());
        return post(config);
    }

    public ApiBody addOverridesValue(ApiBody apiBody, Map<String, Object> overrides) {
        for (String overrideKey : overrides.keySet()) {
            addOverrideValue(apiBody, overrideKey, overrides.get(overrideKey));
        }
        return apiBody;
    }

    //keypath separated by ,
    public ApiBody addOverrideValue(ApiBody apiBody, String keypath, Object value) {
        apiBody.get(keypath.split(pathSeparate)).putValue(value);
        return apiBody;
    }

    public ApiBody addOverridesSchema(ApiBody apiBody, Map<String, String> overrides) {
        for (String overrideKey : overrides.keySet()) {
            addOverrideSchema(apiBody, overrideKey, overrides.get(overrideKey));
        }
        return apiBody;
    }

    //keypath separated by ,
    public ApiBody addOverrideSchema(ApiBody apiBody, String keypath, String value) {
        apiBody.get(keypath.split(pathSeparate)).putSchema(value);
        return apiBody;
    }

    public void assertSchemaMatch(String fileName, ApiConfig apiResponse) {
        final ApiBody file = BodyFromFile.getFile(fileName);
        assertSchemaMatch(file, apiResponse.getResponseAsApiBody());
    }

    public void assertSchemaMatch(ApiBody pattern, ApiConfig apiResponse) {
        assertSchemaMatch(pattern, apiResponse.getResponseAsApiBody());
    }

    public void assertResponseMatchesSchemaOfSentBody(ApiConfig config) {
        assertSchemaMatch(createApiBody(config.getBody()), config.getResponseAsApiBody());
    }

    public void assertSchemaMatch(ApiBody schema, ApiBody actual) {
        final Object jsonSchema = schema.getJsonSchema();
        final Object actualValue = actual.getOriginalValue();
        Assert.assertTrue(Utils.schema(jsonSchema, actualValue), "schema:\n" + jsonSchema + "\ndid not match\n" + actualValue);
    }

    public Object getResponseItem(ApiConfig config, String itemPath) {
        return config.getResponseAsApiBody().get(itemPath.split(pathSeparate)).getOriginalValue();
    }

    public void setGlobalOverrideValue(String key, String value) {
        PropertyReader.instance().setProperty(apiValueProperty + key, value);
    }

    public void setGlobalOverrideSchema(String key, String value) {
        PropertyReader.instance().setProperty(apiSchemaProperty + key, value);
    }

    public ApiBody openApiBodyFile(String filename) {
        return BodyFromFile.getFile(filename);
    }

    public ApiBody createApiBody(String json) {
        return ApiBodyFactory.parseJson(json);
    }

    public ApiBody createApiBody(JSONObject json) {
        return ApiBodyFactory.parseJson(json);
    }

    public ApiBody createApiBody(JSONArray json) {
        return ApiBodyFactory.parseJson(json);
    }

    public Api getClient() {
        if (client == null) {
            client = Api.getClient();
        }
        return client;
    }

    public void setClient(Api client) {
        this.client = client;
    }
}
