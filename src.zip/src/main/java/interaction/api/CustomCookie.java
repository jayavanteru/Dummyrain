package interaction.api;


import org.apache.http.impl.cookie.BasicClientCookie;
import org.joda.time.format.DateTimeFormat;

import java.util.Date;

public class CustomCookie {

    private org.openqa.selenium.Cookie selCookie;
    private org.apache.http.cookie.Cookie apCookie;

    public CustomCookie(org.apache.http.cookie.Cookie cookie) {
        setCookie(cookie);
    }

    public CustomCookie(org.openqa.selenium.Cookie cookie) {
        setCookie(cookie);
    }

    public CustomCookie(String value) {
        setCookie(value);
    }

    public void setCookie(org.openqa.selenium.Cookie cookie) {
        selCookie = cookie;
        apCookie = convert(cookie);
    }

    public void setCookie(org.apache.http.cookie.Cookie cookie) {
        apCookie = cookie;
        selCookie = convert(cookie);
    }

    //"SESSION=db4f4efb-c163-485f-861d-0b885d50d973; path=/; domain=.app-stg.rainfocus.com; HttpOnly; Expires=Mon Jan 18 2038 03:14:07 GMT-0700 (MST);");
    public void setCookie(String cookie) {
        String[] keys = {"path", "domain", "Expires"};
        //get key and value
        String[] nameValue = parseCookieString(cookie, "");

        BasicClientCookie basicClientCookie = new BasicClientCookie(nameValue[0], nameValue[1]);

        //path
        if (cookie.contains("path")) {
            basicClientCookie.setPath(parseCookieString(cookie, "path")[1]);
        }

        //domain
        if (cookie.contains("domain")) {
            basicClientCookie.setDomain(parseCookieString(cookie, "domain")[1]);
        }

        //expires
        if (cookie.contains("Expires")) {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("EEE MMM d yyyy HH:mm:ss zZ (zz)");
            Date expires = dateTimeFormatter.parseDateTime(parseCookieString(cookie, "Expires")[1]).toDate();
            basicClientCookie.setExpiryDate(expires);
        }
        setCookie(basicClientCookie);
    }

    public org.apache.http.cookie.Cookie getApacheCookie() {
        return apCookie;
    }

    public org.openqa.selenium.Cookie getSeleniumCookie() {
        return selCookie;
    }

    @Override
    public String toString() {
        return apCookie.getName() + "=" + apCookie.getValue() + "; " +
                "path=" + apCookie.getPath() + "; domain=" + apCookie.getDomain() + "; Expires=" + apCookie.getExpiryDate() + ";";
    }

    private String[] parseCookieString(String cookieString, String searchKey) {
        cookieString = cookieString.substring(cookieString.indexOf(searchKey));
        String name = cookieString.split("=")[0];
        String value = cookieString.split("=")[1].split(";")[0];
        return new String[]{name, value};
    }

    private org.openqa.selenium.Cookie convert(org.apache.http.cookie.Cookie cookie) {
        return new org.openqa.selenium.Cookie(cookie.getName(), cookie.getValue(),
                cookie.getDomain(), cookie.getPath(), cookie.getExpiryDate(), cookie.isSecure());
    }

    private org.apache.http.cookie.Cookie convert(org.openqa.selenium.Cookie cookie) {
        BasicClientCookie basicClientCookie = new BasicClientCookie(cookie.getName(), cookie.getValue());
        basicClientCookie.setDomain(cookie.getDomain());
        basicClientCookie.setPath(cookie.getPath());
        basicClientCookie.setExpiryDate(cookie.getExpiry());
        basicClientCookie.setSecure(cookie.isSecure());
        return basicClientCookie;
    }
}
