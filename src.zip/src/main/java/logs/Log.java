package logs;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Reporter;

import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.function.Consumer;

public class Log {

    public static boolean debugEnabled = true;
    public static boolean allLogging = true;
    public static HashMap<String, Consumer<String>> customLogging = new HashMap<>();
    public static String[] lastMessage = {"", "", ""};
    public static int messageCount = 0;

    //configure the logger to work for us
    static {
        try {
            System.setProperty("log4j.configurationFile", Log.class.getClassLoader().getResource("log4j2.xml").toURI().toURL().toString());
        } catch (MalformedURLException | URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public static void info(String msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsInfo(msg, className, testName);
    }

    public static void debug(String msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsDebug(msg, className, testName);
    }

    public static void error(String msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className, testName);
    }

    public static void error(Exception msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className, testName);
    }

    public static void warn(String msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsWarning(msg, className, testName);
    }

    public static void warn(Exception msg, String className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className, testName);
    }

    public static void info(String msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsInfo(msg, className.getName(), testName);
    }

    public static void debug(String msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsDebug(msg, className.getName(), testName);
    }

    public static void error(String msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className.getName(), testName);
    }

    public static void error(Throwable msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className.getName(), testName);
    }

    public static void warn(String msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsWarning(msg, className.getName(), testName);
    }

    public static void warn(Exception msg, Class className) {
        String testName = Thread.currentThread().getName();
        logAsError(msg, className.getName(), testName);
    }

    private static void logAsInfo(String msg, String className, String testName) {
        String[] thismsg = {msg == null ? "null" : msg, className == null ? "null" : className, testName == null ? "null" : testName};
        if (lastMessage[0].equals(thismsg[0]) && lastMessage[1].equals(thismsg[1])) {
            ++messageCount;
            return;
        }
        else if (messageCount > 0) {
            int mc = messageCount;
            messageCount = 0;
            logAsInfo(lastMessage[0] + " (X" + mc + ")", lastMessage[1], lastMessage[2]);
        }
        if (allLogging) {
            lastMessage = thismsg;
            Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] " + msg;
            String htmlLine = "<b><font color='blue'>[INFO]</font></b> " + markLinks(line) + "<br>";
            logger.info(line);
            customLogging(testName, "[INFO]" + line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static void logAsDebug(String msg, String className, String testName) {
        if (debugEnabled && allLogging) {
            Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] " + msg;
            String htmlLine = "<b><font color='green'>[DEBUG]</font></b> " + markLinks(line) + "<br>";
            logger.debug(line);
            customLogging(testName, "[DEBUG]" + line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static void logAsError(String msg, String className, String testName) {
        if (allLogging) {
            final Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] " + msg;
            String htmlLine = "<b><font color='red'>[ERROR]</font></b> " + markLinks(line) + "<br>";
            logger.error(line);
            customLogging(testName, "[ERROR]" + line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static void logAsWarning(String msg, String className, String testName) {
        if (allLogging) {
            final Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] " + msg;
            String htmlLine = "<b><font color='orange'>[WARN]</font></b> " + markLinks(line) + "<br>";
            logger.warn(line);
            customLogging(testName, "[WARN]" + line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static void logAsError(Throwable msg, String className, String testName) {
        if (allLogging) {
            final Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] Exception -> message: " + msg.getMessage() + "\n Caused By: " + msg.getCause() +
                    "\n stack trace: " + msg.getStackTrace();
            String htmlLine = "<b><font color='red'>[ERROR]</font></b> " + line + "<br>";
            logger.error(line);
            customLogging(testName, "[ERROR]" + line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static void logAsWarning(Exception msg, String className, String testName) {
        if (allLogging) {
            final Logger logger = LogManager.getLogger(className);
            String line = "[" + testName + "] Exception -> message: " + msg.getMessage() + "\n Caused By: " + msg.getCause() +
                    "\n stack trace: " + msg.getStackTrace();
            String htmlLine = "<b><font color='orange'>[WARN]</font></b> " + line + "<br>";
            logger.warn(line);
            Reporter.log(htmlLine);
            FileWriter.instance(testName).write(htmlLine);
        }
    }

    private static String markLinks(String line) {

        String finalLine = line.replaceAll("<[^<]+?>", "");
        for (String word : line.split(" ")) {
            if (word.startsWith("http")) {
                String html = "<a href='" + word + "'>" + word + "</a>";
                finalLine = finalLine.replace(word, html);
            }
        }
        return finalLine;
    }

    private static void customLogging(String testname, String line) {
        if (customLogging.containsKey(testname)) {
            customLogging.get(testname).accept(line);
        }
    }
}
