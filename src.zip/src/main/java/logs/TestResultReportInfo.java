package logs;

import configuration.PropertyReader;

import java.util.Arrays;

public class TestResultReportInfo {

    private String teamName;

    public enum TestStatus {PASSED, FAILED, EXECUTING;}

    private final ReportingInfo testInfo;
    private final TestStatus testStatus;
    private String error;
    private String path;
    private String testExecIssue;

    public TestResultReportInfo(ReportingInfo info, TestStatus status) {
        testInfo = info;
        testStatus = status;
    }

    public TestStatus getTestStatus() {
        return testStatus;
    }

    public String getIssueKey() {
        String issue;
        switch (getBrowser()) {
            case "firefox":
                issue = testInfo.firefoxIssue();
                break;
            case "chrome":
                issue = testInfo.chromeIssue();
                break;
            default:
                issue = "NOT_SUPPORTED";
        }
        return issue;
    }

    public String getEnv() {
        return PropertyReader.instance().getProperty("env");
    }

    public String getBrowser() {
        return PropertyReader.instance().getProperty("browserName");
    }

    public String getResultUrl() {
        final PropertyReader propertyReader = PropertyReader.instance();
        if (propertyReader.hasProperty("JOB_NAME") && propertyReader.hasProperty("BUILD_NUMBER")) {
            propertyReader.setProperty("JOB_NAME", propertyReader.getProperty("JOB_NAME").replace("/", "/job/"));
            return propertyReader.findAndReplaceProperties("https://jenkins-qa.corp.rainfocus.com/job/{{JOB_NAME}}/{{BUILD_NUMBER}}/artifact/test-output/screenshot.html");
//            return PropertyReader.instance().findAndReplaceProperties("https://rainfocustesting.westus.cloudapp.azure.com/job/{{JOB_NAME}}/{{BUILD_NUMBER}}/artifact/test-output/index.html");
        } else return "";
    }

    public String getTeam() {
        return teamName;
//        return testInfo.team().name().toLowerCase();
    }


    public void setTeam(String team) {
        teamName = team;
    }

    public String getError() {
        return error;
    }

    public void setError(Throwable error) {
        StringBuilder errormsg = new StringBuilder();
        errormsg.append(error.getMessage())
                .append("\nCaused By: ")
                .append(error.getCause())
                .append("\n");
        Arrays.stream(error.getStackTrace()).map(e->"\t"+e+"\n").forEach(errormsg::append);

        this.error = errormsg.toString();
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }

    public String getTestExecIssue() {
        return testExecIssue;
    }

    public void setTestExecIssue(String testExecIssue) {
        Log.info("Test Execution issue set to " + testExecIssue, getClass());
        this.testExecIssue = testExecIssue;
    }
}
