package logs;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface ReportingInfo {
    public static final String TROGDOR = "TROGDOR";
    public static final String DATATRON = "DATATRON";
    public static final String ONSITE = "ONSITE";
    public static final String BLUE = "BLUE";
    public static final String AUTOMATIONTEAM = "AUTOMATIONTEAM";
    public static final String REGITEL = "REGITEL";
    public static final String PBJ = "PBJ";
    public static final String API = "API";
    public static final String TRIAGE = "TRIAGE";
    public static final String PRODUCTION = "prodTest";
    public static final String PLANNERTEERS = "PLANNERTEERS";
    public static final String TVA = "TVA";
    public static final String OPTIMUS = "OPTIMUS";
    public static final String NETWOOKIE = "NETWOOKIE";

    public static final String[] ALLTEAMS = new String[]{TROGDOR, DATATRON, ONSITE, BLUE, AUTOMATIONTEAM, REGITEL, PBJ, API, TRIAGE, PLANNERTEERS, TVA, OPTIMUS, NETWOOKIE};

    String firefoxIssue();

    String chromeIssue();
}
