package logs;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;

public class FileWriter {

    private static HashMap<String, FileWriter> instances = new HashMap<>();

    private final File fileName;
    private static final String extension = ".html";

    private FileWriter(File name) {
        fileName = name;
        if (fileName.exists()) {
            fileName.delete();
        }
    }

    public static FileWriter instance(String name) {
        if (!instances.containsKey(name)) {
            File file = new File(getFilePath(name) + extension);
            instances.put(name, new FileWriter(file));
        }
        return instances.get(name);
    }

    public void write(String line) {
        line += "\n";
        synchronized (fileName) {
            try {
                if (!fileName.exists()) {
                    if (fileName.getPath().contains("/")) {
                        String dirs = fileName.getPath().substring(0, fileName.getPath().lastIndexOf("/"));
                        Files.createDirectories(Paths.get(dirs));
                    }
                    fileName.createNewFile();
                }
                Files.write(Paths.get(fileName.getPath()), line.getBytes(), StandardOpenOption.APPEND);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String getFilePath(String name) {
        return name.replace(".", "/");
    }
}
