package apps.workflows;

import apps.App;
import apps.PageConfiguration;
import apps.admin.AdminApp;
import apps.admin.adminPageObjects.workflows.WorkflowEditPage;
import apps.admin.forms.Form;
import apps.workflows.workflowsPageObjects.WorkflowCreateAccountPage;
import apps.workflows.workflowsPageObjects.WorkflowPage;
import configuration.PropertyReader;
import logs.Log;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import testHelp.MyJson;
import testHelp.Utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class WorkflowsApp extends App {

    private HashMap<String, Form> forms;
    private JSONObject workflowJson;

    public WorkflowsApp() {
        forms = new HashMap<>();
    }

    public List<String> findFormIds() {
        return findForms(workflowJson);
    }

    public void setWorkflowJson(JSONObject json) {
        workflowJson = json;
    }

    public JSONObject getWorkflowJson() {
        return workflowJson;
    }

    public String getFormIdFromURI(String uri) {
        return getFormIdsFromURI(uri).get(0);
    }

    public List<String> getFormIdsFromURI(String uri) {
        List<String> formIds = new ArrayList<>();

        //find node with URI
        JSONObject foundStorage = findValueInJsonList("uri", uri, MyJson.getJSONArray(workflowJson,"nodes"));
        String id = MyJson.getString(foundStorage,"id");

        //find all actions associated with URI - get them form ids
        List<JSONObject> actions = findValuesInJsonList("node", id, MyJson.getJSONArray(workflowJson,"actions"));
        for (JSONObject action : actions) {
            //see if the action has a form id
            if (action.has("formId")) {
                formIds.add(MyJson.getString(action,"formId"));
            }
        }

        return formIds;
    }

    public String getUrl(String orgName, String eventName, String workflowURI) {
        String eventCode = PropertyReader.instance().getProperty(eventName.replace(" ", "") + "Code");
        return getUrl("/" + orgName + "/" + eventCode + "/" + workflowURI);
    }

    //=============================== web page objects ===============================
    public void addForm(Form form) {
        Log.info("adding form " + form.getFormId() + " form looks like this:\n" + form.getFormAttributes(), getClass());
        forms.put(form.getFormId(), form);
    }

    public void addForm(Form form, String id) {
        Log.info("adding form " + id + " form looks like this:\n" + form.getFormAttributes(), getClass());
        forms.put(id, form);
    }

    public WorkflowPage getFormPage(String uri) {
        String formId = getFormIdFromURI(uri);
        return new WorkflowPage(forms.get(formId));
    }

    public WorkflowCreateAccountPage getCreateAccountPage() {
        Form accountForm = forms.get(getFormIdFromURI("createaccount"));
        return new WorkflowCreateAccountPage(accountForm);
    }
    //================================================================================

    //================================== REST actions ================================
    @Override
    public String getHost() {
        return PropertyReader.instance().getProperty("workflowsUrl");
    }
    //================================================================================

    private List<String> findForms(JSONObject json) {
        ArrayList<String> formIds = new ArrayList<>();

        JSONArray actions = MyJson.getJSONArray(json,"actions");
        for (int i = 0; i < actions.length(); ++i) {
            JSONObject action = MyJson.getJSONObject(actions, i);
            if (action.has("formId")) {
                formIds.add(MyJson.getString(action,"formId"));
            }
        }
        return formIds;
    }

    private JSONObject findValueInJsonList(String key, String value, JSONArray json) {
        for (int i = 0; i < json.length(); ++i) {
            if (MyJson.getJSONObject(json, i).has(key) && MyJson.getString(MyJson.getJSONObject(json, i), key).equals(value))
                return MyJson.getJSONObject(json, i);
        }
        return new JSONObject();
    }

    private List<JSONObject> findValuesInJsonList(String key, String value, JSONArray json) {
        ArrayList<JSONObject> found = new ArrayList<>();
        for (int i = 0; i < json.length(); ++i) {
            if (MyJson.getJSONObject(json, i).has(key) && MyJson.getString(MyJson.getJSONObject(json, i), key).equals(value))
                found.add(MyJson.getJSONObject(json, i));
        }
        return found;
    }

    private List<String> attributesToIgnore() {
        return Arrays.asList(PropertyReader.instance().getProperty("ignoreAttributes").split(","));
    }


    public void navigate(String url, String page) {
        logs.Log.info("Browser going to " + url + "/" + page, getClass());
        PageConfiguration.getPage().navigateTo(url + "/" +page);
    }

    public String setupWorkflowAndGetUri(AdminApp adminApp, String workflowId) {
        JSONObject workflowJson = adminApp.getWorkflowJson(workflowId);
        setWorkflowJson(workflowJson);
        String uri = WorkflowEditPage.getPage(workflowId).getUri();
        for (String id : findFormIds()) {
            if(StringUtils.isBlank(id))
                continue;

            addForm(adminApp.getForm(id), id);
        }

        //set the workflow url
        return uri;
    }

    public void fillOutFormAndSubmit(String uri) {
        WorkflowPage page = fillOutForm(uri);
        page.submitForm();
    }

    public void fillOutFormAndSubmit(String uri, HashMap<String, String> customValues) {
        WorkflowPage page = fillOutForm(uri, customValues);
        page.submitForm();
    }

    public WorkflowPage fillOutForm(String uri) {
        assertCorrectUrlForPage(uri);
        WorkflowPage page = getFormPage(uri);
        return fillOutForm(page);
    }

    public WorkflowPage fillOutForm(WorkflowPage page) {
        //assert the uri is right
        page.fillOutForm();
        Assert.assertTrue(page.isDisplayNameMatch(), "did not find the correct display names");
        return page;
    }

    public WorkflowPage fillOutForm(String uri, HashMap<String, String> customValues) {
        assertCorrectUrlForPage(uri);
        WorkflowPage page = getFormPage(uri);
        return fillOutForm(page, customValues);
    }

    public WorkflowPage fillOutForm(WorkflowPage page, HashMap<String, String> customValues) {
        //assert the uri is right
        page.fillOutForm(customValues);
        Assert.assertTrue(page.isDisplayNameMatch(), "did not find the correct display names");
        return page;
    }

    public void assertCorrectUrlForPage(String uri) {
        Assert.assertTrue(Utils.waitForTrue(()-> PageConfiguration.getPage().getCurrentUrl().split("\\?")[0].endsWith(uri), 10)
                ,"not on the right page, expected " + uri + " full url was " + PageConfiguration.getPage().getCurrentUrl());
    }

    public String findNonZeroPackageId(JSONArray jsonArray) {

        for(int i = 0; i < jsonArray.length(); ++i) {
            try {
                //get the price
                int price = jsonArray.getJSONObject(i).getInt("price");
                //if it has a price get the package id
                if (price > 0) {
                    String packageId = jsonArray.getJSONObject(i).getString("id");
                    return packageId;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        //no package found returning null
        return null;
    }
}

