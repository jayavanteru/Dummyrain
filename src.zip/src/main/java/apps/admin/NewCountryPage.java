package apps.admin;

import interaction.pageObjects.WebPage;
import interaction.pageObjects.rfBy;
import org.openqa.selenium.By;

public class NewCountryPage extends WebPage {

  protected final By TWO_CHARACTER_CODE_INPUT = rfBy.datatest("rf-text-input-node-country-id-input");
  protected final By THREE_CHARACTER_CODE_INPUT = rfBy.datatest("rf-text-input-node-tricode-input");
  protected final By COUNTRY_DISPLAY_NAME_INPUT = rfBy.datatest("rf-text-input-node-country-name-input");
  protected final By CALLING_CODE_INPUT = rfBy.datatest("rf-text-input-node-calling-code-input");
  protected final By NUMERIC_CODE_INPUT = rfBy.datatest("rf-text-input-node-numeric-code-input");
  protected final By LONGITUDE_INPUT = rfBy.datatest("rf-text-input-node-longitude-input");
  protected final By LATITUDE_INPUT = rfBy.datatest("rf-text-input-node-latitude-input");
  protected final By SAVE_BUTTON = By.xpath("//span[text()='Save']");

  public static NewCountryPage getPage() {
    return initialize(NewCountryPage.class);
  }

  public void navigate() {
    navigateTo(getData("adminUrl") + "/rain.focus#country.do");
  }

  public void fillCountryInformation(String twoCharacterCode, String threeCharacterCode, String countryName, String callingCode, String numericCode, String longitude, String latitude) {
    setTwoCharacterCode(twoCharacterCode);
    setThreeCharacterCode(threeCharacterCode);
    setCountryDisplayName(countryName);
    setCallingCode(callingCode);
    setNumericCode(numericCode);
    setLongitude(longitude);
    setLatitude(latitude);
  }

  public void setTwoCharacterCode(String code) {
    scrollToElement(TWO_CHARACTER_CODE_INPUT);
    click(TWO_CHARACTER_CODE_INPUT);
    sendKeys(TWO_CHARACTER_CODE_INPUT, code);
  }

  public void setThreeCharacterCode(String code) {
    scrollToElement(THREE_CHARACTER_CODE_INPUT);
    click(THREE_CHARACTER_CODE_INPUT);
    sendKeys(THREE_CHARACTER_CODE_INPUT, code);
  }

  public void setCountryDisplayName(String name) {
    scrollToElement(COUNTRY_DISPLAY_NAME_INPUT);
    clearWithBackSpace(COUNTRY_DISPLAY_NAME_INPUT);
    click(COUNTRY_DISPLAY_NAME_INPUT);
    sendKeys(COUNTRY_DISPLAY_NAME_INPUT, name);
  }

  public void setCallingCode(String code) {
    scrollToElement(CALLING_CODE_INPUT);
    click(CALLING_CODE_INPUT);
    sendKeys(CALLING_CODE_INPUT, code);
  }

  public void setNumericCode(String code) {
    scrollToElement(NUMERIC_CODE_INPUT);
    click(NUMERIC_CODE_INPUT);
    sendKeys(NUMERIC_CODE_INPUT, code);
  }

  public void setLongitude(String longitude) {
    scrollToElement(LONGITUDE_INPUT);
    click(LONGITUDE_INPUT);
    sendKeys(LONGITUDE_INPUT, longitude);
  }

  public void setLatitude(String latitude) {
    scrollToElement(LATITUDE_INPUT);
    click(LATITUDE_INPUT);
    sendKeys(LATITUDE_INPUT, latitude);
  }

  public void save() {
    scrollToElement(SAVE_BUTTON);
    click(SAVE_BUTTON);
    waitForPageLoad();
    justWait();
  }

  public boolean existText(String text) {
    justWait();
    return isElementOnPage(By.xpath("//*[text()='" + text + "']"));
  }

  public String getCountryNameValue() {
    justWait();
    waitForPageLoad();
    return findElement(COUNTRY_DISPLAY_NAME_INPUT).getAttribute("value");
  }
}
