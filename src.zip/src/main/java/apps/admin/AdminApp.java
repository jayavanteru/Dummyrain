package apps.admin;

import apps.App;
import apps.PageConfiguration;
import apps.admin.adminHelpers.Criteria;
import apps.admin.adminPageObjects.*;
import apps.admin.adminPageObjects.Demos.DemoRoles.CreateDemoRolePage;
import apps.admin.adminPageObjects.Demos.DemoRoles.DemoRoleSearchPage;
import apps.admin.adminPageObjects.Demos.Demos.CreateDemoPage;
import apps.admin.adminPageObjects.analysis.birstReporting.NewReportPage;
import apps.admin.adminPageObjects.content.*;
import apps.admin.adminPageObjects.exhibits.*;
import apps.admin.adminPageObjects.libraries.*;
import apps.admin.adminPageObjects.manageUsers.EditUserPage;
import apps.admin.adminPageObjects.meetings.*;
import apps.admin.adminPageObjects.onsite.GiftSearchPage;
import apps.admin.adminPageObjects.onsite.NewGiftPage;
import apps.admin.adminPageObjects.profile.PersistentProfileForm;
import apps.admin.adminPageObjects.registration.*;
import apps.admin.adminPageObjects.workflows.*;
import apps.admin.events.EventSearchPage;
import apps.admin.forms.Form;
import apps.admin.forms.FormApi;
import configuration.PropertyReader;
import interaction.DriverManager;
import interaction.api.ApiConfig;
import interaction.api.apiObjects.ApiBodies.ApiBody;
import interaction.api.apiObjects.BodyFromFile;
import interaction.awsDatabase.DbQueryConfig;
import interaction.awsDatabase.DbQueryRunner;
import interaction.loadTesting.QueueReader;
import interaction.webUI.NetworkRequest;
import logs.Log;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.joda.time.DateTime;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import testHelp.DataGenerator;
import testHelp.MyJson;
import testHelp.Utils;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AdminApp extends App {
    public static String orgIBMCode = "nGHYGAOXirpk2EuFF1rMzwEXr2KQMqiw4g2ImBOf";
    public static String orgNicVanityURLTestCode = "1TePxGuIcfwVrgagzvN7uHRllQbJ95ewC3g8geD8";
    public static String orgRFAutomationCode = "TLypgYbLgW1FSCBJcqZUuBVQqD8qF2CFewd1j3bg";

    private ResultSet resultSet;

    public void getToTestOrgFromLogin() {
        AdminLoginPage.getPage().login();
        AdminOrgPage.getPage().openTestOrg();
    }

    public void loginApi() {
        //get a token
//        post("/processLogin.do")
        PropertyReader reader = PropertyReader.instance();
        JSONObject body = new JSONObject();
        MyJson.put(body, "email", reader.getProperty("adminEmail"));
        MyJson.put(body, "password", reader.getProperty("adminPassword"));

        JSONObject post = post("/processLogin?email=" + reader.getProperty("adminEmail") +
                "&password=" + reader.getProperty("adminPassword"));
        setrfcsrf();
    }

    public void setrfcsrf() {
        //get the rfcsrf and save it
        JSONObject get = get("/rain.focus");
        final Matcher matcher = Pattern.compile("(?<=var rfcsrf = \").*?(?=\")").matcher(MyJson.getString(get, "data"));
        if (matcher.find()) {
            Log.info("adding rfcsrf to the header", getClass());
            ApiConfig.permanentHeaders.put("rfcsrf", matcher.group());
        }
    }

    public Form getForm(String formcode) {
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(formcode);
        Assert.assertEquals(FormsSearchPage.getPage().getResults().size(), 1);
        String formId = FormsSearchPage.getPage().getFirstId();

        return getFormFromId(formId);
    }

    public Form getFormFromId(String formid) {
        //make api call
        JSONObject result = PageConfiguration.getPage().post(getHost() +"/formJson.focus?id=" + formid).getResponse();

        //convert it to a form object
        return new Form(result);
    }

    public Form getFormApi(String formId, String... replaceFields) {
        //get the form json
        JSONObject result = post("/formJson.focus?id=" + formId);

        //make the response a Form object
        Form form = new FormApi(result);

        //any fields that we want set values for, do that here
        for (int i = 0; i < replaceFields.length; ++i) {
            form.addOverride(replaceFields[i], replaceFields[++i]);
        }
        return form;
    }

    public JSONObject getWorkflowJson(String workflowId) {
        WorkflowEditPage workflowEditPage = WorkflowEditPage.getPage(workflowId);
        //go to the workflow
        workflowEditPage.navigate();

        return MyJson.createJSON(workflowEditPage.getJson());
    }

    public JSONObject saveObjectApi(String formid, Form savingObject) {
        return postAsUrlParams("/saveObject.focus",
                        MyJson.createJSON("{'formId':'"+formid+"', 'valueMapJson':'"+savingObject.getValueMapJson()+"'}"));
    }

    public JSONObject saveFormApi(String formid, String objectid, Form savingObject) {
        return postAsUrlParams("/saveRenderedForm.focus",
                MyJson.createJSON("{'id':'"+formid+"','objectId':'"+objectid+"', 'valueMapJson':'"+savingObject.getValueMapJson()+"'}"));
    }

    public String createAttendee(String email, String password) {
        CreateAttendeePage createAttendeepage = CreateAttendeePage.getPage();
        Utils.sleep(200);
        createAttendeepage.navigate();
        createAttendeepage.fillOutForm(email);

        //set password of attendee
        EditAttendeePage.getPage().openEditLogin();
        EditLoginPage.getPage().changePasswordTo(password);
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1];
    }

    public String createAttendee(String email) {
        CreateAttendeePage createAttendeepage = CreateAttendeePage.getPage();
        createAttendeepage.navigate();
        createAttendeepage.fillOutForm(email);

        //get the id from the url
        PageConfiguration.getPage().waitForPageLoad();
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        String id = url[url.length - 1].split("&")[0];
        //should be 20 digit id, if not then you got the wrong one

        AdminGenericPage.getPage().waitForReactReady();
        return id.length() == 20 ? id : null;
    }

    public String createAttendee(String email, String firstName, String lastName) {
        CreateAttendeePage createAttendeepage = CreateAttendeePage.getPage();
        createAttendeepage.navigate();
        Utils.sleep(500);
        createAttendeepage.fillOutForm(email, firstName, lastName);

        //get the id from the url
        PageConfiguration.getPage().waitForPageLoad();
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        String id = url[url.length - 1].split("&")[0];
        //should be 20 digit id, if not then you got the wrong one

        AdminGenericPage.getPage().waitForReactReady();
        return id.length() == 20 ? id : null;
    }

    public String createAttendee() {
        String email = new DataGenerator().generateEmail();
        return createAttendee(email);
    }

    public String createAttendeeWithName(String name) {
        String email = new DataGenerator().generateValidEmail();
        CreateAttendeePage createAttendeepage = CreateAttendeePage.getPage();
        createAttendeepage.navigate();
        createAttendeepage.fillOutForm(email, name, PropertyReader.instance().getProperty("attendeeLastName"));

        //get the id from the url
        PageConfiguration.getPage().waitForPageLoad();
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        String id = url[url.length - 1].split("&")[0];
        //should be 20 digit id, if not then you got the wrong one
        return id.length() == 20 ? id : null;
    }

    public String createSessionRoom(String roomName) {
      NewSessionRoomPage newSessionRoomPage = NewSessionRoomPage.getPage();
      newSessionRoomPage.navigate();

      newSessionRoomPage.setRoomName(roomName);
      newSessionRoomPage.setRoomSingleCapacity(20);
      newSessionRoomPage.clickSubmitButton();

      // wait for the search page to load
      PageConfiguration.getPage().waitForPageLoad();
      AdminGenericPage.getPage().waitForReactReady();

      RoomsSearchPage roomsSearchPage = RoomsSearchPage.getPage();
      roomsSearchPage.searchFor(roomName);
      return roomsSearchPage.getTopResultId();
    }

    public String createDay(String dayName, String date, String abbreviation)
    {
        NewSessionDayPage newSessionDayPage = new NewSessionDayPage();
        newSessionDayPage.navigate();

        PageConfiguration.getPage().waitForPageLoad();
        newSessionDayPage.setDayName(dayName);
        newSessionDayPage.setDate(date);
        newSessionDayPage.setAbbreviation(abbreviation);
        newSessionDayPage.clickSubmitButton();

        PageConfiguration.getPage().waitForPageLoad();
        AdminGenericPage.getPage().waitForReactReady();

        SessionDaysSearchPage daysSearchPage = SessionDaysSearchPage.getPage();
        daysSearchPage.searchFor(dayName);
        return daysSearchPage.getTopResultId();
    }

    public String createGift(String name) {
        NewGiftPage newGiftPage = NewGiftPage.getPage();
        newGiftPage.navigate();
        newGiftPage.setName(name);
        newGiftPage.setQuantity("100");
        newGiftPage.setAttribute("Attendee Type: Vendor");
        newGiftPage.clickHasData();
        newGiftPage.clickSubmit();
        GiftSearchPage.getPage().searchFor(name);
        GiftSearchPage.getPage().editGift(name);
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1];
    }

    public String createSession() {
        SessionSearchPage searchPage = SessionSearchPage.getPage();
        Utils.sleep(200);
        searchPage.navigate();
        searchPage.add();
        CreateSessionPage.getPage().filloutForm();

        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        //return the session id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");

        AdminGenericPage.getPage().waitForReactReady();
        return url[url.length - 1].split("&")[0];
    }

    public String createSessionWithLength (String title, int length) {
        SessionSearchPage searchPage = SessionSearchPage.getPage();

        searchPage.navigate();
        searchPage.add();
        CreateSessionPage.getPage().filloutForm(title, length);

        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        //return the session id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");

        AdminGenericPage.getPage().waitForReactReady();
        return url[url.length - 1].split("&")[0];
    }

    public String createSessionWithLength (int length) {
        SessionSearchPage searchPage = SessionSearchPage.getPage();

        searchPage.navigate();
        searchPage.add();
        CreateSessionPage.getPage().filloutForm(length);

        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        //return the session id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");

        AdminGenericPage.getPage().waitForReactReady();
        return url[url.length - 1].split("&")[0];
    }

    public String createSession(String title) {
        SessionSearchPage searchPage = SessionSearchPage.getPage();
        searchPage.navigate();
        searchPage.waitForPageLoad();
        searchPage.add();
        CreateSessionPage.getPage().filloutForm(title);

        //wait to click the link, make sure everything is loaded
        PageConfiguration.getPage().waitForPageLoad();
        //return the session id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createExhibitor() {
        String eventName = PropertyReader.instance().getProperty("event");
        ExhibitorSearchPage searchPage = ExhibitorSearchPage.getPage();
        Utils.sleep(200);
        searchPage.navigate();
        searchPage.add();
        CreateExhibitorPage.getPage().filloutForm(eventName);

        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        //return the exhibitor id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createExhibitor(String exhibitorName) {
        String eventName = PropertyReader.instance().getProperty("event");
        ExhibitorSearchPage searchPage = ExhibitorSearchPage.getPage();
        Utils.sleep(500);
        searchPage.navigate();
        PageConfiguration.getPage().waitForPageLoad();
        searchPage.add();
        Utils.sleep(500, "little bit of time so the exhibitor will save");
        CreateExhibitorPage.getPage().filloutForm(eventName, exhibitorName);

        //wait to click the link, make sure everything is loaded
        Utils.sleep(1000);
        //return the exhibitor id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createExhibitorInCurrentEvent(String exhibitorName){
        CreateExhibitorPage.getPage().navigate();
        CreateExhibitorPage.getPage().setName(exhibitorName);
        CreateExhibitorPage.getPage().setDisplayName(exhibitorName);
        CreateExhibitorPage.getPage().submit();
        CreateExhibitorPage.getPage().addNowToCurrentEvent();

        //return the exhibitor id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createDemoInCurrentEvent(String exhibitorName){
        CreateDemoPage.getPage().navigate();
        CreateDemoPage.getPage().setName(exhibitorName);
        CreateDemoPage.getPage().submit();
        CreateDemoPage.getPage().addNowToCurrentEvent();

        //return the exhibitor id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createBooth(String booth, String exhibitorName){
        BoothsSearchPage searchPage = BoothsSearchPage.getPage();
        NewBoothPage boothPage = NewBoothPage.getPage();
        searchPage.navigate();
        searchPage.waitForPageLoad();
        searchPage.clickAdd();
        boothPage.setName(booth);
        boothPage.setTimesOffered("1");
        try{
            boothPage.setCompany(exhibitorName);
        }catch(Exception e){
            e.printStackTrace();
        }
        boothPage.clickSubmit();
        searchPage.waitForPageLoad();
        searchPage.searchBooth(booth);
        searchPage.editItem();
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1];
    }

    public String createMeeting() {
        NewMeetingPage createPage = NewMeetingPage.getPage();
        Utils.sleep(200);
        createPage.navigate();
        createPage.createMeeting();

        //return the meeting id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }


    public String createMeeting(String meetingName) {
        NewMeetingPage createPage = NewMeetingPage.getPage();
        Utils.sleep(200);
        createPage.navigate();
        createPage.createMeeting();
        EditMeetingPage.getPage().setAbstract();
        EditMeetingPage.getPage().setTitle(meetingName);
        EditMeetingPage.getPage().submit();

        //return the meeting id
        Utils.waitForTrue(()->PageConfiguration.getPage().getCurrentUrl().contains("id="));
        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1].split("&")[0];
    }

    public String createSurvey(String name) throws Exception
    {
        PageConfiguration.getPage().startNetworkMonitoring();
        SurveysSearchPage searchPage = SurveysSearchPage.getPage();
        searchPage.navigate();
        searchPage.waitForPageLoad();
        searchPage.addItem();
        CreateSurveyPage createPage = CreateSurveyPage.getPage();
        createPage.selectType("Attendee");
        createPage.setName(name);
        createPage.submit();

        Utils.waitForTrue(()-> PageConfiguration.getPage().getCurrentUrl().contains("surveys.do"));
        NetworkRequest request = PageConfiguration.getPage().getRequestByEndpoint("processForm.focus");
        PageConfiguration.getPage().stopNetworkMonitoring();
        String responseData = request.getResponseContent();
        String surveyId = new JSONObject(responseData).getJSONObject("data").getJSONObject("form").getString("formId");
        return surveyId;
    }

    public JSONObject changePasswordApi(String attendeeId, String newPassword) {
        return postAsUrlParams("/processEditLogin.focus", MyJson.createJSON("{attendeeId:'"+attendeeId+"',newPassword:'"+newPassword+"',forceChangePassword:'false'}"));
    }

    public String getAttendeeIdApi(String search) {
        String attendeeId = null;
        JSONObject searchBody = MyJson.createJSON("{\"columnOptionJson\":\"[{\\\"optionId\\\":\\\"15445927277954596866\\\",\\\"type\\\":\\\"attendees\\\",\\\"valueId\\\":null}]\"," +
                "\"param\":\""+search+"\",\"regcode\":\"\",\"paid\":\"\",\"registered\":\"\",\"formPojoJson\":\"{}\",\"ajaxSearch\":true,\"inventoryitemId\":\"\"}");

        JSONObject result = postAsUrlParams("/attendeesSearch.do", searchBody);
        try {
            JSONArray jsonArray = result.getJSONObject("data").getJSONArray("list");
            for (int i = 0; i < jsonArray.length() && attendeeId == null; ++i) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (search.equals(jsonObject.getString("email"))){
                    attendeeId = jsonObject.getString("attendee_id");
                }
            }
        } catch (JSONException e) {
            Log.error(e, getClass());
        }

        return attendeeId;
    }

    public JSONObject deleteAttribute(String attributeId) {
        return PageConfiguration.getPage().post(getHost() + "/processAttributeDelete.focus?id=" + attributeId).getResponse();
    }

    public JSONObject deleteAttendee(String attendeeId) {
        return PageConfiguration.getPage().post(getHost() + "/attendeeDelete.focus?id=" + attendeeId).getResponse();
    }

    public JSONObject deleteAttendeeApi(String attendeeId) {
        return post("/attendeeDelete.focus?id=" + attendeeId);
    }

    public JSONObject deleteAccessRule(String accessRuleId) {
        return PageConfiguration.getPage().post(getHost() + "/scheduleAccessDelete.focus?id=" + accessRuleId).getResponse();
    }

    public JSONObject deleteSession(String sessionId) {
        return PageConfiguration.getPage().post(getHost() + "/sessionDelete.focus?id=" + sessionId).getResponse();
    }

    public JSONObject deleteSessionLength(Integer sessionLengthId) {
        return PageConfiguration.getPage().post(getHost() + "/lengthDelete.focus?id=" + sessionLengthId).getResponse();
    }

    public JSONObject deleteSessionRole(String sessionRoleId) {
        return PageConfiguration.getPage().post(getHost() + "/sessionRoleDelete.focus?id=" + sessionRoleId).getResponse();
    }

    public JSONObject deleteGift(String giftId) {
        return PageConfiguration.getPage().post(getHost() + "/spiffDelete.focus?id=" + giftId).getResponse();
    }

    public JSONObject deleteWidget(String widgetId) {
        return PageConfiguration.getPage().post(getHost() + "/deleteWidget.do?id=" + widgetId).getResponse();
    }

    public JSONObject deleteCustomPage(String customPageId){
        return PageConfiguration.getPage().post(getHost() + "/customPageDelete.focus?id=" + customPageId).getResponse();
    }

    public JSONObject deleteSessionRoom(String sessionRoomId) {
        return PageConfiguration.getPage().post(getHost() + "/roomDelete.focus?id=" + sessionRoomId).getResponse();
    }

    public JSONObject deleteSurvey(String surveyId)
    {
        return PageConfiguration.getPage().post(getHost() + "/formDelete.focus?id=" + surveyId).getResponse();
    }

    public JSONObject deleteWorkflow(String workflowId) {
        return PageConfiguration.getPage().post(getHost() + "/deleteWorkflowVersion.focus?override=true&workflowId=" + workflowId).getResponse();
    }

    public JSONObject deletePageBuilder(String pageBuilderId) {
        return PageConfiguration.getPage().post(getHost() + "/deleteDynamicPage.focus?override=true&pageId=" + pageBuilderId).getResponse();
    }

    public boolean isSuccessfulJSONObjectResponse (JSONObject serverResponse) {
        boolean response;

        try {
            response = serverResponse.getJSONObject("data").getString("status").equalsIgnoreCase("success");
        } catch (Exception e) {
            response = false;
        }

        return response;
    }

    public String createAddToScheduleSessionRole (String roleName) {
        NewSessionRolesPage newSessionRolesPage = NewSessionRolesPage.getPage();
        SessionRolesSearchPage sessionRolesSearchPage = SessionRolesSearchPage.getPage();
        DataGenerator dataGenerator = new DataGenerator();

        newSessionRolesPage.navigate();

        newSessionRolesPage.setRoleName(roleName);
        newSessionRolesPage.setRoleDescription(dataGenerator.generateString()); // believe it or not, this is required
        newSessionRolesPage.clickAddToScheduleCheckbox();
        newSessionRolesPage.clickSaveButton();

        PageConfiguration.getPage().waitForPageLoad();

        sessionRolesSearchPage.searchFor(roleName);
        Utils.waitForTrue(()->sessionRolesSearchPage.getResults().get(0).equals(roleName));
        return sessionRolesSearchPage.getTopResultId();
    }

    public JSONObject deleteExhibitor(String exhibitorId) {
        return PageConfiguration.getPage().post(getHost() + "/exhibitorDelete.focus?id=" + exhibitorId).getResponse();
    }

    public void deleteLeadsOrder(String exhibitorId) {
        AdminExhibitorLeadOrdersTab.getPage().navigate(exhibitorId);
        Utils.sleep(1000);
        if (AdminExhibitorLeadOrdersTab.getPage().isAnyOrders()) {
            AdminExhibitorLeadOrdersTab.getPage().selectAllOrders();
            AdminExhibitorLeadOrdersTab.getPage().deleteOrders();
            AdminExhibitorLeadOrdersTab.getPage().toggleCancellationEmail();
            AdminExhibitorLeadOrdersTab.getPage().cancelOrder();
            AdminExhibitorLeadOrdersTab.getPage().clearError();
        }
    }

    public JSONObject deleteExhibitorRole(String exhibitorRoleId) {
        return PageConfiguration.getPage().post(getHost() + "/exhibitorParticipantRoleDelete.focus?id=" + exhibitorRoleId).getResponse();
    }

    public JSONObject deleteExhibitorApi(String exhibitorId) {
        return post("/exhibitorDelete.focus?id=" + exhibitorId);
    }

    public JSONObject deleteRule(String ruleId) {
        return PageConfiguration.getPage().post(getHost() + "/ruleDelete.do?id=" + ruleId).getResponse();
    }

    public JSONObject deleteHotel(String hotelId)
    {
        JSONObject object = new JSONObject();
        MyJson.put(object,"hotelId", hotelId);
        return PageConfiguration.getPage().post(getHost() + "/deleteHotel.focus?hotelId="+hotelId).getResponse();
    }

    public JSONObject deleteSubBlock(String subBlockId)
    {
        JSONObject object = new JSONObject();
        MyJson.put(object,"blockId", subBlockId);
        return PageConfiguration.getPage().post(getHost() + "/deleteSubBlock.focus?blockId="+subBlockId).getResponse();
    }

    public JSONObject deleteSaturnApi(String id) {
        return PageConfiguration.getPage().post(getHost() + "/saturnServerDelete.focus?id=" + id).getResponse();
    }

    public JSONObject deleteAreaApi(String areaId) {
        return PageConfiguration.getPage().post(getHost() + "/deleteArea.do?id=" + areaId).getResponse();
    }

    public JSONObject deleteMeetingProgramOld(String meetingProgramId) {
        MeetingProgramPage meetingProgramPage = MeetingProgramPage.getPage();
        meetingProgramPage.navigate(meetingProgramId);
        meetingProgramPage.goToScheduling();
        Utils.sleep(200);
        MeetingProgramSchedulePage.getPage().clearAllTimes();
        meetingProgramPage.saveAndContinue();
        meetingProgramPage.roomsTab();
        Utils.sleep(500);
        MeetingProgramRoomsPage.getPage().clearAllRooms();
        meetingProgramPage.saveAndContinue();
        Utils.sleep(200);
        MeetingProgramsSearchPage.getPage().navigate();
        return PageConfiguration.getPage().post(getHost() + "/meetingProgramDelete.focus?id=" + meetingProgramId).getResponse();
    }

    public JSONObject deleteMeetingProgram(String meetingProgramId) {
        //clear schedule times
        PageConfiguration.getPage().post(getHost() + "/saveMeetingProgramSchedule.do?meetingProgramId="+meetingProgramId+"&gridInterval=60&summary=false&data=%7B%22meetingLengths%22%3A%5B15%5D%2C%22meetingStartInterval%22%3A60%2C%22selectedScheduleItems%22%3A%5B%5D%7D");

        //clear selected removes
        PageConfiguration.getPage().post(getHost() + "/saveMeetingProgramRooms.do?meetingProgramId="+meetingProgramId+"&data=%7B%22rooms%22%3A%5B%5D%7D");
        //https://app.dev.rainfocus.com/saveMeetingProgramRooms.do
        //meetingProgramId=1597322181748001SJPE&data=%7B%22rooms%22%3A%5B%5D%7D
        return PageConfiguration.getPage().post(getHost() + "/meetingProgramDelete.focus?id=" + meetingProgramId).getResponse();
    }

    public JSONObject deleteMeeting(String meetingId) {
        return PageConfiguration.getPage().post(getHost() + "/sessionDelete.focus?id=" + meetingId).getResponse();
    }

    public JSONObject deleteLocationApi(String id) {
        return PageConfiguration.getPage().post(getHost() + "/badgePrintLocationDelete.focus?id=" + id).getResponse();
    }

    public JSONObject deletePaymentType(String paymentId) {
        return PageConfiguration.getPage().post(getHost() + "/paymentTypeDelete.focus?id=" + paymentId).getResponse();
    }

    public JSONObject deletePackage(String packageId) {
        return PageConfiguration.getPage().post(getHost() + "/eventInventoryItemDelete.focus?itemId=" + packageId).getResponse();
    }

    public JSONObject deleteBooth(String boothId) {
        return PageConfiguration.getPage().post(getHost() + "/booth/delete.focus?itemId=" + boothId).getResponse();
    }

    public JSONObject deleteTask(String taskId) {
        return PageConfiguration.getPage().post(getHost() + "/entityTaskDelete.focus?id=" + taskId).getResponse();
    }

    public JSONObject deleteTaskQualifier(String qualifierId) {
        return PageConfiguration.getPage().post(getHost() + "/entityTaskQualifierDelete.focus?id=" + qualifierId).getResponse();
    }

    public JSONObject deleteForm(String formId) {
        return PageConfiguration.getPage().post(getHost() + "/formDelete.focus?id=" + formId).getResponse();
    }

    public JSONObject deleteWorkingReport(String workingReportID){
        return PageConfiguration.getPage().post(getHost() + "/workingReportDelete.focus?id=" + workingReportID).getResponse();
    }

    public JSONObject deleteRegCodeAllocation(String regCodeAllocationId) {
        return PageConfiguration.getPage().post(getHost() + "/regCodeAllocatorItemDelete.focus?id=" + regCodeAllocationId).getResponse();
    }

    public JSONObject deleteDemoRegCodeAllocation(String regCodeAllocationId) {
        return PageConfiguration.getPage().post(getHost() + "/regCode/demo/allocatorItemDelete.focus?id=" + regCodeAllocationId).getResponse();
    }

    public JSONObject deleteFile(String fileId) {
        return PageConfiguration.getPage().post("/fileDelete.focus?id=" + fileId).getResponse();
    }

    public JSONObject deleteBirstReport(String reportName) {
        return PageConfiguration.getPage().post(getHost() + "/deleteBirstReport.do?data=%7B%22resourceName%22:%22shared%2F"+reportName+".viz.dashlet%22%7D").getResponse();
    }

    public void getToBirstReportPage() {
        String url = NewReportPage.getPage().getiframeUrl();
        Utils.sleep(6000, "wait for some loading before going to the report");

        //load the real page
        PageConfiguration.getPage().navigateTo(url);
        try {
            NewReportPage.getPage().waitForPageToLoad();
        } catch (NoSuchElementException e) {
            Log.warn("the birst page did not load, probably went to the login page, trying again", getClass());
            PageConfiguration.getPage().navigateTo(url);
            NewReportPage.getPage().waitForPageToLoad();
        }
    }

    public JSONObject uploadFile(String attendeeId, String fileTypeId) {
        String boundary = "----WebKitFormBoundary" + new DataGenerator().generateString(5);
        File file = Utils.getResourceAsFile("pic1.jpg");
        ApiConfig config = generateConfigForFileUpload(boundary, file, attendeeId, fileTypeId, "attendees");

        syncCookieFromBrowserToApi();
        JSONObject response = post("/fileUploadToS3.focus", config);
        return response;
    }

    public JSONObject uploadStaticFile() {
        String boundary = "----WebKitFormBoundary" + new DataGenerator().generateString(5);
        File file = Utils.getResourceAsFile("pic1.jpg");
        ApiConfig config = generateConfigForFileUpload(boundary, file);

        syncCookieFromBrowserToApi();
        JSONObject response = post("/uploadStaticFiles.focus", config);
        return response;
    }

    /**
     * Returns Hotel Name
     */
    public String createHotelViaApi() {
        syncCookieFromBrowserToApi();
        final WebDriver browser = PageConfiguration.getPage().getBrowser();
        ApiConfig.permanentHeaders.put("rfcsrf", ((JavascriptExecutor) browser).executeScript("return typeof rfcsrf === 'undefined' ? '' : rfcsrf").toString());

        final DataGenerator dataGenerator = new DataGenerator();
        String boundary = "----WebKitFormBoundary" + dataGenerator.generateString(5);
        final String name = dataGenerator.generateName();
        File file = Utils.getResourceAsFile("pic1.jpg");
        final ApiBody jsonValue = BodyFromFile.getFile("CreateHotel.json");
        jsonValue.get("name").putValue(name);
        final ApiConfig config = generateConfigForFileUpload(boundary, file, (JSONObject) jsonValue.getJsonValue());

        JSONObject response = post("/hotelStore.focus", config);
        System.out.println(response);
        return name;
    }

    public JSONObject uploadFileExhibitors(String attendeeId, String fileTypeId) {
        String boundary = "----WebKitFormBoundary" + new DataGenerator().generateString(5);
        File file = Utils.getResourceAsFile("pic1.jpg");
        ApiConfig config = generateConfigForFileUpload(boundary, file, attendeeId, fileTypeId, "exhibitors");

        syncCookieFromBrowserToApi();
        JSONObject response = post("/fileUploadToS3.focus", config);
        return response;
    }

    private ApiConfig generateConfigForFileUpload(String boundary, File file, String attendeeId, String fileTypeId, String type) {
        HttpEntity input = MultipartEntityBuilder
                .create()
                .setBoundary(boundary)
                .addBinaryBody("fileUpload", file, ContentType.create("image/jpeg"), "pic1.jpg")
                .addTextBody("fileUploadFileName", "pic1.jpg")
                .addTextBody("file.rainfocusId", attendeeId)
                .addTextBody("file.tablename", type)
                .addTextBody("file.filetypeId", fileTypeId)
                .addTextBody("bucket", "rainfocus-public")
                .build();

        ApiConfig apiConfig = new ApiConfig();
        apiConfig.setPostEntity(input);
        apiConfig.setContentType("multipart/form-data; boundary=" + boundary);
        return apiConfig;
    }

    private ApiConfig generateConfigForFileUpload(String boundary, File file) {
        HttpEntity input = MultipartEntityBuilder
                .create()
                .setBoundary(boundary)
                .addBinaryBody("fileUploads", file, ContentType.create("image/jpeg"), "pic1.jpg")
                .addTextBody("fileUploadFileNames", "pic1.jpg")
                .addTextBody("fileUploadContentTypes", "image/jpeg")
                .build();

        ApiConfig apiConfig = new ApiConfig();
        apiConfig.setPostEntity(input);
        apiConfig.setContentType("multipart/form-data; boundary=" + boundary);
        return apiConfig;
    }

    private ApiConfig generateConfigForFileUpload(String boundary, File file, JSONObject json) {
        HttpEntity input = MultipartEntityBuilder
                .create()
                .setBoundary(boundary)
                .addBinaryBody("coverFileUploads[0]", file, ContentType.create("image/jpeg"), "pic1.jpg")
                .addTextBody("coverFileUploadFileNames[0]", file.getName())
                .addTextBody("formJson", json.toString(), ContentType.TEXT_PLAIN)
                .addTextBody("fieldsErrors", "[]")
                .build();

        ApiConfig apiConfig = new ApiConfig();
        apiConfig.setPostEntity(input);
        apiConfig.setContentType("multipart/form-data; boundary=" + boundary);
        return apiConfig;
    }

    public String createPackage(String name, String paymentType) {
        DataGenerator generator = new DataGenerator();
        String code = "auto" + generator.generateString(3);
        NewExhibitorPackagePage newPackage = NewExhibitorPackagePage.getPage();
        newPackage.navigate();
        Utils.sleep(2000);
        newPackage.enterStandardPackageData(name, code, "user", 80);
        newPackage.addPaymentType(paymentType, 1);
        newPackage.submit();
        Utils.sleep(500);

        return ExhibitorPackageSearchPage.getPage().getId(name);
    }

    public String createPaymentType(String paymentTypeName) {
        NewPaymentTypePage paymentTypePage = NewPaymentTypePage.getPage();
        paymentTypePage.navigate();
        paymentTypePage.createPaymentType(paymentTypeName);


        return PaymentTypesSearchPage.getPage().getId(paymentTypeName);
    }

    public String getRuleId(String ruleName) {
        //get all the rules
        JSONObject allRules = PageConfiguration.getPage().post(getHost() +"/rulesSearch.do?returnFullList=false").getResponse();

        //search through them to find THE ONE
        JSONArray jsonArray = MyJson.getJSONArray(MyJson.getJSONObject(MyJson.getJSONObject(allRules, "data"), "results"), "list");
        for (int i = 0; i < jsonArray.length(); ++i) {
            JSONObject ruleInfo = MyJson.getJSONObject(jsonArray, i);
            if (MyJson.getString(ruleInfo, "name").equals(ruleName)) {
                return MyJson.getString(ruleInfo, "rule_id");
            }
        }
        Log.error("did not find the rule id in this json:\n" + jsonArray.toString(), getClass());
        return null;
    }

    public void addSelectAttributeToEvent(String name) {
        //add the parent attribute to the event
        CreateEventAttributePage eventAttributePage = CreateEventAttributePage.getPage();
        eventAttributePage.navigate();
        eventAttributePage.createSelectList(name, new String[]{"testOption1", "testOption2", "testOption3"},
                CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Session);
        eventAttributePage.saveAttribute();
        AdminEventAttributesPage.getPage().waitForPageLoad();
    }

    public void addCheckboxAttributeToEvent(String name) {
        //add the parent attribute to the event
        CreateEventAttributePage eventAttributePage = CreateEventAttributePage.getPage();
        eventAttributePage.navigate();
        eventAttributePage.createCheckBoxList(name, new String[]{"testOption1", "testOption2", "testOption3"},
                CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Session);
        eventAttributePage.saveAttribute();
        AdminEventAttributesPage.getPage().waitForPageLoad();
    }

    public void addRadioAttributeToEvent(String name) {
        //add the parent attribute to the event
        CreateEventAttributePage eventAttributePage = CreateEventAttributePage.getPage();
        eventAttributePage.navigate();
        eventAttributePage.createRadioList(name, new String[]{"testOption1", "testOption2", "testOption3"},
                CreateEventAttributePage.AUDIENCE_TYPES.Exhibitor, CreateEventAttributePage.AUDIENCE_TYPES.Attendee, CreateEventAttributePage.AUDIENCE_TYPES.Session);
        eventAttributePage.saveAttribute();
        Utils.sleep(10000);
        AdminEventAttributesPage.getPage().waitForPageLoad();
    }

    /**
     * import an attendee file
     * @param keyColumn which column to key off of, how it is in the database not UI
     * @param fileContents the keys in the map should map to the json databaseColumn in the api not the UI
     */
    public JSONObject importAttendeeFile(String keyColumn, ArrayList<HashMap<String, String>> fileContents){
        return importAttendeeFile(keyColumn, true, true, fileContents);
    }

    /**
     * import an attendee file
     * @param keyColumn which column to key off of, how it is in the database not UI
     * @param updateRecords will this upload be updating records?
     * @param insertRecords will this upload be inserting new records?
     * @param fileContents the keys in the map should map to the json databaseColumn in the api not the UI
     * @return
     */
    public JSONObject importAttendeeFile(String keyColumn, boolean updateRecords, boolean insertRecords, ArrayList<HashMap<String, String>> fileContents, String... attributeTypeIds) {
        JSONArray records = new JSONArray();
        JSONObject importTemplate = MyJson.createJSON("{" +
                "  'id': null," +
                "  'name': ''," +
                "  'type': 'Attendee Import'," +
                "  'keyColumn': '" + keyColumn + "'," +
                "  'updateRecords': "+ (updateRecords ? "true" : "false") + "," +
                "  'insertRecords': "+ (insertRecords ? "true" : "false") + "," +
                "  'items': []" +
                "}");

        //generate the template items
        Set<String> keySet= fileContents.get(0).keySet();
        String[] keys = keySet.toArray(new String[keySet.size()]);

        try {
            for (int i = 0; i < keys.length; ++i) {
                JSONObject templateItems = MyJson.createJSON("{" +
                        "'databaseColumn': '" + keys[i] + "'," +
                        "'templateColumn': " + i + "," +
                        //if this is an attribute instead of an eventAttendee type
                        (Arrays.asList(attributeTypeIds).contains(keys[i]) ? "'type': 'attribute'}" : "'type': 'eventAttendee'}"));
                importTemplate.getJSONArray("items").put(templateItems);
            }

            //generate the records
            //go through each row
            for (HashMap<String, String> row : fileContents) {
                JSONArray recordRow = new JSONArray();
                //get each key out of each row
                for (int j = 0; j < keys.length; ++j) {
                    recordRow.put(j, row.get(keys[j]));
                }
                records.put(recordRow);
            }
        } catch (JSONException e) {
            Log.error("creating the json file for an attendee import broke", getClass());
            Log.error(e, getClass());
        }

        //now bring it all together
        JSONObject body = MyJson.createJSON("{'importTemplate': '" + importTemplate + "'," +
                "'records': '" + records + "'," +
                "'eventLevel': 'false'}");

        Log.info("uploading body\n" + body.toString(), getClass());
        ApiConfig config = new ApiConfig();
        config.setBody(body);
        config.setContentType("application/json");
        config.setUrl(getHost() + "/uploadRecords.focus");
        return PageConfiguration.getPage().post(config).getResponse();
    }

    public void changePassword(String attendeeId, String password) {
        PageConfiguration.getPage().post(getHost() + "/processEditLogin.focus?attendeeId=" + attendeeId + "&newPassword=" + password + "&forceChangePassword=false");
    }

    public Form setupSurvey(String surveyName, String completedMsg, String surveyId, String email) {

        //create the survey
        EditSurveyPage surveyPage = EditSurveyPage.getPage();
        Criteria criteria = new Criteria("Email", "equal to", email);
        surveyPage.navigate(surveyId);
        surveyPage.clearEditWarning();
        Utils.sleep(500);
        surveyPage.clearEditWarning();

        surveyPage.toggleExpandingSettings();
        surveyPage.setFormName(surveyName);
        surveyPage.setFinishedMessage(completedMsg);
        surveyPage.setClosedDate(DateTime.now().plusDays(60));
//        surveyPage.addNewAttribute(EditFormPage.ATTR_TYPE.TEXT_BOX, "My First Question");
//        surveyPage.toggleRequiredSetting();
//        surveyPage.addNewAttribute(EditFormPage.ATTR_TYPE.SCALE, "A Scale Question");
//        surveyPage.toggleRequiredSetting();
//        surveyPage.addNewAttribute(EditFormPage.ATTR_TYPE.SCALE_MATRIX, "A Matrix Question");
//        surveyPage.toggleRequiredSetting();
        surveyPage.defineAttendees(criteria);
        Utils.sleep(500);
        //set the date to be in the future
        surveyPage.submitForm();
        Utils.sleep(200);
        surveyPage.clearEditWarning();

//        surveyId = FormsSearchPage.getPage().getId(surveyName);

        return getFormFromId(surveyId);
    }

    public JSONObject addSessionToAttendeeSchedule(String attendeeId, String sessionId, String sessionTimeId) {
        return PageConfiguration.getPage().post(getHost() + "/addSession.focus?attendeeId="+attendeeId+"&sessionId="+sessionId+"&sessionTimeId="+sessionTimeId+"&waitlist=false").getResponse();
    }

    public JSONObject removeSessionFromAttendeeSchedule(String attendeeId, String sessionid, String sessionTimeId) {
        return PageConfiguration.getPage().post(getHost() + "/removeSession.focus?attendeeId="+attendeeId+"&sessionId="+sessionid+"&sessionTimeId="+sessionTimeId).getResponse();
    }

    public void setOrgAndEventApi(String orgCode, String eventId) {
        post("/setOrg.do?orgCode=" + orgCode);
        setrfcsrf();
        post("/setEvent.do?eventId=" + eventId);
    }

    public String getAdminUser(String userEmail, String securityRoleMapJson) {
        final DataGenerator dataGenerator = new DataGenerator();
        String createJson = "\"{'email':'"+userEmail+"','firstname':'"+dataGenerator.generateName()+"','lastname':'"+dataGenerator.generateName()+"','navColor':'Pink','dashboard':'birst','superuserall':false}\"";
        PropertyReader properties = PropertyReader.instance();

        ApiConfig config = new ApiConfig(properties.getProperty("adminUrl") + "/userSearch.do","{'pg':1,'securityroleIds':[],'param':'"+userEmail+"'}");
        config.setContentType("application/json");
        PageConfiguration.getPage().post(config);
        if (!config.getResponse().toString().contains(userEmail)) {
            final ApiConfig createConfig = new ApiConfig(properties.getProperty("adminUrl") + "/processUser.focus");
            final ApiBody file = BodyFromFile.getFile("createAdminUser.json");

            file.useOriginal();
            file.get("formJson").putValue(createJson);
            file.get("securityRoleMapJson").putValue("\""+securityRoleMapJson+"\"");

            createConfig.setBody((JSONObject) file.getJsonValue());

            createConfig.setUrlParams(true);
            PageConfiguration.getPage().get(createConfig);

            PageConfiguration.getPage().get(config);
        }
        return config.getResponseAsApiBody().get("user_id").getOriginalValue().toString();
    }

    public synchronized QueueReader<AttendeeCredentials> getAttendeeCredentials(String eventid) {
        if (resultSet == null) {
            DbQueryConfig dbConfig = DbQueryConfig.createConfig("eventattendees",
                    "event_id = '" + eventid + "' and registered = 1 and paid_in_full = 1",
                    "attendee_id", "email", "initial_badge_id");
            resultSet = new DbQueryRunner().runQueryResultSet(dbConfig);
        }

        return new QueueReader<>(this::getUsernamePassword);
    }

    public synchronized QueueReader<AttendeeCredentials> getAttendeeCredentialsWorkflow(String eventid) {
        if (resultSet == null) {
            DbQueryConfig dbConfig = DbQueryConfig.createConfig("eventattendees",
                    "event_id = '" + eventid + "' and registered = 0 and paid_in_full = 0",
                    "attendee_id", "email", "initial_badge_id");
            resultSet = new DbQueryRunner().runQueryResultSet(dbConfig);
        }

        return new QueueReader<>(this::getUsernamePassword);
    }

    public synchronized QueueReader<AttendeeCredentials> getOracleAttendee() {
        if (resultSet == null) {
            //Select field1 from stuff where type = 'crmconfig' and rainfocus_id = '1526776366008001QsMB'
            DbQueryConfig dbConfig = DbQueryConfig.createCustomConfig("select DISTINCT stuff.field1, eventattendees.attendee_id\n" +
                    "from stuff INNER JOIN eventattendees ON eventattendees.email = stuff.field1\n" +
                    "where stuff.type = 'crmconfig' and stuff.rainfocus_id = '1526776366008001QsMB' and eventattendees.event_id = '150393630796000oow18'\n");
            resultSet = new DbQueryRunner().runQueryResultSet(dbConfig);

            setOrgAndEventApi("uzHhFwEof4M4gsB7zbjegHcjH2CvAw4YgDE6HDQt", "150393630796000oow18");
        }

        return new QueueReader<>(this::getUsernamePasswordOracle);
    }

    public class AttendeeCredentials {
        public final String username;
        public final String password;
        public final String attendeeId;
        public final String badgeId;

        public AttendeeCredentials(String username, String password, String attendeeId) {
            this(username, password, attendeeId, "");
        }

        public AttendeeCredentials(String username, String password, String attendeeId, String badgeId) {
            this.username = username;
            this.password = password;
            this.attendeeId = attendeeId;
            this.badgeId = badgeId;
        }
    }

    private AttendeeCredentials getUsernamePassword() {
        AttendeeCredentials userInfo = null;
        String password = "Rainfocus123";

        synchronized (resultSet) {
            try {
                if (resultSet.next()) {
                    String email = resultSet.getString("email");
                    String id = resultSet.getString("attendee_id");
                    String badgeId = resultSet.getString("initial_badge_id");
                    changePasswordApi(id, password);
                    userInfo = new AttendeeCredentials(email, password, id, badgeId);
                } else {
                    System.out.println("Ran out of registered users");
                }
            } catch (SQLException e) {
                Log.error(e, getClass());
                e.printStackTrace();
            }
        }
        return userInfo;
    }

    private AttendeeCredentials getUsernamePasswordOracle() {
        AttendeeCredentials userInfo = null;
        String password = "Rainfocus123";

        synchronized (resultSet) {
            try {
                while (userInfo == null) {
                    if (resultSet.next()) {
                        String email = resultSet.getString("field1");
                        String id = resultSet.getString("attendee_id");

                        if (id != null) {
                            changePasswordApi(id, password);

                            userInfo = new AttendeeCredentials(email, password, id);
                        }
                    } else {
                        System.out.println("Ran out of oracle users");
                        userInfo = new AttendeeCredentials(null, null, null);
                    }
                }
            } catch (SQLException e) {
                Log.error(e, getClass());
                e.printStackTrace();
            }
        }
        return userInfo;
    }

    public void ensureSessionLengthExists(int minutes) {
        ensureSessionLengthExists(Integer.toString(minutes));
    }

    public void ensureSessionLengthExists(String minutes) {
        LengthsSearchPage sessionLengthsSearch = LengthsSearchPage.getPage();
        sessionLengthsSearch.navigate();

        sessionLengthsSearch.searchFor(minutes);
        if (!sessionLengthsSearch.hasLength(minutes)) {
            NewLengthPage newSessionLengthPage = NewLengthPage.getPage();
            newSessionLengthPage.navigate();
            newSessionLengthPage.setLength(minutes);
            newSessionLengthPage.setDisplayValue(minutes + " minutes");
            newSessionLengthPage.clickSubmitButton();
            PageConfiguration.getPage().waitForPageLoad();
        }
    }

    public static void ensurePackageExists(String packageName) throws Exception
    {
      RegistrationPackageSearchPage packageListPage = RegistrationPackageSearchPage.getPage();
      packageListPage.navigate();

      packageListPage.searchPackage(packageName);

      // todo: there is probably a better way to do this, look into in SeleniumHelpers.waitForAndClick or similar methods
      Utils.sleep(200);

      WebElement element = packageListPage.getPackageElement(packageName);
      if (element == null)
      {
        NewPackagePage packagePage = NewPackagePage.getPage();
        packagePage.navigate();
        packagePage.createPackage(packageName, RandomStringUtils.randomAlphabetic(5),"user",4);

        // todo: there is probably a better way to do this, look into in SeleniumHelpers.waitForAndClick or similar methods
        Utils.sleep(200);

        packageListPage.searchPackage(packageName);
        element = packageListPage.getPackageElement(packageName);
      }

      if (element == null)
        throw new Exception("Package: "+packageName+" does not exist");

      // this might not be necessary at all
      element.click();
    }

    public void setupAndroidLeads() {
        AdminLoginPage.getPage().login();
        MobileAppsRepo.getPage().navigate();
        String appPath = MobileAppsRepo.getPage().downloadAndroidApp("Leads", false);
        PropertyReader.instance().setProperty("ANDROID_LEADS", appPath);
        PropertyReader.instance().setProperty("mobileDriverType", "ANDROID_LEADS");
        PageConfiguration.getPage().quit();
        DriverManager.resetButton();
    }

    public void setupiOSAegis() {
        AdminLoginPage.getPage().login();
        MobileAppsRepo.getPage().navigate();
        String appPath = MobileAppsRepo.getPage().downloadiOSApp("Aegis", true);
        PropertyReader.instance().setProperty("IOS_AEGIS", appPath);
        PropertyReader.instance().setProperty("mobileDriverType", "IOS_AEGIS");
        PageConfiguration.getPage().quit();
        DriverManager.resetButton();
    }

    public void setupiOSHyperion(boolean login, boolean quitBrowser) {
        if (login) AdminLoginPage.getPage().login();
        MobileAppsRepo.getPage().navigate();
        String appPath = MobileAppsRepo.getPage().downloadiOSApp("Hyperion", true);
        PropertyReader.instance().setProperty("IOS_HYPERION", appPath);
        PropertyReader.instance().setProperty("mobileDriverType", "IOS_HYPERION");
        if (quitBrowser) {
            PageConfiguration.getPage().quit();
            DriverManager.resetButton();
        }
    }

    public void setupAndroidAegis() {
        //AdminLoginPage.getPage().login();
        MobileAppsRepo.getPage().navigate();
        String appPath = MobileAppsRepo.getPage().downloadAndroidApp("Aegis",true);
        PropertyReader.instance().setProperty("ANDROID_AEGIS", appPath);
        PropertyReader.instance().setProperty("mobileDriverType", "ANDROID_AEGIS");
        PageConfiguration.getPage().quit();
        DriverManager.resetButton();
    }

    @Override
    public String getHost() {
        return PropertyReader.instance().getProperty("adminUrl");
    }

    public String createDemo(String demoName, String...EVENTS){
        CreateDemoPage.getPage().navigate();
        CreateDemoPage.getPage().setName(demoName);
        for(String event: EVENTS){
            CreateDemoPage.getPage().setEvent(event);
        }
        CreateDemoPage.getPage().submit();

        String[] url = PageConfiguration.getPage().getCurrentUrl().split("id=");
        return url[url.length - 1];
    }

    public String createCheckBoxAttribute(String name, String[] values, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createCheckBoxList(name, values, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createRuleCustomExpression(String name, String applyTo, String applyValue, Criteria[] criteria, String expression){
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().setRuleName(name);
        AdminRuleCreatePage.getPage().setApplyTo(applyTo);
        AdminRuleCreatePage.getPage().setApplyValue(applyValue);
        for (int i = 0; i < criteria.length; i++) {
            AdminRuleCreatePage.getPage().setCriteria(i, criteria[i]);
            if(i<criteria.length-1){
                AdminRuleCreatePage.getPage().addMoreCriteria();
            }
        }
        AdminRuleCreatePage.getPage().advancedExpression("Custom", expression);
        AdminRuleCreatePage.getPage().save();
        AdminRuleSearchPage.getPage().waitForPageRender();
        return getRuleId(name);
    }

    public String createRule(String name, String applyTo, String applyValue, Criteria[] criteria, String expression){
        AdminRuleCreatePage.getPage().navigate();
        AdminRuleCreatePage.getPage().setRuleName(name);
        AdminRuleCreatePage.getPage().setApplyTo(applyTo);
        AdminRuleCreatePage.getPage().setApplyValue(applyValue);
        for (int i = 0; i < criteria.length; i++) {
            AdminRuleCreatePage.getPage().setCriteria(i, criteria[i]);
            if(i<criteria.length-1){
                AdminRuleCreatePage.getPage().addMoreCriteria();
            }
        }
        if(!expression.equalsIgnoreCase("")){
            AdminRuleCreatePage.getPage().advancedExpression(expression);
        }
        AdminRuleCreatePage.getPage().save();
        AdminRuleSearchPage.getPage().waitForPageRender();
        return getRuleId(name);
    }

    public String createTextFieldAttribute(String name, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createTextField(name,  audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id-
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createDateAttribute(String name, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createDate(name, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createSelectAttribute(String name, String[] values, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createSelectList(name, values, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createRadioAttribute(String name, String[] values, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createRadioList(name, values, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createTextArea(String name, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createTextArea(name, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createNumber(String name, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createNumberAttribute(name, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createMultiSelect(String name, String[] values, CreateEventAttributePage.AUDIENCE_TYPES...audiences){
        //create attribute
        CreateEventAttributePage.getPage().navigate();
        CreateEventAttributePage.getPage().createMultiSelect(name, values, audiences);
        CreateEventAttributePage.getPage().saveAttribute();

        //return id
        AdminEventAttributesPage.getPage().navigate();
        AdminEventAttributesPage.getPage().search(name);
        return AdminEventAttributesPage.getPage().getAttributeId(name);
    }

    public String createGenericMeetingProgram(String programName, String hostRole){
        //creation
        MeetingProgramsSearchPage.getPage().navigate();
        MeetingProgramsSearchPage.getPage().addItem();
        MeetingProgramGeneralTab.getPage().setProgramName(programName);
        MeetingProgramPage.getPage().saveAndContinue();
        MeetingProgramPage.getPage().goToScheduling();
        MeetingProgramSchedulePage.getPage().clickMeetingLengths();
        MeetingProgramSchedulePage.getPage().pickOneRandomMeetingLength();
        MeetingProgramSchedulePage.getPage().selectFirstDay();
        MeetingProgramPage.getPage().saveAndContinue();
        MeetingProgramPage.getPage().rolesTab();
        MeetingProgramRolesPage.getPage().useRole(hostRole);
        MeetingProgramPage.getPage().saveAndContinue();
        EditMeetingProgramPage.getPage().roomsTab();
        MeetingProgramRoomsPage.getPage().pickSomeRandomRooms();
        MeetingProgramPage.getPage().saveAndContinue();

        //return id
        MeetingProgramsSearchPage.getPage().navigate();
        MeetingProgramsSearchPage.getPage().search(programName);
        String id = MeetingProgramsSearchPage.getPage().getProgramId(programName);
        return id.substring(4, id.length()-1);
    }

    public String createMeetingRole(String name, String function){
        //creation
        NewMeetingRolePage.getPage().navigate();
        NewMeetingRolePage.getPage().setRoleName(name);
        NewMeetingRolePage.getPage().setRoleFunction(function);
        NewMeetingRolePage.getPage().clickSubmitButton();

        //return id
        MeetingRolesSearchPage.getPage().navigate();
        MeetingRolesSearchPage.getPage().searchFor(name);
        return MeetingRolesSearchPage.getPage().getTopResultId();
    }

    public JSONObject deleteMeetingRole(String roleId) {
        return PageConfiguration.getPage().post(getHost() + "/meetingRoleDelete.focus?id=" + roleId).getResponse();
    }

    public String createApprovedMeeting(String program){
        MeetingsSearchPage.getPage().navigate();
        MeetingsSearchPage.getPage().add();
        NewMeetingPage.getPage().selectMeetingProgram(program);
        NewMeetingPage.getPage().clickCreateMeetingButton();
        return EditMeetingPage.getPage().getId();
    }

    public String createForm(String name, String entityType, String...attributes){
        NewFormPage.getPage().navigate();
        EditFormPage.getPage().setFormName(name);
        EditFormPage.getPage().setRenderAsSubmit();
        EditFormPage.getPage().setEntityType(entityType);
        for(String attribute: attributes){
            EditFormPage.getPage().addExistingAttribute(attribute);
        }
        EditFormPage.getPage().submitForm();
        FormsSearchPage.getPage().navigate();
        FormsSearchPage.getPage().search(name);
        return FormsSearchPage.getPage().getId(name);
    }

    public String createTaskQualifier(String name, String entityType, Criteria[] criteria, String expression){
        NewTaskQualifierPage.getPage().navigate();
        NewTaskQualifierPage.getPage().setName(name);
        NewTaskQualifierPage.getPage().setEntityType(entityType);
        for (int i = 0; i < criteria.length; i++) {
            NewTaskQualifierPage.getPage().setCriteria(i, criteria[i]);
            if(i < criteria.length-1){
                NewTaskQualifierPage.getPage().addCriteria();
            }
        }
        if(!expression.equals("")){
            NewTaskQualifierPage.getPage().setExpression(expression);
        }
        NewTaskQualifierPage.getPage().save();
        TaskQualifierSearchPage.getPage().searchFor(name);
        return TaskQualifierSearchPage.getPage().getId(name);
    }

    public String createExhibitorCatalog(String name, String uri){
        WidgetBuilderSearchPage.getPage().navigate();
        WidgetBuilderSearchPage.getPage().addItem();
        WidgetBuilderCreateWidgetModal.getPage().clickExhibitorType();
        WidgetBuilderCreateWidgetModal.getPage().clickWidgetTypeNextButton();
        WidgetBuilderCreateWidgetModal.getPage().setWidgetName(name);
        WidgetBuilderCreateWidgetModal.getPage().setWidgetPageUri(uri);
        WidgetBuilderCreateWidgetModal.getPage().clickWidgetNameNextButton();

        return EditWidgetCatalogSettings.getPage().pullWidgetIdFromUrl();
    }

    public String createFileType(String name, String abbreviation, String fileSize, String[] contentTypes, String...audiences){
        NewFileTypePage.getPage().navigate();
        NewFileTypePage.getPage().setName(name);
        NewFileTypePage.getPage().setAbbreviation(abbreviation);
        NewFileTypePage.getPage().setAdminFileSizeMB(fileSize);
        NewFileTypePage.getPage().setWorkFlowFileSizeMB(fileSize);
        for (String contentType: contentTypes){
            NewFileTypePage.getPage().addContentType();
            NewFileTypePage.getPage().selectContentType(contentType);
        }
        NewFileTypePage.getPage().setAudience(audiences);
        NewFileTypePage.getPage().submit();

        FileTypesSearchPage.getPage().search(name);
        return FileTypesSearchPage.getPage().getId(name);
    }

    public JSONObject deleteFileType(String fileTypeId){
        return PageConfiguration.getPage().post(getHost() + "/fileTypeDelete.focus?id=" + fileTypeId).getResponse();
    }

    public String createApiProfile(String name, String[] APIS){
        NewApiProfilePage.getPage().navigate();
        NewApiProfilePage.getPage().setName(name);
        NewApiProfilePage.getPage().generateApiToken();
        for (String api: APIS){
            NewApiProfilePage.getPage().turnEndPointOn(api);
        }
        NewApiProfilePage.getPage().submit();
        ApiProfileSearchPage.getPage().search(name);
        ApiProfileSearchPage.getPage().editItem();
        return ApiProfilePage.getPage().getApiProfileId();
    }

    public JSONObject deleteApiProfile(String id){
        return PageConfiguration.getPage().post(getHost() + "/apiProfileDelete.focus?id=" + id).getResponse();
    }

    public String createGenericWorkflow(String template, String name, String uri){
        WorkflowsSearchPage.getPage().navigate();
        WorkflowsSearchPage.getPage().addItem();
        WorkflowsSearchPage.getPage().clickNewTemplate(template);
        NewWorkflowPage.getPage().setTemplateName(name);
        NewWorkflowPage.getPage().setTemplateURI(uri);
        NewWorkflowPage.getPage().clickModalSave();
        WorkflowEditBuilderPage.getPage().publishWorkflow();
        return WorkflowEditBuilderPage.getPage().getWorkflowId();
    }

    public String createExhibitorPortal(String name, String uri){
        return createGenericWorkflow("Exhibitor Portal", name, uri);
    }

    public String createUserByEmailIfNotExists(String email, String orgCode) {
        String userId = getAdminUser(email, "{'" + orgCode + "':['']}");
        return userId;
    }

    /**
     * Will create a newadmin user or find existing user and give them the requisite roles to enter the "new" admin,
     * Then sso the user into the destination event
     * @param destinationEvent eg. "Eventgers Test Event"
     * @param orgIBMCode Database code for the ORG eg. "nGHYGAOXirpk2EuFF1rMzwEXr2KQMqiw4g2ImBOf"
     */
    public void setupNewAdminUserAndSpoofTo(String org, String destinationEvent, String orgIBMCode)
    {
        NavigationBar navigationBar = new NavigationBar();
        if(!navigationBar.isUserLoggedIn())
            AdminLoginPage.getPage().login();

        AdminApp adminApp = new AdminApp();
        EditUserPage editUserPage = new EditUserPage();
        OrgEventData.getPage().setOrgAndEvent(org, "GLOBAL");
        String userId = adminApp.getAdminUser(PropertyReader.instance().getProperty("ibmNewAdminUserEmail"), "{'" + orgIBMCode + "':['role.system.admin']}");
        editUserPage.assignRolePerOrg(userId, org, "System Administrator");
        OrgEventData.getPage().setOrgAndEvent(org, destinationEvent);
        editUserPage.spoofUser(userId);
        Assert.assertTrue(editUserPage.isSpoofedIn(), "did not spoof in as the admin user");
        navigationBar.switchToNewAdmin();

        EventSearchPage eventSearchPage = new EventSearchPage();
        eventSearchPage.navigate();
        eventSearchPage.accessEventByCode(destinationEvent, navigationBar.isOldAdminNavVisible());
    }

    public void loginAsAdminUser() {
        String adminEmail = PropertyReader.instance().getProperty("ibmNewAdminUserEmail");
        String adminPassword = PropertyReader.instance().getProperty("adminPassword");
        AdminLoginPage adminLoginPage = new AdminLoginPage();
        try {
            if (NavigationBar.getPage().isUserLoggedIn()) {
                adminLoginPage.logout();
            }
            adminLoginPage.login(adminEmail, adminPassword);
        } catch (Exception exception) {
            adminLoginPage.login();
            AdminApp adminApp = new AdminApp();
            adminApp.getAdminUser(adminEmail, "{'" + orgIBMCode + "':['role.system.admin']}");
            adminLoginPage.logout();
            adminLoginPage.login(adminEmail, adminPassword);
        }
    }

    public void loginAsAdminUserAutoOrg() {
        String adminEmail = PropertyReader.instance().getProperty("plannerAdminEmail");
        String adminPassword = PropertyReader.instance().getProperty("adminPassword");
        AdminLoginPage adminLoginPage = new AdminLoginPage();
        try {
            if (NavigationBar.getPage().isUserLoggedIn()) {
                adminLoginPage.logout();
            }
            adminLoginPage.login(adminEmail, adminPassword);
        } catch (Exception exception) {
            adminLoginPage.login();
            AdminApp adminApp = new AdminApp();
            adminApp.getAdminUser(adminEmail, "{'" + orgRFAutomationCode + "':['role.system.admin']}");
            adminLoginPage.logout();
            adminLoginPage.login(adminEmail, adminPassword);
        }
    }

    public void safeSetSelectListValue(String attribute, String value){
        if(!PersistentProfileForm.getPage().selectListRendered(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setSelectAttribute(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetCheckBoxValue(String attribute, String value){
        if(!PersistentProfileForm.getPage().checkBoxRendered(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().clickCheckBoxValue(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetTextArea(String attribute, String value){
        if(!PersistentProfileForm.getPage().textAreaExists(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setTextArea(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetTextBox(String attribute, String value){
        if(!PersistentProfileForm.getPage().textBoxExists(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setTextAttribute(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetMultiSelect(String attribute, String value){
        if(!PersistentProfileForm.getPage().multiSelectRendered(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setMultiSelect(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetRadio(String attribute, String value){
        if(!PersistentProfileForm.getPage().radioRendered(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().selectRadioValue(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetNumber(String attribute, String value){
        if(!PersistentProfileForm.getPage().numberRendered(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setNumberAttribute(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public void safeSetDate(String attribute, String value){
        if(!PersistentProfileForm.getPage().dateAttributeExists(attribute)){
            PersistentProfileForm.getPage().edit();
            EditFormPage.getPage().addExistingAttribute(attribute);
            EditFormPage.getPage().submitForm();
        }
        PersistentProfileForm.getPage().setDateValue(attribute, value);
        PersistentProfileForm.getPage().submit();
    }

    public String createGenericNewPage(String pageName){
        NewPagesSearchPage.getPage().navigate();
        NewPagesSearchPage.getPage().startFromScratch(pageName);
        return  NewPages.getPage().getWorkflowId();
    }

    public String createNewPageWithChatHostCard(String pageName){
        String pageId = createGenericNewPage(pageName);
        NewPages.getPage().selectLayOut(1);
        NewPages.getPage().makeSectionChatCard(1, "Chat Page");
        NewPages.getPage().saveAndPublish();
        return pageId;
    }

    public void elasticExhibitorLoad(String profile, int tab, String apiToken){
        ApiProfileSearchPage.getPage().navigate();
        ApiProfileSearchPage.getPage().search(profile);
        ApiProfileSearchPage.getPage().editItem();
        ApiProfilePage.getPage().swagger();
        PageConfiguration.getPage().switchToTab(tab);
        SwaggerPage.getPage().elasticExhibitorLoad(apiToken);
    }

    public void spoofIntoCatalog(String attendeeName, String catalog, int tab){
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendeeName);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().spoofToWidget(catalog);
        PageConfiguration.getPage().switchToTab(tab);
    }

    public String createExhibitorPortalWithChatModalNoCard(String workflowName){
        String workflowId = createExhibitorPortal(workflowName, workflowName);
        WorkflowEditPage.getPage().dragNode("Host Chat");
        WorkflowStepEditor.getPage().setStepName("chatPage");
        WorkflowStepEditor.getPage().setStepURI("chatPage");
        WorkflowStepEditor.getPage().saveStep();

        WorkflowEditBuilderPage.getPage().openStepEditor("Start");
        WorkflowStepEditor.getPage().openTab("connections");
        WorkflowStepEditor.getPage().takeMeHere("chatPage");
        WorkflowStepEditor.getPage().saveStep();
        WorkflowEditBuilderPage.getPage().publishWorkflow();
        return workflowId;
    }
    public void spoofIntoWorkflow(String attendee, String workflow, int tab){
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendee);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().spoofTo(workflow);
        PageConfiguration.getPage().switchToTab(tab);
    }

    public String createExhibitorPackage(String name, String code, String quantity, String price){
        NewPackagePage.getPage().navigate();
        NewPackagePage.getPage().setName(name);
        NewPackagePage.getPage().setCode(code);
        NewPackagePage.getPage().setTypeToExhibitor();
        NewPackagePage.getPage().setQuantity(quantity);
        NewPackagePage.getPage().setPrice(price);
        NewPackagePage.getPage().submit();
        PackageSearchPage.getPage().searchForPackageByText(name);
        return ExhibitorPackageSearchPage.getPage().getId(name);
    }

    public String createDemoRole(String name, String roleFunction, boolean portalAccess, boolean leadsAccess){
        CreateDemoRolePage.getPage().navigate();
        NewExhibitorRolePage.getPage().setName(name);
        if(portalAccess) NewExhibitorRolePage.getPage().givePortalAccess();
        if(leadsAccess) NewExhibitorRolePage.getPage().giveLeadsAccess();
        NewExhibitorRolePage.getPage().setFunction(roleFunction);
        NewExhibitorRolePage.getPage().submit();
        DemoRoleSearchPage.getPage().searchDemoRole(name);
        return DemoRoleSearchPage.getPage().getRoleId(name);
    }

    public String createExhibitorRole(String name, String roleFunction, boolean portalAccess, boolean leadsAccess){
        NewExhibitorRolePage.getPage().navigate();
        NewExhibitorRolePage.getPage().setName(name);
        if(portalAccess) NewExhibitorRolePage.getPage().givePortalAccess();
        if(leadsAccess) NewExhibitorRolePage.getPage().giveLeadsAccess();
        NewExhibitorRolePage.getPage().setFunction(roleFunction);
        NewExhibitorRolePage.getPage().submit();
        ExhibitorRolesSearchPage.getPage().search(name);
        return ExhibitorRolesSearchPage.getPage().getIdByName(name);
    }

    public void spoofIntoLeads(String attendee, int tab){
        AttendeeSearchPage.getPage().navigate();
        AttendeeSearchPage.getPage().searchFor(attendee);
        AttendeeSearchPage.getPage().clickResult(0);
        EditAttendeePage.getPage().spoofToLeads(tab);
    }

    public String createExhibitorLeadAllocation(String name, String quantity, Criteria[] criteria){
        NewExhibitorLeadDeviceAllocationPage.getPage().navigate();
        NewExhibitorLeadDeviceAllocationPage.getPage().setName(name);
        NewExhibitorLeadDeviceAllocationPage.getPage().setQuantity(quantity);
        for (int i = 0; i < criteria.length; i++) {
            if(i<criteria.length-1){
                NewExhibitorLeadDeviceAllocationPage.getPage().addCriteria();
            }
            NewExhibitorLeadDeviceAllocationPage.getPage().setCriteria(i, criteria[i]);
        }
        NewExhibitorLeadDeviceAllocationPage.getPage().submit();
        ExhibitorLeadDeviceAllocationSearchPage.getPage().navigate();
        ExhibitorLeadDeviceAllocationSearchPage.getPage().search(name);
        return ExhibitorLeadDeviceAllocationSearchPage.getPage().getId(name);
    }

    public JSONObject deleteExhibitorDeviceAllocation(String allocationId) {
        return PageConfiguration.getPage().post(getHost() + "/lead/deleteAllocationItem.do?id=" + allocationId).getResponse();
    }

    public JSONObject deleteDay(String dayId){
        return PageConfiguration.getPage().post(getHost() + "meetingDayDelete.focus?id=" + dayId).getResponse();
    }

    public void elasticSessionLoad(String profile, int tab, String apiToken){
        ApiProfileSearchPage.getPage().navigate();
        ApiProfileSearchPage.getPage().search(profile);
        ApiProfileSearchPage.getPage().editItem();
        ApiProfilePage.getPage().swagger();
        PageConfiguration.getPage().switchToTab(tab);
        SwaggerPage.getPage().elasticSessionLoad(apiToken);
    }

    public JSONObject deleteCountry(String countryId) {
        return PageConfiguration.getPage().post(getHost() + "/deleteCountry.do?countryId=" + countryId).getResponse();
    }

    public String createExhibitorRoleWithRoleAndPermissions(String name, String function, String[] permissions){
        NewExhibitorRolePage.getPage().navigate();
        NewExhibitorRolePage.getPage().setName(name);
        NewExhibitorRolePage.getPage().setFunction(function);
        Arrays.stream(permissions).forEach((permission)->{
            NewExhibitorRolePage.getPage().togglePermission(permission);
        });

        NewExhibitorRolePage.getPage().submit();
        ExhibitorRolesSearchPage.getPage().navigate();
        ExhibitorRolesSearchPage.getPage().search(name);
        return ExhibitorRolesSearchPage.getPage().getIdByName(name);
    }

    public String createDemoRoleWithRoleAndPermissions(String name, String function, String[] permissions){
        CreateDemoRolePage.getPage().navigate();
        CreateDemoRolePage.getPage().setName(name);
        CreateDemoRolePage.getPage().setFunction(function);
        Arrays.stream(permissions).forEach((permission)->{
            CreateDemoRolePage.getPage().togglePermission(permission);
        });

        CreateDemoRolePage.getPage().submit();
        CreateDemoRolePage.getPage().navigate();
        DemoRoleSearchPage.getPage().searchDemoRole(name);
        return ExhibitorRolesSearchPage.getPage().getIdByName(name);
    }
}
