package apps.admin;

import interaction.pageObjects.WebPage;
import interaction.pageObjects.rfBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import testHelp.Utils;

public class CountrySearchPage extends WebPage {

  protected final By SEARCH_INPUT = By.id("filter_param");
  protected final By SEARCH_BUTTON = By.xpath("(//*[@class='search-actions']//button)[2]");
  protected final By TABLE_ROW = rfBy.datatest("adv-table-row");

  public static CountrySearchPage getPage()
  {
    return initialize(CountrySearchPage.class);
  }

  public void navigate()
  {
    navigateTo(getData("adminUrl") + "/rain.focus#countries.do");
  }

  public void search(String country)
  {
    waitForElementOnPage(SEARCH_INPUT);
    clearWithBackSpace(SEARCH_INPUT);
    justWait();
    sendKeys(SEARCH_INPUT, country);
    justWait();
    moveToAndClick(SEARCH_BUTTON);
    justWait();
  }

  public void clickRow(int row)
  {
    justWait();
    moveToAndClick(findElements(TABLE_ROW).get(row));
    justWait();
  }
}
