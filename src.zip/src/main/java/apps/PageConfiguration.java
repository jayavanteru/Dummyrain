package apps;


import interaction.api.ApiConfig;
import interaction.pageObjects.WebPage;
import interaction.screenshots.ScreenShotImage;
import interaction.webUI.NetworkRequest;
import logs.Log;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.HashMap;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class PageConfiguration extends WebPage {

    //singleton constructor
    public static PageConfiguration getPage() {
        return initialize(PageConfiguration.class);
    }

    public int getYScrollPosition() {
        final String offset = executeJavaScript("return Math.round(window.pageYOffset).toString()");
        Log.info("up and down scroll position is " + offset, getClass());
        return Integer.parseInt(offset);
    }

    public int getXScrollPosition() {
        final String offset = executeJavaScript("return window.pageXOffset.toString()");
        Log.info("side to side scroll position is " + offset, getClass());
        return Integer.parseInt(offset);
    }

    @Override
    public WebDriver getBrowser() {
        return super.getBrowser();
    }

    @Override
    public void navigateTo(String url) {
        super.navigateTo(url);
    }

    @Override
    public void navigateBack() {
        super.navigateBack();
    }

    @Override
    public void navigateForward() {
        super.navigateForward();
    }

    @Override
    public void moveMouseToTopCorner() {
        super.moveMouseToTopCorner();
    }

    @Override
    public void refreshPage() {
        super.refreshPage();
    }

    @Override
    public void waitForPageLoad() {
        super.waitForPageLoad();
    }

    @Override
    public String getCurrentUrl() {
        return super.getCurrentUrl();
    }

    @Override
    public boolean waitForPageUrlToContain(String url) {
        return super.waitForPageUrlToContain(url);
    }

    @Override
    public boolean waitForPageUrlToEndWith(String url) {
        return super.waitForPageUrlToEndWith(url);
    }

    @Override
    public boolean waitForPageUrlToStartWith(String url) {
        return super.waitForPageUrlToStartWith(url);
    }

    @Override
    public void close() {
        super.close();
    }

    @Override
    public void quit() {
        super.quit();
    }

    @Override
    public String getWindowHandle() {
        return super.getWindowHandle();
    }

    @Override
    public Set<String> getWindowHandles() {
        return super.getWindowHandles();
    }

    @Override
    public void switchToWindow(String windowHandle) {
        super.switchToWindow(windowHandle);
    }

    @Override
    public void switchToTab(int index) {
        super.switchToTab(index);
    }

    @Override
    public Alert switchToAlert() {
        return super.switchToAlert();
    }

    @Override
    public void switchToFrame(WebElement frame) {
        super.switchToFrame(frame);
    }

    @Override
    public void switchToFrame(int frame) {
        super.switchToFrame(frame);
    }

    @Override
    public void switchToFrame(String frame) {
        super.switchToFrame(frame);
    }

    @Override
    public void switchToActiveElement() {
        super.switchToActiveElement();
    }

    @Override
    public void switchToDefaultContent() {
        super.switchToDefaultContent();
    }

    @Override
    public void switchToParentFrame() {
        super.switchToParentFrame();
    }

    @Override
    public void switchToIframe() {
        super.switchToIframe();
    }

    @Override
    public void setWindowfullscreen() {
        super.setWindowfullscreen();
    }

    @Override
    public void setWindowSize(int width, int height) {
        super.setWindowSize(width, height);
    }

    @Override
    public void setWindowMaximize() {
        super.setWindowMaximize();
    }

    @Override
    public void deleteAllCookies() {
        super.deleteAllCookies();
    }

    @Override
    public void deleteCookieNamed(String cookieName) {
        super.deleteCookieNamed(cookieName);
    }

    @Override
    public void addCookie(Cookie cookie) {
        super.addCookie(cookie);
    }

    @Override
    public void addCookie(String name, String value) {
        super.addCookie(name, value);
    }

    @Override
    public Set<Cookie> getCookies() {
        return super.getCookies();
    }

    @Override
    public Cookie getCookieNamed(String name) {
        return super.getCookieNamed(name);
    }

    @Override
    public void setImplicitWait(long time, TimeUnit unit) {
        super.setImplicitWait(time, unit);
    }

    @Override
    public void resetImplicitWait() { super.resetImplicitWait(); }

    @Override
    public void setPageLoadTimeout(long time, TimeUnit unit) {
        super.setPageLoadTimeout(time, unit);
    }

    @Override
    public void startNetworkMonitoring() {
        super.startNetworkMonitoring();
    }

    @Override
    public void stopNetworkMonitoring() {
        super.stopNetworkMonitoring();
    }

    @Override
    public NetworkRequest getRequestByEndpoint(String endpoint) {
        return super.getRequestByEndpoint(endpoint);
    }

    @Override
    public void setScriptTimeout(long time, TimeUnit unit) {
        super.setScriptTimeout(time, unit);
    }

    public void takeScreenShot(String fileName) {
        getWebUI().takeScreenShot(fileName);
    }

    @Override
    public ScreenShotImage takeScreenShot() {
        return super.takeScreenShot();
    }

    @Override
    public ApiConfig post(String path, HashMap<String, String> headers, String body) {
        return super.post(path, headers, body);
    }

    @Override
    public ApiConfig put(String path, HashMap<String, String> headers, String body) {
        return super.put(path, headers, body);
    }

    @Override
    public ApiConfig postAsUrlParams(String path, HashMap<String, String> headers, String body) {
        return super.postAsUrlParams(path, headers, body);
    }

    @Override
    public ApiConfig postAsUrlParams(String path, String body) {
        return super.postAsUrlParams(path, body);
    }

    @Override
    public ApiConfig patch(String path, HashMap<String, String> headers, String body) {
        return super.patch(path, headers, body);
    }

    @Override
    public ApiConfig get(String path, HashMap<String, String> headers) {
        return super.get(path, headers);
    }

    @Override
    public ApiConfig delete(String path, HashMap<String, String> headers) {
        return super.delete(path, headers);
    }

    @Override
    public ApiConfig post(String path, String body) {
        return super.post(path, body);
    }

    @Override
    public ApiConfig post(ApiConfig config) {
        return super.post(config);
    }

    @Override
    public ApiConfig post(String path) {
        return super.post(path);
}

    @Override
    public ApiConfig put(String path, String body) {
        return super.put(path, body);
    }

    @Override
    public ApiConfig patch(String path, String body) {
        return super.patch(path, body);
    }

    @Override
    public ApiConfig get(String path) {
        return super.get(path);
    }

    @Override
    public ApiConfig get(ApiConfig apiConfig) {
        return super.get(apiConfig);
    }

    @Override
    public ApiConfig delete(String path) {
        return super.delete(path);
    }

    public void closeTabsToDefault(){
        int size = getWindowHandles().size();
        for (int i=1; i<size;++i){
            switchToTab(1);
            close();
        }
        switchToTab(0);
    }

}

