package apps.events;

import apps.App;
import apps.PageConfiguration;
import apps.events.eventsPageObjects.*;
import configuration.PropertyReader;
import org.json.JSONObject;
import testHelp.MyJson;

import java.util.HashSet;

public class EventsApp extends App{
    
    private String eventName;

    PropertyReader reader = PropertyReader.instance();

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventName() {
        return eventName;
    }
    //=============================== web page objects ===============================
    public WidgetPage getWidgetPage() {
        WidgetPage page;
        //get the right page object for this widget
        switch (eventName) {
            case "CL_GLOBAL":
                page = new WidgetPageCiscoGlobal(eventName);
                break;
            case "Splunk_Global":
                page = new WidgetPageSplunk(eventName);
                break;
            case "Constellations" :
                page = new ConstellationsWidgetPage();
                break;
            case "RSA_APJ":
                page = new WidgetPageRSA(eventName);
                break;
            default:
                page = new WidgetPage(eventName);
        }
        page.navigate();
        return page;
    }
    //================================================================================
    //================================== REST actions ================================
    @Override
    public String getHost() {
        return PropertyReader.instance().getProperty("eventsUrl");
    }

    public String getEventUrl() {
        String env = PropertyReader.instance().getProperty("env");
        return PropertyReader.instance().getProperty(eventName + "-" + env + "Url");
    }
    //================================================================================

    public void runElasticSearch() {
        String url = PropertyReader.instance().getProperty("elasticSearchSessionURL");
        runSearch(url);
        url = PropertyReader.instance().getProperty("elasticSearchSpeakerURL");
        runSearch(url);
    }

    public void clearCookies() {
        PageConfiguration.getPage().deleteAllCookies();
        if (isApiInitiated()) {
            getApi().cookies = new HashSet<>();
        }
    }

    public String getUrlForApiCall(String endpoint, String apiProfileId, String widgetId) {
        JSONObject body = new JSONObject();
        MyJson.put(body, "rfApiProfileId", apiProfileId);
        MyJson.put(body, "rfWidgetId", widgetId);
        body = addParametersForEndpoint(body, endpoint);
        return apiFullUrl("/api/"+endpoint, body);
    }

    public JSONObject makeApiCall(String endpoint, String apiProfileId, String widgetId) {
        JSONObject body = new JSONObject();
        MyJson.put(body, "rfApiProfileId", apiProfileId);
        MyJson.put(body, "rfWidgetId", widgetId);
        body = addParametersForEndpoint(body, endpoint);
        return postAsUrlParams("/api/" + endpoint, body);
    }

    public String getHealthCheckUrl() {
        return PropertyReader.instance().getProperty("eventsUrl")
                + "/health?rfApiProfileId=rftoken";
    }

    private void runSearch(String url) {
        //setup parameters
        JSONObject params = new JSONObject();
        MyJson.put(params, "rfWidgetId", PropertyReader.instance().getProperty(eventName + "-widgetId"));
        MyJson.put(params, "rfApiProfileId", PropertyReader.instance().getProperty(eventName + "-apiProfileId"));

        //run elastic search
        PageConfiguration.getPage().postAsUrlParams(getHost() + url, params.toString()).getResponse();
    }

    private JSONObject addParametersForEndpoint(JSONObject body, String endpoint) {
        String key = "EventApi-" + endpoint;
        if (PropertyReader.instance().hasProperty(key)) {
            String[] params = PropertyReader.instance().getProperty(key).split(",");
            for (String param : params) {
                String value = getParameterValue(param, endpoint);
                MyJson.put(body, param, value);
            }
        }
        return body;
    }

    private String getParameterValue(String parameter, String endpoint) {
        PropertyReader reader = PropertyReader.instance();
        return reader.hasProperty("EventParam-" + parameter) ?
                reader.getProperty("EventParam-" + parameter) :
                reader.getProperty("EventParam-" + endpoint + "-" + parameter);
    }
}
