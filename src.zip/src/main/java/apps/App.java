package apps;

import configuration.PropertyReader;
import interaction.api.Api;
import interaction.api.ApiConfig;
import interaction.api.CustomCookie;
import interaction.awsDatabase.DbQueryConfig;
import interaction.awsDatabase.DbQueryRunner;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.Cookie;


public abstract class App {

    private Api api;
    private DbQueryRunner db;

    public JSONObject post(String path, JSONObject body) {
        return postHelper(path, body, false);
    }

    public JSONObject postAsUrlParams(String path, JSONObject body) {
        return postHelper(path, body, true);
    }

    public JSONObject post(String path, ApiConfig config) {
        config.setUrl(getUrl(path));

        //send request
        return getApi().post(config).getResponse();
    }

    public JSONObject post(String path) {
        ApiConfig apiConfig = new ApiConfig(getUrl(path));

        //send request
        return getApi().post(apiConfig).getResponse();
    }

    public JSONObject post_fullUrl(String fullUrl) {
        ApiConfig apiConfig = new ApiConfig(fullUrl);

        //send request
        return getApi().post(apiConfig).getResponse();
    }

    public JSONObject get(String path) {
        ApiConfig apiConfig = new ApiConfig();
        apiConfig.setUrl(getUrl(path));

        //send request
        JSONObject response = getApi().get(apiConfig).getResponse();

        return response;
    }

    public JSONObject get_fullUrl(String fullurl) {
        ApiConfig apiConfig = new ApiConfig();
        apiConfig.setUrl(fullurl);

        //send request
        JSONObject response = getApi().get(apiConfig).getResponse();

        return response;
    }

    public String apiFullUrl(String path, JSONObject params) {
        return getApiConfig(path, params, true).getUrl();
    }

    public JSONArray queryDb(DbQueryConfig config) {
        JSONArray results = getDb().runQuery(config);
        //going to close the connection after every query for now
        getDb().closeConnection();
        db = null;
        return results;
    }

    public void setBrowser(String browser) {
        PropertyReader.instance().setProperty("browserName", browser);
    }

    public Api getApi() {
        if (api == null) {
            Log.info("starting up API", getClass().getName());
            api = new Api();
        }
        return api;
    }

    public void setApi(Api api){
        this.api = api;
    }

    public DbQueryRunner getDb() {
        if (db == null) {
            Log.info("starting up Db connection", getClass().getName());
            db = new DbQueryRunner();
        }
        return db;
    }

    public void syncCookieFromBrowserToApi() {
        Log.info("syncing cookies from browser to api", getClass().getName());
        for (Cookie cookie : PageConfiguration.getPage().getCookies()) {
            getApi().cookies.add(new CustomCookie(cookie));
        }
    }

    public void syncCookieFromApiToBrowser() {
        Log.info("syncing cookies from api to browser", getClass().getName());
        PageConfiguration.getPage().deleteAllCookies();
        for (CustomCookie cookie : getApi().cookies) {
            PageConfiguration.getPage().addCookie(cookie.getSeleniumCookie());
        }
    }

    public boolean isApiInitiated() {
        return api != null;
    }

    public boolean isDbInitiated() {
        return db != null;
    }

    public String getUrl(String path) {
        return getHost() + path;
    }

    protected ApiConfig getApiConfig(String path, JSONObject body, boolean urlParms) {
        ApiConfig apiConfig = new ApiConfig(getUrl(path), body);
        apiConfig.setUrlParams(urlParms);

        //any extra config for the app to do
        return apiConfig;
    }

    public abstract String getHost();

    private JSONObject postHelper(String path, JSONObject body, boolean urlParms) {
        ApiConfig apiConfig = getApiConfig(path, body, urlParms);

        //send request
        return getApi().post(apiConfig).getResponse();
    }
}
