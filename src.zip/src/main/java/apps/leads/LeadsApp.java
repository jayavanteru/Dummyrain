package apps.leads;

import apps.App;
import apps.PageConfiguration;
import configuration.PropertyReader;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import testHelp.MyJson;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * Created by brianpulham on 10/3/17.
 */
public class LeadsApp extends App {

    public JSONObject addLead(String attendeeId, String leadToken) {
        return addLead(attendeeId, getDeviceId(0), getConfigurationId(0), leadToken);
    }

    public JSONObject addLead(String attendeeId, String deviceId, String configurationId, String leadToken) {
        JSONArray leadJson = MyJson.createJSONArray("[{" +
                "'deviceId':'"+deviceId+"'," +
                "'badgeId':'"+attendeeId+"'," +
                "'firstname':'Mantis123'," +
                "'lastname':'Toboggan123'," +
                "'companyname':'Corporation'," +
                "'jobtitle':'Test'," +
                "'note':'test'," +
                "'leadDate':'2017-9-22'," +
                "'leadTime':'11:19:48'," +
                "'configurationId':'"+configurationId+"'," +
                "'questionsetId':'null'," +
                "'questions':[]," +
                "'hotLead':true," +
                "'contactMethod':email" +
                "}]");
        String params = null;
        try {
            params = "?leads=" + URLEncoder.encode(leadJson.toString(), "UTF-8") + "&deviceId=" + deviceId + "&leadToken=" + leadToken;
        } catch (UnsupportedEncodingException e) {
            Log.error(e.getMessage(),getClass());
            e.printStackTrace();
        }
        return PageConfiguration.getPage().post(getHost() +"/api/saveLeads" + params).getResponse();
    }

    public String getDeviceId(int index) {
        JSONObject response = PageConfiguration.getPage().get(getHost() + "/portal/loadDevicesAndConfigurations").getResponse();
        JSONObject deviceInfo = MyJson.getJSONObject(MyJson.getJSONArray(MyJson.getJSONObject(response, "data"), "devices"), index);
        return MyJson.getString(deviceInfo, "deviceId");
    }

    public String getConfigurationId(int index) {
        JSONObject response = PageConfiguration.getPage().get(getHost() + "/portal/loadDevicesAndConfigurations").getResponse();
        JSONObject deviceInfo = MyJson.getJSONObject(MyJson.getJSONArray(MyJson.getJSONObject(response, "data"), "configurations"), index);
        return MyJson.getString(deviceInfo, "configurationId");
    }
    //================================== REST actions ================================

    @Override
    public String getHost() {
        return PropertyReader.instance().getProperty("leadsUrl");
    }
    //================================================================================
    //~
}
