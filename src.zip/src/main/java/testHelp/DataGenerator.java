package testHelp;

import configuration.PropertyReader;
import logs.Log;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;

import javax.annotation.Nullable;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

public class DataGenerator {

    private HashMap<String, String> theData;
    private Random random;

    public static final String DATE_FORMAT_MM_DD_YYYY = "MM/dd/yyyy";
    public static final String DATE_FORMAT_MM_DD_YY = "MM/dd/yy";

    public DataGenerator() {
        theData = new HashMap<>();
        random = new Random();
    }

    public String getValue(String key) {
        //if doesn't contain value will check with the properties
        if (theData.containsKey(key)) {
            return theData.get(key);
        } else {
            return PropertyReader.instance().getProperty(key);
        }
    }

    public void putValue(String key, String value) {
        theData.put(key, value);
    }

    public String generateString(String key) {
        String randString = generateString();
        putValue(key, randString);
        return randString;
    }

    public String generateString(String key, int size) {
        String randString = generateString(size);
        putValue(key, randString);
        return randString;
    }

    public int generateNumber(String key) {
        int randNum = generateNumber();
        putValue(key, String.valueOf(randNum));
        return randNum;
    }

    public int generateNumber(String key, int maxSize) {
        int randNum = generateNumber(maxSize);
        putValue(key, String.valueOf(randNum));
        return randNum;
    }

    public int generateNumber() {
        return random.nextInt(Integer.MAX_VALUE);
    }

    public int generateNumber(int max) {
        return random.nextInt(max);
    }

    public long generateLongNumber(long min, long max) {
        long num = generateLongNumber(min, max);
        Log.debug("generated long number: " + num, DataGenerator.class);
        return num;
    }

    public String generateString() {
        return UUID.randomUUID().toString().replace("-", "").substring(0,20);
    }

    public String generateString(int size) {
        StringBuilder fullString = new StringBuilder(generateString());
        while (fullString.length() < size) {
            fullString.append(generateString());
        }
        return fullString.substring(0, size);
    }

    public String generateName() {
        return "automation" + generateString(5);
    }

    public String generateValidEmail() {
        return "rainfocustestautomationuser+"+generateString(8)+"@gmail.com";
    }

    public String generateEmail() {
        return generateString(8) + "automation@rainfocus.com";
    }

    public String generatePhone() {
        int areaCode = getNumber(100, 999);
        int prefix = getNumber(100, 999);
        int number = getNumber(1000, 9999);
        String phone = "(" + areaCode + ") " + prefix + "-" + number;
        Log.debug("generated phone number: " + phone, DataGenerator.class);
        return phone;
    }

    public DateTime generateDateTimeAfter(DateTime after) {
        DateTime generated = after.plus(getLongNUmber(1000, TimeUnit.DAYS.toMillis(60)));
        Log.debug("generated date: " + generated.toString("MM/dd/yyyy hh:mm:ss"), DataGenerator.class);
        return generated;
    }

    public DateTime generateDateTimeBeforeNow() {
        return generateDateTimeBefore(DateTime.now());
    }

    public DateTime generateDateTimeBefore(DateTime before) {
        DateTime generated = before.minus(getLongNUmber(1000,TimeUnit.DAYS.toMillis(60)));
        Log.debug("generated date: " + generated.toString("MM/dd/yyyy hh:mm:ss"), DataGenerator.class);
        return generated;
    }

    public DateTime generateDateTimeAfterNow() {
        return generateDateTimeAfter(DateTime.now());
    }

    public String generateDateStringAfterNow () {
        return generateDateStringAfterNow(DataGenerator.DATE_FORMAT_MM_DD_YYYY);
    }

    public String generateDateStringAfterNow (@Nullable String format) {
        if (StringUtils.isBlank(format))
            format = DataGenerator.DATE_FORMAT_MM_DD_YYYY;

        DateTime dateTime = generateDateTimeAfterNow();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);

        return simpleDateFormat.format(dateTime.toDate());
    }

    public String generateLetters(int size) {
        StringBuilder fullString = new StringBuilder(generateString().replaceAll("[0-9]", ""));
        while (fullString.length() < size) {
            fullString.append(generateString().replaceAll("[0-9]", ""));
        }
        return fullString.substring(0, size);
    }

    public String generateLetters() {
        return generateLetters(32);
    }

    public String generatePassword() {
        return generateLetters(5).toLowerCase() + generateLetters(5).toUpperCase() + "%#" + generateNumber();
    }

    public String generateStreetAddress() {
        int street = getNumber(100, 99999);
        int house = getNumber(1000, 99999);
        String address = "";

        switch (getNumber(0,5)) {
            case 0:
                address = house + " " + street + " Ave";
                break;
            case 1:
                address =  house + " " + street + " St";
                break;
            case 2:
                address =  house + " W " + street + " N";
                break;
            case 3:
                address =  house + " E " + street + " N";
                break;
            case 4:
                address =  house + " W " + street + " S";
                break;
            case 5:
                address =  house + " E " + street + " S";
                break;
        }
        Log.debug("generated address: " + address, DataGenerator.class);
        return address;
    }

    public int getNumber(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

    private long getLongNUmber(long min, long max) {
        return ThreadLocalRandom.current().nextLong(min, max);
    }
}
