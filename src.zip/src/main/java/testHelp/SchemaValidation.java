package testHelp;

import logs.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

public class SchemaValidation {

    public static boolean schema(JSONObject pattern, JSONObject json) {
        try {
            return schemaMatch(pattern, json);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.error(e, Utils.class);
            return false;
        }
    }

    public static boolean schema(JSONArray pattern, JSONArray json) {
        try {
            return schemaMatch(pattern, json);
        } catch (JSONException e) {
            e.printStackTrace();
            Log.error(e, Utils.class);
            return false;
        }
    }

    private static boolean schemaMatch(JSONObject pattern, JSONObject json) throws JSONException {
        Iterator keys = pattern.keys();
        boolean result = true;
        while (keys.hasNext()) {
            String key = keys.next().toString();

            result = result && json.has(key) && nextLevel(pattern.get(key), json.get(key));
        }

        return result;
    }

    private static boolean schemaMatch(JSONArray pattern, JSONArray json) throws JSONException {
        boolean result = json.length() >= pattern.length();
        for (int i = 0; i < pattern.length(); ++i) {
            result = result && nextLevel(pattern.get(i), json.get(i));
        }

        return result;
    }

    private static boolean schemaMatch(String pattern, String json) {
        return json.matches(pattern);
    }

    private static boolean nextLevel(Object pattern, Object json) throws JSONException {
        if (pattern instanceof JSONObject && json instanceof JSONObject) {
            return schemaMatch((JSONObject) pattern, (JSONObject) json);
        } else if (pattern instanceof JSONArray && json instanceof JSONArray) {
            return schemaMatch((JSONArray) pattern, (JSONArray) json);
        } else if (!(pattern instanceof JSONArray) && !(pattern instanceof JSONObject)) {
            return schemaMatch(pattern.toString(), json.toString());
        }
        return false;
    }
}
