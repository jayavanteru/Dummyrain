package testHelp;

import interaction.DriverManager;
import interaction.webUI.WebUI;
import logs.FileWriter;
import logs.Log;
import org.openqa.selenium.Cookie;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class TestListener extends TestListenerAdapter {

    public static final HashMap<String, Collection<ITestNGMethod>> configure = new HashMap<>();
    public static final HashMap<String, String> urls = new HashMap<>();
    public static final HashMap<String, Set<Cookie>> cookies = new HashMap<>();

    public static void runConfigureMethods() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        for (ITestNGMethod m : configure.get(Thread.currentThread().getName())) {
            String methodName = m.getMethodName();
            m.getRealClass().getMethod(methodName).invoke(m.getInstance());
        }
    }

    @Override
    public void beforeConfiguration(ITestResult var1) {
        super.beforeConfiguration(var1);
        String name = var1.getTestClass().getName();
        name = name == null ? new DataGenerator().generateNumber(50) + "test" : name;
        Thread.currentThread().setName(name);
    }

    @Override
    public void onTestStart(ITestResult var1) {
        super.onTestStart(var1);
        String testClassName = var1.getName();
        String threadName = Thread.currentThread().getName();
        if (DriverManager.isWebDriverCreatedForThread(Thread.currentThread().getName())) {
            WebUI webDriver = DriverManager.getWebDriver(threadName);
            urls.put(testClassName, webDriver.getBrowser().getCurrentUrl());
            this.cookies.put(testClassName, webDriver.getBrowser().manage().getCookies());
        }

        configure.put(Thread.currentThread().getName(), var1.getTestContext().getPassedConfigurations().getAllMethods());
        StringBuilder name = new StringBuilder(var1.getName());
        if (var1.getParameters().length > 0) {
            name.append(" (");
            String seperator = "";
            for (Object param : var1.getParameters()) {
                name.append(seperator).append(param.toString());
                seperator = ", ";
            }
            name.append(")");
        }
        Log.info("<br><center><b> " + name + "</b></center><hr>", var1.getTestClass().getName());
    }

    @Override
    public void onTestSuccess(ITestResult var1) {
        super.onTestSuccess(var1);
        Log.info("<text style='color:green;'>PASSED</text>", var1.getTestClass().getName());
        Log.info("<hr>", var1.getTestClass().getName());
    }

    @Override
    public void onTestSkipped(ITestResult var1) {
        super.onTestSkipped(var1);
        //get a screenshot
        takeScreenshot(var1);

        Log.error("<text style='color:red;'>SKIPPED</text>", var1.getTestClass().getName());
        Log.error(var1.getThrowable().getMessage(), var1.getTestClass().getName());
        Log.info("<hr>", var1.getTestClass().getName());
    }

    @Override
    public void onTestFailure(ITestResult var1) {
        super.onTestFailure(var1);
        //get a screenshot
        takeScreenshot(var1);

        Log.error("<text style='color:red;'>FAILED</text>", var1.getTestClass().getName());
        Log.error(var1.getThrowable().getMessage(), var1.getTestClass().getName());
        Log.info("<hr>", var1.getTestClass().getName());
    }

    private void takeScreenshot(ITestResult test) {
        StringBuilder testName = new StringBuilder(test.getName() + "(");
        String seperator = "";
        for (Object param : test.getParameters()) {
            testName.append(seperator).append(param);
            seperator = ",";
        }
        testName.append(")");
        String threadName = Thread.currentThread().getName();
        try {
            Log.info("taking screenshot", getClass().getName());
            DriverManager.getWebDriver(threadName).takeScreenShot(FileWriter.getFilePath(testName.toString()) + ".png");
        } catch (NullPointerException e) {
            Log.error("Failed to take screenshot, probably something wrong with the driver", getClass().getName());
        }
    }
}
