package testHelp;

import configuration.PropertyReader;
import logs.Log;
import org.apache.commons.io.FileUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.*;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    static public void sleep(int milliseconds, String message) {
        Log.info("sleeping for " + milliseconds / 1000f + " seconds " + message, Utils.class.getName());
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    static public void sleep(int milliseconds) {
        sleep(milliseconds, "");
    }

    static public boolean waitForTrue(BooleanSupplier evaluate) {
        return waitForTrue(evaluate, defaultWaitSeconds());
    }

    static public int defaultWaitSeconds() {
        return PropertyReader.instance().getProperty("adminUrl").toLowerCase().contains("local") ?
                Integer.parseInt(PropertyReader.instance().getProperty("defaultLocalWaitSeconds")):
                Integer.parseInt(PropertyReader.instance().getProperty("defaultWaitSeconds"));
    }

    static public boolean waitForTrue(BooleanSupplier evaluate, int maxSeconds) {
        return waitForTrue(evaluate, maxSeconds, 1000);
    }

    static public String getFromClipboard() {
        String copied = "";
        try {
            copied = Toolkit.getDefaultToolkit().getSystemClipboard()
                    .getContents(null)
                    .getTransferData(DataFlavor.stringFlavor).toString();
        } catch (UnsupportedFlavorException | IOException e) {
            Log.error(e, Utils.class);
            e.printStackTrace();
        }
        return copied;
    }

    static public boolean waitForTrue(BooleanSupplier evaluate, int maxSeconds, int sleepTimeMillis) {
        boolean result;
        maxSeconds = (int) (((float)maxSeconds) / (((float)sleepTimeMillis)/1000));
        while (!(result = evaluate.getAsBoolean()) && --maxSeconds >= 0) {
            sleep(sleepTimeMillis);
        }
        return result;
    }

    static public File getResourceAsFile(String fileName) {
        File file = new File(fileName);
        URL resource = Utils.class.getClassLoader().getResource(fileName);
        try {
            FileUtils.copyURLToFile(resource, file);
        } catch (IOException e) {
            Log.error(e, Utils.class);
            e.printStackTrace();
        }

        return file;
    }

    static public File getResourceAsFile(String fileName, String newFileName) {
        File file = new File(newFileName);
        URL resource = Utils.class.getClassLoader().getResource(fileName);
        try {
            FileUtils.copyURLToFile(resource, file);
        } catch (IOException e) {
            Log.error(e, Utils.class);
            e.printStackTrace();
        }
        return file;
    }

    static public String regexStringExtractor(String original, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(original);
        if (matcher.find())
        {
            return (matcher.group(1));
        }
        return "";
    }

    static public DateTime stringToDateTime(String date, String format) {
        final DateTimeFormatter df = DateTimeFormat.forPattern(format);
        return DateTime.parse(date, df);
    }

    static public boolean isNumeric(String s) {
        return s != null && s.matches("[-+]?\\d*\\.?\\d+");
    }

    static public boolean schema(JSONObject pattern, JSONObject json) {
        return SchemaValidation.schema(pattern, json);
    }

    static public boolean schema(JSONArray pattern, JSONArray json) {
        return SchemaValidation.schema(pattern, json);
    }

    static public boolean schema(Object pattern, Object json) {
        if (pattern instanceof JSONObject && json instanceof JSONObject) {
            return schema((JSONObject) pattern, (JSONObject) json);
        } else if (pattern instanceof JSONArray && json instanceof JSONArray) {
            return schema((JSONArray) pattern, (JSONArray) json);
        } else return false;
    }

    public static String getIdFromUrl(String url) {
        String query = url.split("id=")[1];
        return query.split("&")[0];
    }

    public static double currencyConversion(String text){
        return Double.parseDouble(text.replaceAll("[^0-9\\.]", ""));
    }

    public static String getMachineTimeZone(){
        TimeZone timeZone = TimeZone.getDefault();
        String results = "";
        if(timeZone.getDisplayName().contains("Mountain")){
            if(timeZone.useDaylightTime()){
                results = "MDT";
            } else {
                results = "MST";
            }
        } else {
            if(timeZone.useDaylightTime()){
                results = "PDT";
            } else {
                results = "PST";
            }
        }
        return results;
    }

    public static Map<String, Map<String, String>> icalToMap(File ical) throws IOException {
        Map<String, Map<String, String>> results = new HashMap<>();

        //read lines
        List<String> icalLines = Files.readAllLines(ical.toPath());

        //turn lines into map and add to results
        addToResults(results, icalLineDateParse(icalLines, "DTSTART"), "startTime");
        addToResults(results, icalLineDateParse(icalLines, "DTEND"), "endTime");
        addToResults(results, icalSummaryParse(icalLines), "summary");
        addToResults(results, icalStatusParse(icalLines), "status");

        return results;
    }

    private static void addToResults(Map<String, Map<String, String>> results, List<Map<String, String>> parsed, String name) {
        for (int i = 0; i < parsed.size(); ++i) {
            results.put(name + i, parsed.get(i));
        }
    }

    private static List<Map<String, String>> icalSummaryParse(List<String> lines) {
        List<Map<String, String>> results = new ArrayList<>();

        //get line from lines
        lines.stream().
                filter((line) -> line.contains("SUMMARY")).
                forEach(l-> {
                    Map<String, String> resultLine = new HashMap<>();
                    resultLine.put("value", l.split(":")[1]);
                    results.add(resultLine);
                });

        return results;
    }

    private static List<Map<String, String>> icalStatusParse(List<String> lines) {
        List<Map<String, String>> results = new ArrayList<>();
        String status = "Status : ";

        lines.stream().
                filter((line) ->  line.contains(status)).
                forEach(l-> {
                    Map<String, String> resultLine = new HashMap<>();
                    String s = l.split(status)[1].split("-|=")[0];
                    resultLine.put("value", s);
                    results.add(resultLine);
                });

        return results;
    }

    private static List<Map<String, String>> icalLineDateParse(List<String> lines, String lineName){
        List<Map<String, String>> results = new ArrayList<>();
        int i = 0;

        //get line from lines
        lines.stream().
                filter((line) -> line.contains(lineName)).
                forEach(l->{
                    String up = l.substring(lineName.length()+1, l.length()-1).replace("T",  "");
                    HashMap<String, String> resultLine = new HashMap<String, String>();
                    resultLine.put("year", up.substring(0, 4));
                    resultLine.put("month", up.substring(4, 6));
                    resultLine.put("day", up.substring(6, 8));
                    resultLine.put("time", String.format("%s:%s", up.substring(8, 10), up.substring(10, 12)));
                    results.add(resultLine);
                });

        return results;
    }
}
