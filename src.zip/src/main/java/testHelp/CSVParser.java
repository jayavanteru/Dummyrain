package testHelp;

import logs.Log;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class CSVParser {

    /*
     * This Pattern will match on either quoted text or text between commas, including
     * whitespace, and accounting for beginning and end of line.
     */
    private final Pattern csvPattern = Pattern.compile("\"([^\"]*)\"|(?<=,|^)([^,]*)(?:,|$)");
    private final ArrayList<String[]> file;

    public CSVParser(String data) {
        file = new ArrayList<>();
        for (String row : data.split("\n")) {
            file.add(parse(row));
        }
    }

    public String[] parse(String csvLine) {
        ArrayList<String> allMatches = new ArrayList<>();
        Matcher matcher = csvPattern.matcher(csvLine);
        allMatches.clear();
        String match;
        while (matcher.find()) {
            match = matcher.group(1);
            if (match!=null) {
                allMatches.add(match);
            }
            else {
                allMatches.add(matcher.group(2));
            }
        }

        int size = allMatches.size();
        if (size > 0) {
            return allMatches.toArray(new String[size]);
        }
        else {
            return new String[0];
        }
    }

    public String getField(int row, int column) {
        return file.get(row)[column];
    }

    public static String createCsvFile(List<Map<String, String>> fileContents, String fileName) {
        if (!fileName.endsWith(".csv")) {
            fileName += ".csv";
        }

        Log.info("creating a csv file " + fileName, CSVParser.class.getName());

        File file = new File(fileName);
        if (file.exists()) file.delete();
        FileWriter fileWriter = null;
        String seperator = "";
        try {
            fileWriter = new FileWriter(file, true);

            //create the file header
            StringBuilder header = new StringBuilder();
            List<String> keys = getKeys(fileContents.get(0));
            for (String key : keys) {
                header.append(seperator).append(key);
                seperator = ",";
            }
            header.append("\n");
            //write the header to file
            fileWriter.write(header.toString());

            //create the file body
            for (Map<String, String> row : fileContents) {
                StringBuilder content = new StringBuilder();
                seperator = "";
                //get the row
                for (String key : keys) {
                    content.append(seperator).append(row.get(key));
                    seperator = ",";
                }
                //write that row to file
                content.append("\n");
                fileWriter.write(content.toString());
            }
        } catch (IOException e) {
            Log.error("problem creating the csv file", CSVParser.class.getName());
            Log.error(e.getMessage(), CSVParser.class.getName());
        } finally {
            if (fileWriter != null)
                try {
                    fileWriter.close();
                } catch (IOException e) {
                    Log.error("You've done messed up!! trying to close the csv file writer", CSVParser.class.getName());
                    Log.error(e.getMessage(), CSVParser.class.getName());
                }
        }
        return file.getAbsolutePath();
    }

    private static List<String> getKeys(Map<String, String> row) {
        return row.keySet().stream().sorted().collect(Collectors.toList());
    }
}
