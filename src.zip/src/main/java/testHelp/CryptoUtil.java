package testHelp;

import org.apache.commons.codec.binary.Hex;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class CryptoUtil
{
    private static SecretKeySpec spec = null;
    private static final byte[] keyBytes = {-89,-6,-73,-59,82,124,36,16,-39,86,-39,126,-100,79,-117,92};

    public static SecretKeySpec getKeySpec() throws IOException, NoSuchAlgorithmException
    {
        if (spec != null)
            return spec;

        spec = new SecretKeySpec(keyBytes, "AES");
        return spec;
    }

    public static String encrypt(String text)
    {
        String value = null;
        try {
            SecretKeySpec spec = getKeySpec();
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, spec);
            value = String.valueOf(Hex.encodeHex(cipher.doFinal(text.getBytes())));
        } catch (IOException | NoSuchAlgorithmException | BadPaddingException | NoSuchPaddingException | IllegalBlockSizeException | InvalidKeyException e) {
            e.printStackTrace();
        }
        return value;
    }

    public static String decrypt(String text) throws Exception
    {
        SecretKeySpec spec = getKeySpec();
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, spec);
        return new String((cipher.doFinal(Hex.decodeHex(text.toCharArray()))));
    }

    public static void main(String[] args) throws Exception
    {
        if (args.length < 2 && !args[0].equals("encode") && !args[0].equals("decode"))
        {
            System.out.println("Usage crypto [encode|decode] <text>");
            return;
        }

        boolean encode = args[0].equals("encode");
        if (encode)
            System.out.println(encrypt(args[1]));
        else
            System.out.println(decrypt(args[1]));
    }
}