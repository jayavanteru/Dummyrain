package testHelp;

import configuration.PropertyReader;
import logs.Log;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

public class SeleniumHelpers {

    public DataGenerator data = new DataGenerator();

    public void waitForPageChange(WebDriver browser) {
        String currentPage = browser.getPageSource();
        //wait for 10 seconds
        int tries = 10;
        while (currentPage.equals(browser.getPageSource()) && tries-- > 0) {
            Log.info("Waiting for page to load", getClass().getName());
            Utils.sleep(1000);
        }
    }

    public void waitForAndClick(WebDriver browser, By identifier) {
        Wait wait = new WebDriverWait(browser, 10);
        waitForElementExists(browser, identifier);
        wait.until((el)-> browser.findElements(identifier).size() > 0 && browser.findElement(identifier).isEnabled());
        browser.findElement(identifier).click();
    }

    public WebElement waitForElementExists(WebDriver driver, By identifier) {
        int waitSeconds = 5;
        while (driver.findElements(identifier).size() < 1 && waitSeconds-- > 0) {
            Log.info("Watiing for element to exist", getClass().getName());
            Utils.sleep(1000);
        }
        return driver.findElement(identifier);
    }

    public void waitForElementNotExists(WebDriver driver, By identifier) {
        setWaitTime(driver, 10L, TimeUnit.MILLISECONDS);
        int waitSeconds = 5;
        while (driver.findElements(identifier).size() > 1 && waitSeconds-- > 0) {
            Log.info("Waiting for element to not exist", getClass().getName());
            Utils.sleep(1000);
        }
        resetImplicitWait(driver);
    }

    public void waitForNotLoading(WebDriver browser) {
        int waitSeconds = 15;
        while (browser.findElements(By.className("ajax-loading-animation")).size() > 0 && waitSeconds-- > 0) {
            Utils.sleep(1000);
        }
    }

    public void waitForUrlChange(WebDriver browser, String endOfUrl) {
        int waitFor = 20;
        Log.info("Waiting for url to change", getClass().getName());
        while (--waitFor > 0 && browser.getCurrentUrl().endsWith(endOfUrl))
            Utils.sleep(200);
    }

    public void resetImplicitWait(WebDriver driver) {
        long implicitWaitSeconds = Long.parseLong(PropertyReader.instance().getProperty("implicitWaitSeconds"));
        driver.manage().timeouts().implicitlyWait(implicitWaitSeconds, TimeUnit.SECONDS);
    }

    public void setWaitTime(WebDriver driver, Long time, TimeUnit unit) {
        driver.manage().timeouts().implicitlyWait(time, unit);
    }

    public void changeAttribute(WebDriver driver, By searcher, String attributeName, String attributeValue) {
        List<WebElement> elements = driver.findElements(searcher);
        for (WebElement el : elements) {
            ((JavascriptExecutor)driver).executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                    el, attributeName, attributeValue);
        }
    }

    public boolean waitTillTrue(WebDriver driver, Predicate <WebDriver>func, int maxseconds) {
        //five second timeout, half a second retries
        int maxTime = maxseconds * 2;
        while (!func.test(driver) && maxTime-- > 0) {
            Utils.sleep(500);
        }
        return func.test(driver);
    }

    public boolean waitTillTrue(WebDriver driver, Predicate <WebDriver>func) {
        //five second timeout, half a second retries
        return waitTillTrue(driver, func, 5);
    }

    public void scrollToElement(WebDriver driver, WebElement el) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);
        Utils.sleep(100);
    }

    public boolean isElementExist(WebDriver browser, By element) {
        return browser.findElements(element).size() > 0;
    }

    public void scrollAndClick(WebDriver driver, WebElement element) {
        try {
            element.click();
        } catch (WebDriverException e) {
            scrollDown(driver);
            element.click();
        }
    }

    public void scrollDown(WebDriver driver) {
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ARROW_DOWN).perform();
        Utils.sleep(100); // let the scroll complete
    }

    public void scrollUp(WebDriver driver) {
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.ARROW_UP).perform();
        Utils.sleep(100); // let the scroll complete
    }

    public void backspace(WebDriver driver) {
        final int backspaceCount = 20;
        Keys[] actions = new Keys[backspaceCount];
        for (int i = 0; i < backspaceCount; ++i) {
            actions[i] = Keys.BACK_SPACE;
        }
        Actions keyboardAction = new Actions(driver);
        keyboardAction.sendKeys(actions).perform();
    }

    public void sendKeys(WebDriver driver, String keys) {
        Actions keyboardAction = new Actions(driver);
        keyboardAction.sendKeys(keys).perform();
    }

    public void sendKeys(WebDriver driver, Keys... keys) {
        Actions keyboardAction = new Actions(driver);
        keyboardAction.sendKeys(keys).perform();
    }

    public void scrollToTopOfPage(WebDriver driver) {
        executeJavascript(driver, "window.scrollTo(0, 0);");
    }

    public void executeJavascript(WebDriver driver, String script) {
        ((JavascriptExecutor)driver).executeScript(script);
    }

    public void switchToTab(WebDriver driver, int tabIndex) {
        ArrayList<String> windowHandles = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(windowHandles.get(tabIndex));
    }

    public boolean isElementsDisplayed(WebDriver driver, By... identifiers) {
        boolean displayed = true;
        for (By id : identifiers) {
            displayed = displayed && driver.findElement(id).isDisplayed();
        }
        return displayed;
    }
    public void clickDismiss (WebDriver driver){
        By clickDismiss = By.cssSelector(".cc_dismiss , .cc-dismiss , #_evidon_banner svg");
        if (driver.findElements(clickDismiss).size() > 0
                && driver.findElement(clickDismiss).isDisplayed()) {
            new WebDriverWait(driver, 5).until(ExpectedConditions.elementToBeClickable(clickDismiss));
            driver.findElement(clickDismiss).click();
            Utils.sleep(1000, "wait for the cookie warning to go away");
        }
    }

    public void searchDropDownList(WebDriver driver, String search) {
        By searchField = By.cssSelector("[data-test='dropdown-input']");
        WebElement el = driver.findElement(searchField);
        el.clear();
        el.sendKeys(search);
    }

    public boolean isDropDownOpen(WebDriver driver) {
        By searchField = By.cssSelector("[data-test='dropdown-input']");
        return driver.findElements(searchField).size() > 0;
    }

    public void waitForElementExists(WebDriver browser, WebElement webElement) {
    }
}
