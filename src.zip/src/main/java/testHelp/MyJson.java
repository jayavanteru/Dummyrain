package testHelp;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.datatype.joda.JodaMapper;
import logs.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class MyJson {

    public static void verifyNotNull(Object object) {
        if (object == null) {
            Log.error("null json object", MyJson.class.getName());
        }
    }

    public static JSONObject createJSON(String jsonString) {
        JSONObject json = null;
        try {
            json = new JSONObject(jsonString);
        } catch (JSONException e) {
        }
        return json;
    }

    public static JSONArray createJSONArray(String jsonString) {
        JSONArray json = null;
        try {
            json = new JSONArray(jsonString);
        } catch (JSONException e) {
        }
        return json;
    }

    public static JSONObject put(JSONObject jsonObject, String key, String value) {
        verifyNotNull(jsonObject);
        try {
            jsonObject.put(key, value);
        } catch (JSONException e) {
        }
        return jsonObject;
    }

    public static String getString(JSONObject jsonObject, String key) {
        verifyNotNull(jsonObject);
        String value = null;
        try {
            value = jsonObject.getString(key);
        } catch (JSONException e) {
        }
        return value;
    }

    public static JSONObject getJSONObject(JSONObject jsonObject, String key) {
        verifyNotNull(jsonObject);
        JSONObject value = null;
        try {
            value = jsonObject.getJSONObject(key);
        } catch (JSONException e) {
        }
        return value;
    }

    public static JSONObject getJSONObject(JSONArray jsonObject, int key) {
        verifyNotNull(jsonObject);
        JSONObject value = null;
        try {
            value = jsonObject.getJSONObject(key);
        } catch (JSONException e) {
        }
        return value;
    }

    public static <R> R convertToObject(JSONObject json, Class<R> type) {
        verifyNotNull(json);
        R mapped = null;
        JodaMapper mapper = new JodaMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);

        try {
            mapped = mapper.readValue(json.toString(), type);
        } catch (IOException var5) {
            var5.printStackTrace();
        }
        return mapped;
    }

    public static <R> ArrayList<R> convertToObject(JSONArray jsonArray, Class<R> type) {
        ArrayList<R> results = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); ++i) {
            results.add((R)convertToObject(MyJson.getJSONArray(jsonArray, i), type));
        }
        return results;
    }

    public static JSONArray getJSONArray(JSONObject jsonObject, String key) {
        verifyNotNull(jsonObject);
        JSONArray json = null;
        try {
            json = jsonObject.getJSONArray(key);
        } catch (JSONException e) {
        }
        return json;
    }

    public static JSONArray getJSONArray(JSONArray jsonObject, int key) {
        verifyNotNull(jsonObject);
        JSONArray json = null;
        try {
            json = jsonObject.getJSONArray(key);
        } catch (JSONException e) {
        }
        return json;
    }

    public static int getInt(JSONObject response, String key) {
        verifyNotNull(response);
        int value = -1;
        try {
            value = response.getInt(key);
        } catch (JSONException e) {}
        return value;
    }
}
